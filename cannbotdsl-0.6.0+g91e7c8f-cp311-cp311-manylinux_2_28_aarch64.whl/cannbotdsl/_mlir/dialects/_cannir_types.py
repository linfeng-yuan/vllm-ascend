# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Public CANNIR type extensions.

This module owns Python-tree conversion and type caster registration.  The
native extension remains an unmodified, low-level binding whose recursive type
getters accept ``(elements, value)``.
"""

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir._mlir_libs import _cannir as _cext


class _ReadOnlyConstantsMeta(type(_cext.ShapeType)):
    """Keep sentinel values stable after a public type class is created."""

    _CONSTANT_NAMES = frozenset({"DYNAMIC", "KEEP"})

    def __setattr__(cls, name, value):
        if name in cls._CONSTANT_NAMES and hasattr(cls, name):
            raise AttributeError(f"{cls.__name__}.{name} is read-only")
        super().__setattr__(name, value)

    def __delattr__(cls, name):
        if name in cls._CONSTANT_NAMES and hasattr(cls, name):
            raise AttributeError(f"{cls.__name__}.{name} is read-only")
        super().__delattr__(name)


def _resolve_context(context):
    return ir.Context.current if context is None else context


def _convert_tree_type(
    value,
    *,
    context,
    path,
    kind,
    public_type,
    native_type,
    type_predicate,
    allow_none=False,
):
    """Convert a Python integer tree into one recursive native CANNIR type."""

    if isinstance(value, (list, tuple)):
        elements = [
            _convert_tree_type(
                element,
                context=context,
                path=f"{path}[{index}]",
                kind=kind,
                public_type=public_type,
                native_type=native_type,
                type_predicate=type_predicate,
                allow_none=allow_none,
            )
            for index, element in enumerate(value)
        ]
        return public_type(native_type.get(elements, 0, context=context))

    if allow_none and value is None:
        value = public_type.KEEP

    if isinstance(value, bool):
        raise TypeError(f"Unsupported {kind} value at {path}: {value!r} (bool is not an integer leaf)")

    if isinstance(value, int):
        return public_type(native_type.get([], value, context=context))

    if isinstance(value, ir.Type):
        if not type_predicate(value):
            raise TypeError(f"Expected a {kind} type at {path}, got {value} (type={type(value).__name__})")
        if value.context != context:
            raise ValueError(f"{kind} type at {path} belongs to a different MLIR Context")
        return public_type(value)

    raise TypeError(f"Unsupported {kind} value at {path}: {value!r} (type={type(value).__name__})")


class _TreeTypeMixin:
    @classmethod
    def get(cls, tree, *, context=None):
        context = _resolve_context(context)
        return _convert_tree_type(
            tree,
            context=context,
            path=cls._TREE_KIND,
            kind=cls._TREE_KIND,
            public_type=cls,
            native_type=cls._NATIVE_TYPE,
            type_predicate=cls._TYPE_PREDICATE,
            allow_none=cls._ALLOW_NONE,
        )


@ir.register_type_caster(_cext.ShapeType.get_static_typeid(), replace=True)
class ShapeType(_TreeTypeMixin, _cext.ShapeType, metaclass=_ReadOnlyConstantsMeta):
    DYNAMIC = -1
    _TREE_KIND = "shape"
    _NATIVE_TYPE = _cext.ShapeType
    _TYPE_PREDICATE = staticmethod(_cext.cannirTypeIsAShape)
    _ALLOW_NONE = False


@ir.register_type_caster(_cext.StrideType.get_static_typeid(), replace=True)
class StrideType(_TreeTypeMixin, _cext.StrideType, metaclass=_ReadOnlyConstantsMeta):
    DYNAMIC = -1
    _TREE_KIND = "stride"
    _NATIVE_TYPE = _cext.StrideType
    _TYPE_PREDICATE = staticmethod(_cext.cannirTypeIsAStride)
    _ALLOW_NONE = False


@ir.register_type_caster(_cext.TileType.get_static_typeid(), replace=True)
class TileType(_TreeTypeMixin, _cext.TileType, metaclass=_ReadOnlyConstantsMeta):
    DYNAMIC = -1
    _TREE_KIND = "tile"
    _NATIVE_TYPE = _cext.TileType
    _TYPE_PREDICATE = staticmethod(_cext.cannirTypeIsATile)
    _ALLOW_NONE = False

    @classmethod
    def get(cls, tree, alignment=None, *, context=None):
        """Create a tile type, optionally declaring per-leaf alignment.

        ``alignment`` is a flat sequence (or a broadcast scalar) with one
        positive entry per flattened leaf. ``None`` leaves the alignment
        undeclared; ``1`` declares a leaf as unconstrained.
        """

        context = _resolve_context(context)
        result = _convert_tree_type(
            tree,
            context=context,
            path=cls._TREE_KIND,
            kind=cls._TREE_KIND,
            public_type=cls,
            native_type=cls._NATIVE_TYPE,
            type_predicate=cls._TYPE_PREDICATE,
            allow_none=cls._ALLOW_NONE,
        )
        if alignment is None:
            return result
        if isinstance(alignment, int) and not isinstance(alignment, bool):
            alignment = (alignment,)

        def _count_leaves(node):
            if isinstance(node, (list, tuple)):
                return sum(_count_leaves(child) for child in node)
            return 1

        if isinstance(alignment, (list, tuple)):
            flat = list(alignment)
        else:
            raise TypeError(
                f"tile alignment must be an int or a sequence of ints, got "
                f"{type(alignment).__name__}"
            )
        for index, entry in enumerate(flat):
            if isinstance(entry, bool) or not isinstance(entry, int):
                raise TypeError(
                    f"tile alignment leaf {index} must be an int, got "
                    f"{type(entry).__name__}"
                )
            if entry <= 0:
                raise ValueError(
                    f"tile alignment leaf {index} must be positive, got {entry}"
                )
        leaf_count = _count_leaves(tree)
        if len(flat) == 1 and leaf_count > 1:
            flat = flat * leaf_count
        if len(flat) != leaf_count:
            raise ValueError(
                f"tile alignment rank ({len(flat)}) must match the flattened "
                f"leaf count ({leaf_count})"
            )
        elements = [] if result.is_scalar else list(result.elements)
        return cls(
            cls._NATIVE_TYPE.get_with_alignment(
                elements, result.value, flat, context=context
            )
        )


@ir.register_type_caster(_cext.CoordType.get_static_typeid(), replace=True)
class CoordType(_TreeTypeMixin, _cext.CoordType, metaclass=_ReadOnlyConstantsMeta):
    DYNAMIC = -1
    KEEP = -2
    _TREE_KIND = "coord"
    _NATIVE_TYPE = _cext.CoordType
    _TYPE_PREDICATE = staticmethod(_cext.cannirTypeIsACoord)
    _ALLOW_NONE = True


@ir.register_type_caster(_cext.LayoutType.get_static_typeid(), replace=True)
class LayoutType(_cext.LayoutType):
    @classmethod
    def get_checked(cls, shape, stride, *, context=None):
        """Create a layout, returning ``None`` only for verifier failures."""

        context = _resolve_context(context)
        shape_type = ShapeType.get(shape, context=context)
        stride_type = StrideType.get(stride, context=context)
        result = _cext.LayoutType.get_checked(shape_type, stride_type, context=context)
        return None if result is None else cls(result)

    @classmethod
    def get(cls, shape, stride, *, context=None):
        """Create a verified layout from shape and stride trees."""

        result = cls.get_checked(shape, stride, context=context)
        if result is not None:
            return result

        resolved_context = _resolve_context(context)
        shape_type = ShapeType.get(shape, context=resolved_context)
        stride_type = StrideType.get(stride, context=resolved_context)
        raise ValueError(
            "Failed to verify LayoutType for "
            f"shape={shape_type.as_tuple!r}, stride={stride_type.as_tuple!r}. "
            f"Original input: shape={shape!r}, stride={stride!r}. "
            "See MLIR diagnostic for details."
        )


__all__ = ["ShapeType", "StrideType", "TileType", "CoordType", "LayoutType"]
