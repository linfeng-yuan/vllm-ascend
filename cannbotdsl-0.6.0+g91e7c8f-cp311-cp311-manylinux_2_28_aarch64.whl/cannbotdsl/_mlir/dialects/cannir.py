# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Public Python facade for the CANNIR dialect.

Import CANNIR types, operations, and native capabilities from this module.  The
private sibling modules contain implementation details and are not API.
"""

from cannbotdsl._mlir._mlir_libs import _cannir as _cext

from . import _cannir_ops_gen as _ops_gen


_GENERATED_PUBLIC = {name for name in vars(_ops_gen) if not name.startswith("_") and name != "builtins"}
_NATIVE_PUBLIC = {name for name in dir(_cext) if not name.startswith("_")}

for _name in _GENERATED_PUBLIC:
    globals()[_name] = getattr(_ops_gen, _name)
for _name in _NATIVE_PUBLIC:
    globals()[_name] = getattr(_cext, _name)

from ._cannir_types import (  # noqa: E402, F401 - public re-exports
    CoordType,
    LayoutType,
    ShapeType,
    StrideType,
    TileType,
)
from ._cannir_ops_ext import (  # noqa: E402, F401 - public re-exports
    MakeCoordOp,
    MakeShapeOp,
    MakeStrideOp,
    MakeTileOp,
    make_coord,
    make_shape,
    make_stride,
    make_tile,
)


__all__ = sorted(_GENERATED_PUBLIC | _NATIVE_PUBLIC)

del _name
