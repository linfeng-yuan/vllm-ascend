# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""CANNIR operation extensions for dynamic integer-tree operands."""

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import arith

from . import _cannir_ops_gen as _ops_gen
from ._ods_common import (
    _cext as _ods_cext,
    get_op_result_or_op_results as _get_op_result_or_op_results,
    get_op_results_or_values as _get_op_results_or_values,
)


def _normalize_dynamic_values(res, dynamic_values, *, loc, ip):
    values = _get_op_results_or_values(dynamic_values)
    i64_type = ir.IntegerType.get_signless(64, context=res.context)
    normalized = []
    for index, value in enumerate(values):
        value_type = value.type
        if isinstance(value_type, ir.IndexType):
            normalized.append(arith.index_cast(i64_type, value, loc=loc, ip=ip))
            continue
        if isinstance(value_type, ir.IntegerType) and value_type.width == 64 and value_type.is_signless:
            normalized.append(value)
            continue
        raise TypeError(f"dynamic_values[{index}] must have index or signless i64 type, got {value_type}")
    return normalized


@_ods_cext.register_operation(_ops_gen._Dialect, replace=True)
class MakeShapeOp(_ops_gen.MakeShapeOp):
    def __init__(self, res, dynamic_values, *, loc=None, ip=None):
        super().__init__(
            res,
            _normalize_dynamic_values(res, dynamic_values, loc=loc, ip=ip),
            loc=loc,
            ip=ip,
        )


@_ods_cext.register_operation(_ops_gen._Dialect, replace=True)
class MakeStrideOp(_ops_gen.MakeStrideOp):
    def __init__(self, res, dynamic_values, *, loc=None, ip=None):
        super().__init__(
            res,
            _normalize_dynamic_values(res, dynamic_values, loc=loc, ip=ip),
            loc=loc,
            ip=ip,
        )


@_ods_cext.register_operation(_ops_gen._Dialect, replace=True)
class MakeTileOp(_ops_gen.MakeTileOp):
    def __init__(self, res, dynamic_values, *, loc=None, ip=None):
        super().__init__(
            res,
            _normalize_dynamic_values(res, dynamic_values, loc=loc, ip=ip),
            loc=loc,
            ip=ip,
        )


@_ods_cext.register_operation(_ops_gen._Dialect, replace=True)
class MakeCoordOp(_ops_gen.MakeCoordOp):
    def __init__(self, res, dynamic_values, *, loc=None, ip=None):
        super().__init__(
            res,
            _normalize_dynamic_values(res, dynamic_values, loc=loc, ip=ip),
            loc=loc,
            ip=ip,
        )


def make_shape(res, dynamic_values, *, loc=None, ip=None) -> ir.Value:
    return _get_op_result_or_op_results(MakeShapeOp(res, dynamic_values, loc=loc, ip=ip))


def make_stride(res, dynamic_values, *, loc=None, ip=None) -> ir.Value:
    return _get_op_result_or_op_results(MakeStrideOp(res, dynamic_values, loc=loc, ip=ip))


def make_tile(res, dynamic_values, *, loc=None, ip=None) -> ir.Value:
    return _get_op_result_or_op_results(MakeTileOp(res, dynamic_values, loc=loc, ip=ip))


def make_coord(res, dynamic_values, *, loc=None, ip=None) -> ir.Value:
    return _get_op_result_or_op_results(MakeCoordOp(res, dynamic_values, loc=loc, ip=ip))


__all__ = [
    "MakeShapeOp",
    "MakeStrideOp",
    "MakeTileOp",
    "MakeCoordOp",
    "make_shape",
    "make_stride",
    "make_tile",
    "make_coord",
]
