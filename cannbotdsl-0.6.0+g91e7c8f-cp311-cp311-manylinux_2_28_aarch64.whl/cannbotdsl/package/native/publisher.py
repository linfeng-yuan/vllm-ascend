# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# Licensed under the CANN Open Software License Agreement Version 2.0.
"""Register collector functions and export relocatable Native artifacts."""
from contextlib import contextmanager
import ast
import hashlib
import importlib
import importlib.util
import inspect
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import threading
import types

from . import runtime as native_binary

__all__ = ['register', 'collect', 'build']
_NAME = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]*\Z')
_session_lock = threading.Lock()


def _name(value):
    if not isinstance(value, str) or not _NAME.fullmatch(value) or value in ('.', '..'):
        raise ValueError(f'invalid Native package/task name: {value!r}')
    return value


def _json(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode()


def _sha(value):
    return hashlib.sha256(value).hexdigest()


def register(name):
    """Mark a no-argument function; importing a collector never invokes it."""
    _name(name)
    def decorate(function):
        if not inspect.isfunction(function) or inspect.iscoroutinefunction(function):
            raise TypeError('Native collector must be a synchronous function')
        if inspect.signature(function).parameters:
            raise TypeError('Native collector takes no arguments')
        if hasattr(function, '__cannbotdsl_native_task__'):
            raise ValueError('Native collector already registered')
        function.__cannbotdsl_native_task__ = name
        return function
    return decorate


class _Collection:
    def __init__(self, target):
        if target not in ('dav-2201', 'dav-3510'):
            raise ValueError('Native collection requires dav-2201 or dav-3510 target')
        self.target = target
        self.task = 'default'
        self.records, self.tasks = {}, {}
        self._temp = tempfile.TemporaryDirectory(prefix='cannbotdsl-collect-')
        self._ready = False
        self._thread = threading.get_ident()
        self._pid = os.getpid()

    def record(self, artifact, function):
        if threading.get_ident() != self._thread or os.getpid() != self._pid:
            raise RuntimeError('Native collection supports one thread/process')
        if not artifact.so_path or not artifact.content_key or not artifact.binary_key or artifact.debug_plans:
            raise native_binary.NativeBinaryError('collection requires a persistent, content-addressed Provider')
        from cannbotdsl.core.compiler.metadata import publish_artifact
        key = artifact.binary_key
        source = {'function': function.__qualname__, 'module': function.__module__, 'mode': 'aot'}
        task = self.tasks.setdefault(self.task, {'requests': 0, 'artifacts': [], 'sources': []})
        task['requests'] += 1
        if source not in task['sources']:
            task['sources'].append(source)
        if key not in task['artifacts']:
            task['artifacts'].append(key)
        directory = Path(self._temp.name) / key
        directory.mkdir(exist_ok=True)
        destination = directory / 'provider.so'
        if key not in self.records:
            publish_artifact(artifact.so_path, str(destination), artifact.symbol_name, artifact.contract,
                             host_abi_version=artifact.host_abi_version, content_key=artifact.content_key,
                             format_version_tag=artifact.format_version_tag)
            from cannbotdsl.core.compiler.binary_key import build_provenance, host_platform
            self.records[key] = {'directory': directory, 'owner': self.task,
                'descriptor': {
                    'binary_key_schema': artifact.binary_key_schema, 'binary_key': key,
                    'target': self.target, 'host_platform': host_platform(), 'python_abi': None,
                    'key_inputs': artifact.binary_key_inputs,
                    'build_provenance': dict(build_provenance(), cache_key=artifact.content_key,
                                            cache_format_tag=artifact.format_version_tag)}}
        else:
            # Same key with different bytes is an identity conflict, never an overwrite.
            from cannbotdsl.core.compiler.metadata import parse_metadata
            from cannbotdsl.core.contracts.codec import contract_digest
            symbol, contract, abi, digest, _, _ = parse_metadata(
                json.loads(Path(str(destination) + '.meta.json').read_bytes()))
            if (digest != _sha(Path(artifact.so_path).read_bytes()) or
                    symbol != artifact.symbol_name or abi != artifact.host_abi_version or
                    contract_digest(contract) != contract_digest(artifact.contract)):
                raise native_binary.NativeBinaryError('different binaries produced the same binary key')

    def _package_files(self):
        """Create the backend-independent, artifact-root-relative layout."""
        if not self._ready or not self.records:
            raise RuntimeError('Native package requires a completed, nonempty collection')
        from cannbotdsl.core.compiler.binary_key import BINARY_KEY_SCHEMA
        from cannbotdsl.core.compiler.abi import HOST_ABI_VERSION
        files, index = {}, {}
        for key, record in sorted(self.records.items()):
            base = f'operators/{record["owner"]}/variants/{key}'
            binary, sidecar = base + '/provider.so', base + '/provider.so.meta.json'
            files[binary] = (record['directory'] / 'provider.so').read_bytes()
            files[sidecar] = (record['directory'] / 'provider.so.meta.json').read_bytes()
            descriptor = base + '/variant.json'
            files[descriptor] = _json(dict(record['descriptor'], binary=binary, sidecar=sidecar))
            index[key] = {'descriptor': descriptor}
        for name, task in sorted(self.tasks.items()):
            info = dict(task, name=name, variants={key: index[key] for key in sorted(task['artifacts'])})
            files[f'operators/{name}/operator.json'] = _json(info)
        index_path = 'index.json'
        files[index_path] = _json(index)
        manifest_path = 'manifest.json'
        files[manifest_path] = _json({'schema_version': native_binary.SCHEMA, 'target': self.target, 'binary_key_schema': BINARY_KEY_SCHEMA,
            'host_abi_version': HOST_ABI_VERSION, 'index': index_path,
            'files': {name: _sha(data) for name, data in sorted(files.items())}})
        return files

    def build_directory(self, output):
        """Atomically export to the exact output path; never overwrite it."""
        from .storage import publish_path
        files = self._package_files()
        output = Path(output).absolute()
        output.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='.native-artifacts-', dir=output.parent) as temp:
            staged = Path(temp) / 'artifacts'
            staged.mkdir()
            for relative, data in sorted(files.items()):
                destination = staged / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
            publish_path(staged, output)
        return output


@contextmanager
def collect(*, target):
    """Collect explicit compile requests; no changes to user return values."""
    if not _session_lock.acquire(blocking=False):
        raise RuntimeError('nested/concurrent Native collection is unsupported')
    session = None
    token = None
    previous_target = os.environ.get("CANNBOTDSL_NPU_ARCH")
    try:
        session = _Collection(target)
        token = native_binary.COLLECTOR.set(session)
        os.environ["CANNBOTDSL_NPU_ARCH"] = target
        native_binary.COLLECTION_OWNER = (os.getpid(), threading.get_ident())
        yield session
        session._ready = True
    finally:
        native_binary.COLLECTION_OWNER = None
        if previous_target is None:
            os.environ.pop("CANNBOTDSL_NPU_ARCH", None)
        else:
            os.environ["CANNBOTDSL_NPU_ARCH"] = previous_target
        if token is not None:
            native_binary.COLLECTOR.reset(token)
        _session_lock.release()
        if session is not None and not session._ready:
            session._temp.cleanup()


def _declares_registration(source):
    """Find explicit register calls without executing unrelated Python files.

    Registration may be inline in an operator module or in a separate file.
    Recognize direct/qualified calls, import aliases and simple alias assignments;
    actual callable tags are checked after import, never inferred from the AST.
    """
    tree = ast.parse(source.read_bytes(), filename=str(source))
    names = {'register'}
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            names.update(alias.asname or alias.name for alias in node.names
                         if alias.name == 'register')
    def is_register(node):
        return ((isinstance(node, ast.Name) and node.id in names) or
                (isinstance(node, ast.Attribute) and node.attr == 'register'))
    changed = True
    while changed:
        changed = False
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and is_register(node.value):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id not in names:
                        names.add(target.id)
                        changed = True
    return any(isinstance(node, ast.Call) and is_register(node.func)
               for node in ast.walk(tree))


def build(*, collectors, target, output, operators=None, pattern="*.py"):
    """Discover marked functions in matching Python files, then collect tasks.

    Scan declarations before importing candidate modules in a fresh private
    namespace, supporting relative imports
    without a process-global registration table. Imported top-level Python code
    executes normally; collector modules must keep compilation in marked functions.
    """
    if not isinstance(pattern, str) or not pattern.endswith(".py") or "/" in pattern or "\\" in pattern:
        raise ValueError("pattern must be a Python filename pattern, e.g. collect.py")
    root = Path(collectors).resolve(strict=True)
    if not root.is_dir():
        raise ValueError('collectors must be a directory')
    tasks = {}
    namespace = '_cannbot_collect_' + hashlib.sha256(os.urandom(32)).hexdigest()[:16]
    before = set(sys.modules)
    try:
        init = root / '__init__.py'
        if init.exists():
            spec = importlib.util.spec_from_file_location(namespace, init, submodule_search_locations=[str(root)])
            module = importlib.util.module_from_spec(spec)
            sys.modules[namespace] = module
            spec.loader.exec_module(module)
        else:
            module = types.ModuleType(namespace)
            module.__path__ = [str(root)]
            sys.modules[namespace] = module
        modules = [module]
        for source in sorted(root.rglob(pattern)):
            relative = source.relative_to(root)
            if any(part.startswith('.') or part == '__pycache__' for part in relative.parts):
                continue
            try:
                declared = _declares_registration(source)
            except SyntaxError as exc:
                # Preserve SyntaxError location fields and the original cause.
                # Skipping could silently omit an operator from the export.
                message = (f'Native collector discovery failed while parsing {source}; '
                           f'scan root: {root}, pattern: {pattern!r}: {exc.msg}')
                raise SyntaxError(message, (exc.filename, exc.lineno, exc.offset,
                                           exc.text, exc.end_lineno, exc.end_offset)) from exc
            if not declared:
                continue
            parts = list(relative.with_suffix('').parts)
            if parts[-1] == '__init__':
                parts.pop()
            if not parts:
                continue
            if not all(part.isidentifier() for part in parts):
                raise ValueError(f'collector path is not a Python module: {relative}')
            modules.append(importlib.import_module(namespace + '.' + '.'.join(parts)))
        for module in modules:
            for function in vars(module).values():
                if not inspect.isfunction(function) or function.__module__ != module.__name__:
                    continue
                task = getattr(function, '__cannbotdsl_native_task__', None)
                if task is None:
                    continue
                if task in tasks and tasks[task] is not function:
                    raise ValueError(f'duplicate Native task: {task}')
                tasks[task] = function
        selected = sorted(tasks) if operators is None else list(operators)
        if not selected or len(set(selected)) != len(selected) or any(task not in tasks for task in selected):
            raise ValueError('empty, duplicate or unknown Native task selection')
        with collect(target=target) as session:
            for task in selected:
                session.task = task
                tasks[task]()
                if task not in session.tasks:
                    raise RuntimeError(f'Native task collected no Provider: {task}')
        return session.build_directory(output)
    finally:
        for module_name in set(sys.modules) - before:
            if module_name == namespace or module_name.startswith(namespace + '.'):
                sys.modules.pop(module_name, None)
