# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Matrix multiplication.

Split out of the former flat ``cannbotdsl/math.py``: matmul is a compute
paradigm of its own (cube unit / L0C, its own precision modes in
``cannbotdsl.ops.cube``) rather than an elementwise tensor op.
"""

from __future__ import annotations

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.core.scalar_conversion import coerce_scalar_value
from cannbotdsl.ops._operands import _tensor_operand
from cannbotdsl.tensor import Tensor


def matmul(
    dst: Tensor,
    lhs: Tensor,
    rhs: Tensor,
    *,
    bias: Tensor | None = None,
    init=True,
    unit_flag: int = 0,
    disable_gemv: bool = True,
):
    """Matrix multiplication with optional row bias.

    With ``bias=None``, computes ``dst = lhs @ rhs`` (or accumulates into
    ``dst`` if ``init=False``). With ``bias`` present and initialization
    enabled, computes ``dst = lhs @ rhs + bias`` and broadcasts the rank-1
    ``[N]`` bias over M. ``bias`` must reside in ``MemLoc.BIAS``; load it from
    an L1 fp16/bf16/fp32 buffer for float32 bias, or an L1 int32 buffer for
    int32 bias, with ``mem_copy`` before calling ``matmul``.

    FP8 inputs use regular ``asc_mmad`` when neither L0 input has an MX scale
    binding. If both inputs were loaded with
    ``mem_copy(l0_data, l1_data, mx_scale=l1_scale)``, matmul automatically
    uses OCP MXFP8. A scale binding on only one input is rejected.

    ``init`` accepts a Python bool or any SSA i1 expression. The operator owns
    the initial L0C value and the correctness of this choice; the compiler
    does not require a first-iteration predicate or a particular loop shape.
    It preserves the boolean choice between initialization (including Bias)
    and accumulation. Accumulation still reads and writes L0C.

    On the current dav-3510 target, consecutive MMAD accumulations do not
    require an additional PIPE_M barrier, regardless of tile size. A/B/Bias
    initialization checks and cross-pipeline synchronization remain in effect.

    ``unit_flag`` may likewise be either a compile-time integer or a scalar SSA
    integer. Dynamic values are converted to i32 and forwarded directly to the
    hardware MMAD operand; static integers retain the legacy attribute path.

    M, N and K come from the operand **views** and there are deliberately no
    ``actual_m`` / ``actual_n`` / ``actual_k`` overrides. A tail block is
    expressed by giving this op the *view* that declares its real extent, so one
    shape drives the L1->L0 copies, this instruction and the fixpipe together::

        av = reinterpret(l1a, shape=(m, D), offset=0)  # runtime m is fine
        bv = reinterpret(l1b, shape=(n, D), offset=0)
        mem_copy(reinterpret(l0a, shape=(m, D), offset=0), av)
        mem_copy(reinterpret(l0b, shape=(n, D), offset=0), bv)
        matmul(l0c, reinterpret(l0a, shape=(m, D), offset=0),
                     reinterpret(l0b, shape=(n, D), offset=0))

    Two things to watch. First, the extent follows the operand's **defining
    op**: slicing only a copy's source leaves this op's operand a plain buffer,
    which resolves to the declared tile -- the whole static tile, which is why
    the raw L1->L0 escape hatch path needed a whole-slot zero-fill (issue #81
    §4). The slice has to be the operand *here*. Second, N additionally has to
    agree with the N-fractal frame the L1->L0 copy produced, because the mmad
    *derives* that frame from the n it is handed (``ceil(n/N0)`` fractals, K1
    step ``N1*N0*C0``); an override that disagreed would make the instruction
    walk its K blocks at the wrong stride, which is silently wrong -- measured
    on dav-3510, uncorrelated with the reference, neither shifted nor a column
    permutation, and wrong at aligned n too (16 and 32 against a 4-fractal copy).
    Both instructions reading the same view is what keeps them consistent.

    The mmad does take an actual, runtime, **unrounded** n -- the tail path hands
    it one and is numerically exact on hardware (``test_matmul_tail_npu.py``:
    the copy is stepped by ``ceil(rows/16)`` fractals while the mmad is handed
    the unrounded ``rows``), and neither extent needs 16/C0 alignment: measured
    exact on dav-3510 for m in 4/8/12/16 and k in 160/168/176/184/192.

    **MX K tails** (issue #70).  ``asc_mmad_mx`` walks the L0A_MX/L0B_MX scale
    frame at the pair count derived from the mmad's K, so the scale frame must
    carry exactly ``ceil(K / 64)`` pairs per outer fractal -- the lowering
    programs it from the paired *data* load, not from the scale view's own
    width.  Two consequences for a K tail below the declared L0 window:

    * narrow the **data** operands with the same *runtime* extent (the view
      form above, or a dynamic GM tile that ``infer-layout`` narrows) and leave
      the MX scale views at their declared window width -- the extra scale pairs
      are simply never consumed.  A *static* narrowed data view has no such
      form yet: the data/scale actual-shape check requires a static scale
      ``2 * ceil(K / 64)``, and the narrowed scale view that asks for is exactly
      the corrupting shape below;
    * do **not** narrow a scale view below the width its GM->L1 fill wrote:
      the L1 scale grid keeps the fill's pitch, so a narrowed scale view reads
      later outer-fractal groups at the wrong pitch and silently corrupts
      every group but the first.

    Under MX the two operands' K extents must agree.  If both are static they
    must be equal (a compile error otherwise); any extent that is runtime --
    against a static one or against another runtime one -- is the caller's
    contract: keep them equal, because the mmad's K follows the lhs while each
    operand's L1->L0 data and scale frames follow its own K, and frames that
    disagree (whichever side is narrower) silently corrupt every n-fractal
    group but the first.  The lowering cannot see through the runtime leaves
    to compare them: a dynamic-shape matmul reaches its operands through
    different shape leaves, and a staged kernel may pair a static lhs view
    with a streamed runtime rhs.

    Do not use ``unit_flag`` for any of this -- it is a MMAD control field, not
    a valid-extent channel.

    ``disable_gemv`` mirrors the per-instruction C API parameter of
    ``asc_mmad``/``asc_mmad_mx`` (compile-time bool only). It only takes effect
    when M == 1: the default ``True`` keeps the fractal (NZ/ZZ) L0A read of the
    DSL cube path; ``False`` enables GEMV mode, which reads L0A as ND — the
    caller is then responsible for producing an ND-layout L0A, otherwise the
    M=1 results are silently wrong. It is a no-op for any other M.
    """
    if type(disable_gemv) is not bool:
        raise TypeError(
            "disable_gemv must be a bool, got "
            f"{type(disable_gemv).__name__}"
        )
    if isinstance(init, bool):
        kwargs = {"init": init}
    else:
        # SSA i1 (typically from `Int64(...) == Int64(...)` etc.). Pass via
        # the optional operand so MatMulOp lowering wraps in scf.if.
        kwargs = {"init_value": init}
    if bias is not None:
        kwargs["bias"] = _tensor_operand(bias)
    if isinstance(unit_flag, ir.Value):
        kwargs["unit_flag_value"] = coerce_scalar_value(
            unit_flag, ir.IntegerType.get_signless(32)
        )
    else:
        kwargs["unit_flag"] = int(unit_flag)
    kwargs["disable_gemv"] = disable_gemv
    from cannbotdsl.ops.cube import _managed_matmul_attributes, _record_matmul

    kwargs.update(_managed_matmul_attributes())
    operation = cannir.matmul(
        _tensor_operand(dst),
        _tensor_operand(lhs),
        _tensor_operand(rhs),
        **kwargs,
    )
    if hasattr(operation, "operation"):
        operation = operation.operation
    _record_matmul(operation)
