# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software; you can redistribute it and/or modify it under the terms of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
# See the License for the specific language governing permissions and limitations under the License.

"""Host-side NPU platform queries.

``get_platform_info`` reads SoC identity and core counts directly from the
CANN runtime (``rtGetSocSpec`` in ``libruntime.so``) and clamps them by the
stream core quota (``rtsGetStreamResLimit``, the "core control" / stream
res limit facility), while ``get_mem_size`` reports per-level on-chip memory
capacities.  Both fail soft on machines without a CANN installation: queries
return empty/zero values instead of raising, so ``import cannbotdsl`` never
depends on hardware.

Device-side indexing (``get_block_num`` & co.) lives in ``cannbotdsl.ops.arch``
and answers a different question: those are kernel-code values, while this
module describes the machine the host is driving.

Usage::

    from cannbotdsl import get_platform_info, get_mem_size

    info = get_platform_info()
    print(info.soc_version)    # "DAV_3510"
    print(info.core_num)       # min(28, stream quota)
    print(info.npu_arch)       # "dav-3510" (Bisheng ``--npu-arch`` spelling)
    print(get_mem_size("ub"))  # 253952
"""

from __future__ import annotations

import ctypes
import logging
import os
import sys
import threading
from dataclasses import dataclass, field, replace
from typing import Any, Optional

logger = logging.getLogger(__name__)

_SPEC_BUFFER_LENGTH = 50

# rtGetSocSpec(column, key, out, maxLen) -> 0 on success, non-zero otherwise.
_SOC_SPEC_COLUMNS = {
    "soc_version": ("version", "NpuArch"),
    "short_soc_version": ("version", "Short_SoC_version"),
    "core_num": ("SoCInfo", "ai_core_cnt"),
    "cube_core_num": ("SoCInfo", "cube_core_cnt"),
    "vector_core_num": ("SoCInfo", "vector_core_cnt"),
    "ai_cpu_num": ("SoCInfo", "ai_cpu_cnt"),
}

# mem_type name -> (column, key).  Values land in the snapshot's private
# ``_mem_sizes`` dict; ``get_mem_size`` is the only public reader.
_MEM_SPECS = {
    "ub": ("AICoreSpec", "ub_size"),
    "l1": ("AICoreSpec", "l1_size"),
    "l0a": ("AICoreSpec", "l0_a_size"),
    "l0b": ("AICoreSpec", "l0_b_size"),
    "l0c": ("AICoreSpec", "l0_c_size"),
    "bt": ("AICoreSpec", "bt_size"),
    "fb0": ("AICoreSpec", "fb0_size"),
}

# rtDevResLimitType_t values for rtsGetStreamResLimit(stream, type, &value):
# the per-stream core quota ("控核").  Uncontrolled streams report the full
# hardware core count; failures report 0 and must not clamp anything.
_RT_DEV_RES_CUBE_CORE = 0
_RT_DEV_RES_VECTOR_CORE = 1


class _RuntimeLibraries:
    """Lazy libprofapi/libruntime pair with runtime symbols resolved once.

    libprofapi.so must be opened ``RTLD_GLOBAL`` before libruntime.so, mir-
    roring the load order CANN tooling itself relies on.  Loading is thread-
    safe and idempotent; failures are sticky so a driver-less host pays the
    lookup cost once and never raises.

    Resolves ``rtGetSocSpec`` (platform specs) and ``rtsGetStreamResLimit``
    (per-stream core quota) independently: an older CANN may export one but
    not the other.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._loaded = False
        self._get_soc_spec = None
        self._get_stream_res_limit = None

    def _find_library(self, names, *, global_mode):
        search_paths = [
            os.environ.get("ASCEND_HOME_PATH", ""),
            os.environ.get("ASCEND_TOOLKIT_HOME", ""),
            os.environ.get("LD_LIBRARY_PATH", "").split(":"),
        ]
        flat = []
        for p in search_paths:
            if isinstance(p, str) and p:
                flat.append(p)
            elif isinstance(p, list):
                flat.extend(x for x in p if x)
        mode = ctypes.RTLD_GLOBAL if global_mode else ctypes.RTLD_LOCAL
        for name in names:
            try:
                return ctypes.CDLL(name, mode=mode)
            except OSError:
                pass
            for d in flat:
                full = os.path.join(d, name)
                if os.path.isfile(full):
                    try:
                        return ctypes.CDLL(full, mode=mode)
                    except OSError:
                        pass
        return None

    def _ensure_loaded(self):
        with self._lock:
            if not self._loaded:
                self._loaded = True
                self._get_soc_spec, self._get_stream_res_limit = self._load()

    def get_soc_spec(self):
        self._ensure_loaded()
        return self._get_soc_spec

    def get_stream_res_limit(self):
        self._ensure_loaded()
        return self._get_stream_res_limit

    def _load(self):
        try:
            profapi = self._find_library(["libprofapi.so"], global_mode=True)
            if profapi is None:
                logger.debug("libprofapi.so not found; platform queries unavailable")
                return None, None
            runtime = self._find_library(["libruntime.so"], global_mode=False)
            if runtime is None:
                logger.debug("libruntime.so not found; platform queries unavailable")
                return None, None
            spec = self._resolve(runtime, "rtGetSocSpec")
            if spec is not None:
                spec.argtypes = [
                    ctypes.c_char_p,
                    ctypes.c_char_p,
                    ctypes.c_char_p,
                    ctypes.c_uint32,
                ]
                spec.restype = ctypes.c_int32
            limit = self._resolve(runtime, "rtsGetStreamResLimit")
            if limit is not None:
                limit.argtypes = [
                    ctypes.c_void_p,
                    ctypes.c_int32,
                    ctypes.POINTER(ctypes.c_uint32),
                ]
                limit.restype = ctypes.c_int32
            return spec, limit
        except OSError as error:
            logger.debug("runtime library query setup failed: %s", error)
            return None, None

    @staticmethod
    def _resolve(library, symbol):
        try:
            return getattr(library, symbol)
        except AttributeError:
            logger.debug("%s unavailable in %s", symbol, library._name)
            return None


_libraries = _RuntimeLibraries()


def _query(column: str, key: str) -> str:
    spec = _libraries.get_soc_spec()
    if spec is None:
        return ""
    try:
        buffer = ctypes.create_string_buffer(_SPEC_BUFFER_LENGTH)
        status = spec(column.encode(), key.encode(), buffer, _SPEC_BUFFER_LENGTH)
    except RuntimeError as error:
        logger.debug("rtGetSocSpec(%s, %s) failed: %s", column, key, error)
        return ""
    if status != 0:
        logger.debug("rtGetSocSpec(%s, %s) returned %d", column, key, status)
        return ""
    return buffer.value.decode(errors="replace")


def _parse_int(value: str, column: str, key: str) -> int:
    if not value:
        return 0
    try:
        return int(value, 10)
    except ValueError:
        logger.debug("rtGetSocSpec(%s, %s) returned non-integer %r", column, key, value)
        return 0


def _query_int(column: str, key: str) -> int:
    return _parse_int(_query(column, key), column, key)


def _query_stream_res_limit(handle: int, res_type: int) -> int:
    """Per-stream core quota from ``rtsGetStreamResLimit``; 0 when unknown.

    0 means "no answer" (symbol missing, query failed, or a null stream),
    never "zero cores", so callers only clamp on positive values.
    """

    limit = _libraries.get_stream_res_limit()
    if limit is None or not handle:
        return 0
    value = ctypes.c_uint32(0)
    try:
        status = limit(ctypes.c_void_p(handle), res_type, value)
    except RuntimeError as error:
        logger.debug("rtsGetStreamResLimit(handle=%#x) failed: %s", handle, error)
        return 0
    if status != 0:
        logger.debug(
            "rtsGetStreamResLimit(handle=%#x, type=%d) returned %d",
            handle,
            res_type,
            status,
        )
        return 0
    return value.value


def _extract_stream_handle(stream: Any) -> Optional[int]:
    """Raw stream pointer from a torch_npu Stream or an integer handle."""

    try:
        handle = getattr(stream, "npu_stream", None)
        if handle is not None:
            return int(handle)
        parameter = getattr(stream, "_as_parameter_", None)
        if parameter is not None:
            handle = getattr(parameter, "value", parameter)
            if handle is not None:
                return int(handle)
        if isinstance(stream, int) and not isinstance(stream, bool):
            return stream
    except (TypeError, ValueError):
        pass
    logger.debug("cannot derive a stream handle from %r", stream)
    return None


def _current_stream_handle() -> Optional[int]:
    """Handle of the stream kernels would launch on, when torch is driving.

    Only consulted when ``torch``/``torch_npu`` are already imported: this
    mirrors the JIT launch default (``torch.npu.current_stream()``) without
    making a platform query trigger heavy imports.
    """

    torch_npu = sys.modules.get("torch_npu")
    torch = sys.modules.get("torch")
    if torch_npu is None or torch is None:
        return None
    try:
        return _extract_stream_handle(torch.npu.current_stream())
    except Exception as error:
        logger.debug("current stream unavailable: %s", error)
        return None


def _normalize_soc_version(raw: str) -> str:
    """Normalize the raw ``NpuArch`` spec to ``DAV_3510`` form.

    The runtime reports a bare numeric id (``3510``) on current CANN
    versions; older/newer builds may already carry the ``DAV_`` prefix.
    Unknown shapes pass through unchanged.
    """

    value = raw.strip()
    if value.isdigit():
        return f"DAV_{value}"
    return value


@dataclass
class PlatformInfo:
    """NPU platform hardware information.

    Carries SoC identity and core counts, mirroring the pypto
    ``PlatformInfo`` surface; on-chip memory capacities are queried through
    ``get_mem_size`` instead of fields.  ``core_num``/``cube_core_num`` and
    ``vector_core_num`` report the *effective* counts — the minimum of the
    hardware count and the current stream's core quota (控核), so tiling
    code sizes work against what the kernel may actually use.  All fields
    default to empty/zero so the dataclass remains constructible on hosts
    without a CANN installation.
    """

    soc_version: str = ""
    short_soc_version: str = ""
    core_num: int = 0
    cube_core_num: int = 0
    vector_core_num: int = 0
    ai_cpu_num: int = 0
    available: bool = False
    # Same-snapshot capacity table backing get_mem_size; kept private so the
    # public surface stays pypto-aligned.
    _mem_sizes: dict = field(default_factory=dict, repr=False, compare=False)

    @property
    def npu_arch(self) -> str:
        """Compilation arch in Bisheng ``--npu-arch`` spelling (``dav-3510``).

        Empty when the SoC version is unknown or outside the ``DAV_`` family;
        callers fall back to the ``CANNBOTDSL_NPU_ARCH`` default.  Restricting
        detection to the family Bisheng actually understands keeps unknown
        runtime spellings (e.g. ``Ascend910B3``) from silently becoming an
        invalid ``--npu-arch`` value — they degrade to the default instead,
        preserving the pre-detection behavior.
        """

        if not self.soc_version:
            return ""
        normalized = self.soc_version.strip().upper()
        if not normalized.startswith("DAV_"):
            return ""
        suffix = normalized[len("DAV_"):].strip("_").lower()
        return f"dav-{suffix}" if suffix else ""


_cached_info: Optional[PlatformInfo] = None
_cache_lock = threading.Lock()


def _hardware_snapshot() -> PlatformInfo:
    """Cached hardware snapshot without any stream-quota clamping.

    Internal fast path for consumers that depend only on static hardware
    facts (``get_mem_size`` capacities, ``_detect_npu_arch`` identity): it
    must never pay for the dynamic per-stream quota queries.
    """

    global _cached_info
    if _cached_info is None:
        with _cache_lock:
            if _cached_info is None:
                _cached_info = _query_hardware_snapshot()
    return _cached_info


def get_platform_info(
    force_refresh: bool = False,
    stream: Any = None,
) -> PlatformInfo:
    """Query NPU platform information from the CANN runtime.

    Hardware identity and capacities are cached after the first successful
    call (``force_refresh`` re-queries them).  The core counts are then
    clamped to ``min(hardware, stream core quota)`` using the per-stream
    "core control" limit (``rtsGetStreamResLimit``): a 28-core SoC whose
    stream is limited to 14 cores reports ``core_num == 14``.  Quotas are
    re-read on every call because they are dynamic state — they follow the
    resolved stream and may be set or reset at any time.

    ``stream`` selects which stream's quota applies: an explicit
    ``torch.npu.Stream`` (or raw handle) wins; otherwise the current
    ``torch.npu`` stream is used when torch is driving, matching the stream
    JIT kernels launch on.  Without a resolvable stream (no torch_npu, no
    CANN) the unclamped hardware counts are returned.

    On hosts without CANN libraries every query degrades to empty/zero
    values; the dataclass ``available`` flag distinguishes that case from a
    real machine.
    """

    global _cached_info
    if _cached_info is None or force_refresh:
        with _cache_lock:
            if _cached_info is None or force_refresh:
                _cached_info = _query_hardware_snapshot()
    info = _cached_info
    if stream is not None:
        handle = _extract_stream_handle(stream)
    else:
        handle = _current_stream_handle()
    if not handle:
        return info
    cube_limit = _query_stream_res_limit(handle, _RT_DEV_RES_CUBE_CORE)
    vector_limit = _query_stream_res_limit(handle, _RT_DEV_RES_VECTOR_CORE)
    if cube_limit <= 0 and vector_limit <= 0:
        return info
    return _apply_core_limits(info, cube_limit, vector_limit)


def _query_hardware_snapshot() -> PlatformInfo:
    """Read the (static) SoC specs; called under ``_cache_lock``."""
    info = PlatformInfo()
    for name, (column, key) in _SOC_SPEC_COLUMNS.items():
        value = _query(column, key)
        if name == "soc_version":
            info.soc_version = _normalize_soc_version(value)
        elif name == "short_soc_version":
            info.short_soc_version = value
        else:
            setattr(info, name, _parse_int(value, column, key))
    info._mem_sizes = {
        mem_type: _query_int("AICoreSpec", key)
        for mem_type, (_, key) in _MEM_SPECS.items()
    }
    info.available = bool(info.soc_version)
    if info.available:
        logger.info(
            "Platform: %s (%s), core_num=%d, cube=%d, vector=%d",
            info.soc_version,
            info.short_soc_version,
            info.core_num,
            info.cube_core_num,
            info.vector_core_num,
        )
    else:
        logger.debug("Platform info unavailable (CANN runtime not loaded)")
    return info


def _apply_core_limits(
    info: PlatformInfo,
    cube_limit: int,
    vector_limit: int,
) -> PlatformInfo:
    """Core counts clamped by the stream quota.

    ``core_num``/``cube_core_num`` follow the cube (AIC) quota and
    ``vector_core_num`` the vector (AIV) quota, mirroring PyPTO's
    ``GetCfgBlockdim`` clamping.  ``ai_cpu_num`` has no quota and is left
    untouched.  Zero/negative quotas mean "unknown" and do not clamp.

    Returns ``info`` itself when nothing binds (the common uncontrolled
    case) so the cached-snapshot identity semantics are preserved.
    """

    core_num = min(info.core_num, cube_limit) if cube_limit > 0 else info.core_num
    cube_core_num = (
        min(info.cube_core_num, cube_limit) if cube_limit > 0 else info.cube_core_num
    )
    vector_core_num = (
        min(info.vector_core_num, vector_limit)
        if vector_limit > 0
        else info.vector_core_num
    )
    if (
        core_num == info.core_num
        and cube_core_num == info.cube_core_num
        and vector_core_num == info.vector_core_num
    ):
        return info
    clamped = replace(
        info,
        core_num=core_num,
        cube_core_num=cube_core_num,
        vector_core_num=vector_core_num,
    )
    logger.debug(
        "Stream core quota: cube=%d, vector=%d -> core_num=%d, cube=%d, vector=%d",
        cube_limit,
        vector_limit,
        clamped.core_num,
        clamped.cube_core_num,
        clamped.vector_core_num,
    )
    return clamped


def get_mem_size(mem_type: str) -> int:
    """Total on-chip memory capacity in bytes for one memory level.

    ``mem_type`` is one of ``ub``, ``l1``, ``l0a``, ``l0b``, ``l0c``, ``bt``,
    ``fb0`` (case-insensitive).  Values come from the same cached snapshot as
    ``get_platform_info`` and, being static hardware facts, are unaffected by
    core control (控核).  Unknown names raise ``ValueError``; a query on a
    host without CANN returns ``0``.
    """

    normalized = str(mem_type).strip().lower()
    if normalized not in _MEM_SPECS:
        raise ValueError(
            f"unknown mem_type {mem_type!r}; expected one of "
            f"{sorted(_MEM_SPECS)}"
        )
    info = _hardware_snapshot()
    return info._mem_sizes.get(normalized, 0)


def _detect_npu_arch() -> str:
    """Best-effort SoC-derived arch string for Bisheng (``dav-3510``).

    Empty when no runtime query succeeded or the SoC is outside the ``DAV_``
    family (see ``PlatformInfo.npu_arch``).  Internal bridge for
    ``resolve_npu_arch``'s last fallback; public callers should read
    ``get_platform_info().npu_arch`` instead.  ``CANNBOTDSL_NPU_ARCH``
    always wins over detection so cross-compilation setups stay
    deterministic.  Reads the hardware snapshot only — the compilation
    arch never depends on the stream core quota.
    """

    return _hardware_snapshot().npu_arch


def _reset_cache() -> None:
    """Test hook: drop the cached snapshot and library state."""

    global _cached_info
    with _cache_lock:
        _cached_info = None
    with _libraries._lock:
        _libraries._loaded = False
        _libraries._get_soc_spec = None
        _libraries._get_stream_res_limit = None
