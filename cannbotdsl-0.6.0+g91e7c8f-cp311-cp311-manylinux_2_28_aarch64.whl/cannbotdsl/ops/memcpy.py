# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Data movement: ``mem_copy`` and the copy-engine configuration it accepts.

The engine enums, the ``CopyEngine`` value wrapper and ``make_copy_engine``
live here rather than in ``cannbotdsl.tensor`` so that every setting and data
structure a caller needs to configure a copy sits next to the copy interface
itself. Static transforms live on the engine; runtime controls live on each copy.
"""

from enum import IntEnum
from typing import Optional

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.ops._operands import _operand_memref_type
from cannbotdsl.tensor import (
    MemLoc,
    Tensor,
    _normalize_part_id,
    _make_partition_tiler,
    _static_full_shape,
)


class FormatTransform(IntEnum):
    Identity = 0
    ND2NZ = 1
    NZ2ND = 2
    DN2NZ = 3
    MX_SCALE_A = 4
    MX_SCALE_B = 5
    TRANSPOSE = 6
    MX_SCALE_BND = 7
    MX_SCALE_BDN = 8
    MX_SCALE_AND = 9
    MX_SCALE_ADN = 10
    Auto = 11


class CopyLayoutTransform(IntEnum):
    None_ = 0
    NZ_FOLD_N_TO_M = 1


class CopyEngineKind(IntEnum):
    Auto = 0
    NDDMA = 1


class CopyTailAlignment(IntEnum):
    Tiler = 0
    UB = 1


class NDDMAPaddingMode(IntEnum):
    Constant = 0
    Nearest = 1


@ir.register_value_caster(cannir.CopyEngineType.get_static_typeid())
class CopyEngine(ir.Value):
    @property
    def format_transform(self):
        return FormatTransform(self.type.format_transform)

    @property
    def layout_transform(self):
        return CopyLayoutTransform(self.type.layout_transform)

    @property
    def kind(self):
        return CopyEngineKind(self.type.kind)

    @property
    def tail_alignment(self):
        return CopyTailAlignment(self.type.tail_alignment)


_FORMAT_TRANSFORM_MAP = {
    None: FormatTransform.Auto,
    "identity": FormatTransform.Identity,
    "nd2nz": FormatTransform.ND2NZ,
    "nz2nd": FormatTransform.NZ2ND,
    "dn2nz": FormatTransform.DN2NZ,
    "mx_scale_a": FormatTransform.MX_SCALE_A,
    "mx_scale_b": FormatTransform.MX_SCALE_B,
    "transpose": FormatTransform.TRANSPOSE,
    "mx_scale_bnd": FormatTransform.MX_SCALE_BND,
    "mx_scale_bdn": FormatTransform.MX_SCALE_BDN,
    "mx_scale_and": FormatTransform.MX_SCALE_AND,
    "mx_scale_adn": FormatTransform.MX_SCALE_ADN,
}

_COPY_LAYOUT_TRANSFORM_MAP = {
    None: CopyLayoutTransform.None_,
    "none": CopyLayoutTransform.None_,
    "nz_fold_n_to_m": CopyLayoutTransform.NZ_FOLD_N_TO_M,
}

_COPY_ENGINE_KIND_MAP = {
    "auto": CopyEngineKind.Auto,
    "nddma": CopyEngineKind.NDDMA,
}

_COPY_TAIL_ALIGNMENT_MAP = {
    None: CopyTailAlignment.Tiler,
    "tiler": CopyTailAlignment.Tiler,
    "ub": CopyTailAlignment.UB,
}

_NDDMA_PADDING_MODE_MAP = {
    None: NDDMAPaddingMode.Constant,
    "constant": NDDMAPaddingMode.Constant,
    "nearest": NDDMAPaddingMode.Nearest,
}


class CopyBlockMapping:
    """Repeat a rectangular block at explicit logical coordinate steps.

    Coordinates are relative to each operand view and measured in elements.
    For repetition ``i``, copy ``block_shape`` elements beginning at
    ``i * src_step`` to ``i * dst_step``. Zero source steps express broadcast;
    equal row/column steps express a block diagonal. Hardware pitches are
    derived from the tensors' physical layouts.
    """
    __slots__ = ("block_shape", "repeats", "src_step", "dst_step")

    def __init__(self, block_shape, *, repeats, src_step, dst_step):
        for name, value in (("block_shape", block_shape), ("src_step", src_step), ("dst_step", dst_step)):
            if not isinstance(value, (tuple, list)) or len(value) != 2 or any(type(v) is not int for v in value):
                raise TypeError(f"{name} must be a pair of static integers")
        if type(repeats) is not int or repeats < 1 or any(v < 1 for v in block_shape):
            raise ValueError("block_shape and repeats must be positive")
        if any(v < 0 for v in (*src_step, *dst_step)):
            raise ValueError("copy block coordinate steps must be non-negative")
        self.block_shape = tuple(block_shape)
        self.repeats = repeats
        self.src_step = tuple(src_step)
        self.dst_step = tuple(dst_step)


def _resolve_transpose_format(format_transform, transpose):
    if transpose is None:
        return format_transform
    if type(transpose) is not bool:
        raise TypeError("transpose must be a compile-time bool")
    if transpose:
        if format_transform not in (FormatTransform.Auto, FormatTransform.TRANSPOSE):
            raise ValueError("transpose=True conflicts with the explicit format_transform")
        return FormatTransform.TRANSPOSE
    if format_transform == FormatTransform.TRANSPOSE:
        raise ValueError("transpose=False conflicts with the transpose engine")
    return format_transform


def make_copy_engine(
    *, kind="auto", format_transform=None, transpose=None, layout_transform=None,
    tail_alignment=None, padding_mode=None, split_axis=None,
    split_alignment=1, block_mapping=None, relu=False, smallc0=False,
):
    """Describe static copy transforms, partitioning and implementation choices.

    ``transpose=True`` requests an L1 -> L0A/L0B transpose. It is a
    compile-time bool and must agree with any explicit ``format_transform``.
    ``split_axis`` selects the M (0) or N (1) two-part Cube/Vector mapping;
    runtime part selection and actual shape belong to ``mem_copy``.
    """
    def enum_value(mapping, value, name):
        if value not in mapping:
            raise ValueError(f"Unknown {name}: {value!r}")
        return int(mapping[value])

    if split_axis is not None and (type(split_axis) is not int or split_axis not in (0, 1)):
        raise ValueError("split_axis must be 0, 1, or None")
    if type(split_alignment) is not int or split_alignment < 1:
        raise ValueError("split_alignment must be a positive integer")
    if split_axis != 0 and split_alignment != 1:
        raise ValueError("split_alignment != 1 requires split_axis=0")
    if not isinstance(relu, bool) or not isinstance(smallc0, bool):
        raise TypeError("relu and smallc0 must be bools")
    if block_mapping is not None and not isinstance(block_mapping, CopyBlockMapping):
        raise TypeError("block_mapping must be a CopyBlockMapping")
    mapping = (() if block_mapping is None else
               (*block_mapping.block_shape, block_mapping.repeats,
                *block_mapping.src_step, *block_mapping.dst_step))
    transform = _resolve_transpose_format(
        enum_value(_FORMAT_TRANSFORM_MAP, format_transform, "format_transform"),
        transpose,
    )
    engine_type = cannir.CopyEngineType.get(
        int(transform),
        layout_transform=enum_value(_COPY_LAYOUT_TRANSFORM_MAP, layout_transform, "layout_transform"),
        kind=enum_value(_COPY_ENGINE_KIND_MAP, kind, "kind"),
        tail_alignment=enum_value(_COPY_TAIL_ALIGNMENT_MAP, tail_alignment, "tail_alignment"),
        padding_mode=enum_value(_NDDMA_PADDING_MODE_MAP, padding_mode, "padding_mode"),
        split_axis=-1 if split_axis is None else split_axis,
        split_alignment=split_alignment,
        block_mapping=mapping,
        relu=relu, smallc0=smallc0,
    )
    return cannir.make_copy_engine(engine_type)


def _copy_engine_with_transpose(engine, transpose):
    if transpose is None:
        return engine
    if engine is None:
        transform = _resolve_transpose_format(FormatTransform.Auto, transpose)
        return make_copy_engine(transpose=True) if transform == FormatTransform.TRANSPOSE else None

    descriptor = cannir.CopyEngineType(unwrap_operand(engine).type)
    transform = _resolve_transpose_format(descriptor.format_transform, transpose)
    if transform == descriptor.format_transform:
        return engine
    # Copy the complete descriptor, including when the engine is a block
    # argument. Do not mutate a shared engine or inspect its defining op.
    engine_type = cannir.CopyEngineType.get(
        int(transform),
        layout_transform=descriptor.layout_transform,
        kind=descriptor.kind,
        tail_alignment=descriptor.tail_alignment,
        padding_mode=descriptor.padding_mode,
        split_axis=descriptor.split_axis,
        split_alignment=descriptor.split_alignment,
        block_mapping=descriptor.block_mapping,
        relu=descriptor.relu,
        smallc0=descriptor.smallc0,
    )
    return cannir.make_copy_engine(engine_type)


def _copy_split_full_side(dst, src):
    """The operand whose tile defines the split's full/actual shape."""
    dst_memloc = cannir.PointerType(_operand_memref_type(dst).pointer).memloc
    src_memloc = cannir.PointerType(_operand_memref_type(src).pointer).memloc
    src_is_full = src_memloc == MemLoc.GM or src_memloc == MemLoc.L0C
    dst_is_full = dst_memloc == MemLoc.GM or dst_memloc == MemLoc.L1
    if src_is_full and not dst_is_full:
        return src, src_memloc
    if dst_is_full and not src_is_full:
        return dst, dst_memloc
    raise ValueError(
        "copy split supports GM -> UB, UB -> GM, UB -> L1, and L0C -> UB "
        "copies; the split's full side must be the GM tile, the L1 tile, or "
        "the L0C tile"
    )


def _copy_split_defers_actual(full_side, full_side_memloc, actual):
    """Whether copy split defers the actual shape to the compiler.

    Only the L0C -> UB direction can: the L0C tile's reaching matmul shape
    is the authoritative runtime actual. Deferral applies when the full-side
    operand is a slot root (or transaction slot) carrying no explicit view
    window — an explicit tile_slice/reinterpret keeps the user's actual. An
    explicit ``actual`` also disables deferral.
    """
    if actual is not None:
        return False
    if full_side_memloc != MemLoc.L0C:
        return False
    raw = unwrap_operand(full_side)
    definition = getattr(raw, "owner", None)
    if definition is None or not hasattr(definition, "name"):
        return True
    if definition.name == "cannir.reinterpret_view":
        attrs = definition.attributes
        parent = unwrap_operand(definition.operands[0])
        parent_type = parent.type
        result_type = raw.type
        if isinstance(parent_type, cannir.ChannelType):
            parent_type = parent_type.element
        if isinstance(result_type, cannir.ChannelType):
            result_type = result_type.element
        if ("preserve_layout" in attrs and "user_stride" not in attrs
                and ir.IntegerAttr(attrs["offset_bytes"]).value == 0
                and cannir.TensorType(parent_type).pointer.dtype
                == cannir.TensorType(result_type).pointer.dtype):
            # Normalization forwards an omitted-shape identity view. Keep
            # the same reaching-matmul actual as copying its input directly.
            return _copy_split_defers_actual(parent, full_side_memloc, actual)
        return False
    return definition.name not in (
        "cannir.tile_slice",
        "cannir.local_slice",
        "cannir.memref_slice",
    )


def _materialize_copy_split(dst, src, engine, part_id, actual):
    full_side, full_side_memloc = _copy_split_full_side(dst, src)
    if full_side_memloc == MemLoc.L0C and part_id is not None:
        raise ValueError(
            "copy split on an L0C -> UB copy is the dual-destination fixpipe "
            "mode; omit part_id (the hardware routes each half per "
            "sub-block)"
        )
    if full_side_memloc != MemLoc.L0C and part_id is None:
        raise ValueError(
            "copy split requires part_id (usually get_subblock_id()); only the "
            "L0C -> UB dual-destination fixpipe mode omits it"
        )
    full_shape = _static_full_shape(full_side)
    actual_shape = (
        actual if actual is not None else tuple(full_side.shape)
    )
    return _make_partition_tiler(
        actual_shape,
        full_shape,
        axis=engine.type.split_axis,
        alignment=engine.type.split_alignment,
    )


def cv_valid_extent(tensor, *, axis, alignment=1, part_id):
    """Runtime valid extent of one part of ``tensor``'s current tile.

    The shape-query counterpart of an engine with matching ``split_axis`` and
    ``split_alignment`` over the same full-side operand: the
    tile's full shape comes from its static declaration and its actual
    shape from ``tensor.shape``.
    """
    full_shape = _static_full_shape(tensor)
    actual_shape = tuple(tensor.shape)
    return _make_partition_tiler(
        actual_shape, full_shape, axis=axis, alignment=alignment
    ).valid_extent(part_id)


def _normalize_copy_control(value, name, choices):
    """Keep cache policy on the copy, including when it is a constant."""
    from cannbotdsl.types._numeric import Int32

    if isinstance(value, int) and not isinstance(value, bool):
        if value not in choices:
            raise ValueError(f"{name} must be one of {choices}")
        return Int32(value)
    if isinstance(value, ir.Value) and value.type == ir.IntegerType.get_signless(32):
        return value
    raise TypeError(f"{name} must be an integer constant or an i32 SSA value")


def _normalize_l2_cache_ctl(value):
    return _normalize_copy_control(value, "l2_cache_ctl", (0, 1, 2, 4))


def mem_copy(
    dst: Tensor,
    src: Tensor,
    *,
    engine: Optional[object] = None,
    transpose: Optional[bool] = None,
    deq_scale: Optional[object] = None,
    dst_subblock=None,
    unit_flag=0,
    pad_value=None,
    left_padding=None,
    right_padding=None,
    mx_scale: Optional[Tensor] = None,
    part_id=None,
    actual=None,
    l2_cache_ctl: int = 0,
    atomic_add=False,
    axis: Optional[int] = None,
):
    """Copy ``src`` to ``dst``.

    UB -> UB format conversion requires a user-written raw VF. This API
    supports ordinary UB copies and hardware DMA format conversions.

    ``transpose=True`` is shorthand for an L1 -> L0A/L0B transpose engine.
    Python resolves this compile-time bool into the engine descriptor; it is
    not a runtime copy operand. With an explicit engine, other static fields
    are preserved and conflicting formats are rejected. ``False`` leaves
    ordinary copies unchanged and rejects an explicitly transposing engine.

    A nonempty tuple/list of GM or UB Tensors copies their contents, in source
    order (``axis=0`` only). GM sources copy into UB or L1; UB sources copy into
    ND L1 on AIV MTE3 with ``l2_cache_ctl=0`` and no format conversion.
    All sources must use the same memory space. Equal-rank sources concatenate
    on axis 0 with provably equal inner extents. For differing ranks, the
    ordered logical stream fills a destination prefix. Larger destinations
    preserve untouched logical values. Arbitrary ranks and multi-row sources
    are supported when their layouts form one regular DMA burst stream.
    This is one Channel write access and lowers to exactly one DMA instruction.
    Sources must share a provable base and have equal address intervals.
    Unequal or unprovable intervals are compilation errors, with no split
    fallback or source reordering. A dynamic interval must be non-negative and
    fit the target DMA range at runtime, like a dynamic single-source stride.
    For GM sources, a NZ L1 destination selects ND-to-NZ conversion, including regular batches
    of matrices. An optional identity/ND2NZ engine may specify
    the matching format, with default addressing and zero padding only.
    UB-to-L1 addresses, burst lengths and gaps must be 32-byte aligned. It
    supports up to 4095 bursts, each 1..65535 DataBlocks (32 bytes), with
    non-negative source/destination gaps of at most 65535 DataBlocks.
    Dynamic parameters must satisfy these bounds at runtime.

    An engine with ``split_axis`` selects a two-part copy. ``part_id`` selects
    the current AIV partition for GM <-> UB / UB -> L1. L0C -> UB uses hardware
    routing and omits ``part_id``. ``actual`` optionally supplies the full-side
    runtime shape when it cannot be inferred from the tensor or reaching matmul.

    ``l2_cache_ctl`` is a constant or runtime i32 policy (0, 1, 2, or 4;
    default 0). Runtime values must belong to this set.
    Nonzero policies are supported for GM -> UB (including NDDMA),
    UB -> GM, GM -> L1, and L0C -> GM copies. GM/UB policies use the
    corresponding AscendC load/store L2 cache enum values.

    ``atomic_add`` may be a Python ``bool`` or a runtime i1 SSA value. Atomic
    add is supported for UB/L0C writes to GM; the GM destination dtype selects
    the AscendC atomic setter.

    ``make_copy_engine(relu=True)`` enables the fixpipe on-the-fly ReLU epilogue (the CAPI
    ``relu_pre`` argument, ReluMode 1=NORMAL_RELU) for an L0C -> GM, L0C -> UB
    or L0C -> L1 store. It composes with the fixpipe quant modes; any other
    copy direction is rejected by the verifier instead of being silently
    dropped. It cannot be combined with the dual-destination FIXPIPE engine
    (``split_axis`` on an L0C -> UB engine): hardware dual destination
    requires all other fixpipe functions to be bypassed.
    """
    from cannbotdsl.lang.vf import _tag_if_in_vf

    engine = _copy_engine_with_transpose(engine, transpose)
    if axis is not None and (type(axis) is not int or axis != 0):
        raise ValueError("mem_copy currently supports axis=0 only")
    if not isinstance(src, (tuple, list)) and axis is not None:
        raise ValueError("axis is only supported for multi-source mem_copy")
    if isinstance(src, (tuple, list)):
        if not src:
            raise ValueError("multi-source mem_copy requires at least one source")
        if (deq_scale is not None or mx_scale is not None
                or part_id is not None or actual is not None or atomic_add is not False
                or dst_subblock is not None or pad_value is not None
                or left_padding is not None or right_padding is not None
                or not (isinstance(unit_flag, int) and unit_flag == 0)):
            raise ValueError(
                "multi-source mem_copy supports only default GM -> UB/L1 or UB -> L1 copies "
                "with axis=0 and l2_cache_ctl"
            )
        _operand_memref_type(dst)
        for source in src:
            if not isinstance(source, Tensor):
                raise TypeError("multi-source mem_copy sources must be GM or UB Tensors")
            _operand_memref_type(source)
        op = cannir.multi_src_copy(
            unwrap_operand(dst), _normalize_l2_cache_ctl(l2_cache_ctl),
            [unwrap_operand(source) for source in src], engine=engine,
        )
        _tag_if_in_vf(op)
        return

    # Validate the semantic memory boundary even when an explicit engine
    # bypasses auto-inference.
    _operand_memref_type(dst)
    _operand_memref_type(src)
    if mx_scale is not None:
        _operand_memref_type(mx_scale)
    has_split = engine is not None and engine.type.split_axis >= 0
    if (part_id is not None or actual is not None) and not has_split:
        raise ValueError("part_id and actual require an engine with split_axis")
    if actual is not None and (not isinstance(actual, (tuple, list)) or len(actual) != 2):
        raise ValueError("actual must be a rank-2 tuple")
    kwargs = {"l2_cache_ctl": _normalize_l2_cache_ctl(l2_cache_ctl),
              "unit_flag": _normalize_copy_control(unit_flag, "unit_flag", (0, 1, 2, 3))}
    if dst_subblock is not None:
        kwargs["dst_subblock"] = _normalize_copy_control(dst_subblock, "dst_subblock", (0, 1))
    def padding_values(value, name):
        if value is None:
            return []
        values = value if isinstance(value, (tuple, list)) else (value,)
        if not 1 <= len(values) <= 5:
            raise ValueError(f"{name} must have 1 to 5 entries")
        return [_normalize_copy_control(v, name, range(256)) for v in values]

    kwargs["left_padding"] = padding_values(left_padding, "left_padding")
    kwargs["right_padding"] = padding_values(right_padding, "right_padding")
    if pad_value is not None:
        from cannbotdsl.types._numeric import Float32, Int64
        if type(pad_value) is int:
            pad_value = Int64(pad_value)
        elif type(pad_value) is float:
            pad_value = Float32(pad_value)
        if not isinstance(pad_value, ir.Value):
            raise TypeError("pad_value must be an integer or floating-point scalar")
        kwargs["pad_value"] = pad_value
    if isinstance(atomic_add, bool):
        kwargs["atomic_add"] = atomic_add
    elif (
        isinstance(atomic_add, ir.Value) and isinstance(atomic_add.type, ir.IntegerType) and atomic_add.type.width == 1
    ):
        kwargs["atomic_add_value"] = atomic_add
    else:
        raise TypeError("atomic_add must be a bool or an i1 SSA value")
    if engine is not None:
        kwargs["engine"] = engine
    if mx_scale is not None:
        kwargs["mx_scale"] = unwrap_operand(mx_scale)
    if deq_scale is not None:
        from cannbotdsl.types._numeric import Float32

        if isinstance(deq_scale, (int, float)) and not isinstance(deq_scale, bool):
            deq_scale = Float32(float(deq_scale))
        if isinstance(deq_scale, Tensor):
            kwargs["deq_scale"] = unwrap_operand(deq_scale)
        elif isinstance(deq_scale, ir.Value) and deq_scale.type == ir.F32Type.get():
            kwargs["deq_scale"] = deq_scale
        else:
            raise TypeError("deq_scale must be a number, f32 SSA value, or Tensor scale table")
    if has_split:
        kwargs["partition"] = _materialize_copy_split(dst, src, engine, part_id, actual)
        if part_id is not None:
            kwargs["part_id"] = _normalize_part_id(part_id)
    op = cannir.mem_copy(unwrap_operand(dst), unwrap_operand(src), **kwargs)
    if has_split:
        full_side, full_side_memloc = _copy_split_full_side(dst, src)
        if _copy_split_defers_actual(full_side, full_side_memloc, actual):
            operation = op.operation if hasattr(op, "operation") else op
            operation.attributes["cannir.copy_split_infer_actual"] = ir.UnitAttr.get()
    _tag_if_in_vf(op)


__all__ = [
    "CopyBlockMapping",
    "CopyEngine",
    "CopyEngineKind",
    "CopyLayoutTransform",
    "CopyTailAlignment",
    "FormatTransform",
    "NDDMAPaddingMode",
    "cv_valid_extent",
    "make_copy_engine",
    "mem_copy",
]
