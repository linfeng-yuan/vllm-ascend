# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Shared validation of Tensor operation operands."""

from cannbotdsl._mlir.dialects import cannir
from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.tensor import Tensor


def _tensor_operand(x):
    """Validate and unwrap one selected Tensor memory operand."""
    from cannbotdsl.channel import Channel

    if isinstance(x, Channel):
        raise TypeError("select a Tensor with Channel.produce()/consume() before passing it to a data operation")
    if not isinstance(x, Tensor):
        raise TypeError(
            "tensor operands must be Tensor, got "
            f"{type(x).__name__}"
        )
    return unwrap_operand(x)


def _operand_memref_type(value):
    """Return the storage type carried by a selected Tensor operand."""
    carrier = _tensor_operand(value)
    if cannir.TensorType.isinstance(carrier.type):
        return cannir.TensorType(carrier.type)
    raise TypeError(f"expected a Tensor operand, got carrier {carrier.type}")


__all__ = []
