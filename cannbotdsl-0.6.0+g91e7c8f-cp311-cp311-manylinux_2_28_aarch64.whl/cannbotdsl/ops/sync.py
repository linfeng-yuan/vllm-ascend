# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

from enum import IntEnum as _IntEnum

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import ascvec, asccube, cannir
from cannbotdsl.core.scalar_conversion import coerce_scalar_value
from cannbotdsl.core.ir_transport import unwrap_operand


class PIPE(_IntEnum):
    P_NULL = 0
    S = 1
    V = 2
    M = 3
    MTE1 = 4
    MTE2 = 5
    MTE3 = 6
    MTE4 = 7
    MTE5 = 8
    V2 = 9
    ALL = 10
    FIXPIPE = 11
    VLD = 12
    VST = 13
    LD = 14
    ST = 15
    LD_ST = 16
    VEXE = 17
    AIV_MTE2 = 18
    AIC_MTE3 = 19
    AIC_MTE1 = 20


class CmpOp(_IntEnum):
    EQ = 0
    NE = 1
    GE = 2
    GT = 3
    LE = 4
    LT = 5


# Codegen packs flag_id into a 4-bit FFTS config field (`flagId & 0xf` in
# lib/CANNIR/Translate/TranslateToAscendC.cpp), so ids above 15 wrap silently.
MAX_SYNC_BLOCK_FLAG_ID = 15

# Flags per barrier: one for the AIV->AIC funnel, one for the cross-block
# handshake, one for the AIC->AIV release.  The ids need not be adjacent or
# related -- the hardware just shifts each into a 4-bit field -- only distinct,
# because the wait path discards mode.
#
# The cross-block flag is issued twice, once by each core type, and that is not
# a collision: mode 0 means "all cores of the issuing type"
# (pto/npu/a2a3/TPush.hpp gives CUBE_ALL_CORE_SYNC and VEC_ALL_CORE_SYNC the
# same value 0), so the issuing core type partitions the flag.
_GLOBAL_SYNC_ALL_FLAG_IDS = (0, 1, 2)
_GLOBAL_SYNC_ALL_PHASES = len(_GLOBAL_SYNC_ALL_FLAG_IDS)


def _check_flag_id(flag_id, *, api_name):
    """Range-check a constant sync_block flag id.

    Out-of-range ids are truncated silently by codegen and the sync_block ops
    declare no verifier, so this is the only guard.  Dynamic i64 SSA ids cannot
    be checked at trace time and pass through.
    """
    if isinstance(flag_id, int) and not 0 <= flag_id <= MAX_SYNC_BLOCK_FLAG_ID:
        raise ValueError(
            f"{api_name} flag_id must be in [0, {MAX_SYNC_BLOCK_FLAG_ID}] "
            f"(codegen truncates with & 0xf), got {flag_id}"
        )


def _ensure_i32_attr(val: int) -> ir.IntegerAttr:
    """Helper to convert standard Python ints to MLIR I32 attributes."""
    if isinstance(val, ir.IntegerAttr):
        return val
    return ir.IntegerAttr.get(ir.IntegerType.get_signless(32), int(val))


def _ensure_i32_value(val) -> ir.Value:
    """Convert Python int / MLIR Value to an MLIR i32 Value."""
    return coerce_scalar_value(val, ir.IntegerType.get_signless(32))


def _ensure_index_value(val) -> ir.Value:
    """Convert Python int / MLIR Value to an MLIR index Value."""
    return coerce_scalar_value(val, ir.IndexType.get())


def _ensure_i64_value(val) -> ir.Value:
    """Convert a Python integer or explicit i64 SSA value to MLIR i64."""
    try:
        return coerce_scalar_value(val, ir.IntegerType.get_signless(64))
    except TypeError as exc:
        raise TypeError(
            "sync/buffer ID must be an int or i64 MLIR Value "
            f"(or a convertible integer SSA value), got {type(val).__name__}"
        ) from exc


def _unwrap_tensor(value):
    """Raw memory operations consume an explicitly selected Tensor."""
    from cannbotdsl.ops._operands import _tensor_operand
    return unwrap_operand(_tensor_operand(value))


def _wait_point_operands(point, *, api_name):
    if not isinstance(point, ir.Value):
        raise TypeError(
            f"{api_name} point must be a direct Tensor[...] result, got "
            f"{type(point).__name__}"
        )

    # Tensor point indexing produces a scalar load SSA value.  Recover its
    # address operands so the wait APIs observe the location rather than the
    # already-loaded scalar.  Unsigned tensor loads add one storage cast.
    value = point
    owner = getattr(value, "owner", None)
    operation = getattr(owner, "operation", owner)
    while getattr(operation, "name", None) == "cannir.scalar_storage_cast":
        value = unwrap_operand(operation.operands[0])
        owner = getattr(value, "owner", None)
        operation = getattr(owner, "operation", owner)

    if getattr(operation, "name", None) != "cannir.memref_load":
        producer = getattr(operation, "name", type(point).__name__)
        raise TypeError(
            f"{api_name} point must be a direct Tensor[...] result; "
            f"got value produced by {producer}"
        )

    memref = unwrap_operand(operation.operands[0])
    coord = unwrap_operand(operation.operands[1])
    from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type
    from cannbotdsl.tensor import MemLoc

    memref_type = cannir.TensorType(memref.type)
    pointer_type = cannir.PointerType(memref_type.pointer)
    if MemLoc(pointer_type.memloc) != MemLoc.GM:
        raise NotImplementedError(f"{api_name} supports only GM tensor points")

    storage_type = pointer_type.dtype
    dtype = dtype_for_storage_mlir_type(storage_type)
    if dtype.name not in ("int32", "uint32"):
        raise TypeError(
            f"{api_name} requires an int32 or uint32 GM tensor point, got "
            f"dtypes.{dtype.name}"
        )
    return memref, coord, storage_type


def _busy_wait(point, expected, cmp, pause_nops, *, api_name, op):
    """Shared body of :func:`cube_busy_wait` and :func:`vec_busy_wait`.

    Two calling conventions:
    1. ``*_busy_wait(check_fn)`` — ``check_fn`` is a callable (e.g. ``@jit``
       method) returning ``Boolean``.  Builds an ``scf.while`` loop that
       repeatedly calls ``check_fn`` until it returns ``True``.  The caller
       manages all UB buffer allocation, event IDs, DMA, and pipeline sync
       inside ``check_fn``.  The loop itself is core-agnostic scaffolding.
    2. ``*_busy_wait(tensor_point, expected, cmp=CmpOp.NE, pause_nops=50)`` —
       dev-bypass GM load polling.  Loops while ``*ptr <cmp> expected`` is
       true, where <cmp> names the not-ready (keep-waiting) condition, and
       executes ``pause_nops`` NOP instructions between two polls.
    """
    if callable(point):
        from cannbotdsl.core.frontend.api import SourceSpan
        from cannbotdsl.core.frontend.runtime.control_flow import while_region
        from cannbotdsl.core.frontend.runtime.hooks import RegionInfo

        def _cond():
            return ~point()

        def _body():
            return ()

        while_region(
            (),
            _cond,
            _body,
            RegionInfo(
                id=0,
                kind="while",
                span=SourceSpan(f"<{api_name}>", 0, 0, 0, 1),
                source=f"<{api_name}>",
                source_first_line=0,
            ),
        )
        return

    from cannbotdsl.core.contracts.elements import coerce_scalar_to_storage

    memref, coord, storage_type = _wait_point_operands(
        point, api_name=api_name
    )
    expected_value = coerce_scalar_to_storage(
        expected, storage_type, path=f"{api_name} expected"
    )
    if type(pause_nops) is not int or pause_nops < 0:
        raise TypeError(
            f"{api_name} pause_nops must be a non-negative int, got "
            f"{pause_nops!r}"
        )
    cmp_val = int(cmp) if isinstance(cmp, CmpOp) else int(CmpOp.NE)
    op(memref, coord, expected_value, cmp=cmp_val, pause_nops=pause_nops)


def cube_busy_wait(point, expected=None, *, cmp=CmpOp.NE, pause_nops=50):
    """Busy-wait on a GM scalar on the cube (AIC) core.

    See :func:`_busy_wait` for the two calling conventions.  On a MIX
    kernel the wait executes only in the AIC clone.
    """
    _busy_wait(point, expected, cmp, pause_nops,
               api_name="cube_busy_wait", op=cannir.cube_busy_wait)


def vec_busy_wait(point, expected=None, *, cmp=CmpOp.NE, pause_nops=50):
    """Busy-wait on a GM scalar on the vector (AIV) core.

    See :func:`_busy_wait` for the two calling conventions.  On a MIX
    kernel the wait executes only in the AIV clone.
    """
    _busy_wait(point, expected, cmp, pause_nops,
               api_name="vec_busy_wait", op=cannir.vec_busy_wait)


def try_wait(point, expected=None, *, cmp=CmpOp.NE):
    """Read one GM scalar once and return whether it satisfies ``cmp``.

    Two calling conventions:
    1. ``try_wait(check_fn)`` — ``check_fn`` is a callable returning
       ``Boolean``.  Calls ``check_fn`` once and returns its result.
    2. ``try_wait(tensor_point, expected, cmp=CmpOp.NE)`` — volatile GM load.
       Returns ``Boolean`` indicating whether ``*ptr <cmp> expected`` is true.
    """
    if callable(point):
        return point()

    from cannbotdsl.core.contracts.elements import coerce_scalar_to_storage, wrap_produced_scalar

    memref, coord, storage_type = _wait_point_operands(
        point, api_name="try_wait"
    )
    expected_value = coerce_scalar_to_storage(
        expected, storage_type, path="try_wait expected"
    )
    cmp_val = int(cmp) if isinstance(cmp, CmpOp) else int(CmpOp.NE)
    result = cannir.try_wait(memref, coord, expected_value, cmp=cmp_val)
    from cannbotdsl._mlir.ir import IntegerType
    return wrap_produced_scalar(result, storage_type=IntegerType.get_signless(1))


# ==============================================================================
# Vector Core Synchronization Operations
# ==============================================================================


def dcci_single(point):
    """Invalidate the data-cache line of one GM scalar location.

    Flushes the cache line containing the location addressed by ``point`` so
    the next scalar-unit read observes Global Memory directly (manual
    cache-coherency barrier for cross-core communication).  Use before
    polling a flag written by another core, or after publishing a
    scalar-unit store that must become visible immediately.

    ``point`` must be a direct ``Tensor[...]`` indexing expression result
    (same calling convention as ``cube_busy_wait``/``vec_busy_wait``/``try_wait``).
    """
    memref, coord, _ = _wait_point_operands(point, api_name="dcci_single")
    cannir.dcci_single(memref, coord)


def dcci_entire_out():
    """Flush all write-out data-cache lines to Global Memory.

    Batch publish barrier after scalar-unit GM stores spanning many cache
    lines.  Complements dcci_single (one precise line) with a whole-region
    flush; stronger than needed for a single flag, cheaper per line for
    large scattered stores.
    """
    cannir.dcci_entire_out()


def dcci_entire_atomic():
    """Flush all atomic-path data-cache lines to Global Memory.

    Publish barrier after atomic read-modify-write ops on GM (counters,
    locks) so other cores observe the effects.  Companion of
    dcci_entire_out for the atomic access path.
    """
    cannir.dcci_entire_atomic()


def dci():
    """Invalidate the entire data cache, discarding dirty lines.

    Stronger than dcci_entire_*: unpublished local modifications are dropped,
    not flushed.  A full data barrier (DSB_ALL) is emitted automatically
    before the invalidation as the hardware contract requires.  Use when
    re-reading GM wholesale after other cores rewrote it and local cached
    writes are known to be disposable.
    """
    cannir.dci()


def vec_get_buf(pipe: PIPE, buf_id, mode: int = 0):
    """
    Apply for a logical buffer within the NPU Vector Core.
    """
    ascvec.get_buf(pipe, _ensure_i64_value(buf_id), _ensure_i32_attr(mode))


def vec_release_buf(pipe: PIPE, buf_id, mode: int = 0):
    """
    Release a logical buffer within the NPU Vector Core.
    """
    ascvec.release_buf(pipe, _ensure_i64_value(buf_id), _ensure_i32_attr(mode))


def vec_sync_intra_arrive(pipe: PIPE, sync_id):
    """
    Issue an intra-block arrive signal within the NPU Vector Core.
    """
    ascvec.sync_intra_arrive(pipe, _ensure_i64_value(sync_id))


def vec_sync_intra_wait(pipe: PIPE, sync_id):
    """
    Wait for an intra-block arrive signal within the NPU Vector Core.
    """
    ascvec.sync_intra_wait(pipe, _ensure_i64_value(sync_id))


def cube_raw_l1_to_l0a(l0a_buf, l1_buf, *, l1_offset_elems: int = 0,
                       m_start: int = 0, k_start: int = 0,
                       m_step: int = 1, k_step: int = 1,
                       src_stride: int = 1, dst_stride: int = 1,
                       transpose: bool = False):
    cannir.raw_l1_to_l0a(
        _unwrap_tensor(l0a_buf),
        _unwrap_tensor(l1_buf),
        _ensure_index_value(l1_offset_elems),
        _ensure_i32_value(m_start),
        _ensure_i32_value(k_start),
        _ensure_i32_value(m_step),
        _ensure_i32_value(k_step),
        _ensure_i32_value(src_stride),
        _ensure_i32_value(dst_stride),
        transpose=transpose,
    )


def cube_raw_l1_to_l0a_mx(
    l0a_buf,
    l1_scale_buf,
    *,
    l1_offset_elems: int = 0,
    x_start_pos: int = 0,
    y_start_pos: int = 0,
    x_step: int = 1,
    y_step: int = 1,
    src_stride: int = 1,
    dst_stride: int = 1,
):
    """Copy fp8_e8m0 L1 scale fractures to the paired L0A_MX mapping.

    Position, step, and stride parameters use 32-byte scale fractures and map
    directly to the non-sync ``asc_copy_l12l0a_mx`` interface.
    """
    for name, value, upper in (
        ("x_start_pos", x_start_pos, 65535),
        ("y_start_pos", y_start_pos, 65535),
        ("x_step", x_step, 255),
        ("y_step", y_step, 255),
        ("src_stride", src_stride, 65535),
        ("dst_stride", dst_stride, 65535),
    ):
        if type(value) is int and not 0 <= value <= upper:
            raise ValueError(f"asc_copy_l12l0a_mx {name} must be in [0, {upper}]")
    cannir.raw_l1_to_l0a_mx(
        _unwrap_tensor(l0a_buf),
        _unwrap_tensor(l1_scale_buf),
        _ensure_index_value(l1_offset_elems),
        _ensure_i32_value(x_start_pos),
        _ensure_i32_value(y_start_pos),
        _ensure_i32_value(x_step),
        _ensure_i32_value(y_step),
        _ensure_i32_value(src_stride),
        _ensure_i32_value(dst_stride),
    )


def cube_raw_l1_to_l0b(l0b_buf, l1_buf, *, l1_offset_elems: int = 0,
                       m_start: int = 0, k_start: int = 0,
                       m_step: int = 1, k_step: int = 1,
                       src_stride: int = 1, dst_stride: int = 1,
                       transpose: bool = False):
    cannir.raw_l1_to_l0b(
        _unwrap_tensor(l0b_buf),
        _unwrap_tensor(l1_buf),
        _ensure_index_value(l1_offset_elems),
        _ensure_i32_value(m_start),
        _ensure_i32_value(k_start),
        _ensure_i32_value(m_step),
        _ensure_i32_value(k_step),
        _ensure_i32_value(src_stride),
        _ensure_i32_value(dst_stride),
        transpose=transpose,
    )


def cube_raw_l1_to_l0b_mx(
    l0b_buf,
    l1_scale_buf,
    *,
    l1_offset_elems: int = 0,
    x_start_pos: int = 0,
    y_start_pos: int = 0,
    x_step: int = 1,
    y_step: int = 1,
    src_stride: int = 1,
    dst_stride: int = 1,
):
    """Copy fp8_e8m0 L1 scale fractures to the paired L0B_MX mapping.

    Position, step, and stride parameters map directly to the non-sync
    ``asc_copy_l12l0b_mx`` interface.
    """
    for name, value, upper in (
        ("x_start_pos", x_start_pos, 65535),
        ("y_start_pos", y_start_pos, 65535),
        ("x_step", x_step, 255),
        ("y_step", y_step, 255),
        ("src_stride", src_stride, 65535),
        ("dst_stride", dst_stride, 65535),
    ):
        if type(value) is int and not 0 <= value <= upper:
            raise ValueError(f"asc_copy_l12l0b_mx {name} must be in [0, {upper}]")
    cannir.raw_l1_to_l0b_mx(
        _unwrap_tensor(l0b_buf),
        _unwrap_tensor(l1_scale_buf),
        _ensure_index_value(l1_offset_elems),
        _ensure_i32_value(x_start_pos),
        _ensure_i32_value(y_start_pos),
        _ensure_i32_value(x_step),
        _ensure_i32_value(y_step),
        _ensure_i32_value(src_stride),
        _ensure_i32_value(dst_stride),
    )


def cube_raw_l1_to_l0b_trans(l0b_buf, l1_buf, *,
                             l1_offset_elems: int = 0,
                             index_id: int = 0, repeat: int = 1,
                             src_stride: int = 0, dst_gap: int = 0,
                             dst_frac_gap: int = 0, src_frac_gap: int = 0):
    """Fracture-level transposing L1 -> L0B copy (asc_copy_l12l0b_trans).

    `index_id` selects the source fracture matrix to start from; each
    `repeat` iteration transposes one block matrix. `src_stride` is in
    1024-byte units between consecutive source block matrices; `dst_gap`
    is in 512-byte units between consecutive iterations; `dst_frac_gap` /
    `src_frac_gap` are in 512-byte units between the two fractals within
    one iteration (effective for float/int32/uint32/int8/uint8).
    """
    cannir.raw_l1_to_l0b_trans(
        _unwrap_tensor(l0b_buf),
        _unwrap_tensor(l1_buf),
        _ensure_index_value(l1_offset_elems),
        _ensure_i32_value(index_id),
        _ensure_i32_value(repeat),
        _ensure_i32_value(src_stride),
        _ensure_i32_value(dst_gap),
        _ensure_i32_value(dst_frac_gap),
        _ensure_i32_value(src_frac_gap),
    )


def cube_raw_gm2l1(l1_buf, gm_buf, *, m_start: int = 0, k_start: int = 0,
                   m_step: int = 1, k_step: int = 1, dst_stride: int = 0,
                   l2_cache_ctl: int = 0):
    """Typed 2D GM -> L1 copy with explicit source-window control
    (asc_copy_gm2l1).

    ``m_start`` is the GM source M-axis start offset in 16-element units;
    ``k_start`` is the source K-axis start offset in 32-byte units;
    ``m_step`` / ``k_step`` are the M/K-axis copy lengths in the same units;
    ``dst_stride`` is the destination K-direction fractal gap in 512-byte
    units. The copy lands at the destination tensor's base address — pass a
    ``tile_slice`` of the L1 buffer (or an offset Channel slot) to place data
    at a later fractal.
    """
    cannir.raw_gm2l1(
        _unwrap_tensor(l1_buf),
        _unwrap_tensor(gm_buf),
        _ensure_i32_value(m_start),
        _ensure_i32_value(k_start),
        _ensure_i32_value(m_step),
        _ensure_i32_value(k_step),
        _ensure_i32_value(dst_stride),
        l2_cache_ctl=_ensure_i32_attr(l2_cache_ctl),
    )


def cube_raw_gm2l1_highdim(l1_buf, gm_buf, *, n_burst: int = 1,
                           len_burst: int = 1, pad_func_mode: int = 0,
                           src_stride: int = 0, dst_stride: int = 0,
                           pad_value: int = 0):
    """High-dimensional GM -> L1 copy with channel padding control.

    Length and strides use 32-byte DataBlocks. Modes 1..5 insert padding;
    modes 6..8 remove padding; mode 0 preserves all bytes.
    """
    cannir.raw_gm2l1_highdim(
        _unwrap_tensor(l1_buf),
        _unwrap_tensor(gm_buf),
        _ensure_i32_value(n_burst), _ensure_i32_value(len_burst),
        _ensure_i32_value(pad_func_mode), _ensure_i64_value(src_stride),
        _ensure_i32_value(dst_stride),
        pad_value=_ensure_i32_attr(pad_value),
    )


def _fill_l1_value(value, value_dtype):
    from cannbotdsl import dtypes

    supported = (dtypes.uint32, dtypes.float16, dtypes.bfloat16)
    if value_dtype is None:
        value_dtype = getattr(value, "dtype", None)
        if value_dtype is None:
            if type(value) is int:
                value_dtype = dtypes.uint32
            elif type(value) is float:
                value_dtype = dtypes.float16
    if value_dtype not in supported:
        names = ", ".join(f"dtypes.{dtype.name}" for dtype in supported)
        raise TypeError(f"asc_fill_l1 value_dtype must be one of: {names}")
    return unwrap_operand(value_dtype(value)), value_dtype


def _validate_fill_l1_config(*, offset_elems, repeat, blk_num, dst_gap):
    if type(offset_elems) is int and offset_elems < 0:
        raise ValueError("asc_fill_l1 offset_elems must be non-negative")
    for name, value in (("repeat", repeat), ("blk_num", blk_num)):
        if type(value) is int and not 1 <= value <= 32767:
            raise ValueError(f"asc_fill_l1 {name} must be in [1, 32767]")
    if type(dst_gap) is int and not 0 <= dst_gap <= 32767:
        raise ValueError("asc_fill_l1 dst_gap must be in [0, 32767]")


def cube_fill_l1(l1_buf, value, *, value_dtype=None, offset_elems: int = 0,
                 repeat: int = 1, blk_num: int = 1, dst_gap: int = 0):
    """Fill L1 DataBlocks with a uint32 bit pattern, half, or bfloat16 value.

    Python integers default to the ``uint32_t`` bit-pattern overload and Python
    floats default to ``half``. Pass ``value_dtype`` explicitly when a literal
    must use another supported overload. A ``bfloat16_t`` fill value is valid
    only for a bfloat16 L1 destination, matching the Ascend C API.
    """
    from cannbotdsl import dtypes

    _validate_fill_l1_config(
        offset_elems=offset_elems,
        repeat=repeat,
        blk_num=blk_num,
        dst_gap=dst_gap,
    )
    fill_value, resolved_dtype = _fill_l1_value(value, value_dtype)
    dst_dtype = getattr(l1_buf, "dtype", None)
    normal_destinations = {
        dtypes.int16, dtypes.uint16, dtypes.float16,
        dtypes.int32, dtypes.uint32, dtypes.float32,
    }
    if dst_dtype == dtypes.bfloat16:
        pass
    elif dst_dtype in normal_destinations:
        if resolved_dtype == dtypes.bfloat16:
            raise TypeError(
                "a bfloat16 asc_fill_l1 value requires a bfloat16 destination"
            )
    else:
        raise TypeError(
            "cube_fill_l1 destination dtype is not supported by asc_fill_l1"
        )
    cannir.raw_fill_l1(
        _unwrap_tensor(l1_buf),
        _ensure_index_value(offset_elems),
        fill_value,
        _ensure_i32_value(repeat),
        _ensure_i32_value(blk_num),
        _ensure_i32_value(dst_gap),
    )


def cube_fill_l1_zero(l1_buf, *, offset_elems: int = 0, repeat: int = 1,
                      blk_num: int = 1, dst_gap: int = 0):
    """Compatibility zero-fill, including internal aliased fp8 L1 buffers."""
    _validate_fill_l1_config(
        offset_elems=offset_elems,
        repeat=repeat,
        blk_num=blk_num,
        dst_gap=dst_gap,
    )
    cannir.raw_fill_l1(
        _unwrap_tensor(l1_buf),
        _ensure_index_value(offset_elems),
        _ensure_i32_value(0),
        _ensure_i32_value(repeat),
        _ensure_i32_value(blk_num),
        _ensure_i32_value(dst_gap),
    )


def cube_raw_l12fb(fb_buf, l1_buf, *, n_burst: int = 1,
                   len_burst: int = 1, src_gap: int = 0,
                   dst_gap: int = 0):
    """High-dimensional L1 -> Fixpipe Buffer copy.

    ``len_burst`` and ``dst_gap`` use 64-byte Fixpipe blocks; ``src_gap``
    uses 32-byte DataBlocks.
    """
    cannir.raw_l12fb(
        _unwrap_tensor(fb_buf),
        _unwrap_tensor(l1_buf),
        _ensure_i32_value(n_burst), _ensure_i32_value(len_burst),
        _ensure_i32_value(src_gap), _ensure_i32_value(dst_gap),
    )


def cube_raw_l12fb_size(fb_buf, l1_buf, size: int, *, sync: bool = False):
    """Copy the first ``size`` bytes (64-byte aligned on arch 3510) from L1 to FBUF."""
    cannir.raw_l12fb_size(
        _unwrap_tensor(fb_buf),
        _unwrap_tensor(l1_buf),
        _ensure_i32_value(size), sync=sync,
    )


def cube_raw_l12ub(ub_buf, l1_buf, *, sub_blockid: int = 0,
                   n_burst: int = 1, burst_len: int = 1,
                   src_gap: int = 0, dst_gap: int = 0):
    """Copy strided 32-byte DataBlocks from L1 to a Vector sub-core's UB.

    ``sub_blockid`` selects Vector sub-core 0 or 1. ``burst_len``, ``src_gap``,
    and ``dst_gap`` are measured in 32-byte DataBlocks. This is the
    non-synchronizing seven-argument ``asc_copy_l12ub`` form; Channel operands
    provide the cross-core ownership and synchronization protocol.
    """
    cannir.raw_l12ub(
        _unwrap_tensor(ub_buf),
        _unwrap_tensor(l1_buf),
        _ensure_i32_value(sub_blockid), _ensure_i32_value(n_burst),
        _ensure_i32_value(burst_len), _ensure_i32_value(src_gap),
        _ensure_i32_value(dst_gap),
    )


def cube_raw_l12bt_size(bt_buf, l1_buf, size: int):
    """Copy the first ``size`` bytes (32-byte aligned) from L1 to BIAS/BT."""
    cannir.raw_l12bt_size(
        _unwrap_tensor(bt_buf),
        _unwrap_tensor(l1_buf),
        _ensure_i32_value(size),
    )


def vec_sync_block_arrive(pipe: PIPE, flag_id, mode: int = 2):
    """Issue an all-core arrive signal from the NPU Vector Core."""
    _check_flag_id(flag_id, api_name="vec_sync_block_arrive")
    kwargs = {} if mode == 2 else {"mode": _ensure_i32_attr(mode)}
    ascvec.sync_block_arrive(pipe, _ensure_i64_value(flag_id), **kwargs)


def vec_sync_block_wait(pipe: PIPE, flag_id, mode: int = 2):
    """Wait for an all-core sync signal from the NPU Vector Core.

    ``mode`` does not reach the device: codegen emits ``asc_sync_block_wait``
    without it, so the matching arrive alone selects the participant set.

    It is not inert, though.  ``split-mix-kernel`` reads it to tell an
    all-cores handshake (mode 0, survives on a pure-core kernel) from an
    intra-block one (mode 2, pruned there because its partner core is gone).
    Pass the same mode as the matching arrive, or a mode 0 wait will be
    dropped on a pure-core kernel and the barrier will not hold.
    """
    _check_flag_id(flag_id, api_name="vec_sync_block_wait")
    kwargs = {} if mode == 2 else {"mode": _ensure_i32_attr(mode)}
    ascvec.sync_block_wait(pipe, _ensure_i64_value(flag_id), **kwargs)


def vec_sync_all():
    """Wait for all pending Vector Core pipeline operations."""
    ascvec.sync_all()


def vec_sync_pipe(pipe: PIPE):
    """Order operations on one Vector pipeline, including overlapping writes."""
    ascvec.sync_pipe(pipe)


def vec_sync_notify(src_pipe: PIPE, dst_pipe: PIPE, event_id: int):
    """
    Cross-pipe notify within the NPU Vector Core (asc_sync_notify).

    Issued by the producer pipe to inform the consumer pipe that a hardware
    event_id slot is now armed.
    """
    ascvec.sync_notify(
        _ensure_i32_attr(int(src_pipe)),
        _ensure_i32_attr(int(dst_pipe)),
        _ensure_i32_attr(int(event_id)),
    )


def vec_sync_wait(src_pipe: PIPE, dst_pipe: PIPE, event_id: int):
    """
    Cross-pipe wait within the NPU Vector Core (asc_sync_wait).

    AscendC convention: BOTH notify and wait carry (src_pipe=producer,
    dst_pipe=consumer). The wait blocks the consumer pipe until the
    producer signals — pass the SAME (src, dst) ordering as the matching
    vec_sync_notify; do not flip the args.
    """
    ascvec.sync_wait(
        _ensure_i32_attr(int(src_pipe)),
        _ensure_i32_attr(int(dst_pipe)),
        _ensure_i32_attr(int(event_id)),
    )


# ==============================================================================
# Cube Core Synchronization Operations
# ==============================================================================


def cube_get_buf(pipe: PIPE, buf_id, mode: int = 0):
    """
    Apply for a logical buffer within the NPU Cube Core.
    """
    asccube.get_buf(pipe, _ensure_i64_value(buf_id), _ensure_i32_attr(mode))


def cube_release_buf(pipe: PIPE, buf_id, mode: int = 0):
    """
    Release a logical buffer within the NPU Cube Core.
    """
    asccube.release_buf(pipe, _ensure_i64_value(buf_id), _ensure_i32_attr(mode))


def cube_sync_intra_arrive(pipe: PIPE, sync_id):
    """
    Issue an intra-block arrive signal within the NPU Cube Core.
    """
    asccube.sync_intra_arrive(pipe, _ensure_i64_value(sync_id))


def cube_sync_intra_wait(pipe: PIPE, sync_id):
    """
    Wait for an intra-block arrive signal within the NPU Cube Core.
    """
    asccube.sync_intra_wait(pipe, _ensure_i64_value(sync_id))


def cube_sync_block_arrive(pipe: PIPE, flag_id, mode: int = 2):
    """Issue an all-core arrive signal from the NPU Cube Core."""
    _check_flag_id(flag_id, api_name="cube_sync_block_arrive")
    kwargs = {} if mode == 2 else {"mode": _ensure_i32_attr(mode)}
    asccube.sync_block_arrive(pipe, _ensure_i64_value(flag_id), **kwargs)


def cube_sync_block_wait(pipe: PIPE, flag_id, mode: int = 2):
    """Wait for an all-core sync signal from the NPU Cube Core.

    ``mode`` does not reach the device: codegen emits ``asc_sync_block_wait``
    without it, so the matching arrive alone selects the participant set.

    It is not inert, though.  ``split-mix-kernel`` reads it to tell an
    all-cores handshake (mode 0, survives on a pure-core kernel) from an
    intra-block one (mode 2, pruned there because its partner core is gone).
    Pass the same mode as the matching arrive, or a mode 0 wait will be
    dropped on a pure-core kernel and the barrier will not hold.
    """
    _check_flag_id(flag_id, api_name="cube_sync_block_wait")
    kwargs = {} if mode == 2 else {"mode": _ensure_i32_attr(mode)}
    asccube.sync_block_wait(pipe, _ensure_i64_value(flag_id), **kwargs)


def cube_sync_all():
    """Wait for all pending Cube Core pipeline operations."""
    asccube.sync_all()


def cube_sync_pipe(pipe: PIPE):
    """Wait for all pending operations issued on one Cube pipeline."""
    asccube.sync_pipe(pipe)


def cube_sync_notify(src_pipe: PIPE, dst_pipe: PIPE, event_id: int):
    """
    Cross-pipe notify within the NPU Cube Core (asc_sync_notify).

    The canonical use is to serialize a producer pipe's GM/L1 write against
    a consumer pipe's GM/L1 read on the same memory region — e.g., after a
    FIXPIPE drains L0C → GM, notify MTE2 before re-reading the same GM tile
    via copy_gm2l1. AscendC does NOT auto-serialize across pipes.
    """
    asccube.sync_notify(
        _ensure_i32_attr(int(src_pipe)),
        _ensure_i32_attr(int(dst_pipe)),
        _ensure_i32_attr(int(event_id)),
    )


def cube_sync_wait(src_pipe: PIPE, dst_pipe: PIPE, event_id: int):
    """
    Cross-pipe wait within the NPU Cube Core (asc_sync_wait).

    AscendC convention: BOTH notify and wait carry (src_pipe=producer,
    dst_pipe=consumer). The wait says 'block on the consumer pipe until
    the producer pipe has signalled this event_id'. So callers should pass
    the SAME (src, dst) ordering they used for cube_sync_notify — do not
    flip the args.

    event_id should cycle over a small pool (typically 0-3 for the cube
    core) — reusing the same id sequentially is safe because each
    notify/wait pair drains before the id is reused.
    """
    asccube.sync_wait(
        _ensure_i32_attr(int(src_pipe)),
        _ensure_i32_attr(int(dst_pipe)),
        _ensure_i32_attr(int(event_id)),
    )


# ==============================================================================
# Grid-wide Synchronization
# ==============================================================================


def global_sync_all(*, flag_ids=None):
    """Barrier across every core of the launch.

    Emits the full four-phase sequence.  What survives depends on how the
    kernel classifies, which ``split-mix-kernel`` decides late in the pass
    pipeline from the ops the whole function ended up emitting:

    ======  ==============================  ============================
    phase   handshake                       kept on
    ======  ==============================  ============================
    1       AIV -> AIC, within block (m=2)  mix
    2       all AIC, across blocks   (m=0)  mix, pure-AIC
    3       all AIV, across blocks   (m=0)  mix, pure-AIV
    4       AIC -> AIV, within block (m=2)  mix
    ======  ==============================  ============================

    On a mix kernel all four run.  Phase 2 is the grid barrier; phases 1 and 4
    funnel the vector cores through the AIC of their own block, which is the
    only cross-block path they have.  Phase 3 is a redundant AIV-to-AIV meeting
    point inside that funnel -- every AIV reaches it anyway, so it reorders
    nothing.

    On a pure-core kernel ``split-mix-kernel`` prunes the other core's ops and
    the mode 2 handshakes, whose partner no longer runs, leaving a single
    mode 0 barrier: phase 2 on pure AIC, phase 3 on pure AIV.  That is why this
    function does not take a "which core am I" argument -- at trace time the
    kernel body after this call does not exist yet, so any answer here would be
    a guess about ops not yet emitted.  Emitting the superset and letting the
    pass prune moves the decision to where the answer is known.

    Phases 2 and 3 share a flag id.  mode 0 means "all cores of the issuing
    type" -- ``pto/npu/a2a3/TPush.hpp`` gives ``CUBE_ALL_CORE_SYNC`` and
    ``VEC_ALL_CORE_SYNC`` the same value 0 -- so the issuing core type
    partitions the flag and the two handshakes cannot alias.  The three ids
    that *are* distinct must stay so: codegen drops ``mode`` on the wait path,
    leaving the id as the only thing telling one phase from the next.

    The leading sync_all calls are load-bearing: an FFTS arrive drains only the
    pipe it is issued on, so without them a peer can observe the flag before an
    in-flight write on another pipe.

    Args:
        flag_ids: three distinct ids in [0, 15] -- funnel-in, cross-block,
            funnel-out. Defaults to the fixed triple (0, 1, 2), reused by
            successive completed barriers, including statically unrolled loops.
            Keep these IDs separate from overlapping manual FFTS protocols,
            or supply a different explicit triple for the barrier.

    The Channel resource pass can reuse hardware IDs across this complete
    barrier once the old protocols are closed. ``channel_rewind()`` is needed
    only when explicitly reusing on-chip addresses; it is not an ID allocator
    and cannot replace this synchronization boundary.

    Deadlocks if the launch does not fit one resident wave: a mode 0 phase
    makes resident blocks wait for blocks the scheduler cannot start.
    ``block_dim`` must not exceed the device core count for the issuing core
    type.  That cannot be checked here -- this function has no visibility into
    block_dim.
    """
    if flag_ids is None:
        flag_ids = _GLOBAL_SYNC_ALL_FLAG_IDS
    else:
        flag_ids = list(flag_ids)
        if len(flag_ids) != _GLOBAL_SYNC_ALL_PHASES:
            raise ValueError(
                f"global_sync_all needs {_GLOBAL_SYNC_ALL_PHASES} flag ids "
                f"(one per phase), got {len(flag_ids)}"
            )
        if len(set(flag_ids)) != len(flag_ids):
            raise ValueError(
                "global_sync_all flag_ids must be distinct -- the wait path "
                f"ignores mode, so a shared id merges two phases: {flag_ids}"
            )
        for flag_id in flag_ids:
            _check_flag_id(flag_id, api_name="global_sync_all")

    aiv_ready_flag_id, cross_block_flag_id, aic_aiv_ready_flag_id = flag_ids

    # Drain both cores' pipelines before anything is announced externally.
    cube_sync_all()
    vec_sync_all()

    # 1. AIV -> AIC, within block.
    vec_sync_block_arrive(PIPE.MTE3, aiv_ready_flag_id, mode=2)
    cube_sync_block_wait(PIPE.S, aiv_ready_flag_id)

    # 2. All AIC, across blocks -- the grid barrier.
    cube_sync_block_arrive(PIPE.FIXPIPE, cross_block_flag_id, mode=0)
    cube_sync_block_wait(PIPE.S, cross_block_flag_id, mode=0)

    # 3. All AIV, across blocks.  Redundant on a mix kernel -- every AIV is
    # already held by phases 1 and 4 -- and the whole barrier on a pure-AIV
    # kernel, once the pass has pruned the cube side.  Shares phase 2's flag:
    # mode 0 is partitioned by issuing core type.
    vec_sync_block_arrive(PIPE.MTE3, cross_block_flag_id, mode=0)
    vec_sync_block_wait(PIPE.S, cross_block_flag_id, mode=0)

    # 4. AIC -> AIV, within block.
    cube_sync_block_arrive(PIPE.MTE3, aic_aiv_ready_flag_id, mode=2)
    vec_sync_block_wait(PIPE.S, aic_aiv_ready_flag_id)


def channel_rewind(reset_sync_id=True):
    """Declare an explicit address/Buffer-ID allocation boundary.

    With reset_sync_id=True, also permit a new counter allocation phase.
    False keeps counters in the same phase at this boundary only. A boundary
    does not insert a hardware barrier or release live resources: counter reuse
    still needs proven completion, and address reuse requires dead storage.
    Hardware IDs are assigned by MLIR using next-fit; its cursor is not reset.
    """
    from cannbotdsl._onchip import _current_onchip_trace

    if type(reset_sync_id) is not bool:
        raise TypeError("reset_sync_id must be a static bool")
    if _current_onchip_trace()._ub_space_root is not None:
        raise ValueError("channel_rewind is not supported in UB-space mode")
    cannir.OnChipRewindOp(reset_sync_id=reset_sync_id)
