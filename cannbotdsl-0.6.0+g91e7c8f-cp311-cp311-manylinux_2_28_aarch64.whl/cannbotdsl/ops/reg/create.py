# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode register creation ops."""

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import ascvec
from cannbotdsl._mlir.dialects import arith, cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _dtype_type, _raw_vreg_type, _scalar_value, _tag_raw_op
from cannbotdsl.ops.reg.mask import Mask
from cannbotdsl.ops.reg.reg_defs import OrderMode, RawVReg


def vdups(value, dtype, *, mask: "Mask | None" = None, mode: str = "zeroing",
                merge: "RawVReg | None" = None) -> RawVReg:
    """Fill all lanes with `value` (optional mask, optional merging).

    When `mask` is omitted, lowers to the no-mask vbr form
    ``asc_duplicate_scalar(dst, val)``.
    When `mask` is provided with ``mode="zeroing"`` (default), lowers to
    ``asc_duplicate_scalar(dst, val, mask)`` — inactive lanes are zeroed
    (exec_zeroing semantics).
    ``mode="merging"`` lowers to ``asc_duplicate_scalar_merge(dst, val, mask)`` —
    inactive lanes keep the value of `merge` (MODE_MERGING); requires both
    `mask` and `merge` (AscendC has no merging overload without a mask).
    """
    _require_raw_mode("vdups")
    if mode not in ("zeroing", "merging"):
        raise ValueError(f"vdups: mode must be 'zeroing' or 'merging', got {mode!r}")
    if mode == "merging":
        if mask is None:
            raise ValueError("vdups: mode='merging' requires a mask")
        if merge is None:
            raise ValueError("vdups: mode='merging' requires merge=<old vreg>")
        if merge.dtype != _dtype_type(dtype):
            raise ValueError(f"vdups: merge dtype {merge.dtype} must match dtype {dtype}")
        dtype = _dtype_type(dtype)
        scalar = _scalar_value(value, dtype)
        op = ascvec.DuplicateScalarOp(
            _raw_vreg_type(dtype), scalar, mask.value,
            mode="merging", merge_src=merge.value,
        )
        _tag_raw_op(op)
        return RawVReg(op.result, dtype)
    elif merge is not None:
        raise ValueError("vdups: merge is only valid with mode='merging'")
    dtype = _dtype_type(dtype)
    scalar = _scalar_value(value, dtype)
    if mask is None:
        op = ascvec.DuplicateScalarNoMaskOp(_raw_vreg_type(dtype), scalar)
    else:
        op = ascvec.DuplicateScalarOp(
            _raw_vreg_type(dtype), scalar, mask.value, mode="zeroing"
        )
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def vdup(src: RawVReg, *, mask: Mask, position: str = "lowest", mode: str = "zeroing",
         merge: "RawVReg | None" = None) -> RawVReg:
    """Broadcast one lane of ``src`` to all other lanes (pos/mode selectable).

    Matches arch35 ``vdup(dst, src, mask, POS, MODE)`` 1:1 with CANN 9.2.0:

    - default (``pos="lowest"``, ``mode="zeroing"``) -> ``asc_duplicate``
    - ``pos="highest"`` -> ``asc_duplicate_highest`` (POS_HIGHEST, zeroing)
    - ``mode="merging"`` -> ``asc_duplicate_merge`` / ``asc_duplicate_highest_merge``;
      lanes outside ``mask`` keep the value of ``merge`` (MODE_MERGING), so
      ``merge`` is required exactly when ``mode="merging"``.
    """
    _require_raw_mode("vdup")
    if position not in ("lowest", "highest"):
        raise ValueError(f"vdup: position must be 'lowest' or 'highest', got {position!r}")
    if mode not in ("zeroing", "merging"):
        raise ValueError(f"vdup: mode must be 'zeroing' or 'merging', got {mode!r}")
    if mode == "merging":
        if merge is None:
            raise ValueError("vdup: mode='merging' requires merge=<old vreg>")
        if merge.dtype != src.dtype:
            raise ValueError(
                f"vdup: merge dtype {merge.dtype} must match src dtype {src.dtype}"
            )
    elif merge is not None:
        raise ValueError("vdup: merge is only valid with mode='merging'")
    op = ascvec.DuplicateOp(
        _raw_vreg_type(src.dtype), src.value, mask.value,
        merge_src=merge.value if merge is not None else None,
        pos=position, mode=mode,
    )
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def varange(start, dtype, *, order_mode: "str | OrderMode" = OrderMode.INCREASED) -> RawVReg:
    """Fill vector with sequential values starting from `start`.

    ``order_mode=OrderMode.INCREASED`` (default) matches ``asc_arange`` (vci
    INC_ORDER); ``OrderMode.DECREASED`` matches ``asc_arange_descend``
    (vci DEC_ORDER), producing ``{value+VL-1, ..., value}`` for element
    offsets, and the result still starts from `start` in logical layout.
    """
    _require_raw_mode("varange")
    if isinstance(order_mode, OrderMode):
        order = order_mode.value
    elif isinstance(order_mode, str):
        order = order_mode
        if order not in ("increased", "decreased"):
            raise ValueError(f"varange: order_mode must be 'increased' or 'decreased', got {order_mode!r}")
    else:
        raise TypeError("varange: order_mode must be an OrderMode or string")
    order = "inc" if order == "increased" else "dec"
    dtype = _dtype_type(dtype)
    scalar = _scalar_value(start, dtype)
    # The result element type fixes the index width (the verifier requires
    # matching bit widths). When `index` arrives as a wider/narrower SSA value
    # (e.g. an i64 scf.for induction variable), coerce it to the signless
    # equivalent of the result element width.
    if isinstance(scalar, ir.Value) and isinstance(scalar.type, ir.IntegerType):
        want = ir.IntegerType.get_signless(dtype.width)
        if scalar.type.width != dtype.width:
            if scalar.type.width > dtype.width:
                scalar = arith.trunci(want, scalar)
            else:
                scalar = arith.extsi(want, scalar)
        elif scalar.type != want:
            scalar = arith.bitcast(want, scalar)
    op = ascvec.VArangeOp(_raw_vreg_type(dtype), scalar, order=order)
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)
