# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode dtype cast and rounding ops."""

from enum import IntEnum as _IntEnum

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import ascvec, cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _dtype_bits, _dtype_type, _raw_vreg_type, _tag_raw_op
from cannbotdsl.ops.reg.mask import Mask
from cannbotdsl.ops.reg.reg_defs import RawVReg


class RegLayout(_IntEnum):
    UNKNOWN = -1
    ZERO = 0
    ONE = 1
    TWO = 2
    THREE = 3


class RoundingMode(_IntEnum):
    NA = 6  # not specified: widening casts pass through (no rounding);
    # narrowing casts auto-select RN (AscendC default)
    RN = 0  # nearest even
    RNA = 1  # nearest away from zero
    RD = 2  # toward negative infinity
    RU = 3  # toward positive infinity
    RZ = 4  # toward zero
    RO = 5  # nearest odd; f32->f16 only


_ROUNDING_ALIASES = {
    "na": RoundingMode.NA,
    "rn": RoundingMode.RN,
    "rna": RoundingMode.RNA,
    "rd": RoundingMode.RD,
    "ru": RoundingMode.RU,
    "rz": RoundingMode.RZ,
    "ro": RoundingMode.RO,
}


def _normalize_rounding(rounding) -> RoundingMode:
    if isinstance(rounding, RoundingMode):
        return rounding
    if isinstance(rounding, str):
        key = rounding.lower()
        if key in _ROUNDING_ALIASES:
            return _ROUNDING_ALIASES[key]
    raise ValueError("vcast: rounding must be one of 'na', 'rn', 'rna', 'rd', 'ru', 'rz', or 'ro'")


def _normalize_reg_layout(reg_layout) -> RegLayout:
    if isinstance(reg_layout, RegLayout):
        return reg_layout
    raise TypeError("vcast: reg_layout must be a RegLayout")


def _is_full_mask(mask: "Mask") -> bool:
    """True when ``mask`` was produced by full_mask/create_mask (pset).

    A full mask is granularity-agnostic (b8 all-true covers b16/b32 lanes),
    so callers may accept it for any element bit width.
    """
    try:
        defining_op = mask.value.owner
        return getattr(defining_op, "name", "") == "cannir.raw_reg.full_mask"
    except Exception:
        return False


def vcast(
    src: RawVReg,
    dtype,
    *,
    mask: Mask,
    rounding=RoundingMode.NA,
    saturate=False,
    reg_layout=RegLayout.UNKNOWN,
) -> RawVReg:
    """Cast a raw vector register to ``dtype``.

    ``rounding=RoundingMode.NA`` (default) lets the DSL pick per AscendC
    conventions: widening casts carry no rounding (exact); narrowing casts
    auto-select RN. Pass an explicit RoundingMode to pin the behavior.

    For fp4x2_e2m1 to bfloat16, ``RegLayout.ZERO`` through
    ``RegLayout.THREE`` select source positions P0 through P3. The conversion
    uses an 8-bit mask because each physical source carrier holds two fp4
    values.
    """
    _require_raw_mode("vcast")
    from cannbotdsl.ops.reg._common import _reject_b64

    _reject_b64("vcast", src)
    dtype = _dtype_type(dtype)
    src_bits = _dtype_bits(src.dtype)
    dst_bits = _dtype_bits(dtype)
    rounding = _normalize_rounding(rounding)
    fp8_types = (ir.Float8E4M3FNType, ir.Float8E5M2Type)
    src_is_fp8 = isinstance(src.dtype, fp8_types)
    dst_is_fp8 = isinstance(dtype, fp8_types)
    src_is_f32 = isinstance(src.dtype, ir.F32Type)
    dst_is_f32 = isinstance(dtype, ir.F32Type)
    src_is_f16 = isinstance(src.dtype, ir.F16Type)
    dst_is_f16 = isinstance(dtype, ir.F16Type)
    src_is_bf16 = isinstance(src.dtype, ir.BF16Type)
    dst_is_bf16 = isinstance(dtype, ir.BF16Type)
    src_integer_type = (
        src.dtype if isinstance(src.dtype, ir.IntegerType) else None
    )
    dst_integer_type = dtype if isinstance(dtype, ir.IntegerType) else None
    src_is_int4 = cannir.Int4x2Type.isinstance(src.dtype)
    dst_is_int4 = cannir.Int4x2Type.isinstance(dtype)
    src_is_integer = src_integer_type is not None or src_is_int4
    dst_is_integer = dst_integer_type is not None or dst_is_int4
    src_is_i16 = (
        src_integer_type is not None
        and src_integer_type.width == 16
        and not src_integer_type.is_unsigned
    )
    src_is_i32 = (
        src_integer_type is not None
        and src_integer_type.width == 32
        and not src_integer_type.is_unsigned
    )
    src_is_i64 = (
        src_integer_type is not None
        and src_integer_type.width == 64
        and not src_integer_type.is_unsigned
    )
    src_is_u16 = (
        src_integer_type is not None
        and src_integer_type.width == 16
        and src_integer_type.is_unsigned
    )
    src_is_u32 = (
        src_integer_type is not None
        and src_integer_type.width == 32
        and src_integer_type.is_unsigned
    )
    dst_is_i8 = (
        dst_integer_type is not None
        and dst_integer_type.width == 8
        and not dst_integer_type.is_unsigned
    )
    dst_is_i16 = (
        dst_integer_type is not None
        and dst_integer_type.width == 16
        and not dst_integer_type.is_unsigned
    )
    dst_is_i32 = (
        dst_integer_type is not None
        and dst_integer_type.width == 32
        and not dst_integer_type.is_unsigned
    )
    dst_is_i64 = (
        dst_integer_type is not None
        and dst_integer_type.width == 64
        and not dst_integer_type.is_unsigned
    )
    dst_is_u8 = (
        dst_integer_type is not None
        and dst_integer_type.width == 8
        and dst_integer_type.is_unsigned
    )
    dst_is_u16 = (
        dst_integer_type is not None
        and dst_integer_type.width == 16
        and dst_integer_type.is_unsigned
    )
    src_is_hif8 = cannir.HiFloat8Type.isinstance(src.dtype)
    dst_is_hif8 = cannir.HiFloat8Type.isinstance(dtype)
    dst_is_fp4 = (
        cannir.Fp4x2E2M1Type.isinstance(dtype)
        or cannir.Fp4x2E1M2Type.isinstance(dtype)
    )
    packed4_to_wider = src_bits == 4 and dst_bits > 4
    fp8_cast = (src_is_fp8 and dst_is_f32) or (src_is_f32 and dst_is_fp8)
    hif8_cast = (
        (src_is_hif8 and (dst_is_f16 or dst_is_f32))
        or ((src_is_f16 or src_is_f32) and dst_is_hif8)
    )
    if (src_is_hif8 or dst_is_hif8) and not hif8_cast:
        raise ValueError(
            "vcast: hifloat8 only casts from float16/float32 or to "
            "float16/float32"
        )
    # NA means no user-selected rounding. Float-to-integer conversion still
    # requires a rounding mode even when the integer carrier is wider.
    if rounding == RoundingMode.NA and (
        src_bits >= dst_bits
        or ((src_is_f16 or src_is_f32 or src_is_bf16) and dst_is_integer)
        or ((src_is_f16 or src_is_bf16) and dst_is_fp4)
    ):
        rounding = RoundingMode.RN
    # Both families pack a narrow float against a wider one, so the mask is
    # always denominated in source elements.
    narrow_float_cast = fp8_cast or hif8_cast
    reg_layout = _normalize_reg_layout(reg_layout)
    width_ratio = max(src_bits, dst_bits) // min(src_bits, dst_bits)
    if width_ratio == 1:
        if reg_layout != RegLayout.UNKNOWN:
            raise ValueError("vcast: same-width casts require RegLayout.UNKNOWN")
    elif width_ratio == 2:
        if reg_layout not in (
            RegLayout.UNKNOWN,
            RegLayout.ZERO,
            RegLayout.ONE,
        ):
            raise ValueError(
                "vcast: 1:2 and 2:1 casts require RegLayout.UNKNOWN, ZERO, or ONE"
            )
    elif width_ratio == 4:
        if reg_layout not in (
            RegLayout.UNKNOWN,
            RegLayout.ZERO,
            RegLayout.ONE,
            RegLayout.TWO,
            RegLayout.THREE,
        ):
            raise ValueError(
                "vcast: 1:4 and 4:1 casts require RegLayout.UNKNOWN, ZERO, ONE, TWO, or THREE"
            )
    if not isinstance(saturate, bool):
        raise TypeError("vcast: saturate must be a bool")
    saturating_pair = (
        (
            src_is_f32
            and (
                dst_is_f16
                or dst_is_bf16
                or dst_is_i16
                or dst_is_i32
                or dst_is_i64
                or dst_is_hif8
                or dst_is_fp8
            )
        )
        or (
            src_is_f16
            and (dst_is_i8 or dst_is_i16 or dst_is_u8 or dst_is_int4 or dst_is_hif8)
        )
        or (src_is_bf16 and (dst_is_f16 or dst_is_i32))
        or (src_is_i16 and dst_is_u8)
        or (src_is_i32 and (dst_is_i16 or dst_is_u16 or dst_is_u8))
        or (src_is_u16 and dst_is_u8)
        or (src_is_u32 and (dst_is_i16 or dst_is_u16 or dst_is_u8))
        or (src_is_i64 and dst_is_i32)
    )
    if saturate and not saturating_pair:
        if src_bits <= dst_bits:
            raise ValueError(
                "vcast: saturate only applies to narrowing casts "
                "(src wider than dst)"
            )
        raise ValueError(
            "vcast: saturation is not supported for this source/destination pair"
        )
    if fp8_cast and rounding not in (RoundingMode.RN, RoundingMode.NA):
        raise ValueError("vcast: fp8 casts only support RN rounding")
    # The half->hif8 store has round-half-to-even (spelled `_rh`) and
    # round-nearest-away variants; the widening direction is RN only.
    if hif8_cast and dst_is_hif8 and rounding not in (
        RoundingMode.RN,
        RoundingMode.RNA,
    ):
        raise ValueError(
            "vcast: float16/float32 to hifloat8 casts only support RN or RNA rounding"
        )
    if hif8_cast and src_is_hif8 and rounding not in (RoundingMode.RN, RoundingMode.NA):
        raise ValueError("vcast: hifloat8 widening casts only support RN rounding")
    layout_selects_source = (
        src_bits < dst_bits and reg_layout != RegLayout.UNKNOWN
    )
    # Packed four-bit values are carried two per byte, and their widening
    # conversions consume a b8 mask.
    expected_mask_bits = 8 if packed4_to_wider else (
        src_bits if narrow_float_cast or layout_selects_source
        else max(src_bits, dst_bits)
    )
    if mask.elem_bits != expected_mask_bits and not _is_full_mask(mask):
        if packed4_to_wider:
            raise ValueError(
                "vcast: packed four-bit source mask elem_bits must be 8"
            )
        if narrow_float_cast or layout_selects_source:
            raise ValueError(
                "vcast: layout-selecting cast mask elem_bits must match src_bits"
            )
        raise ValueError("vcast: mask elem_bits must match max(src_bits, dst_bits)")
    kwargs = {"rounding": rounding, "saturate": saturate}
    if reg_layout != RegLayout.UNKNOWN:
        kwargs["reg_layout"] = reg_layout
    op = ascvec.VCastOp(
        _raw_vreg_type(dtype), src.value, mask.value, **kwargs
    )
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def vceil(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Round toward +inf (asc_ceil / vtrc ROUND_C). Same-dtype unary op."""
    _require_raw_mode("vceil")
    from cannbotdsl.ops.reg._common import _reject_b64

    _reject_b64("vceil", src)
    return vcast(src, src.dtype, mask=mask, rounding=RoundingMode.RU)


def vfloor(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Round toward -inf (asc_floor / vtrc ROUND_F). Same-dtype unary op."""
    _require_raw_mode("vfloor")
    from cannbotdsl.ops.reg._common import _reject_b64

    _reject_b64("vfloor", src)
    return vcast(src, src.dtype, mask=mask, rounding=RoundingMode.RD)


def vtrunc(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Round toward zero (asc_trunc / vtrc ROUND_TZ). Same-dtype unary op."""
    _require_raw_mode("vtrunc")
    from cannbotdsl.ops.reg._common import _reject_b64

    _reject_b64("vtrunc", src)
    return vcast(src, src.dtype, mask=mask, rounding=RoundingMode.RZ)
