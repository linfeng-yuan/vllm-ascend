# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode vector load ops."""

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _as_offset, _dtype_bits, _is_integer_dtype, _normalize_width, _raw_mask_type, _raw_tensor_operand, _raw_vreg_type, _tag_raw_op, _validate_postupdate_stride
from cannbotdsl.ops.reg.mask import Mask
from cannbotdsl.ops.reg.reg_defs import BrcMode, RawVReg, UnpackMode


def _unsigned_int_type(bits: int) -> ir.Type:
    if bits not in (8, 16, 32):
        raise TypeError(f"unsupported unsigned raw register bit-width {bits}")
    return ir.IntegerType.get_unsigned(bits)


def _normalize_unpack_mode(mode) -> str:
    if isinstance(mode, UnpackMode):
        return mode.value
    if isinstance(mode, str):
        key = mode.lower()
        if key == "unpack2":
            return "unpack2"
        if key == "unpack4":
            return "unpack4"
        try:
            return UnpackMode(mode).value
        except ValueError as err:
            allowed = "unpack2, unpack4"
            raise ValueError(f"unpack_mode must be one of {allowed}") from err
    raise TypeError("unpack_mode must be an UnpackMode or string")


def _normalize_mask_load_dist(dist) -> str:
    if not isinstance(dist, str):
        raise TypeError("vmask_load: dist must be a string")
    key = dist.lower()
    aliases = {
        "norm": "norm",
        "normal": "norm",
        "us": "upsample",
        "upsample": "upsample",
        "ds": "downsample",
        "downsample": "downsample",
    }
    if key not in aliases:
        raise ValueError("vmask_load: dist must be 'norm', 'upsample', or 'downsample'")
    return aliases[key]


def vload(tensor, offset=0, *, post_update: bool = False) -> RawVReg:
    """Aligned load (asc_loadalign).

    Reads 128 elements of ``dtype`` from ``tensor[offset]`` (32B-aligned).
    With ``post_update=True`` the offset operand is the *cursor stride* in
    elements: the load starts at the tensor base and the hardware advances
    the per-buffer cursor by ``offset`` elements after the access, so
    consecutive post-update loads on the same tensor stream through it
    (tensor[0], tensor[offset], tensor[2*offset], ...). The stride must be a
    positive element count, 32B (DataBlock) aligned for compile-time
    integers, and must not be an addr_reg. Do not additionally add the
    stride per call.
    """
    _require_raw_mode("vload")
    operand, dtype = _raw_tensor_operand(tensor)
    if post_update:
        _validate_postupdate_stride(offset, _dtype_bits(dtype), "vload")
    out_ty = _raw_vreg_type(dtype)
    op = cannir.RawRegLoadOp(out_ty, operand, _as_offset(offset), post_update=post_update)
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def vload_unalign_init(tensor, offset=0) -> None:
    """Initialize an unaligned load on ``tensor`` (arch35 ``vldas``).

    Emits ``asc_loadunalign_pre`` and declares the persistent
    ``vector_load_unalign`` ureg for ``(tensor, offset)``. Pair with
    :func:`vload_unalign` at the **same** ``(tensor, offset)``; call once
    outside the hot loop, then issue the per-iteration loads inside.

    Mirror of :func:`vsqueeze_and_storeunalign_init` on the store side.
    """
    _require_raw_mode("vload_unalign_init")
    operand, _ = _raw_tensor_operand(tensor)
    op = cannir.RawRegLoadUnalignInitOp(operand, _as_offset(offset))
    _tag_raw_op(op)


def vload_unalign(tensor, offset=0) -> RawVReg:
    """Unaligned load into a raw vector register (arch35 ``vldus``).

    No 32B alignment requirement on ``tensor + offset`` (unlike :func:`vload`).
    Must follow :func:`vload_unalign_init` with the **same**
    ``(tensor, offset)``, which carries the ureg / VLDAS setup. Lowers to
    ``asc_loadunalign(dst, ureg, buf)``.
    """
    _require_raw_mode("vload_unalign")
    operand, dtype = _raw_tensor_operand(tensor)
    out_ty = _raw_vreg_type(dtype)
    op = cannir.RawRegLoadUnalignOp(out_ty, operand, _as_offset(offset))
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def vload_broadcast(tensor, offset=0, *, mode=None, width=None,
                    post_update: bool = False) -> RawVReg:
    """Broadcast load with selectable granularity (asc_loadalign_brc family).

    ``mode`` is named after the CAPI suffix (the ``BRC_`` part of
    ``DIST_BRC_*``):

    - ``None``/``"brc"``/``BrcMode.FULL``: broadcast element 0 across all
      lanes (``asc_loadalign_brc``, DIST_BRC_B<elem-width>). With
      ``width="b8"/"b16"`` the result is a u32 register whose every
      byte/half is a replica of byte0/half0 (DIST_BRC_B8/B16).
    - ``"elem2datablock"``/``BrcMode.ELEM2DATABLOCK``: each value fills one
      32B DataBlock (``asc_loadalign_brc_elem2datablock``).
    - ``"datablock"``/``BrcMode.DATABLOCK``: alias of elem2datablock.

    With ``post_update=True`` (full-lane brc only) the offset operand is the
    *cursor stride*: the load starts at the tensor base and the hardware
    advances the per-buffer cursor by ``offset`` pointer elements after the
    access. For ``width="b8"/"b16"`` the cursor is a u8/u16 pointer, so the
    stride is counted in bytes/halves. The stride must be positive and 32B
    (DataBlock) aligned for compile-time integers.
    """
    _require_raw_mode("vload_broadcast")
    operand, dtype = _raw_tensor_operand(tensor)
    bits = _dtype_bits(dtype)
    if post_update:
        eff_mode = mode.value if isinstance(mode, BrcMode) else mode
        if eff_mode in ("datablock", "elem2datablock"):
            raise ValueError(
                "vload_broadcast: post_update=True is only supported with the "
                "full-lane brc mode (mode=None/'brc'), not elem2datablock"
            )
        stride_bits = bits
        if width is not None:
            w = _normalize_width(width, name="vload_broadcast")
            if w not in ("b8", "b16"):
                raise ValueError("vload_broadcast: width must be 'b8' or 'b16'")
            stride_bits = 8 if w == "b8" else 16
        _validate_postupdate_stride(offset, stride_bits, "vload_broadcast")
    if mode is None or (isinstance(mode, BrcMode) and mode == BrcMode.FULL) or mode == "brc":
        if width is not None:
            width = _normalize_width(width, name="vload_broadcast")
            if width not in ("b8", "b16"):
                raise ValueError("vload_broadcast: width must be 'b8' or 'b16'")
            out_ty = _raw_vreg_type(ir.IntegerType.get_unsigned(32))
            op = cannir.RawRegLoadBrcOp(
                out_ty, operand, _as_offset(offset), brc_width=width, post_update=post_update
            )
            _tag_raw_op(op)
            return RawVReg(op.result, ir.IntegerType.get_unsigned(32))
        out_ty = _raw_vreg_type(dtype)
        op = cannir.RawRegLoadBrcOp(out_ty, operand, _as_offset(offset), post_update=post_update)
        _tag_raw_op(op)
        return RawVReg(op.result, dtype)
    if (isinstance(mode, BrcMode) and mode in (BrcMode.DATABLOCK, BrcMode.ELEM2DATABLOCK)) or mode in ("datablock", "elem2datablock"):
        if bits == 16:
            out_dtype = ir.IntegerType.get_unsigned(16)
        elif bits == 32:
            out_dtype = ir.IntegerType.get_unsigned(32)
        else:
            raise TypeError("vload_broadcast(mode='datablock'): tensor dtype must be 16 or 32-bit")
        out_ty = _raw_vreg_type(out_dtype)
        op = cannir.RawRegLoadBrcOp(
            out_ty, operand, _as_offset(offset),
            brc_width=f"e2b_b{bits}", post_update=post_update
        )
        _tag_raw_op(op)
        return RawVReg(op.result, out_dtype)
    raise ValueError(
        f"vload_broadcast: mode must be 'brc', 'datablock', or 'elem2datablock', got {mode!r}"
    )


def vload_upsample(tensor, offset=0, *, post_update: bool = False) -> RawVReg:
    """2x upsample load: replicate each source element into an element pair.

    With ``post_update=True`` the offset operand is the *cursor stride* in
    elements: the load starts at the tensor base and the hardware advances
    the per-buffer cursor by ``offset`` elements after the access. The
    stride must be a positive element count, 32B (DataBlock) aligned for
    compile-time integers.
    """
    _require_raw_mode("vload_upsample")
    operand, dtype = _raw_tensor_operand(tensor)
    bits = _dtype_bits(dtype)
    if bits not in (8, 16):
        raise TypeError("vload_upsample: tensor dtype must be 8-bit or 16-bit")
    if post_update:
        _validate_postupdate_stride(offset, bits, "vload_upsample")
    out_ty = _raw_vreg_type(dtype)
    op = cannir.RawRegLoadUpsampleOp(out_ty, operand, _as_offset(offset), post_update=post_update)
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def vload_downsample(tensor, offset=0, *, post_update: bool = False) -> RawVReg:
    """2x downsample load: take only the low half of each source element pair.

    Matches arch35 ``LoadAlign<T, DIST_DS_B8>`` and CANN 9.2.0
    ``asc_loadalign_downsample`` (``vlds(dst, src, 0, DS_B8)``).
    ``tensor`` is read at ``offset`` (element units) from a 32B-aligned base.
    With ``post_update=True`` the offset operand is the *cursor stride* in
    elements: the load starts at the tensor base and the hardware advances
    the per-buffer cursor by ``offset`` elements after the access. The
    stride must be a positive element count, 32B (DataBlock) aligned for
    compile-time integers.
    """
    _require_raw_mode("vload_downsample")
    operand, dtype = _raw_tensor_operand(tensor)
    bits = _dtype_bits(dtype)
    if bits not in (8, 16):
        raise TypeError("vload_downsample: tensor dtype must be 8-bit or 16-bit")
    if post_update:
        _validate_postupdate_stride(offset, bits, "vload_downsample")
    out_ty = _raw_vreg_type(dtype)
    op = cannir.RawRegLoadDownsampleOp(out_ty, operand, _as_offset(offset), post_update=post_update)
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def vload_unpack(tensor, offset=0, *, unpack_mode, post_update: bool = False) -> RawVReg:
    """Zero-extend load: narrow elements unpacked into wider lanes.

    Note: ``post_update=True`` is accepted for API compatibility but is not
    yet lowered for unpack accesses (no ``asc_loadalign_unpack_postupdate``
    emission); the offset always behaves as a plain address for this op.
    """
    _require_raw_mode("vload_unpack")
    mode = _normalize_unpack_mode(unpack_mode)
    # semantic names map onto granularities by tensor dtype
    operand, dtype = _raw_tensor_operand(tensor, operation="vload_unpack")
    bits = _dtype_bits(dtype)
    if mode == "unpack2":
        mode = "b16_to_b32" if bits == 16 else "b8_to_b16"
    elif mode == "unpack4":
        mode = "b8_to_b32"
    out_dtype = dtype
    if mode == UnpackMode.B16_TO_B32.value:
        if bits != 16:
            raise TypeError("vload_unpack(mode='b16_to_b32'): tensor dtype must be 16-bit")
        if ir.IntegerType.isinstance(dtype):
            out_dtype = ir.IntegerType.get_signless(32)
    elif mode == UnpackMode.B8_TO_B16.value:
        if bits != 8:
            raise TypeError(f"vload_unpack(mode='{mode}'): tensor dtype must be 8-bit")
        out_dtype = ir.IntegerType.get_unsigned(16)
    elif mode == UnpackMode.B8_TO_B32.value:
        if bits != 8:
            raise TypeError(f"vload_unpack(mode='{mode}'): tensor dtype must be 8-bit")
        out_dtype = ir.IntegerType.get_unsigned(32)
    else:
        raise ValueError(f"vload_unpack: unsupported mode {mode!r}")
    out_ty = _raw_vreg_type(out_dtype)
    op = cannir.RawRegLoadUnpackOp(
        out_ty, operand, _as_offset(offset), mode=mode
    )
    _tag_raw_op(op)
    return RawVReg(op.result, out_dtype)


def vload_deinterleave(tensor, offset=0, *, width=None, post_update: bool = False):
    """Load and deinterleave: returns (even_lanes, odd_lanes) registers.

    ``width`` selects the deinterleave granularity ("b8"/"b16"/"b32").
    Default None uses the tensor's element width. Output lanes double and
    narrow accordingly: e.g. u16 tensor + width="b8" -> two u8 registers.
    With ``post_update=True`` the offset operand is the *cursor stride* in
    pointer elements (the selected ``width``: bytes for "b8"): the load
    starts at the tensor base and the hardware advances the per-buffer
    cursor by ``offset`` elements after the access. The stride must be a
    positive element count, 32B (DataBlock) aligned for compile-time
    integers.
    """
    _require_raw_mode("vload_deinterleave")
    operand, t_dtype = _raw_tensor_operand(tensor)
    tensor_bits = _dtype_bits(t_dtype)
    if width is None:
        width = f"b{tensor_bits}"
    else:
        width = _normalize_width(width, name="vload_deinterleave")
    bits = int(width[1:])
    if tensor_bits < bits:
        raise TypeError(f"vload_deinterleave(width='{width}'): tensor dtype must be at least {bits}-bit")
    if post_update:
        _validate_postupdate_stride(offset, bits, "vload_deinterleave")
    out_dtype = t_dtype if tensor_bits == bits else _unsigned_int_type(bits)
    out_ty = _raw_vreg_type(out_dtype)
    op = cannir.RawRegLoadDeintlvOp(out_ty, out_ty, operand, _as_offset(offset), dintlv_width=width, post_update=post_update)
    _tag_raw_op(op)
    return RawVReg(op.result0, out_dtype), RawVReg(op.result1, out_dtype)


def vmask_load(tensor, offset=0, *, elem_bits: int = 32, dist="norm") -> Mask:
    _require_raw_mode("vmask_load")
    if elem_bits not in (8, 16, 32):
        raise ValueError("vmask_load: elem_bits must be 8, 16, or 32")
    operand, dtype = _raw_tensor_operand(tensor)
    if not _is_integer_dtype(dtype) or _dtype_bits(dtype) != 32:
        raise TypeError("vmask_load: tensor dtype must be 32-bit integer storage")
    dist = _normalize_mask_load_dist(dist)
    op = cannir.RawRegMaskLoadOp(
        operand,
        _as_offset(offset),
        dist,
        elem_bits=elem_bits,
    )
    _tag_raw_op(op)
    return Mask(op.mask, elem_bits)


def vload_strided(
    tensor, offset, mask: Mask, *, block_stride, repeat_stride=0
) -> RawVReg:
    """Masked NZ repeat-stride load: the raw counterpart of the high-level
    ``mem_copy(nz2nd) -> cast`` fold.

    Emits v5 ``asc_loadalign(v, buf + off, (uint16_t)block_stride,
    (uint16_t)repeat_stride, mask)`` (via ``ascvec::LoadAlignStridedOp``), which
    gathers from an NZ-layout buffer into one register. ``block_stride`` /
    ``repeat_stride`` are in DataBlock (32B) units; for an NZ source derive
    ``block_stride`` from ``nzN1Stride / kN0`` (read off the src physical layout).
    """
    _require_raw_mode("vload_strided")
    operand, dtype = _raw_tensor_operand(tensor)
    out_ty = _raw_vreg_type(dtype)
    op = cannir.RawRegLoadStridedOp(
        out_ty,
        operand,
        _as_offset(offset),
        mask.value,
        block_stride=_as_offset(block_stride),
        repeat_stride=_as_offset(repeat_stride),
    )
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)
