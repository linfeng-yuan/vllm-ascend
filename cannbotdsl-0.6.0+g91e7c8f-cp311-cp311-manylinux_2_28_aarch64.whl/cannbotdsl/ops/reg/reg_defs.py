# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register/handle SSA wrappers and raw-op mode enums."""

from enum import Enum

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir


class MergeMode(str, Enum):
    """exec-mask merge mode: zeroing (default) or merging."""
    ZEROING = "zeroing"
    MERGING = "merging"


class OrderMode(str, Enum):
    """arange order mode."""
    INCREASED = "increased"
    DECREASED = "decreased"


class BrcMode(str, Enum):
    """broadcast load mode."""
    FULL = "full"
    DATABLOCK = "datablock"
    ELEM2DATABLOCK = "elem2datablock"


class UnpackMode(str, Enum):
    UNPACK2 = "unpack2"      # 2x widen: b16->b32, b8->b16
    UNPACK4 = "unpack4"      # 4x widen: b8->b32
    # legacy granularities kept for internal normalization
    B16_TO_B32 = "b16_to_b32"
    B8_TO_B16 = "b8_to_b16"
    B8_TO_B32 = "b8_to_b32"


class PackMode(str, Enum):
    """pack granularity for vstore_pack / vpack."""
    PACK_HALF = "pack_half"
    PACK_QUARTER = "pack_quarter"
    LOWER = "lower"
    HIGHEST = "highest"
    # legacy values kept for internal normalization
    B16_TO_B8 = "b16_to_b8"
    B32_TO_B16 = "b32_to_b16"
    B64_TO_B32 = "b64_to_b32"
    B32_TO_B8 = "b32_to_b8"


class RawVReg(ir.Value):
    """First-class SSA wrapper for ``!ascvec.vreg``.

    ``logical`` optionally carries the *semantic* dtype label (a
    ``dtypes.DType``, e.g. ``dtypes.int64``) of a 64-bit view over the b32
    register bytes. The IR type stays ``vreg<ui32>`` — the label only drives
    Python-side dispatch inside the base arithmetic wrappers
    (``vadd``/``vcmp``/... choose the B64 soft-emulation sequences when the
    lhs register is labeled 64-bit). Attach it with the
    ``ops.reg.b64.as_int64`` / ``as_uint64`` view helpers.
    """

    def __init__(self, value: ir.Value, dtype: ir.Type | None = None,
                 logical=None):
        if not isinstance(value, ir.Value):
            raise TypeError(
                f"RawVReg requires ir.Value, got {type(value).__name__}"
            )
        ty = str(value.type)
        if not ty.startswith("!ascvec.vreg<") or not ty.endswith(">"):
            raise TypeError(
                f"RawVReg requires !ascvec.vreg<...> SSA value, got {value.type}"
            )
        super().__init__(value)
        actual_dtype = ir.Type.parse(ty[len("!ascvec.vreg<"):-1])
        if dtype is not None and dtype != actual_dtype:
            raise TypeError(
                f"RawVReg dtype {dtype} does not match SSA type {actual_dtype}"
            )
        self.dtype = actual_dtype
        self.logical = logical

    @property
    def value(self):
        return self


def _ascvec_typeid(text: str):
    """Register value casters against a parsed AscVec type's TypeID.

    TypeID identifies the type class (parameter-invariant), so a throwaway
    parse context is sufficient at import time.
    """
    with ir.Context() as _ctx:
        return ir.Type.parse(text).typeid


RawVReg = ir.register_value_caster(_ascvec_typeid("!ascvec.vreg<f32>"))(RawVReg)


class ULoadReg(ir.Value):
    """First-class SSA wrapper for ``!cannir.uload_reg``."""

    def __init__(self, value: ir.Value):
        if not isinstance(value, ir.Value):
            raise TypeError(
                f"ULoadReg requires ir.Value, got {type(value).__name__}"
            )
        if str(value.type) != "!ascvec.uload_reg":
            raise TypeError(
                f"ULoadReg requires !ascvec.uload_reg SSA value, got {value.type}"
            )
        super().__init__(value)

    @property
    def value(self):
        return self


ULoadReg = ir.register_value_caster(_ascvec_typeid("!ascvec.uload_reg"))(ULoadReg)


class UStoreReg(ir.Value):
    """First-class SSA wrapper for ``!cannir.ustore_reg``."""

    def __init__(self, value: ir.Value):
        if not isinstance(value, ir.Value):
            raise TypeError(
                f"UStoreReg requires ir.Value, got {type(value).__name__}"
            )
        if str(value.type) != "!ascvec.ustore_reg":
            raise TypeError(
                f"UStoreReg requires !ascvec.ustore_reg SSA value, got {value.type}"
            )
        super().__init__(value)

    @property
    def value(self):
        return self


UStoreReg = ir.register_value_caster(_ascvec_typeid("!ascvec.ustore_reg"))(UStoreReg)


class StoreUnalignReg:
    """Handle for the persistent ``vector_store_unalign`` cursor (ureg).

    Created by :func:`vstore_unalign_begin` and passed explicitly to
    :func:`vstore_unalign` / :func:`vsqueeze_and_storeunalign` /
    :func:`vstore_unalign_post` / :func:`vsqueeze_and_storeunalign_finalize`,
    mirroring the CAPI ``vector_store_unalign&`` operand.
    """

    def __init__(self, operand: ir.Value):
        self.operand = operand
