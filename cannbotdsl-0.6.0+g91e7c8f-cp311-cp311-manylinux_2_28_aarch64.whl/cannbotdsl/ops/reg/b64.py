"""B64 (int64/uint64) 软仿实现层：拆 lo/hi 双字 + b32 进位链。

用户通过 ``as_int64`` / ``as_uint64`` 给 b32 寄存器打 64 位语义标签，
基础算术接口（``vadd``/``vcmp``/``vshr``/...）检测标签后内部分发到
本模块的软仿序列（对标 AscendC ``Reg::Add<int64_t>`` 的类型分发）。
接口层无 64 位专用名字；vdiv 64 位由本文件的 DivU64/DivS64 软仿序列
对标 AscendC ``kernel_reg_compute_vec_binary_impl.h`` 的 DivU64Impl/DivS64Impl。
"""
from cannbotdsl.ops.reg.arith import vaddc, vaddco, vsubc, vmull, vsub, vmadd
from cannbotdsl.ops.reg.compare import vgt, vge, veq, vle, vlt, vne, vselect
from cannbotdsl.ops.reg.create import vdups
from cannbotdsl.ops.reg.logic import vnot, vbitwise_and, vbitwise_or, vbitwise_xor, vshl, vshr, vreinterpret
from cannbotdsl.ops.reg.mask import Mask, create_mask, mask_and, mask_not, mask_or, mask_xor
from cannbotdsl.ops.reg.permute import vdeinterleave, vinterleave
from cannbotdsl.ops.reg.reg_defs import RawVReg

_NO_CARRY_CACHE = {}
_ALL_CARRY_CACHE = {}


def _no_carry_mask():
    if "m" not in _NO_CARRY_CACHE:
        _NO_CARRY_CACHE["m"] = create_mask("allf", elem_bits=32)
    return _NO_CARRY_CACHE["m"]


def _all_carry_mask():
    if "m" not in _ALL_CARRY_CACHE:
        _ALL_CARRY_CACHE["m"] = create_mask("all", elem_bits=32)
    return _ALL_CARRY_CACHE["m"]


# ---------------------------------------------------------------------------
# 语义标签视图：给 b32 寄存器打 64 位语义标签（IR 类型保持 vreg<ui32>，
# 标签只驱动 Python 侧分发）。这是用户获得 B64 寄存器的唯一入口。
# ---------------------------------------------------------------------------


def _check_b32(reg, name):
    from cannbotdsl._mlir.ir import IntegerType

    if not isinstance(reg.dtype, IntegerType) or reg.dtype.width != 32:
        raise TypeError(
            f"{name}: expects a 32-bit raw register (256B = 32 packed int64), "
            f"got {reg.dtype}"
        )


def as_int64(reg):
    """把 b32 寄存器的 256B 字节标注为 32 个 packed int64（软仿分发标签）。"""
    _check_b32(reg, "as_int64")
    from cannbotdsl import dtypes

    return RawVReg(reg.value, reg.dtype, logical=dtypes.int64)


def as_uint64(reg):
    """把 b32 寄存器的 256B 字节标注为 32 个 packed uint64（软仿分发标签）。"""
    _check_b32(reg, "as_uint64")
    from cannbotdsl import dtypes

    return RawVReg(reg.value, reg.dtype, logical=dtypes.uint64)


def b64_logical(reg):
    """寄存器的 64 位语义标签；非 64 位返回 None。"""
    lg = getattr(reg, "logical", None)
    if lg is not None and lg.kind.value == "integer" and lg.bits == 64:
        return lg
    return None


def _split_lo_hi(packed):
    return vdeinterleave(packed, packed)


def _words(reg):
    """剥掉 64 位语义标签，得到普通 b32 字视图（impl 内部一律用字视图）。"""
    return RawVReg(reg.value, reg.dtype)


def _word_exec(mask):
    """字级（compacted）exec mask 归一化。

    - elem_bits=64（packed 逐元素语义，每元素 2 bit 覆盖 packed lane）：
      经 mask_deinterleave 取偶位得到 compacted 逐元素 mask（元素 i = lo/hi
      寄存器的 lane i，无需 ×2）。
    - elem_bits=32：按字级语义直接使用（历史约定；full_mask() 在两个空间
      等价）。
    """
    if (mask.elem_bits or 32) == 64:
        m32 = Mask(mask.value, 32)  # 物理上就是 b32 lane mask，降粒度过校验
        lo_half, _ = vdeinterleave(m32, m32)
        return Mask(lo_half.value, 32)
    return mask


# ---------------------------------------------------------------------------
# 算术（对标 AddB64Impl / SubB64Impl / MulB64Impl）
# ---------------------------------------------------------------------------


def _add64(lhs, rhs, *, mask):
    """int64/uint64 加法（软仿）：result = lhs + rhs（回绕语义）。"""
    lhs = _words(lhs)
    wmask = _word_exec(mask)
    lo_a, hi_a = _split_lo_hi(lhs)
    lo_b, hi_b = _split_lo_hi(rhs)
    carry, lo_r = vaddc(lo_a, lo_b, _no_carry_mask(), mask=wmask)
    _, hi_r = vaddc(hi_a, hi_b, carry, mask=wmask)
    d0, d1 = vinterleave(lo_r, hi_r)
    return d0  # packed 视图：vinterleave 输出的选择经 round-trip 验证固定


def _sub64(lhs, rhs, *, mask):
    """int64/uint64 减法（软仿）：result = lhs - rhs（回绕语义）。

    借位链对标 SubB64Impl。硬件 vsubcs 为加法器语义 dst = src0 + ~src1 +
    carry_in（carry_in=1 才是普通减法，carry_out=1 表示无借位），故低字
    carry_in 须传全真 mask（等价于带借位出的普通 Sub），高字直接链。
    """
    lhs = _words(lhs)
    lo_a, hi_a = _split_lo_hi(lhs)
    lo_b, hi_b = _split_lo_hi(rhs)
    wmask = _word_exec(mask)
    borrow, lo_r = vsubc(lo_a, lo_b, _all_carry_mask(), mask=wmask)
    _, hi_r = vsubc(hi_a, hi_b, borrow, mask=wmask)
    d0, d1 = vinterleave(lo_r, hi_r)
    return d0


def _dup_words(packed):
    """拆 lo/hi 双字并把每个字复制到相邻 lane（偶数 lane 复制域）。

    AIV 上 deintlv 的 result1（奇数 lane）寄存器作乘法源会损坏数据，
    而 result0（偶数 lane）寄存器全精确。把 hi 字经 vintlv(x,x)[0]
    复制到偶数 lane 后，全部字级算术（尤其乘法）只喂偶数 lane 寄存器。
    """
    lo, hi = vdeinterleave(packed, packed)
    lo2, _ = vinterleave(lo, lo)
    hi2, _ = vinterleave(hi, hi)
    return lo2, hi2


def _undup_word(dup):
    """复制域 → 单副本字寄存器（取偶数 lane）。"""
    u, _ = vdeinterleave(dup, dup)
    return u


def _wmul_dup(x, y, wmask):
    """32×32 → 64 位积（偶数 lane 复制域）。

    实测 vmull 在复制域（intlv 复制出的偶数 lane 寄存器）上对所有值精确，
    直接返回 (lo, hi) 复制寄存器对。16×16 分解版（asc_mul+进位链）已废弃。
    """
    return vmull(x, y, x.dtype, mask=wmask)


def _mul64(lhs, rhs, *, mask):
    """int64/uint64 乘法低 64 位（软仿），对标 MulB64Impl。

    lo = aLo*bLo 低 32 位；hi = aLo*bLo 高字 + aLo*bHi + aHi*bLo
    （mod 2^32）。回绕乘积低 64 位与符号无关。全程偶数 lane 复制域。
    """
    wmask = _word_exec(mask)
    al2, ah2 = _dup_words(_words(lhs))
    bl2, bh2 = _dup_words(_words(rhs))
    lo, hi_ll = _wmul_dup(al2, bl2, wmask)
    t1lo, _ = _wmul_dup(bh2, al2, wmask)  # aLo*bHi
    t2lo, _ = _wmul_dup(ah2, bl2, wmask)  # aHi*bLo
    # 交叉项之和的进位属于乘积 ≥96 位 → 丢弃，不进 hi 字
    _, s1 = vaddco(t1lo, t2lo, mask=wmask)
    _, hi_r = vaddc(hi_ll, s1, _no_carry_mask(), mask=wmask)
    d0, _ = vinterleave(_undup_word(lo), _undup_word(hi_r))
    return d0


def _abs64_words(reg, wmask):
    """字视图 u64 绝对值：hi 字符号判定 + 0-x 借位链选择。"""
    from cannbotdsl import dtypes

    lo, hi = _split_lo_hi(reg)
    zero = vsub(hi, hi, mask=wmask)
    sign = vlt(vreinterpret(hi, dtypes.int32),
               vreinterpret(zero, dtypes.int32), mask=wmask)
    all_t = _all_carry_mask()
    zero_w = vsub(lo, lo, mask=wmask)
    borrow, neg_lo = vsubc(zero_w, lo, all_t, mask=wmask)
    _, neg_hi = vsubc(zero_w, hi, borrow, mask=wmask)
    neg0, _ = vinterleave(neg_lo, neg_hi)
    expanded, _ = vinterleave(sign, sign)
    sel = vselect(neg0, reg, cond_mask=Mask(expanded.value, 64))
    return _words(sel)



# ---------------------------------------------------------------------------
# 按位逻辑：b32 lane 独立按位运算对 lo/hi 交错 packed 表示天然成立，
# 直接作用于 packed 寄存器，无需拆分/合并。
# ---------------------------------------------------------------------------


def _and64(lhs, rhs, *, mask):
    lhs = _words(lhs)
    rhs = _words(rhs)
    return vbitwise_and(lhs, rhs, mask=mask)


def _or64(lhs, rhs, *, mask):
    lhs = _words(lhs)
    rhs = _words(rhs)
    return vbitwise_or(lhs, rhs, mask=mask)


def _xor64(lhs, rhs, *, mask):
    lhs = _words(lhs)
    rhs = _words(rhs)
    return vbitwise_xor(lhs, rhs, mask=mask)


def _not64(lhs, *, mask):
    lhs = _words(lhs)
    return vnot(lhs, mask=mask)


# ---------------------------------------------------------------------------
# 比较：字级组合（高位字定序、低位字无符号决胜），返回 ×2 展开的
# packed lane 掩码（b32 mask，元素的两个字 lane 同值），可直接喂给
# vselect 物化 0/-1。有符号/无符号由寄存器语义标签驱动（对标 AscendC
# Compare<int64_t> vs Compare<uint64_t> 的类型分发）。
# ---------------------------------------------------------------------------

_CMP_WORD_OPS = {"lt": vlt, "le": vle, "gt": vgt, "ge": vge}


def _cmp_word(lhs, rhs, kind, *, signed, mask):
    if signed:
        from cannbotdsl import dtypes

        lhs = vreinterpret(lhs, dtypes.int32)
        rhs = vreinterpret(rhs, dtypes.int32)
    return _CMP_WORD_OPS[kind](lhs, rhs, mask=mask)


def _cmp64_elem(lhs, rhs, *, mask, kind, unsigned):
    """字级组合比较的逐元素（elem_bits=32）结果，对标 AscendC 的
    Compare<uint64_t> 掩码流（VcmpEqUsingU32/VcmpGeUsingU32 产出即用，
    不做 ×2 展开）。"""
    wmask = _word_exec(mask)
    lo_a, hi_a = _split_lo_hi(lhs)
    lo_b, hi_b = _split_lo_hi(rhs)
    if kind == "eq":
        per_elem = mask_and(
            veq(lo_a, lo_b, mask=wmask), veq(hi_a, hi_b, mask=wmask), exec_mask=wmask
        )
    elif kind == "ne":
        eq = mask_and(
            veq(lo_a, lo_b, mask=wmask), veq(hi_a, hi_b, mask=wmask), exec_mask=wmask
        )
        per_elem = mask_not(eq, exec_mask=wmask)
    else:
        lo_cmp = _cmp_word(lo_a, lo_b, kind, signed=False, mask=wmask)
        hi_cmp = _cmp_word(hi_a, hi_b, kind, signed=not unsigned, mask=wmask)
        hi_eq = veq(hi_a, hi_b, mask=wmask)
        not_hi_eq = mask_not(hi_eq, exec_mask=wmask)
        per_elem = mask_or(
            mask_and(hi_eq, lo_cmp, exec_mask=wmask),
            mask_and(not_hi_eq, hi_cmp, exec_mask=wmask),
            exec_mask=wmask,
        )
    return Mask(per_elem.value, 32)


def _cmp64(lhs, rhs, *, mask, kind, unsigned):
    """字级组合比较（hi 字定序 + lo 字无符号决胜）。

    mask 支持 elem_bits=64（packed 逐元素）与 elem_bits=32（字级）两种
    粒度，字级 op 统一经 _word_exec 归一化到 compacted 空间。输出统一为
    ×2 展开（mask_interleave 自身）的 packed lane 掩码（elem_bits=64），
    可直接喂 packed 域 vselect / vstore。
    """
    per_elem = _cmp64_elem(lhs, rhs, mask=mask, kind=kind, unsigned=unsigned)
    wmask = _word_exec(mask)
    expanded, _ = vinterleave(per_elem, per_elem)  # mask ×2 展开覆盖 lo/hi
    return Mask(expanded.value, 64)


# ---------------------------------------------------------------------------
# 取负/绝对值/最值
# ---------------------------------------------------------------------------


def _neg64(lhs, *, mask):
    """int64 取负（软仿）：0 - x 走 vsub64 借位链（INT64_MIN 回绕到自身）。"""
    from cannbotdsl import dtypes

    zero = vdups(0, dtypes.uint32)
    return _sub64(zero, lhs, mask=mask)


def _abs64(lhs, *, mask):
    """int64 绝对值（软仿），对标 AbsUsingS32。

    符号 = hi 字有符号小于 0；x<0 → 取负（INT64_MIN 回绕到自身），
    否则原值。无符号标签下恒等返回。
    """
    from cannbotdsl import dtypes

    wmask = _word_exec(mask)
    _, hi_a = _split_lo_hi(lhs)
    zero_w = vsub(hi_a, hi_a, mask=wmask)
    sign_hi = vlt(vreinterpret(hi_a, dtypes.int32),
                  vreinterpret(zero_w, dtypes.int32), mask=wmask)
    expanded, _ = vinterleave(sign_hi, sign_hi)
    return vselect(_neg64(lhs, mask=mask), lhs, cond_mask=Mask(expanded.value, 64))


def _extremum64(lhs, rhs, *, mask, want_max, unsigned):
    kind = "ge" if want_max else "le"
    cond = _cmp64(lhs, rhs, mask=mask, kind=kind, unsigned=unsigned)
    return vselect(lhs, rhs, cond_mask=cond)


# ---------------------------------------------------------------------------
# 移位：立即数（对标 B64 移位的字间漏斗组合）。
# ---------------------------------------------------------------------------


def _zero_like(reg, wmask):
    return vsub(reg, reg, mask=wmask)


def _shl64(lhs, shift: int, *, mask):
    """int64/uint64 左移（软仿）：立即数 shift ∈ [0, 64)。"""
    lhs = _words(lhs)
    shift = int(shift)
    if not 0 <= shift < 64:
        raise ValueError(f"64-bit shift must be in [0, 64), got {shift}")
    if shift == 0:
        return lhs
    wmask = _word_exec(mask)
    lo_a, hi_a = _split_lo_hi(lhs)
    if shift < 32:
        lo_r = vshl(lo_a, shift, mask=wmask)
        hi_r = vbitwise_or(vshl(hi_a, shift, mask=wmask),
                           vshr(lo_a, 32 - shift, mask=wmask), mask=wmask)
    else:
        lo_r = _zero_like(lo_a, wmask)
        hi_r = vshl(lo_a, shift - 32, mask=wmask)
    d0, _ = vinterleave(lo_r, hi_r)
    return d0


def _shr64(lhs, shift: int, *, mask, arithmetic: bool):
    """右移（软仿）：arithmetic=False 逻辑（uint64）/ True 算术符号填充（int64）。"""
    lhs = _words(lhs)
    from cannbotdsl import dtypes

    shift = int(shift)
    if not 0 <= shift < 64:
        raise ValueError(f"64-bit shift must be in [0, 64), got {shift}")
    if shift == 0:
        return lhs
    wmask = _word_exec(mask)
    lo_a, hi_a = _split_lo_hi(lhs)
    if not arithmetic:
        if shift < 32:
            hi_r = vshr(hi_a, shift, mask=wmask)
            lo_r = vbitwise_or(vshr(lo_a, shift, mask=wmask),
                               vshl(hi_a, 32 - shift, mask=wmask), mask=wmask)
        else:
            hi_r = _zero_like(hi_a, wmask)
            lo_r = vshr(hi_a, shift - 32, mask=wmask)
    else:
        hi_s = vreinterpret(hi_a, dtypes.int32)
        if shift < 32:
            hi_r = vreinterpret(vshr(hi_s, shift, mask=wmask), dtypes.uint32)
            lo_r = vbitwise_or(vshr(lo_a, shift, mask=wmask),
                               vshl(hi_a, 32 - shift, mask=wmask), mask=wmask)
        else:
            hi_r = vreinterpret(vshr(hi_s, 31, mask=wmask), dtypes.uint32)  # 符号填充
            lo_r = vreinterpret(vshr(hi_s, shift - 32, mask=wmask), dtypes.uint32)
    d0, _ = vinterleave(lo_r, hi_r)
    return d0


# ---------------------------------------------------------------------------
# 除法（对标 AscendC DivU64Impl / DivS64Impl 的 f32 倒数 + B128 高位乘 +
# Newton 精化 + 商校正软仿序列；helper 按原文顺序转录）
# ---------------------------------------------------------------------------


def _bcast(lo, hi):
    """对标 VbrUsingU32：把两个 u32 标量广播成 packed u64 常量。"""
    from cannbotdsl import dtypes

    lo_w = vdups(lo, dtypes.uint32)
    hi_w = vdups(hi, dtypes.uint32)
    d0, _ = vinterleave(lo_w, hi_w)
    return d0


def _pack64(lo_w, hi_w):
    """字视图 (lo, hi) 组装回 packed u64 视图（对标 vdintlv 方向）。"""
    d0, _ = vinterleave(lo_w, hi_w)
    return d0


def _f32_to_s64(reg, wmask):
    """对标 VcvtF322S64：vintlv(reg,reg) 逐值复制后经 vcvt f32→int64
    ROUND_Z PART_EVEN 转成 packed u64（DSL 层为 f32→int64 新增 cast 路径，
    直接映射 asc_float2int64_rz + ASC_POSITION_EVEN）。"""
    from cannbotdsl import dtypes
    from cannbotdsl.ops.reg.cast import RoundingMode, vcast
    from cannbotdsl.ops.reg.logic import vreinterpret_lanes

    dup_lo, _ = vinterleave(reg, reg)
    full = create_mask("all", elem_bits=64)
    t5 = vcast(dup_lo, dtypes.int64, mask=full, rounding=RoundingMode.RZ)
    return vreinterpret_lanes(t5, dtypes.uint32)


def _b128_calc(src0, src1, src2, wmask):
    """对标 B128Calc：dst = (src0 * src1 + src2) >> 64 高位，src0/src1 为
    packed u64、src2 为 u32 字寄存器，结果写回并返回 packed u64。

    全程偶数 lane 复制域（_wmul_dup 精确 32×32→64）；加链逐字转录
    （m3.reg[1] 写 pTmp128Carry1 的 AddC 省略：该 mask 从不被消费）。
    """
    al2, ah2 = _dup_words(src0)
    bl2, bh2 = _dup_words(src1)
    m0l, m0h = _wmul_dup(al2, bl2, wmask)
    m1l, m1h = _wmul_dup(bh2, al2, wmask)
    m2l, m2h = _wmul_dup(ah2, bl2, wmask)
    m3l, m3h = _wmul_dup(ah2, bh2, wmask)
    c0a, d0a = vaddco(m0h, m1l, mask=wmask)
    c1a, d1a = vaddco(d0a, m2l, mask=wmask)
    c0b, d0b = vaddc(m3l, m1h, c0a, mask=wmask)
    c1b, out_lo = vaddc(d0b, m2h, c1a, mask=wmask)
    c0c, d0c = vaddc(src2, m3h, c0b, mask=wmask)
    _, out_hi = vaddc(src2, d0c, c1b, mask=wmask)
    return _pack64(_undup_word(out_lo), _undup_word(out_hi))


# ---------------------------------------------------------------------------
# 除法链的复制域（dup-domain）原语：div 全链以 (lo,hi) 复制对流转，
# 只在入口拆包一次、出口打包一次，避免每个 helper 都做
# deintlv/intlv 往返（大内核下 permute 链过深会触发后端损坏）。
# ---------------------------------------------------------------------------


def _d_add(aL, aH, bL, bH, wmask):
    c, lo = vaddc(aL, bL, _no_carry_mask(), mask=wmask)
    _, hi = vaddc(aH, bH, c, mask=wmask)
    return lo, hi


def _d_sub(aL, aH, bL, bH, wmask):
    b1, lo = vsubc(aL, bL, _all_carry_mask(), mask=wmask)
    _, hi = vsubc(aH, bH, b1, mask=wmask)
    return lo, hi


def _d_mul(aL, aH, bL, bH, wmask):
    lo, hi_ll = _wmul_dup(aL, bL, wmask)
    t1lo, _ = _wmul_dup(bH, aL, wmask)  # aLo*bHi
    t2lo, _ = _wmul_dup(aH, bL, wmask)  # aHi*bLo
    _, s1 = vaddco(t1lo, t2lo, mask=wmask)
    _, hi = vaddc(hi_ll, s1, _no_carry_mask(), mask=wmask)
    return lo, hi


def _d_b128(aL, aH, bL, bH, cW, wmask):
    m0l, m0h = _wmul_dup(aL, bL, wmask)
    m1l, m1h = _wmul_dup(bH, aL, wmask)
    m2l, m2h = _wmul_dup(aH, bL, wmask)
    m3l, m3h = _wmul_dup(aH, bH, wmask)
    c0a, d0a = vaddco(m0h, m1l, mask=wmask)
    c1a, d1a = vaddco(d0a, m2l, mask=wmask)
    c0b, d0b = vaddc(m3l, m1h, c0a, mask=wmask)
    c1b, out_lo = vaddc(d0b, m2h, c1a, mask=wmask)
    c0c, d0c = vaddc(cW, m3h, c0b, mask=wmask)
    _, out_hi = vaddc(cW, d0c, c1b, mask=wmask)
    return out_lo, out_hi


def _d_not(aL, aH, wmask):
    return vnot(aL, mask=wmask), vnot(aH, mask=wmask)


def _d_cmp(aL, aH, bL, bH, wmask, kind, unsigned):
    if kind == "eq":
        return mask_and(veq(aL, bL, mask=wmask), veq(aH, bH, mask=wmask),
                        exec_mask=wmask)
    lo_cmp = _cmp_word(aL, bL, kind, signed=False, mask=wmask)
    hi_cmp = _cmp_word(aH, bH, kind, signed=not unsigned, mask=wmask)
    hi_eq = veq(aH, bH, mask=wmask)
    not_hi_eq = mask_not(hi_eq, exec_mask=wmask)
    return mask_or(
        mask_and(hi_eq, lo_cmp, exec_mask=wmask),
        mask_and(not_hi_eq, hi_cmp, exec_mask=wmask),
        exec_mask=wmask,
    )


def _d_sel(tL, tH, fL, fH, cond):
    return vselect(tL, fL, cond_mask=cond), vselect(tH, fH, cond_mask=cond)


def _d_abs(aL, aH, wmask):
    from cannbotdsl import dtypes

    i32 = dtypes.int32
    zero_h = vsub(aH, aH, mask=wmask)
    sign = vlt(vreinterpret(aH, i32), vreinterpret(zero_h, i32), mask=wmask)
    zero_l = vsub(aL, aL, mask=wmask)
    b1, neg_lo = vsubc(zero_l, aL, _all_carry_mask(), mask=wmask)
    _, neg_hi = vsubc(zero_l, aH, b1, mask=wmask)
    return vselect(neg_lo, aL, cond_mask=sign), vselect(neg_hi, aH, cond_mask=sign)


def _d_s64_to_f32(aL, aH, wmask):
    """复制域 s64→f32：``f32(hi)*2^32 + f32(lo)`` 的 f32 FMA（正确舍入）。"""
    from cannbotdsl import dtypes
    from cannbotdsl.ops.reg.cast import vcast

    f_hi = vcast(vreinterpret(aH, dtypes.int32), dtypes.float32, mask=wmask)
    f_lo = vcast(vreinterpret(aL, dtypes.int32), dtypes.float32, mask=wmask)
    two32 = vdups(4294967296.0, dtypes.float32)
    return vmadd(f_hi, two32, f_lo, mask=wmask)


def _div_u64(lhs, rhs, *, mask):
    """uint64 除法（软仿），对标 DivU64Impl。

    b == 0 → 全 1；b > 2^63-1 → 商 0 或 1（比较选择）；b == 1 → 直通 a；
    其余走 f32 倒数 + B128Calc 高位 + 两轮商校正。全程复制域流转。
    """
    from cannbotdsl import dtypes
    from cannbotdsl.ops.reg.arith import vadds, vdiv

    aL, aH = _dup_words(_words(lhs))
    bL, bH = _dup_words(_words(rhs))
    wmask = _word_exec(mask)
    c0L, c0H = _dup_words(_bcast(0, 0))
    c1L, c1H = _dup_words(_bcast(1, 0))
    qzL, qzH = _dup_words(_bcast(0xFFFFFFFF, 0xFFFFFFFF))
    kL, kH = _dup_words(_bcast(0xFFFFFFFF, 0x7FFFFFFF))  # 2^63 - 1
    zero_w = vdups(0, dtypes.uint32)

    zero_mask = _d_cmp(bL, bH, c0L, c0H, wmask, "eq", unsigned=True)
    non_zero = mask_not(zero_mask, exec_mask=wmask)
    u1_mask = _d_cmp(bL, bH, kL, kH, wmask, "gt", unsigned=True)
    cnd = mask_and(_d_cmp(aL, aH, bL, bH, wmask, "ge", unsigned=True),
                   u1_mask, exec_mask=wmask)
    rqL, rqH = _d_sel(c1L, c1H, c0L, c0H, cnd)
    cnd = mask_and(_d_cmp(aL, aH, bL, bH, wmask, "lt", unsigned=True),
                   u1_mask, exec_mask=wmask)
    rqL, rqH = _d_sel(c0L, c0H, rqL, rqH, cnd)
    one_mask = _d_cmp(bL, bH, c1L, c1H, wmask, "eq", unsigned=True)
    non_one = mask_not(one_mask, exec_mask=wmask)
    core = mask_and(non_one, non_zero, exec_mask=wmask)

    b_f = _d_s64_to_f32(bL, bH, wmask)
    r_f = vdiv(vdups(1.0, dtypes.float32), b_f, mask=core)
    r_bits = vreinterpret(r_f, dtypes.uint32)
    r_f = vreinterpret(vadds(r_bits, 0x1FFFFFFE, mask=core), dtypes.float32)
    t5L, t5H = _dup_words(_f32_to_s64(_undup_word(r_f), wmask))
    t6L, t6H = _d_mul(bL, bH, t5L, t5H, wmask)
    t6L, t6H = _d_not(t6L, t6H, wmask)
    t6L, t6H = _d_add(t6L, t6H, c1L, c1H, wmask)
    t7L, t7H = _d_b128(t5L, t5H, t6L, t6H, zero_w, wmask)
    t7L, t7H = _d_add(t5L, t5H, t7L, t7H, wmask)
    t6L, t6H = _d_mul(bL, bH, t7L, t7H, wmask)
    t6L, t6H = _d_not(t6L, t6H, wmask)
    t6L, t6H = _d_add(t6L, t6H, c1L, c1H, wmask)
    b0L, b0H = _d_b128(t7L, t7H, t6L, t6H, zero_w, wmask)
    t6L, t6H = _d_add(t7L, t7H, b0L, b0H, wmask)  # r'' = r' + hi64(r'*(-br'))
    t6L, t6H = _d_b128(aL, aH, t6L, t6H, zero_w, wmask)
    t7L, t7H = _d_mul(t6L, t6H, bL, bH, wmask)
    remL, remH = _d_sub(aL, aH, t7L, t7H, wmask)
    ge0 = _d_cmp(remL, remH, bL, bH, wmask, "ge", unsigned=True)
    remCL, remCH = _d_sub(remL, remH, bL, bH, wmask)
    q1L, q1H = _d_add(t6L, t6H, c1L, c1H, wmask)
    remL, remH = _d_sel(remCL, remCH, remL, remH, ge0)
    t6L, t6H = _d_sel(q1L, q1H, t6L, t6H, ge0)
    ge0 = _d_cmp(remL, remH, bL, bH, wmask, "ge", unsigned=True)
    q1L, q1H = _d_add(t6L, t6H, c1L, c1H, wmask)
    t6L, t6H = _d_sel(q1L, q1H, t6L, t6H, ge0)
    t6L, t6H = _d_sel(rqL, rqH, t6L, t6H, u1_mask)
    t6L, t6H = _d_sel(aL, aH, t6L, t6H, one_mask)
    qL, qH = _d_sel(qzL, qzH, t6L, t6H, zero_mask)
    return _pack64(_undup_word(qL), _undup_word(qH))


def _div_s64(lhs, rhs, *, mask):
    """int64 除法（软仿），对标 DivS64Impl（绝对值 + DivU64 核心 + 符号化）。"""
    from cannbotdsl import dtypes
    from cannbotdsl.ops.reg.arith import vadds, vdiv

    aL, aH = _dup_words(_words(lhs))
    bL, bH = _dup_words(_words(rhs))
    wmask = _word_exec(mask)
    c0L, c0H = _dup_words(_bcast(0, 0))
    c1L, c1H = _dup_words(_bcast(1, 0))
    qzL, qzH = _dup_words(_bcast(0xFFFFFFFF, 0xFFFFFFFF))
    zero_w = vdups(0, dtypes.uint32)

    absaL, absaH = _d_abs(aL, aH, wmask)
    absbL, absbH = _d_abs(bL, bH, wmask)
    zero_mask = _d_cmp(bL, bH, c0L, c0H, wmask, "eq", unsigned=True)
    non_zero = mask_not(zero_mask, exec_mask=wmask)
    one_mask = _d_cmp(absbL, absbH, c1L, c1H, wmask, "eq", unsigned=True)
    non_one = mask_not(one_mask, exec_mask=wmask)
    core = mask_and(non_one, non_zero, exec_mask=wmask)
    # |b| = 2^63（INT64_MIN）超出核心算法的 2^63-1 前提：预置商
    # a >= |b| → 1，否则 0（对标 DivU64Impl 的 uSrc1 门控）。
    kL, kH = _dup_words(_bcast(0xFFFFFFFF, 0x7FFFFFFF))  # 2^63 - 1
    u1_mask = _d_cmp(absbL, absbH, kL, kH, wmask, "gt", unsigned=True)
    cnd = mask_and(_d_cmp(absaL, absaH, absbL, absbH, wmask, "ge", unsigned=True),
                   u1_mask, exec_mask=wmask)
    rqL, rqH = _d_sel(c1L, c1H, c0L, c0H, cnd)

    b_f = _d_s64_to_f32(absbL, absbH, wmask)
    r_f = vdiv(vdups(1.0, dtypes.float32), b_f, mask=core)
    r_bits = vreinterpret(r_f, dtypes.uint32)
    r_f = vreinterpret(vadds(r_bits, 0x1FFFFFFE, mask=core), dtypes.float32)
    t5L, t5H = _dup_words(_f32_to_s64(_undup_word(r_f), wmask))
    t6L, t6H = _d_mul(absbL, absbH, t5L, t5H, wmask)
    t6L, t6H = _d_not(t6L, t6H, wmask)
    t6L, t6H = _d_add(t6L, t6H, c1L, c1H, wmask)
    t7L, t7H = _d_b128(t5L, t5H, t6L, t6H, zero_w, wmask)
    t7L, t7H = _d_add(t5L, t5H, t7L, t7H, wmask)
    t6L, t6H = _d_mul(absbL, absbH, t7L, t7H, wmask)
    t6L, t6H = _d_not(t6L, t6H, wmask)
    t6L, t6H = _d_add(t6L, t6H, c1L, c1H, wmask)
    b0L, b0H = _d_b128(t7L, t7H, t6L, t6H, zero_w, wmask)
    t6L, t6H = _d_add(t7L, t7H, b0L, b0H, wmask)  # r'' = r' + hi64(r'*(-br'))
    t6L, t6H = _d_b128(absaL, absaH, t6L, t6H, zero_w, wmask)
    t7L, t7H = _d_mul(t6L, t6H, absbL, absbH, wmask)
    remL, remH = _d_sub(absaL, absaH, t7L, t7H, wmask)
    ge0 = _d_cmp(remL, remH, absbL, absbH, wmask, "ge", unsigned=True)
    remCL, remCH = _d_sub(remL, remH, absbL, absbH, wmask)
    q1L, q1H = _d_add(t6L, t6H, c1L, c1H, wmask)
    remL, remH = _d_sel(remCL, remCH, remL, remH, ge0)
    t6L, t6H = _d_sel(q1L, q1H, t6L, t6H, ge0)
    ge0 = _d_cmp(remL, remH, absbL, absbH, wmask, "ge", unsigned=True)
    q1L, q1H = _d_add(t6L, t6H, c1L, c1H, wmask)
    t6L, t6H = _d_sel(q1L, q1H, t6L, t6H, ge0)
    t6L, t6H = _d_sel(rqL, rqH, t6L, t6H, u1_mask)
    t6L, t6H = _d_sel(absaL, absaH, t6L, t6H, one_mask)
    negL, negH = _d_sub(c0L, c0H, t6L, t6H, wmask)
    i32 = dtypes.int32
    ge_a = vge(vreinterpret(aH, i32), vreinterpret(zero_w, i32), mask=wmask)
    ge_b = vge(vreinterpret(bH, i32), vreinterpret(zero_w, i32), mask=wmask)
    sign_res = mask_not(mask_xor(ge_a, ge_b, exec_mask=wmask), exec_mask=wmask)
    t6L, t6H = _d_sel(t6L, t6H, negL, negH, sign_res)
    qL, qH = _d_sel(qzL, qzH, t6L, t6H, zero_mask)
    return _pack64(_undup_word(qL), _undup_word(qH))
