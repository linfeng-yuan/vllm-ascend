# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode scatter ops."""

from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _raw_tensor_operand, _tag_raw_op
from cannbotdsl.ops.reg.mask import Mask
from cannbotdsl.ops.reg.reg_defs import RawVReg


def vscatter(tensor, src: RawVReg, index: RawVReg, *, mask: Mask) -> None:
    """Scatter a register into UB tensor by per-lane index.

    For each lane i where mask is true, stores src[i] to tensor[index[i]].
    """
    _require_raw_mode("vscatter")
    operand, _ = _raw_tensor_operand(tensor)
    op = cannir.RawRegScatterOp(
        operand, src.value, index.value, mask.value
    )
    _tag_raw_op(op)
