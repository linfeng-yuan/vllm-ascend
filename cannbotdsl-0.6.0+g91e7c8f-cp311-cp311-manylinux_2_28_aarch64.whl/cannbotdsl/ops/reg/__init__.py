# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode VF API, split by operation family."""

# `_INSIDE_RAW_VF_LOOP_BODY` is read by cannbotdsl.core.frontend.runtime.hooks
# through the package path, as it was on the old flat raw_reg.py.
from cannbotdsl.ops.reg._common import _INSIDE_RAW_VF_LOOP_BODY  # noqa: F401

from cannbotdsl.ops.reg.reg_defs import MergeMode, OrderMode, BrcMode, UnpackMode, PackMode, RawVReg, ULoadReg, UStoreReg, StoreUnalignReg
from cannbotdsl.ops.reg.mask import Mask, MaskCounter, create_mask, full_mask, update_mask, mask_counter, vmask, mask_xor, mask_and, mask_or, mask_not
from cannbotdsl.ops.reg.load import vload, vload_unalign_init, vload_unalign, vload_broadcast, vload_upsample, vload_downsample, vload_unpack, vload_deinterleave, vmask_load, vload_strided
from cannbotdsl.ops.reg.store import vstore, vstore_strided, vstore_first, vstore_interleave, vstore_pack, vmask_store, vsqueeze_and_storeunalign_init, vstore_unalign_begin, vstore_unalign, vsqueeze_and_storeunalign, vstore_unalign_post, vsqueeze_and_storeunalign_finalize, vstorealign_squeeze_status, vstore_mask
from cannbotdsl.ops.reg.arith import vaddc, vsubc, vaddco, vsubbo, vmull, vadd, vsub, vmul, vdiv, vmax, vmin, vexp, vlog, vsqrt, vrelu, vabs, vneg, vabs_sub, vprelu, vexp_sub, vcast_exp_sub, vmadd, vmula, vmuls, vadds, vmaxs, vmins, vleakyrelu, vaxpy
from cannbotdsl.ops.reg.compare import vselect, vmerge, vgt, vge, veq, vle, vlt, vne, veqs, vgts, vges, vlts, vles, vnes
from cannbotdsl.ops.reg.reduce import vreduce_sum, vreduce_max, vreduce_min, vreduce_max_datablock, vreduce_sum_datablock, vreduce_min_datablock, vpair_reduce_sum
from cannbotdsl.ops.reg.logic import vnot, vbitwise_xor, vbitwise_and, vbitwise_or, vshr, vshl, vreinterpret_lanes, vreinterpret
from cannbotdsl.ops.reg.permute import vpack, vunpack, vsqueeze, vdeinterleave, vcompress, vinterleave
from cannbotdsl.ops.reg.cast import RegLayout, RoundingMode, vcast, vceil, vfloor, vtrunc
from cannbotdsl.ops.reg.gather import vgather, vgather_reg, vgather_datablock
from cannbotdsl.ops.reg.create import vdups, vdup, varange
from cannbotdsl.ops.reg.misc import vhistogram_frequency, vhistogram_accumulate
from cannbotdsl.ops.reg.scatter import vscatter
from cannbotdsl.ops.reg.sync_barrier import vmem_bar
from cannbotdsl.ops.reg.b64 import as_int64, as_uint64

__all__ = [
    "RegLayout",
    "RoundingMode",
    "MergeMode",
    "OrderMode",
    "BrcMode",
    "UnpackMode",
    "PackMode",
    "RawVReg",
    "ULoadReg",
    "UStoreReg",
    "StoreUnalignReg",
    "Mask",
    "MaskCounter",
    "create_mask",
    "full_mask",
    "update_mask",
    "mask_counter",
    "vmask",
    "mask_xor",
    "mask_and",
    "mask_or",
    "mask_not",
    "vload",
    "vload_unalign_init",
    "vload_unalign",
    "vload_broadcast",
    "vload_upsample",
    "vload_downsample",
    "vload_unpack",
    "vload_deinterleave",
    "vmask_load",
    "vload_strided",
    "vstore",
    "vstore_strided",
    "vstore_first",
    "vstore_interleave",
    "vstore_pack",
    "vmask_store",
    "vsqueeze_and_storeunalign_init",
    "vstore_unalign_begin",
    "vstore_unalign",
    "vsqueeze_and_storeunalign",
    "vstore_unalign_post",
    "vsqueeze_and_storeunalign_finalize",
    "vstorealign_squeeze_status",
    "vstore_mask",
    "vaddc",
    "vsubc",
    "vaddco",
    "vsubbo",
    "vmull",
    "vadd",
    "vsub",
    "vmul",
    "vdiv",
    "vmax",
    "vmin",
    "vexp",
    "vlog",
    "vsqrt",
    "vrelu",
    "vabs",
    "vneg",
    "vabs_sub",
    "vprelu",
    "vexp_sub",
    "vcast_exp_sub",
    "vmadd",
    "vmula",
    "vmuls",
    "vadds",
    "vmaxs",
    "vmins",
    "vleakyrelu",
    "vaxpy",
    "vselect",
    "vmerge",
    "vgt",
    "vge",
    "veq",
    "vle",
    "vlt",
    "vne",
    "veqs",
    "vgts",
    "vges",
    "vlts",
    "vles",
    "vnes",
    "vreduce_sum",
    "vreduce_max",
    "vreduce_min",
    "vreduce_max_datablock",
    "vreduce_sum_datablock",
    "vreduce_min_datablock",
    "vpair_reduce_sum",
    "vnot",
    "vbitwise_xor",
    "vbitwise_and",
    "vbitwise_or",
    "vshr",
    "vshl",
    "vreinterpret_lanes",
    "vreinterpret",
    "vpack",
    "vunpack",
    "vsqueeze",
    "vdeinterleave",
    "vcompress",
    "vinterleave",
    "vcast",
    "vceil",
    "vfloor",
    "vtrunc",
    "vgather",
    "vgather_reg",
    "vgather_datablock",
    "vdups",
    "vdup",
    "varange",
    "vhistogram_frequency",
    "vhistogram_accumulate",
    "vscatter",
    "vmem_bar",
    "as_int64",
    "as_uint64",
]
