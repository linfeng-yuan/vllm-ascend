# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw-mode mask values, mask construction and mask algebra."""

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import ascvec, cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _raw_mask_type, _raw_vreg_type, _tag_raw_op
from cannbotdsl.ops.reg.reg_defs import RawVReg


def _as_i32(value):
    from cannbotdsl.core.scalar_conversion import coerce_scalar_value

    return coerce_scalar_value(value, ir.IntegerType.get_signless(32))


class Mask(ir.Value):
    """First-class SSA wrapper for ``!cannir.raw_mask``."""

    def __init__(self, value: ir.Value, elem_bits: int | None = None):
        if not isinstance(value, ir.Value):
            raise TypeError(f"Mask requires ir.Value, got {type(value).__name__}")
        if str(value.type) != "!ascvec.mask":
            raise TypeError(
                f"Mask requires !ascvec.mask SSA value, got {value.type}"
            )
        super().__init__(value)
        if elem_bits is None:
            elem_bits = _mask_provenance_elem_bits(value)
        self.elem_bits = (
            int(elem_bits) if elem_bits is not None else None
        )

    @property
    def value(self):
        """Deprecated internal compatibility view; the object is the SSA value."""

        return self


def _ascvec_mask_typeid():
    with ir.Context() as _ctx:
        return ir.Type.parse("!ascvec.mask").typeid


def _mask_provenance_elem_bits(value: ir.Value) -> int | None:
    """Best-effort elem_bits of a mask from its defining instruction."""
    owner = getattr(value, "owner", None)
    if owner is None:
        return None
    name = getattr(owner, "name", "")
    try:
        if name == "ascvec.create_mask":
            return int(owner.attributes["elem_bits"].value)
        if name == "ascvec.update_mask":
            return int(owner.attributes["elem_bits"].value)
    except (KeyError, AttributeError):
        return None
    return None


Mask = ir.register_value_caster(_ascvec_mask_typeid())(Mask)


class MaskCounter(ir.Value):
    """Mutable remaining-element counter for raw-VF tail masks.

    Holds the i32 remaining-element count and is threaded through scf.for as a
    loop-carried value via the same protocol as ``Mask`` / ``RawVReg``. Pass it
    to ``update_mask(counter, elem_bits)`` and explicitly bind both results as
    ``mask, counter = update_mask(counter, elem_bits)``. ``elem_bits`` is
    supplied per call, not stored on the counter.
    """

    def __init__(self, value: ir.Value):
        if not isinstance(value, ir.Value):
            raise TypeError(
                f"MaskCounter requires ir.Value, got {type(value).__name__}"
            )
        super().__init__(value)
        if not isinstance(value.type, ir.IntegerType) or value.type.width != 32:
            raise TypeError(
                f"MaskCounter requires an i32 SSA value, got {value.type}"
            )

    @property
    def value(self):
        return self


_PAT_MODES = {
    "all": "PAT_ALL", "allf": "PAT_ALLF",
    **{f"vl{n}": f"PAT_VL{n}" for n in (1, 2, 3, 4, 8, 16, 32, 64, 128)},
    "m3": "PAT_M3", "m4": "PAT_M4",
    "h": "PAT_H", "half": "PAT_H", "q": "PAT_Q", "quarter": "PAT_Q",
}


def _normalize_pat_mode(pattern) -> str:
    if isinstance(pattern, str):
        key = pattern.strip().lower()
        if key.startswith("pat_"):
            return pattern.strip().upper()
        if key in _PAT_MODES:
            return _PAT_MODES[key]
    raise ValueError(
        "create_mask: pattern must be one of "
        "'all', 'allf', 'vl1'..'vl128', 'm3', 'm4', 'h', 'q' (PAT_* pset modes)"
    )


def create_mask(pattern: str = "all", elem_bits: int = 32) -> Mask:
    """Create a mask register from a hardware pset pattern
    (asc_create_mask_b8/b16/b32(pat_mode)).

    ``pattern`` selects the hardware fill pattern:

    - ``"all"`` (PAT_ALL): all elements true; ``"allf"`` (PAT_ALLF): all false
    - ``"vl1"``..``"vl128"`` (PAT_VLn): lowest N elements true
    - ``"m3"``/``"m4"`` (PAT_M3/M4): every 3rd/4th element true
    - ``"h"`` (PAT_H): lowest half true; ``"q"`` (PAT_Q): lowest quarter true

    ``elem_bits`` selects the mask granularity (8/16/32, or 64 for B64 soft
    emulation — see :func:`_create_mask_b64`).
    """
    _require_raw_mode("create_mask")
    if elem_bits == 64:
        return _create_mask_b64(pattern)
    pat = _normalize_pat_mode(pattern)
    op = ascvec.CreateMaskOp(
        _raw_mask_type(elem_bits), elem_bits=elem_bits, pat_mode=pat
    )
    _tag_raw_op(op)
    return Mask(op.mask, elem_bits)


def _create_mask_b64(pattern: str) -> Mask:
    """elem_bits=64 mask: per-B64-element granularity implemented on b32 lanes.

    Each b64 element owns two b32 mask bits (lo/hi word lanes), so the
    physical mask is the plain b32 pset/update result for twice the element
    count.     pat modes are parsed permissively here: any ``vl<n>`` (n = b64 element
    count) is accepted even when 2n has no b32 pset — those fall back to the
    dynamic update-mask instruction.
    """
    key = pattern.strip().lower()
    if key.startswith("pat_"):
        pat = key.upper()
    elif key in _PAT_MODES:
        pat = _PAT_MODES[key]
    elif key.startswith("vl") and key[2:].isdigit() and 1 <= int(key[2:]) <= 32:
        pat = f"PAT_VL{int(key[2:])}"
    else:
        raise ValueError(
            "create_mask: pattern must be one of "
            "'all', 'allf', 'vl1'..'vl32', 'h', 'q' (or PAT_* pset modes)"
        )
    ty = _raw_mask_type(32)
    if pat in ("PAT_ALL", "PAT_ALLF", "PAT_H", "PAT_Q"):
        op = ascvec.CreateMaskOp(ty, elem_bits=32, pat_mode=pat)
        _tag_raw_op(op)
        return Mask(op.mask, 64)
    if pat.startswith("PAT_VL"):
        n = int(pat[len("PAT_VL"):])
        twice = 2 * n
        b32_vls = {int(k[2:]) for k in _PAT_MODES if k.startswith("vl")}
        if twice in b32_vls:
            op = ascvec.CreateMaskOp(ty, elem_bits=32, pat_mode=f"PAT_VL{twice}")
        else:
            op = ascvec.UpdateMaskOp(
                ty, ir.IntegerType.get_signless(32), _as_i32(twice), elem_bits=32
            )
        _tag_raw_op(op)
        return Mask(op.mask, 64)
    raise ValueError(
        f"create_mask: pattern {pattern!r} (every-3rd/4th-element masks) "
        "has no elem_bits=64 semantics"
    )


def full_mask(elem_bits: int = 32) -> Mask:
    """Deprecated alias of :func:`create_mask(pattern="all")`.

    A full mask needs no element bit width argument: PAT_ALL sets every bit,
    so the hardware result is identical at b8/b16/b32 granularity (an
    all-true b8 pset covers b16/b32 lanes too). The mask is still typed with
    the widest (b32) granularity internally so derived masks keep matching
    the vector dtypes they gate. ``full_mask(elem_bits=64)`` returns the
    per-B64-element full mask (32 elements over 64 b32 lanes).
    """
    return create_mask(pattern="all", elem_bits=elem_bits)


def update_mask(remaining, elem_bits: int = 32):
    """Update the tail mask for the next register chunk.

    ``remaining`` counts *elements* at ``elem_bits`` granularity (an int, an
    SSA value, or a :class:`MaskCounter` from :func:`mask_counter`). With
    ``elem_bits=64`` the count is in B64 elements: the count is doubled to
    drive the b32 update instruction and the outgoing count is halved back
    to element units, so counters stay in B64 elements across iterations.
    """
    _require_raw_mode("update_mask")
    if elem_bits == 64:
        return _update_mask_b64(remaining)
    if isinstance(remaining, MaskCounter):
        op = ascvec.UpdateMaskOp(
            _raw_mask_type(elem_bits),
            ir.IntegerType.get_signless(32),
            remaining.value,
            elem_bits=elem_bits,
        )
        _tag_raw_op(op)
        return Mask(op.mask, elem_bits), MaskCounter(op.remaining_out)
    remaining = _as_i32(remaining)
    op = ascvec.UpdateMaskOp(
        _raw_mask_type(elem_bits),
        ir.IntegerType.get_signless(32),
        remaining,
        elem_bits=elem_bits,
    )
    _tag_raw_op(op)
    # ``remaining_out`` is physically signless i32, so MLIR's generic caster
    # cannot recover its signed semantic identity.  The operation contract is
    # explicitly a signed remaining-element count; restore that canonical
    # wrapper at the producer instead of asking control-flow transport to
    # guess from the carrier.
    from cannbotdsl.types._numeric import Int32

    return Mask(op.mask, elem_bits), Int32(op.remaining_out)


def _update_mask_b64(remaining):
    """elem_bits=64 tail-mask update implemented on the b32 update instruction.

    ``asc_update_mask_b32`` consumes/produces *b32 lane* counts, so the B64
    element count doubles on the way in; the outgoing lane count is always
    even (``2n`` or ``2n - 64`` after saturation) and is halved back to
    element units. The produced mask covers ``min(remaining, 32)`` elements
    as ``2 * min(remaining, 32)`` b32 lanes.
    """
    from cannbotdsl._mlir.dialects import arith

    ty = ir.IntegerType.get_signless(32)
    base = remaining.value if isinstance(remaining, MaskCounter) else remaining
    if isinstance(base, ir.Value):
        base32 = _as_i32(base)
        two = arith.ConstantOp(ty, 2)
        rem2 = arith.MulIOp(base32, two).result
    else:
        rem2 = _as_i32(int(base) * 2)
    op = ascvec.UpdateMaskOp(_raw_mask_type(32), ty, rem2, elem_bits=32)
    _tag_raw_op(op)
    two = arith.ConstantOp(ty, 2)
    half = arith.DivSIOp(op.remaining_out, two).result
    if isinstance(remaining, MaskCounter):
        return Mask(op.mask, 64), MaskCounter(half)
    from cannbotdsl.types._numeric import Int32

    return Mask(op.mask, 64), Int32(half)


def mask_counter(logical) -> MaskCounter:
    """Create a mutable remaining-element counter for raw-VF tail masks.

    ``logical`` is the total logical element count; accepts ``int``, ``Int32``,
    or an ``ir.Value``. Inside a loop, explicitly update the carried value with
    ``mask, counter = update_mask(counter, elem_bits)``.
    """
    _require_raw_mode("mask_counter")
    return MaskCounter(_as_i32(logical))


def _binary(lhs: RawVReg, rhs: RawVReg, mask: Mask, op_cls, name: str) -> RawVReg:
    _require_raw_mode(name)
    from cannbotdsl.ops.reg._common import _reject_b64

    _reject_b64(name, lhs, rhs)
    if lhs.dtype != rhs.dtype:
        raise ValueError(f"{name}: dtype mismatch {lhs.dtype} vs {rhs.dtype}")
    op = op_cls(_raw_vreg_type(lhs.dtype), lhs.value, rhs.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, lhs.dtype)


def _unary(src: RawVReg, mask: Mask, op_cls, name: str) -> RawVReg:
    _require_raw_mode(name)
    from cannbotdsl.ops.reg._common import _reject_b64

    _reject_b64(name, src)
    op = op_cls(_raw_vreg_type(src.dtype), src.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vmask(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VCopyOp, "vmask")


def mask_xor(lhs: Mask, rhs: Mask, *, exec_mask: Mask) -> Mask:
    """Mask-domain (predicate) XOR. Lowers to `asc_xor` on the vector_bool overload.

    arch35 ``MicroAPI::Xor`` predicate-register algebra. All three masks must
    share the same element bit width.
    """
    _require_raw_mode("mask_xor")
    if lhs.elem_bits != rhs.elem_bits or lhs.elem_bits != exec_mask.elem_bits:
        raise ValueError(
            f"mask_xor: elem_bits mismatch {lhs.elem_bits}/{rhs.elem_bits}/{exec_mask.elem_bits}"
        )
    op = ascvec.MaskXorOp(
        _raw_mask_type(lhs.elem_bits), lhs.value, rhs.value, exec_mask.value
    )
    _tag_raw_op(op)
    return Mask(op.result, lhs.elem_bits)


def mask_and(lhs: Mask, rhs: Mask, *, exec_mask: Mask) -> Mask:
    """Mask-domain (predicate) AND. Lowers to `asc_and` on the vector_bool overload.

    All three masks must share the same element bit width.
    """
    _require_raw_mode("mask_and")
    if lhs.elem_bits != rhs.elem_bits or lhs.elem_bits != exec_mask.elem_bits:
        raise ValueError(
            f"mask_and: elem_bits mismatch {lhs.elem_bits}/{rhs.elem_bits}/{exec_mask.elem_bits}"
        )
    op = ascvec.MaskAndOp(
        _raw_mask_type(lhs.elem_bits), lhs.value, rhs.value, exec_mask.value
    )
    _tag_raw_op(op)
    return Mask(op.result, lhs.elem_bits)


def mask_or(lhs: Mask, rhs: Mask, *, exec_mask: Mask) -> Mask:
    """Mask-domain (predicate) OR. Lowers to `asc_or` on the vector_bool overload.

    All three masks must share the same element bit width.
    """
    _require_raw_mode("mask_or")
    if lhs.elem_bits != rhs.elem_bits or lhs.elem_bits != exec_mask.elem_bits:
        raise ValueError(
            f"mask_or: elem_bits mismatch {lhs.elem_bits}/{rhs.elem_bits}/{exec_mask.elem_bits}"
        )
    op = ascvec.MaskOrOp(
        _raw_mask_type(lhs.elem_bits), lhs.value, rhs.value, exec_mask.value
    )
    _tag_raw_op(op)
    return Mask(op.result, lhs.elem_bits)


def mask_not(src: Mask, *, exec_mask: Mask) -> Mask:
    """Mask-domain (predicate) NOT. Lowers to `asc_not` on the vector_bool overload.

    Both masks must share the same element bit width.
    """
    _require_raw_mode("mask_not")
    if src.elem_bits != exec_mask.elem_bits:
        raise ValueError(
            f"mask_not: elem_bits mismatch {src.elem_bits}/{exec_mask.elem_bits}"
        )
    op = ascvec.MaskNotOp(
        _raw_mask_type(src.elem_bits), src.value, exec_mask.value
    )
    _tag_raw_op(op)
    return Mask(op.result, src.elem_bits)
