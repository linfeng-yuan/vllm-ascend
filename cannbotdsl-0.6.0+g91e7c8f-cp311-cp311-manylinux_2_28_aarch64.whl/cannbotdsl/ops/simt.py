# Copyright (c) 2026 Huawei Technologies Co., Ltd.
"""Scalar SIMT APIs for use inside ``with vf(mode="simt")``.

Use ordinary Python arithmetic and control flow on the returned scalars.
"""
import cannbotdsl._mlir.ir as ir
from cannbotdsl.core.contracts.elements import (
    coerce_scalar_to_storage,
    wrap_produced_scalar,
)
from cannbotdsl.lang.vf import _current_vf_mode, _CURRENT_VF

__all__ = ["thread_idx", "sqrt"]


def _require_simt(api):
    if _current_vf_mode() != "simt":
        raise RuntimeError(f"simt.{api} requires with vf(mode='simt')")


def thread_idx():
    """Return the current thread's zero-based index within the VF launch."""
    _require_simt("thread_idx")
    dtype = ir.IntegerType.get_signless(32)
    value = ir.Operation.create(
        "cannir.simt.thread_idx", results=[dtype],
        attributes={"cannir.simt.scope": ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), _CURRENT_VF.get().group_id)}
    ).results[0]
    return wrap_produced_scalar(value, storage_type=dtype)


def sqrt(x):
    """Compute the scalar float32 square root."""
    _require_simt("sqrt")
    dtype = ir.F32Type.get()
    value = coerce_scalar_to_storage(x, dtype, path="simt.sqrt input")
    result = ir.Operation.create(
        "cannir.simt.sqrt", operands=[value], results=[dtype]
    ).results[0]
    return wrap_produced_scalar(result, storage_type=dtype)
