# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software; you can redistribute it and/or modify it under the terms and conditions of
# the CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""High-level communication context API for CANNBotDSL.

Provides a unified ``CommContext`` datastruct, a ``CommEngine`` configuration
dataclass for selecting protocol / engine / buffer source, and the
``get_comm_context`` / ``get_device_ptr`` host-side entry points.

Internally delegates to ``cannbotdsl.ops.distributed._hccl`` for all HCCL C-API calls.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum, auto
from typing import Optional

from cannbotdsl.types import dtypes
from cannbotdsl.types.datastruct import CArray, datastruct, _marshal_datastruct
from cannbotdsl.ops.distributed import _hccl as hccl

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

COMM_MAX_RANK_NUM = 64

# ---------------------------------------------------------------------------
# CommEngine configuration dataclass (with nested parameterising enums)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CommEngine:
    """Configuration for communication context construction.

    Similar to ``mem_copy``'s ``engine`` parameter — a configuration object
    that selects the communication protocol, engine, buffer source, and
    buffer size in one place.

    The protocol / engine / buffer-source enums that parameterise a
    ``CommEngine`` are nested inside it (``CommEngine.Protocol``,
    ``CommEngine.Engine``, ``CommEngine.BufferSource``) because they are
    sub-concepts of the engine configuration, not standalone top-level API.
    Construct an engine as::

        CommEngine(
            protocol=CommEngine.Protocol.URMA,
            buffer_source=CommEngine.BufferSource.SELF_REGISTERED,
            buffer_size=2 * 1024 * 1024,
        )

    Attributes:
        protocol: Link protocol (URMA for RDMA, UBMEM for shared memory).
        engine: HCCL engine (currently only AIV).
        buffer_source: Whether to use HCCL's built-in buffer or a
            self-registered buffer.
        buffer_size: Extra shared memory size in bytes when
            ``buffer_source=SELF_REGISTERED``.  Ignored for ``HCCL``.
    """

    class Protocol(IntEnum):
        """HCCL link protocol for channel acquisition.

        Member values mirror ``hccl.COMM_PROTOCOL_*`` so a change to the
        HCCL constant is followed automatically.
        """

        URMA = hccl.COMM_PROTOCOL_UBC_CTP   # cross-supernode RDMA
        UBMEM = hccl.COMM_PROTOCOL_UB_MEM   # intra-supernode UB memory

    class Engine(IntEnum):
        """HCCL communication engine identifier."""

        AIV = hccl.COMM_ENGINE_AIV

    class BufferSource(IntEnum):
        """Where the comm buffer addresses come from.

        Internal Python-side discriminator (no HCCL counterpart); values are
        assigned by ``auto()`` and never passed to a C-API.
        """

        HCCL = auto()            # HcclGetHcclBuffer / HcclChannelGetHcclBuffer
        SELF_REGISTERED = auto()  # HcclCommMemReg + HcclChannelGetRemoteMems

    protocol: Protocol = Protocol.URMA
    engine: Engine = Engine.AIV
    buffer_source: BufferSource = BufferSource.HCCL
    buffer_size: int = 0


# Module-level aliases so ``from cannbotdsl.ops.distributed.context import Protocol``
# (and Engine / BufferSource) still resolve for existing submodule callers;
# they point at the nested classes above and are deliberately NOT re-exported
# from the top-level ``cannbotdsl`` package — reach them via ``CommEngine``.

Protocol = CommEngine.Protocol
Engine = CommEngine.Engine
BufferSource = CommEngine.BufferSource


# ---------------------------------------------------------------------------
# Unified CommContext datastruct
# ---------------------------------------------------------------------------


@datastruct(c_name="CommContext")
class CommContext:
    """Unified device-side communication context.

    Flat 4-field structure — no nested sub-contexts.  All communication
    modes (URMA, UBMEM) use the same schema; unused fields are zeroed.

    Fields:
        rankId: This rank's ID in the communication group.
        rankSize: Total number of ranks in the group.
        channelHandles: Per-peer channel handles.  URMA mode stores
            acquired channel handles; UBMEM mode zeroes this (handles
            are discarded after address query).
        commBufferAddrs: Per-peer communication buffer addresses.
            Source depends on ``CommEngine.buffer_source``.
    """

    rankId: dtypes.int32
    rankSize: dtypes.int32
    channelHandles: CArray[dtypes.int64, COMM_MAX_RANK_NUM]
    commBufferAddrs: CArray[dtypes.int64, COMM_MAX_RANK_NUM]


# ---------------------------------------------------------------------------
# Host-side entry points
# ---------------------------------------------------------------------------

_CTX_CACHE: dict[tuple[str, str], int] = {}
_CTX_TENSOR_CACHE: dict[tuple[str, str], object] = {}


def _build_hccl_buffer_ctx(
    comm: int, rank_id: int, rank_size: int, engine: int,
    protocol: int, store_handles: bool,
) -> CommContext:
    """Build a CommContext that sources its buffers from HCCL's built-in
    buffer (URMA + HCCL or UBMEM + HCCL).

    ``store_handles`` selects whether per-peer channel handles are kept
    (URMA keeps them; UBMEM discards them after the address query).
    """
    layer_id = hccl.get_rank_graph_layers(comm)[0]
    buf, buf_size = hccl.get_hccl_buffer(comm)
    hccl.mem_set(buf, buf_size)

    channel_handles = [0] * COMM_MAX_RANK_NUM
    comm_buffer_addrs = [0] * COMM_MAX_RANK_NUM
    comm_buffer_addrs[rank_id] = buf

    for peer in range(rank_size):
        if peer == rank_id:
            continue
        links, _ = hccl.get_links(comm, layer_id, rank_id, peer)
        ch = hccl.acquire_channel(comm, engine, protocol, peer, layer_id, links)
        if store_handles:
            channel_handles[peer] = ch
        comm_buffer_addrs[peer] = hccl.get_channel_hccl_buffer(comm, ch)

    return CommContext(
        rankId=rank_id,
        rankSize=rank_size,
        channelHandles=channel_handles,
        commBufferAddrs=comm_buffer_addrs,
    )


def _build_urma_hccl(comm: int, rank_id: int, rank_size: int, engine: int) -> CommContext:
    """Build CommContext for URMA protocol + HCCL buffer source."""
    return _build_hccl_buffer_ctx(
        comm, rank_id, rank_size, engine, hccl.COMM_PROTOCOL_UBC_CTP, store_handles=True,
    )


def _build_ubmem_self_registered(
    comm: int, rank_id: int, rank_size: int, engine: int, tag: str, buffer_size: int,
    dev_ptr: int, ctx_size: int,
) -> CommContext:
    """Build CommContext for UBMEM protocol + self-registered buffer."""
    barrier_buf_addr = dev_ptr + ctx_size
    hccl.mem_set(barrier_buf_addr, buffer_size)

    sync_tag = tag + "syncBuf"
    handle = hccl.register_mem(comm, sync_tag, barrier_buf_addr, buffer_size)

    comm_buffer_addrs = [0] * COMM_MAX_RANK_NUM
    comm_buffer_addrs[rank_id] = barrier_buf_addr

    layer_id = hccl.get_rank_graph_layers(comm)[0]
    for peer in range(rank_size):
        if peer == rank_id:
            continue
        links, _ = hccl.get_links(comm, layer_id, rank_id, peer)
        ch = hccl.acquire_channel(
            comm, engine, hccl.COMM_PROTOCOL_UB_MEM, peer, layer_id, links,
            mem_handles=[handle],
        )
        remote_addr = hccl.get_channel_remote_mems(comm, ch, sync_tag)
        if remote_addr:
            comm_buffer_addrs[peer] = remote_addr

    return CommContext(
        rankId=rank_id,
        rankSize=rank_size,
        channelHandles=[0] * COMM_MAX_RANK_NUM,
        commBufferAddrs=comm_buffer_addrs,
    )


def _build_ubmem_hccl(comm: int, rank_id: int, rank_size: int, engine: int) -> CommContext:
    """Build CommContext for UBMEM protocol + HCCL buffer source."""
    return _build_hccl_buffer_ctx(
        comm, rank_id, rank_size, engine, hccl.COMM_PROTOCOL_UB_MEM, store_handles=False,
    )


def _simple_strategy(build_ctx_obj):
    """Strategy factory for the common shape: build ctx_obj -> marshal ->
    create an engine ctx of exactly ctx_size bytes.

    Used by (engine, protocol, BufferSource.HCCL) combos whose device ctx
    holds only the struct.  Pass the per-combo ``_build_*`` host-struct
    builder.
    """

    def strategy(comm, rank_id, rank_size, schema, comm_engine, tag, ctx_size):
        ctx_obj = build_ctx_obj(comm, rank_id, rank_size, comm_engine.engine)
        ctypes_ctx = _marshal_datastruct(ctx_obj, schema)
        dev_ptr = hccl.engine_ctx_create(comm, tag, ctx_size)
        return ctypes_ctx, dev_ptr

    return strategy


def _strategy_ubmem_self_registered(
    comm, rank_id, rank_size, schema, comm_engine, tag, ctx_size,
):
    """Strategy for UBMEM + self-registered buffer.

    The engine ctx must hold the struct *and* the self-registered barrier
    buffer, so dev_ptr (sized ctx_size + buffer_size) is created *before*
    the host ctx_obj (whose commBufferAddrs[rank_id] = dev_ptr + ctx_size).
    """
    total_size = ctx_size + comm_engine.buffer_size
    dev_ptr = hccl.engine_ctx_create(comm, tag, total_size)
    ctx_obj = _build_ubmem_self_registered(
        comm, rank_id, rank_size, comm_engine.engine, tag,
        comm_engine.buffer_size, dev_ptr, ctx_size,
    )
    ctypes_ctx = _marshal_datastruct(ctx_obj, schema)
    return ctypes_ctx, dev_ptr


# Dispatch table: (engine, protocol, buffer_source) -> strategy.  Adding a new
# engine / protocol / buffer combination is a new strategy (or a
# _simple_strategy(_build_*)) plus one table entry -- get_comm_context itself
# never changes (open-closed).
_BUILD_STRATEGIES = {
    (CommEngine.Engine.AIV, CommEngine.Protocol.URMA, CommEngine.BufferSource.HCCL):
        _simple_strategy(_build_urma_hccl),
    (CommEngine.Engine.AIV, CommEngine.Protocol.UBMEM, CommEngine.BufferSource.HCCL):
        _simple_strategy(_build_ubmem_hccl),
    (CommEngine.Engine.AIV, CommEngine.Protocol.UBMEM, CommEngine.BufferSource.SELF_REGISTERED):
        _strategy_ubmem_self_registered,
}


def get_comm_context(
    ctx_type,
    group_name: str,
    *,
    op_name: str = "",
    comm_engine: CommEngine = CommEngine(),
):
    """Construct a CommContext, upload it to device memory, and return it as
    a provider-owned NPU tensor.

    Builds the host CommContext, creates the HCCL engine ctx (or reuses an
    existing one), copies the host bytes into device memory, then copies
    those bytes into a ``torch.uint8`` NPU tensor of length ``ctx_type``
    schema size.  The returned tensor can be passed to an op as a
    ``StructRef[ctx_type]``.  Idempotent: the first call builds the device
    ctx and the tensor (one D2D copy); subsequent calls with the same
    ``group_name``/``op_name`` return the cached tensor without re-copying
    or re-allocating (the engine ctx is reused, no re-acquisition of
    channels).

    Args:
        ctx_type: The ``@datastruct`` class (must be ``CommContext`` or
            a compatible schema).
        group_name: HCCL group name (from ``torch.distributed``).
        op_name: Operation name used as engine ctx tag suffix.
        comm_engine: Communication configuration (protocol, engine,
            buffer source, buffer size).

    Returns:
        A 1-D ``torch.uint8`` NPU tensor holding the device-side
        CommContext bytes.
    """
    cache_key = (group_name, op_name)
    cached_tensor = _CTX_TENSOR_CACHE.get(cache_key)
    if cached_tensor is not None:
        return cached_tensor

    comm = hccl.get_comm_handle(group_name)
    rank_id = hccl.get_rank_id(comm)
    rank_size = hccl.get_rank_size(comm)

    tag = f"{group_name}{op_name}"

    existing = hccl.engine_ctx_get(comm, tag)
    if existing is not None:
        # Cache hit: an engine ctx already exists (prior call in this process
        # or a leftover HCCL ctx).  Reuse it rather than re-acquiring channels
        # (a collective op that deadlocks if not all ranks re-call it).
        _CTX_CACHE[cache_key] = existing
    else:
        schema = ctx_type.__cannbotdsl_datastruct_schema__
        ctx_size = schema.size

        strategy = _BUILD_STRATEGIES.get(
            (comm_engine.engine, comm_engine.protocol, comm_engine.buffer_source)
        )
        if strategy is None:
            raise ValueError(
                f"Unsupported comm_engine combination: "
                f"engine={comm_engine.engine!r}, protocol={comm_engine.protocol!r}, "
                f"buffer_source={comm_engine.buffer_source!r}"
            )
        ctypes_ctx, dev_ptr = strategy(
            comm, rank_id, rank_size, schema, comm_engine, tag, ctx_size,
        )

        hccl.engine_ctx_copy(comm, tag, ctypes_ctx, ctx_size)
        _CTX_CACHE[cache_key] = dev_ptr

    tensor = _make_ctx_tensor(ctx_type, group_name, op_name=op_name)
    _CTX_TENSOR_CACHE[cache_key] = tensor
    return tensor


def get_device_ptr(group_name: str, *, op_name: str = "") -> int:
    """Return the device pointer for a previously created engine ctx.

    Raises RuntimeError if no engine ctx exists for the given group/op.
    """
    cache_key = (group_name, op_name)
    if cache_key in _CTX_CACHE:
        return _CTX_CACHE[cache_key]

    comm = hccl.get_comm_handle(group_name)
    tag = f"{group_name}{op_name}"
    ptr = hccl.engine_ctx_get(comm, tag)
    if ptr is None:
        raise RuntimeError(
            f"No engine ctx for tag {tag!r}; call get_comm_context first"
        )
    _CTX_CACHE[cache_key] = ptr
    return ptr


def _make_ctx_tensor(ctx_type, group_name, *, op_name: str = ""):
    """Return a provider-owned NPU ``uint8`` tensor holding the device ctx.

    Reads back the engine-ctx device pointer (a cache lookup after
    ``get_comm_context`` has created it) and copies ``ctx_size`` bytes into a
    fresh ``torch.uint8`` NPU tensor.  Internal helper invoked by
    ``get_comm_context`` so callers never fetch a device pointer themselves.
    """
    import torch
    dev_ptr = get_device_ptr(group_name, op_name=op_name)
    ctx_size = ctx_type.__cannbotdsl_datastruct_schema__.size
    tensor = torch.zeros(ctx_size, dtype=torch.uint8).npu()
    hccl.aclrt_memcpy(tensor.data_ptr(), dev_ptr, ctx_size,
                      kind=hccl.ACL_MEMCPY_DEVICE_TO_DEVICE)
    return tensor


__all__ = [
    "CommContext",
    "CommEngine",
    "Protocol",
    "Engine",
    "BufferSource",
    "COMM_MAX_RANK_NUM",
    "get_comm_context",
    "get_device_ptr",
]
