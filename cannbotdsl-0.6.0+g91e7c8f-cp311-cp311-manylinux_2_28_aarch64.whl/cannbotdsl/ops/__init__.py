# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""cannbotdsl.ops -- compute, data movement, synchronisation and topology.

The tensor-level surfaces (matmul, conv, memcpy, sync,
arch and platform info) are re-exported here. The register-level and
collective surfaces stay behind their own namespaces and are reached as
``cannbotdsl.reg.*`` and ``cannbotdsl.distributed.*``.
"""

from cannbotdsl._mlir.dialects import cannir
from cannbotdsl.core.scalar_conversion import coerce_scalar_value
from cannbotdsl.tensor import Tensor
# Initialize language entry points before distributed datastruct declarations.
from cannbotdsl.lang.vf import vf as _vf
from cannbotdsl.ops.matmul import matmul
from cannbotdsl.ops.conv import (
    arith,
    Conv2dInputWindow,
    Conv2dTile,
    Conv2dSpec,
    make_conv2d_spec,
    make_conv2d_fmap_l1,
    conv2d_load_fmap,
    conv2d_load_im2col,
    conv2d_load_filter,
    conv2d_store_output,
)
from cannbotdsl.ops.memcpy import (
    CopyEngine,
    CopyBlockMapping,
    CopyEngineKind,
    CopyLayoutTransform,
    CopyTailAlignment,
    FormatTransform,
    NDDMAPaddingMode,
    make_copy_engine,
    mem_copy,
)
from cannbotdsl.ops.info import (
    PlatformInfo,
    get_mem_size,
    get_platform_info,
)
from cannbotdsl.ops.arch import (
    get_block_idx,
    get_block_num,
    get_core_id,
    get_squeeze_status,
    get_status,
    get_subblock_dim,
    get_subblock_id,
    get_system_cycle,
    get_vf_len,
)

# Namespace modules. `reg` and `distributed` are deliberately *not* flattened
# into this package: their symbols are reached through the namespace, which is
# also re-exported from the package root as `cannbotdsl.reg` /
# `cannbotdsl.distributed`. Keeping `reg` unflattened is what lets the
# tensor-level `vmax` / `vselect` above stay visible as `cannbotdsl.ops.vmax`.
from cannbotdsl.ops import (  # noqa: F401
    arch,
    cube,
    distributed,
    info,
    memcpy,
    reg,
    scalar,
    simt,
    sync,
)

__all__ = [
    "Conv2dInputWindow",
    "Conv2dSpec",
    "Conv2dTile",
    "CopyEngine",
    "CopyBlockMapping",
    "CopyEngineKind",
    "CopyLayoutTransform",
    "CopyTailAlignment",
    "FormatTransform",
    "NDDMAPaddingMode",
    "PlatformInfo",
    "Tensor",
    "arch",
    "arith",
    "cannir",
    "coerce_scalar_value",
    "conv2d_load_filter",
    "conv2d_load_fmap",
    "conv2d_load_im2col",
    "conv2d_store_output",
    "cube",
    "distributed",
    "get_block_idx",
    "get_block_num",
    "get_core_id",
    "get_mem_size",
    "get_platform_info",
    "get_squeeze_status",
    "get_status",
    "get_subblock_dim",
    "get_subblock_id",
    "get_system_cycle",
    "get_vf_len",
    "info",
    "make_conv2d_fmap_l1",
    "make_conv2d_spec",
    "make_copy_engine",
    "matmul",
    "mem_copy",
    "memcpy",
    "reg",
    "scalar",
    "simt",
    "sync",
]
