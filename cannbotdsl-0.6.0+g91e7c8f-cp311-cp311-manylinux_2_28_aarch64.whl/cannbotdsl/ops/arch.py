# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Device / grid indexing helpers for kernel code (MLIR i64 values).

Generates CANNIR core info query ops that lower through AscScalar
to AscendC C API calls (get_block_idx, get_block_num, etc.).
"""

from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.types._numeric import Int64 as _Int64


def get_block_idx() -> int:
    """Get current block (logical core) index."""
    return _Int64(cannir.get_block_idx())


def get_block_num() -> int:
    """Get total number of blocks (logical cores)."""
    return _Int64(cannir.get_block_num())


def get_subblock_dim() -> int:
    """Get sub-core count in current block (Cube=1, Vector=2)."""
    return _Int64(cannir.get_subblock_dim())


def get_subblock_id() -> int:
    """Get sub-core ID in current block (Cube=0, Vector=0/1)."""
    return _Int64(cannir.get_subblock_id())


def get_core_id() -> int:
    """Get current physical core ID."""
    return _Int64(cannir.get_core_id())


def get_system_cycle() -> int:
    """Read the system cycle counter (SYS_CNT, 1GHz on 950PR/DT)."""
    return _Int64(cannir.get_system_cycle())


def get_status() -> int:
    """Read the status register (overflow/underflow/NaN-INF flags)."""
    return _Int64(cannir.get_status())


def get_squeeze_status() -> int:
    """Read the squeeze valid-data byte count from the AR special register.

    Lowers to the device-side AscendC API ``asc_get_squeeze_status()``.
    This is a raw system-register query: its value is meaningful only after a
    compatible squeeze/store operation has initialized and updated AR. The
    CANN 9.2.0 beta.1 package does not provide the latest
    ``asc_squeeze_and_storeunalign`` producer.
    """
    return _Int64(cannir.get_squeeze_status())


def get_vf_len() -> int:
    """Get vector register width VL in bits (256 on dav-3510)."""
    return _Int64(cannir.get_vf_len())
