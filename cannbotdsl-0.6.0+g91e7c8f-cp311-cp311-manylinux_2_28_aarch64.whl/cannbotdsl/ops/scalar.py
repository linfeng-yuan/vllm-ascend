# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").

"""3510 scalar-instruction frontend.

This module intentionally contains only target scalar instructions with no
ordinary Python-operator equivalent.  Normal Tensor point indexing retains
its cached memory semantics; use ``load_bypass`` and the explicit
``cube_store_bypass``/``vec_store_bypass`` interfaces for the C API
DCache-bypass operations.
"""

from __future__ import annotations

from enum import IntEnum as _IntEnum

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir
from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.types import dtypes
from cannbotdsl.core.contracts.elements import (
    coerce_scalar_to_storage,
    dtype_for_storage_mlir_type,
    wrap_produced_scalar,
)
from cannbotdsl.tensor import MemLoc
from cannbotdsl.tensor import Tensor


class RoundingMode(_IntEnum):
    """Rounding modes supported by scalar float32-to-int32 conversion."""

    RN = 0
    RNA = 1
    RD = 2
    RU = 3


class _StoreCore(_IntEnum):
    AIC = 0
    AIV = 1


_BYPASS_DTYPES = frozenset(
    {
        dtypes.int8,
        dtypes.uint8,
        dtypes.int16,
        dtypes.uint16,
        dtypes.int32,
        dtypes.uint32,
        dtypes.int64,
        dtypes.uint64,
    }
)
_ATOMIC_ADD_DTYPES = frozenset(
    {
        dtypes.int32,
        dtypes.uint32,
        dtypes.float32,
        dtypes.int64,
        dtypes.uint64,
    }
)
_ATOMIC_INTEGER_DTYPES = frozenset(
    {
        dtypes.int32,
        dtypes.uint32,
        dtypes.int64,
        dtypes.uint64,
    }
)
_ATOMIC_COUNTER_DTYPES = frozenset({dtypes.uint32, dtypes.uint64})
_ROUNDING_ALIASES = {
    "rd": RoundingMode.RD,
    "ru": RoundingMode.RU,
    "rn": RoundingMode.RN,
    "rna": RoundingMode.RNA,
}

def _u64_type():
    """Build ui64 only while a tracing MLIR context is active."""
    return ir.IntegerType.get_unsigned(64)


def _i64_type():
    """Build i64 only while a tracing MLIR context is active."""
    return ir.IntegerType.get_signless(64)


def _i32_type():
    """Build i32 only while a tracing MLIR context is active."""
    return ir.IntegerType.get_signless(32)


def _f32_type():
    """Build f32 only while a tracing MLIR context is active."""
    return ir.F32Type.get()


def _u64(value, *, api_name: str):
    return coerce_scalar_to_storage(value, _u64_type(), path=f"{api_name} value")


def _i64(value, *, api_name: str):
    return coerce_scalar_to_storage(value, _i64_type(), path=f"{api_name} value")


def _wrap_i64(value):
    return wrap_produced_scalar(value, storage_type=_i64_type())


def _wrap_u64(value):
    return wrap_produced_scalar(value, storage_type=_u64_type())


def popc(value):
    """Return the number of set bits in one ``uint64`` scalar."""
    return _wrap_i64(cannir.scalar_popc(_i64_type(), _u64(value, api_name="scalar.popc")))


def clz(value):
    """Return the leading-zero count of one ``uint64`` scalar."""
    return _wrap_i64(cannir.scalar_clz(_i64_type(), _u64(value, api_name="scalar.clz")))


def zero_bits_cnt(value):
    """Return the total number of zero bits in one ``uint64`` scalar."""
    return _wrap_i64(cannir.scalar_zero_bits_cnt(_i64_type(), _u64(value, api_name="scalar.zero_bits_cnt")))


def ffs(value):
    """Return the first set-bit position, or -1 when absent."""
    return _wrap_i64(cannir.scalar_ffs(_i64_type(), _u64(value, api_name="scalar.ffs")))


def ffz(value):
    """Return the first zero-bit position, or -1 when absent."""
    return _wrap_i64(cannir.scalar_ffz(_i64_type(), _u64(value, api_name="scalar.ffz")))


def sflbits(value):
    """Return the count of leading bits equal to the sign bit."""
    return _wrap_i64(cannir.scalar_sflbits(_i64_type(), _i64(value, api_name="scalar.sflbits")))


def set_nthbit(bits, idx):
    """Set bit ``idx`` in one ``uint64`` scalar."""
    return _wrap_u64(
        cannir.scalar_set_nthbit(
            _u64_type(),
            _u64(bits, api_name="scalar.set_nthbit"),
            _i64(idx, api_name="scalar.set_nthbit"),
        )
    )


def clear_nthbit(bits, idx):
    """Clear bit ``idx`` in one ``uint64`` scalar."""
    return _wrap_u64(
        cannir.scalar_clear_nthbit(
            _u64_type(),
            _u64(bits, api_name="scalar.clear_nthbit"),
            _i64(idx, api_name="scalar.clear_nthbit"),
        )
    )


def _normalize_rounding(rounding) -> RoundingMode:
    if isinstance(rounding, RoundingMode):
        return rounding
    if isinstance(rounding, str) and rounding.lower() in _ROUNDING_ALIASES:
        return _ROUNDING_ALIASES[rounding.lower()]
    raise ValueError("scalar.cast: rounding must be one of 'rd', 'ru', 'rn', or 'rna'")


def cast(value, *, dtype, rounding: RoundingMode | str = RoundingMode.RN):
    """Convert one scalar with a 3510 target rounding mode.

    Supports ``dtypes.float32 -> dtypes.int32`` with this module's
    ``RoundingMode`` or a matching string. Register conversions use
    ``reg.vcast`` and their own ``reg.RoundingMode``.
    """
    if dtype is not dtypes.int32:
        actual = getattr(dtype, "name", repr(dtype))
        raise TypeError(f"scalar.cast currently supports only dtype=dtypes.int32, got {actual}")
    rounding = _normalize_rounding(rounding)
    value = coerce_scalar_to_storage(value, _f32_type(), path="scalar.cast value")
    result = cannir.scalar_float2int32(_i32_type(), value, rounding)
    return wrap_produced_scalar(result, storage_type=_i32_type())


def _point_operands(tensor, coord, *, api_name: str):
    from cannbotdsl.tensor import (
        _classify_tensor_index_intent,
        _make_point_coord,
        _tensor_memloc,
        _tensor_storage_type,
    )

    if not isinstance(tensor, Tensor):
        raise TypeError(f"{api_name}: tensor must be a Tensor, got {type(tensor).__name__}")
    if _tensor_memloc(tensor) != MemLoc.GM:
        raise NotImplementedError(f"{api_name}: supports only GM tensors")
    intent = _classify_tensor_index_intent(coord, api_name=api_name)
    coord_value = _make_point_coord(tensor, coord, api_name=api_name, intent=intent)
    storage_type = _tensor_storage_type(tensor)
    return unwrap_operand(tensor), coord_value, storage_type


class ScalarPtr:
    """Typed pointer to one GM scalar element, created by ``tensor.ptr(coord)``.

    This is the frontend counterpart of the ``!cannir.ptr<gm, T>`` SSA value.
    It carries the element dtype so each ``scalar.*`` consumer can enforce its
    own dtype contract.  It is produced only by ``Tensor.ptr`` and cannot be
    constructed directly.
    """

    __slots__ = ("_value", "_storage_type", "_dtype")

    def __init__(self, *args, **kwargs):
        del args, kwargs
        raise TypeError("ScalarPtr values are created by Tensor.ptr(coord)")

    @classmethod
    def _from_ir(cls, value, storage_type, dtype):
        result = object.__new__(cls)
        object.__setattr__(result, "_value", value)
        object.__setattr__(result, "_storage_type", storage_type)
        object.__setattr__(result, "_dtype", dtype)
        return result

    @property
    def dtype(self) -> dtypes.DType:
        return self._dtype


def _tensor_ptr(tensor, coord) -> ScalarPtr:
    """Create a typed pointer to one GM scalar element of ``tensor``.

    This is pure address formation: no memory is accessed until the pointer is
    consumed by ``scalar.load_bypass``, ``scalar.cube_store_bypass``,
    ``scalar.vec_store_bypass``, or one of the ``scalar.atomic_*`` interfaces.
    The same pointer may be reused by several such accesses.  Public entry
    point: ``Tensor.ptr(coord)``.
    """
    memref, coord_value, storage_type = _point_operands(tensor, coord, api_name="tensor.ptr")
    dtype = dtype_for_storage_mlir_type(storage_type)
    value = cannir.scalar_ptr(memref, coord_value)
    return ScalarPtr._from_ir(value, storage_type, dtype)


def _checked_ptr(ptr, allowed_dtypes, *, api_name: str) -> ScalarPtr:
    if not isinstance(ptr, ScalarPtr):
        raise TypeError(f"{api_name}: ptr must be a scalar pointer from tensor.ptr(coord), got {type(ptr).__name__}")
    if ptr._dtype not in allowed_dtypes:
        names = ", ".join(sorted(item.name for item in allowed_dtypes))
        raise TypeError(
            f"{api_name}: unsupported pointer element dtype dtypes.{ptr._dtype.name}; expected one of {names}"
        )
    return ptr


def load_bypass(ptr):
    """Read one GM integer scalar through ``asc_load_dev`` (DCache bypass)."""
    ptr = _checked_ptr(ptr, _BYPASS_DTYPES, api_name="scalar.load_bypass")
    return wrap_produced_scalar(cannir.scalar_load_dev(ptr._value), storage_type=ptr._storage_type)


def _store_on_core(ptr, value, *, api_name: str, core: _StoreCore) -> None:
    ptr = _checked_ptr(ptr, _BYPASS_DTYPES, api_name=api_name)
    cannir.scalar_store_dev(
        coerce_scalar_to_storage(value, ptr._storage_type, path=f"{api_name} value"),
        ptr._value,
        core=core,
    )


def cube_store_bypass(ptr, value) -> None:
    """Write one GM integer scalar from the AIC half of a MIX kernel.

    This operation only selects the executing half.  It establishes no
    ordering, visibility, fence, or MIX-wide synchronization protocol.
    """
    _store_on_core(
        ptr,
        value,
        api_name="scalar.cube_store_bypass",
        core=_StoreCore.AIC,
    )


def vec_store_bypass(ptr, value) -> None:
    """Write one GM integer scalar from the AIV half of a MIX kernel.

    Both AIV subcores execute this operation.  Guard it with
    ``get_subblock_id() == 0`` when one vector writer is required.  This
    operation establishes no ordering, visibility, fence, or MIX-wide
    synchronization protocol.
    """
    _store_on_core(
        ptr,
        value,
        api_name="scalar.vec_store_bypass",
        core=_StoreCore.AIV,
    )


def _atomic_binary(ptr, value, *, api_name, allowed_dtypes, op):
    ptr = _checked_ptr(ptr, allowed_dtypes, api_name=api_name)
    value = coerce_scalar_to_storage(value, ptr._storage_type, path=f"{api_name} value")
    return wrap_produced_scalar(op(ptr._value, value), storage_type=ptr._storage_type)


def atomic_add(ptr, value):
    """Atomically add to one GM scalar and return its value before the update.

    The instruction bypasses DCache.  Callers must establish cache coherence
    and MTE/Scalar ordering explicitly when the same GM range is shared with
    cached accesses or DMA.
    """
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_add", allowed_dtypes=_ATOMIC_ADD_DTYPES, op=cannir.scalar_atomic_add
    )


def atomic_sub(ptr, value):
    """Atomically subtract ``value`` from one GM scalar and return the old value."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_sub", allowed_dtypes=_ATOMIC_ADD_DTYPES, op=cannir.scalar_atomic_sub
    )


def atomic_exch(ptr, value):
    """Atomically replace one GM scalar and return the old value."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_exch", allowed_dtypes=_ATOMIC_ADD_DTYPES, op=cannir.scalar_atomic_exch
    )


def atomic_max(ptr, value):
    """Atomically write the maximum of one GM scalar and ``value``."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_max", allowed_dtypes=_ATOMIC_ADD_DTYPES, op=cannir.scalar_atomic_max
    )


def atomic_min(ptr, value):
    """Atomically write the minimum of one GM scalar and ``value``."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_min", allowed_dtypes=_ATOMIC_ADD_DTYPES, op=cannir.scalar_atomic_min
    )


def atomic_and(ptr, value):
    """Atomically apply bitwise AND and return the old GM value."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_and", allowed_dtypes=_ATOMIC_INTEGER_DTYPES, op=cannir.scalar_atomic_and
    )


def atomic_or(ptr, value):
    """Atomically apply bitwise OR and return the old GM value."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_or", allowed_dtypes=_ATOMIC_INTEGER_DTYPES, op=cannir.scalar_atomic_or
    )


def atomic_xor(ptr, value):
    """Atomically apply bitwise XOR and return the old GM value."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_xor", allowed_dtypes=_ATOMIC_INTEGER_DTYPES, op=cannir.scalar_atomic_xor
    )


def atomic_inc(ptr, value):
    """Atomically increment a wrapping GM counter with upper bound ``value``."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_inc", allowed_dtypes=_ATOMIC_COUNTER_DTYPES, op=cannir.scalar_atomic_inc
    )


def atomic_dec(ptr, value):
    """Atomically decrement a wrapping GM counter with upper bound ``value``."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_dec", allowed_dtypes=_ATOMIC_COUNTER_DTYPES, op=cannir.scalar_atomic_dec
    )


def atomic_cas(ptr, compare, value):
    """Atomically replace a GM scalar when it equals ``compare``; return old."""
    ptr = _checked_ptr(ptr, _ATOMIC_ADD_DTYPES, api_name="scalar.atomic_cas")
    compare = coerce_scalar_to_storage(compare, ptr._storage_type, path="scalar.atomic_cas compare")
    value = coerce_scalar_to_storage(value, ptr._storage_type, path="scalar.atomic_cas value")
    return wrap_produced_scalar(
        cannir.scalar_atomic_cas(ptr._value, compare, value),
        storage_type=ptr._storage_type,
    )


__all__ = [
    "RoundingMode",
    "cube_store_bypass",
    "atomic_add",
    "atomic_and",
    "atomic_cas",
    "atomic_dec",
    "atomic_exch",
    "atomic_inc",
    "atomic_max",
    "atomic_min",
    "atomic_or",
    "atomic_sub",
    "atomic_xor",
    "cast",
    "clear_nthbit",
    "clz",
    "ffz",
    "ffs",
    "load_bypass",
    "popc",
    "ScalarPtr",
    "set_nthbit",
    "sflbits",
    "vec_store_bypass",
    "zero_bits_cnt",
]
