# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Tensor and Layout values, layout derivation, type construction, and views."""

from __future__ import annotations

import math
from enum import IntEnum as _IntEnum
from functools import reduce
from typing import Any, Optional, Tuple, Union

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import arith, cannir
from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.types import dtypes as _dtypes
from cannbotdsl.types import _tensor as _tensor_values
from cannbotdsl.types._tensor import PartitionTiler
from cannbotdsl.types.scalar import ScalarValue as _ScalarValue
from cannbotdsl.core.scalar_conversion import (
    _constant_i64,
    _index_value,
    _int64_result,
    _render_literal,
    _validate_index_value,
)


class MemLoc(_IntEnum):
    GM = 0
    UB = 1
    L1 = 2
    L0A = 3
    L0B = 4
    L0C = 5
    RegFile = 6
    L0A_MX = 7
    L0B_MX = 8
    BIAS = 9
    SSBUF = 10
    FBUF = 11


class LayoutMapKind(_IntEnum):
    Identity = 0
    ND2NZ = 1
    DN2NZ = 2
    NZ2ND = 3
    ZN2ND = 4


# Recursive Python metadata trees; integer validation is performed at use sites.
Shape = Union[int, _ScalarValue, Tuple["Shape", ...]]
Stride = Union[int, _ScalarValue, Tuple["Stride", ...]]
Coord = Union[int, None, _ScalarValue, Tuple["Coord", ...]]
Tile = Union[int, _ScalarValue, Tuple["Tile", ...]]
Tiler = Union[Shape, Tile]
_TensorIndex = Union[int, None, slice, _ScalarValue, Tuple["_TensorIndex", ...]]

class Layout:
    """Read-only semantic view of one CANNIR layout SSA value.

    Layout objects are created by CANNBotDSL.  The backend carrier is kept
    private so frontend code cannot accidentally couple itself to MLIR's
    Python value implementation.
    """

    __slots__ = ("_ssa_value",)

    def __init__(self, *args, **kwargs):
        del args, kwargs
        raise TypeError("Layout values are created by CANNBotDSL")

    def __init_subclass__(cls, **kwargs):
        del kwargs
        raise TypeError("Layout is a sealed CANNBotDSL value type")

    @classmethod
    def _from_ir(cls, value):
        if type(value) is cls:
            return value
        if not isinstance(value, ir.Value) or not cannir.LayoutType.isinstance(value.type):
            actual = getattr(value, "type", type(value).__name__)
            raise TypeError(f"Layout requires a !cannir.layout carrier, got {actual}")
        result = object.__new__(cls)
        object.__setattr__(result, "_ssa_value", value)
        return result

    @property
    def shape(self) -> Shape:
        return _layout_shape(self)

    @property
    def stride(self) -> Stride:
        return _layout_stride(self)


class Tensor:
    """Canonical trace-body tensor value.

    A Tensor owns no host allocation.  It is a composition facade around one
    CANNIR Tensor SSA value and is constructed only by the framework while a
    staged function is being traced.
    """

    __slots__ = ("_ssa_value",)

    def __init__(self, *args, **kwargs):
        del args, kwargs
        raise TypeError("Tensor values are created by CANNBotDSL while tracing")

    def __init_subclass__(cls, **kwargs):
        del cls, kwargs
        raise TypeError("Tensor is a sealed CANNBotDSL value type")

    @classmethod
    def _from_ir(cls, value):
        if type(value) is cls:
            return value
        if not isinstance(value, ir.Value) or not cannir.TensorType.isinstance(value.type):
            actual = getattr(value, "type", type(value).__name__)
            raise TypeError(f"Tensor requires a !cannir.tensor carrier, got {actual}")
        result = object.__new__(cls)
        object.__setattr__(result, "_ssa_value", value)
        return result

    @property
    def shape(self) -> Shape:
        return _tensor_shape(self)

    @property
    def stride(self) -> Stride:
        return _tensor_stride(self)

    @property
    def dtype(self) -> _dtypes.DType:
        return _tensor_dtype(self)

    @property
    def memloc(self) -> MemLoc:
        return _tensor_memloc(self)

    @property
    def layout(self) -> Layout:
        return _tensor_layout(self)

    @property
    def physical_layout(self) -> Layout:
        return _tensor_physical_layout(self)

    @property
    def physical_shape(self) -> Shape:
        return self.physical_layout.shape

    @property
    def physical_stride(self) -> Stride:
        return self.physical_layout.stride

    @property
    def logical_format(self) -> str:
        return _tensor_logical_format(self)

    @property
    def physical_format(self) -> str:
        return _tensor_physical_format(self)

    @property
    def data_format(self) -> str:
        return self.physical_format

    @property
    def rank(self) -> int:
        return len(self.shape)

    def reinterpret(self, dtype=None, shape=None, *, stride=None, offset: int = 0,
                    data_format=None, n1_pad=0):
        """Return a typed same-storage Tensor alias."""

        return reinterpret(self, dtype, shape, stride=stride, offset=offset,
                           data_format=data_format, n1_pad=n1_pad)

    def view(self, *shape, size=None, dtype=None) -> "Tensor":
        """Return a programmer-guaranteed shape or dtype alias."""

        return _tensor_view_dispatch(self, *shape, size=size, dtype=dtype)

    @property
    def vec(self):
        """Return an AIV-affine point-access view of an SSBUF Tensor."""

        return _tensor_ssbuf_core_view(self, "vec")

    @property
    def cube(self):
        """Return an AIC-affine point-access view of an SSBUF Tensor."""

        return _tensor_ssbuf_core_view(self, "cube")

    def __getitem__(self, coord: _TensorIndex) -> Any:
        """Load a point or create a rank-preserving alias view.

        A point coordinate must match the complete logical shape tree.  The
        root one-dimensional form accepts either ``tensor[i]`` or
        ``tensor[(i,)]``.  Static coordinates are bounds-checked; runtime
        coordinates remain caller-managed and receive no implicit guard.

        ``None`` keeps the matching axis or complete nested shape subtree; it
        never inserts a new axis.  Use interval slices such as ``1:4``, ``:4``,
        or ``1:`` for strictly non-empty interval views.  Negative bounds are
        unsupported.  With a static parent extent, non-negative Python literal
        bounds are clipped at compile time; runtime bounds are absolute,
        caller-managed, and introduce no implicit checks or clipping.  The
        caller guarantees ``0 <= start < stop <= parent_extent`` without
        overflow.  A fully open ``:`` is not a keep marker.
        """
        return _tensor_getitem(self, coord)

    def __setitem__(self, coord: _TensorIndex, value: Any) -> None:
        _tensor_setitem(self, coord, value)

    def ptr(self, coord: _TensorIndex):
        """Return a typed scalar pointer to one GM element at ``coord``.

        ``coord`` follows the same complete-tree and static-bounds contract as
        a Tensor point load.

        The pointer is consumed by the DCache-bypass and atomic interfaces in
        ``cannbotdsl.ops.scalar`` (``load_bypass``/``cube_store_bypass``/
        ``vec_store_bypass``/``atomic_*``).
        Creating it accesses no memory.
        """
        from cannbotdsl.ops.scalar import _tensor_ptr

        return _tensor_ptr(self, coord)


# Layout trees, construction, and metadata.


def _is_tuple(x) -> bool:
    return isinstance(x, tuple)


def _product(a):
    """Recursive product of all leaf elements (matches pylayout.product)."""
    if _is_tuple(a):
        return reduce(lambda val, elem: val * _product(elem), a, 1)
    return _int64_result(_index_value(a)) if isinstance(a, ir.Value) else a


def _map_tree_leaves(tree, mapper):
    """Rebuild a nested tuple by applying ``mapper(index, leaf)`` in DFS order."""

    next_index = 0

    def visit(node):
        nonlocal next_index
        if isinstance(node, tuple):
            return tuple(visit(child) for child in node)
        index = next_index
        next_index += 1
        return mapper(index, node)

    return visit(tree)


def _materialize_type_tree(
    static_tree,
    source,
    *,
    materialize_static: bool = False,
    on_extract=None,
):
    """Replace selected type leaves with ``extract_dim`` SSA values."""

    def materialize(index, leaf):
        if not materialize_static and leaf != cannir.ShapeType.DYNAMIC:
            return leaf
        value = _int64_result(cannir.extract_dim(unwrap_operand(source), index=index))
        if on_extract is not None:
            on_extract(value)
        return value

    return _map_tree_leaves(static_tree, materialize)


def _suffix_product(a, init=1):
    """
    Exclusive **suffix** product with output congruent to *a* (row-major strides).

    Same semantics as pylayout.suffix_product.
    """
    if _is_tuple(a):
        if _is_tuple(init):
            assert len(a) == len(init)
            return tuple(_suffix_product(x, i) for x, i in zip(a, init))
        r = [None] * len(a)
        cur = init
        for idx in range(len(a) - 1, -1, -1):
            r[idx] = _suffix_product(a[idx], cur)
            cur = cur * _product(a[idx])
        return tuple(r)
    if _is_tuple(init):
        raise ValueError("scalar shape with tuple init")
    return init


def _infer_contiguous_stride(shape: Shape) -> Stride:
    if isinstance(shape, int):
        if shape == cannir.ShapeType.DYNAMIC:
            raise ValueError("Cannot infer stride for dynamic scalar shape (-1); pass stride=...")
        if shape < 0:
            raise ValueError(f"Invalid scalar shape: {shape}; pass stride=...")
        return 1

    if not isinstance(shape, tuple) or any(isinstance(d, (list, tuple)) for d in shape):
        raise ValueError(f"Cannot infer stride for nested shapes; pass stride=... explicitly (shape={shape!r})")

    if any((not isinstance(d, int)) or d == cannir.ShapeType.DYNAMIC for d in shape):
        raise ValueError(
            f"Cannot infer stride for dynamic/non-integer shapes; pass stride=... explicitly (shape={shape!r})"
        )
    if any(d < 0 for d in shape):
        raise ValueError(f"Invalid shape dimensions: {shape!r}; pass stride=...")

    if len(shape) == 0:
        return ()

    return _suffix_product(shape)  # type: ignore[return-value]


def _encode_integer_tree(
    value,
    *,
    type_class,
):
    """Replace SSA leaves with the public type's dynamic sentinel."""

    dynamic_values = []

    def visit(node):
        if isinstance(node, (list, tuple)):
            return tuple(visit(child) for child in node)
        if isinstance(node, ir.Value):
            dynamic_values.append(_index_value(node, operation=type_class.__name__))
            return type_class.DYNAMIC
        return node

    return visit(value), dynamic_values


def _coord_to_type_and_dynamic_values(val: Coord):
    return _encode_integer_tree(val, type_class=cannir.CoordType)


def _tiler_to_type_and_dynamic_values(tiler: Tiler):
    """Encode a tile tree and collect its dynamic leaves in DFS order."""

    return _encode_integer_tree(tiler, type_class=cannir.TileType)


def _shape_to_type_and_dynamic_values(shape):
    """Encode a shape tree and collect dynamic leaves in DFS order."""

    return _encode_integer_tree(shape, type_class=cannir.ShapeType)


def _stride_to_type_and_dynamic_values(stride):
    """Encode a stride tree and collect dynamic leaves in DFS order."""

    return _encode_integer_tree(stride, type_class=cannir.StrideType)


def _make_shape_value(shape):
    shape_tree, dynamic_values = _shape_to_type_and_dynamic_values(shape)
    shape_type = cannir.ShapeType.get(shape_tree)
    return cannir.make_shape(shape_type, dynamic_values)


def _make_tile_value(tiler):
    tile_tree, dynamic_values = _tiler_to_type_and_dynamic_values(tiler)
    tile_type = cannir.TileType.get(tile_tree)
    return cannir.make_tile(tile_type, dynamic_values)


def _has_dynamic_layout_leaf(tree) -> bool:
    if isinstance(tree, tuple):
        return any(_has_dynamic_layout_leaf(child) for child in tree)
    return tree == cannir.ShapeType.DYNAMIC


def _layout_raw_component(layout: Layout, *, stride: bool):
    """Materialize every layout leaf as SSA while tracing raw VF code."""

    from cannbotdsl.lang.vf import _current_vf_mode, _tag_if_in_vf

    carrier = unwrap_operand(layout)
    owner = carrier.owner
    owner_name = getattr(owner, "name", None)
    if _current_vf_mode() != "raw" or owner_name not in (
        "cannir.extract_layout",
        "cannir.extract_physical_layout",
    ):
        return None
    _tag_if_in_vf(owner)
    component = cannir.extract_stride(carrier) if stride else cannir.extract_shape(carrier)
    _tag_if_in_vf(component.owner)
    layout_type = cannir.LayoutType(carrier.type)
    static_tree = layout_type.stride if stride else layout_type.shape
    return _materialize_type_tree(
        static_tree,
        component,
        materialize_static=True,
        on_extract=lambda value: _tag_if_in_vf(value.owner),
    )


def _layout_shape(layout: Layout) -> Shape:
    raw = _layout_raw_component(layout, stride=False)
    if raw is not None:
        return raw
    carrier = unwrap_operand(layout)
    static_tree = cannir.LayoutType(carrier.type).shape
    if not _has_dynamic_layout_leaf(static_tree):
        return static_tree
    return _materialize_type_tree(static_tree, cannir.extract_shape(carrier))


def _layout_stride(layout: Layout) -> Stride:
    raw = _layout_raw_component(layout, stride=True)
    if raw is not None:
        return raw
    carrier = unwrap_operand(layout)
    static_tree = cannir.LayoutType(carrier.type).stride
    if not _has_dynamic_layout_leaf(static_tree):
        return static_tree
    return _materialize_type_tree(static_tree, cannir.extract_stride(carrier))


def make_layout(
    shape: Shape,
    *,
    stride: Union[Stride, None] = None,
) -> Layout:
    shape_tree, shape_dyn = _shape_to_type_and_dynamic_values(shape)
    if stride is None:
        stride_tree = _infer_contiguous_stride(shape_tree)
        stride_dyn: list = []
    else:
        stride_tree, stride_dyn = _stride_to_type_and_dynamic_values(stride)
    layout_ty = cannir.LayoutType.get(shape_tree, stride_tree)
    shape_val = cannir.make_shape(layout_ty.shape_type, shape_dyn)
    stride_val = cannir.make_stride(layout_ty.stride_type, stride_dyn)
    return cannir.make_layout(layout_ty, shape_val, stride_val)


# Layout operations, coordinates, and tilers.


def _shape_value_to_python(shape_val: ir.Value) -> Shape:
    """Convert a `!cannir.shape<...>` SSA value back to a Python Shape.

    Scalar leaves (rank-0 shape) become a single int; nested shapes preserve
    their tuple structure. Static leaves come from the type tree; dynamic
    leaves (-1 in the tree) materialize as `cannir.extract_dim` SSA values
    indexed in DFS flat order — matching Layout materialization.
    """
    static_tree = shape_val.type.as_tuple
    if not _has_dynamic_layout_leaf(static_tree):
        return static_tree
    return _materialize_type_tree(static_tree, shape_val)


def ceil_div(input: Shape, tiler: Tiler) -> Shape:
    """Element-wise ceiling division of `input` by `tiler`.

    Each leaf result is ``(a + b - 1) // b``. The **trailing** rank(tiler)
    flat leaves of *input* pair with *tiler*; leading prefix leaves pass
    through unchanged. Result preserves *input*'s nesting structure.

    *input* and *tiler* accept:
      - scalar ``int`` / ``ir.Value`` → treated as rank-0 (scalar)
      - nested int-tuple with ``int`` / ``ir.Value`` leaves

    Alignment is defined by the CANNBotDSL trailing-rank contract. The result type
    is fully determined at IR builder time; fully static inputs fold to an
    answer encoded entirely in the result type, with no runtime computation.

    Examples:
      ``ceil_div(10, 3) == 4``
      ``ceil_div((10, 6), (3, 4)) == (4, 2)``
      ``ceil_div((10, 6, 7), (3, 4)) == (10, 2, 2)``
    """
    res = cannir.ceil_div(
        _make_shape_value(input),
        _make_tile_value(tiler),
    )
    return _shape_value_to_python(res)


def _flatten_shape_tuple(shape):
    """Recursively flatten a (possibly nested) shape into leaf values.

    Leaf values are either Python ints or MLIR ir.Value instances.
    """
    if isinstance(shape, (list, tuple)):
        result = []
        for item in shape:
            result.extend(_flatten_shape_tuple(item))
        return result
    return [shape]


def size(
    input: Union[Shape, Layout, Tensor],
    mode: "tuple[int, ...] | list[int]" = (),
) -> Union[int, ir.Value]:
    """Compute the total number of elements in a shape, layout, or tensor.

    When ``mode`` is empty (default), returns the product of all dimensions.
    When ``mode`` is specified, returns the size of the sub-tree at that mode
    path (only supported for ``Layout`` and ``Tensor`` inputs).

    Returns a Python int when all dimensions are static, otherwise an
    MLIR i64 Value.
    """
    if mode:
        if not isinstance(input, (Layout, Tensor)):
            raise TypeError(f"size with mode only supports Layout or Tensor, got {type(input).__name__}")
        shape_tuple = input.shape
        node = shape_tuple
        for idx in mode:
            if not isinstance(node, (list, tuple)):
                raise ValueError(f"mode {mode!r} descends past a scalar at {node!r}")
            if idx < 0 or idx >= len(node):
                raise IndexError(f"mode index {idx} out of range for shape {node!r}")
            node = node[idx]
        sub_shape = node if isinstance(node, (list, tuple)) else (node,)
        return size(sub_shape)

    if isinstance(input, Tensor):
        shape_tuple = input.shape
        flat = _flatten_shape_tuple(shape_tuple)
        if all(isinstance(d, int) and d != cannir.ShapeType.DYNAMIC for d in flat):
            result = 1
            for d in flat:
                result *= d
            return result
        # Dynamic tensor: extract layout, then emit SizeOp
        layout_val = cannir.extract_layout(unwrap_operand(input))
        return _int64_result(cannir.size(unwrap_operand(layout_val)))

    if isinstance(input, Layout):
        shape_tuple = input.shape
        flat = _flatten_shape_tuple(shape_tuple)
        if all(isinstance(d, int) and d != cannir.ShapeType.DYNAMIC for d in flat):
            result = 1
            for d in flat:
                result *= d
            return result
        # Dynamic layout: emit SizeOp
        return _int64_result(cannir.size(unwrap_operand(input)))

    # Shape tuple (may contain ints and/or ir.Value)
    flat = _flatten_shape_tuple(input)
    statics = []
    dynamics = []
    for d in flat:
        if isinstance(d, int):
            if d == cannir.ShapeType.DYNAMIC:
                raise ValueError(
                    "Shape tuple contains -1 (dynamic marker) without an "
                    "associated MLIR value; use an ir.Value for dynamic dims"
                )
            statics.append(d)
        elif isinstance(d, ir.Value):
            dynamics.append(d)
        else:
            raise TypeError(f"Unsupported element in shape tuple: {d!r} (type={type(d).__name__})")

    static_product = 1
    for s in statics:
        static_product *= s

    if not dynamics:
        return static_product

    # Mix of static and dynamic: produce MLIR i64 value
    i64_ty = ir.IntegerType.get_signless(64)
    result = arith.ConstantOp(i64_ty, static_product).result
    for dyn_val in dynamics:
        v = _index_value(dyn_val, operation="size dimension")
        result = arith.muli(result, v)
    return _int64_result(result)


def crd2idx(
    coord: "Coord | tuple",
    layout: "Layout | Tensor",
) -> "int | ir.Value":
    """Convert a coordinate to a linear index under the given layout.

    Returns a Python int when all inputs are static, otherwise an MLIR i64 Value.
    """
    if isinstance(layout, Tensor):
        layout_val = cannir.extract_layout(unwrap_operand(layout))
    elif isinstance(layout, Layout):
        layout_val = layout
    else:
        raise TypeError(f"layout must be a Layout or Tensor, got {type(layout).__name__}")

    # Static fast path: coord is a plain Python nested tuple and stride has no ir.Value leaves
    if not isinstance(coord, ir.Value):
        flat_coord = _flatten_shape_tuple(coord)
        flat_stride = _flatten_shape_tuple(layout_val.stride)
        if (
            all(isinstance(c, int) for c in flat_coord)
            and all(isinstance(d, int) for d in flat_stride)
            and len(flat_coord) == len(flat_stride)
        ):
            return sum(c * d for c, d in zip(flat_coord, flat_stride))

    # Dynamic path: emit Crd2IdxOp
    if not isinstance(coord, ir.Value):
        coord_tree, dynamic_values = _coord_to_type_and_dynamic_values(coord)
        coord_ty = cannir.CoordType.get(coord_tree)
        coord_val = cannir.make_coord(coord_ty, dynamic_values)
    else:
        coord_val = coord

    return _int64_result(cannir.crd2idx(coord_val, unwrap_operand(layout_val)))


def _is_python_static_shape(shape) -> bool:
    """True iff *shape* is a (possibly nested) tree of plain Python ints."""
    if isinstance(shape, int):
        return True
    if isinstance(shape, (list, tuple)):
        return all(_is_python_static_shape(x) for x in shape)
    return False


def _row_major_unravel(idx: int, shape):
    """Pure-Python idx2crd over row-major (suffix-product) strides.

    The CANNBotDSL mixed-radix contract is:
    for flat shape ``(s_0, ..., s_{n-1})`` the leaf-order coordinate is
    ``coord[i] = (idx / prod(s_{i+1..n-1})) % s_i``. Nested shapes flatten
    in tree-leaf order before the formula and re-nest the result back.
    """
    if isinstance(shape, int):
        return idx % shape
    leaves = _flatten_shape_tuple(shape)
    n = len(leaves)
    strides = [1] * n
    for i in range(n - 2, -1, -1):
        strides[i] = strides[i + 1] * leaves[i + 1]
    flat_coord = [(idx // strides[i]) % leaves[i] for i in range(n)]
    it = iter(flat_coord)

    def rebuild(s):
        if isinstance(s, int):
            return next(it)
        return tuple(rebuild(x) for x in s)

    return rebuild(shape)


def idx2crd(
    idx: "int | ir.Value",
    shape: "Shape",
) -> "Coord | _tensor_values._Coord":
    """Unravel a linear index into a coordinate congruent with *shape*.

    Strides are derived internally from *shape* as the row-major suffix
    product (CANNBotDSL convention; equivalent to ``np.unravel_index(order='C')``).
    For nested *shape*, the result is a same-shaped nested coordinate.

    When *idx* is a Python int and *shape* is a Python tree of ints, the
    result is a plain Python (possibly nested) tuple computed at trace
    time — no MLIR op is emitted. Otherwise an MLIR CoordType SSA value
    is returned.

    Examples:
      ``idx2crd(11, (5, 4)) == (2, 3)``
      ``idx2crd(11, ((2, 3), 4)) == ((0, 2), 3)``
    """
    if isinstance(idx, int) and _is_python_static_shape(shape):
        return _row_major_unravel(idx, shape)

    shape_tree, shape_dyn = _shape_to_type_and_dynamic_values(shape)
    shape_ty = cannir.ShapeType.get(shape_tree)
    shape_val = cannir.make_shape(shape_ty, shape_dyn)

    idx_val = _index_value(idx, operation="idx2crd index")

    return cannir.idx2crd(idx_val, shape_val)


def _normalize_part_id(part_id):
    """Coerce a Python int or integer/index SSA value into i64."""
    return _index_value(part_id, operation="part_id")


def _make_partition_tiler(
    actual_shape: Shape,
    full_shape: tuple[int, int],
    *,
    axis: int = 0,
    parts: int = 2,
    alignment: int = 1,
    policy: str = "balanced",
) -> PartitionTiler:
    """Create the private runtime split plan used by ``mem_copy``."""
    if policy != "balanced":
        raise ValueError(f"only policy='balanced' is supported, got {policy!r}")
    if not isinstance(full_shape, (tuple, list)) or len(full_shape) != 2:
        raise ValueError("full_shape must be a rank-2 tuple/list")
    if any(not isinstance(dim, int) or isinstance(dim, bool) or dim <= 0 for dim in full_shape):
        raise ValueError(f"full_shape dimensions must be positive integers, got {full_shape!r}")
    if axis not in (0, 1):
        raise ValueError(f"only axis=0 or axis=1 is supported, got {axis}")
    if parts != 2:
        raise ValueError(f"only parts=2 is supported, got {parts}")
    if not isinstance(alignment, int) or isinstance(alignment, bool) or alignment <= 0:
        raise ValueError(f"alignment must be a positive integer, got {alignment!r}")
    if axis == 1 and alignment != 1:
        raise ValueError(f"axis=1 requires alignment=1; hardware N alignment is modeled separately, got {alignment}")

    shape_tree, shape_dynamic = _shape_to_type_and_dynamic_values(actual_shape)
    shape_type = cannir.ShapeType.get(shape_tree)
    shape_value = cannir.make_shape(shape_type, shape_dynamic)
    partition_type = cannir.PartitionTilerType.get(list(full_shape), axis=axis, parts=parts, alignment=alignment)
    return cannir.make_partition_tiler(partition_type, shape_value)


def _flatten_shape_tree(tree):
    flat = []

    def visit(node):
        if isinstance(node, tuple):
            for child in node:
                visit(child)
            return
        flat.append(node)

    visit(tree)
    return flat


def _static_declared_shape(raw) -> tuple[int, int]:
    """Return the static rank-2 declared shape of a tensor/channel carrier."""
    ty = raw.type
    if isinstance(ty, cannir.ChannelType):
        ty = ty.element
    tensor_ty = cannir.TensorType(ty)
    shape_tree = tensor_ty.layout.shape
    if not isinstance(shape_tree, tuple):
        shape_tree = (shape_tree,)
    flat = _flatten_shape_tree(shape_tree)
    if len(flat) != 2 or any(
        not isinstance(dim, int) or isinstance(dim, bool) or dim <= 0
        for dim in flat
    ):
        raise ValueError(
            "copy split requires a statically-shaped full side: the operand's "
            "declared shape must be static rank-2; route the copy through a "
            "static tile_slice or slice a statically declared buffer"
        )
    return tuple(flat)


def _static_full_shape_raw(raw) -> tuple[int, int]:
    definition = getattr(raw, "owner", None)
    if definition is not None and not hasattr(definition, "name"):
        definition = None

    if definition is not None and definition.name == "cannir.tile_slice":
        parent = unwrap_operand(definition.operands[0])
        ty = parent.type
        if isinstance(ty, cannir.ChannelType):
            ty = ty.element
        parent_is_gm = (
            cannir.PointerType(cannir.TensorType(ty).pointer).memloc == MemLoc.GM
        )
        if not parent_is_gm:
            return _static_full_shape_raw(parent)
        tile = definition.operands[1]
        if isinstance(tile, ir.Value) and isinstance(tile.type, cannir.TileType):
            nominal = _flatten_shape_tree(tile.type.as_tuple)
            if len(nominal) == 2 and all(
                isinstance(dim, int) and not isinstance(dim, bool) and dim > 0
                for dim in nominal
            ):
                return tuple(nominal)
            return _static_full_shape_raw(parent)
    if definition is not None and definition.name == "cannir.reinterpret_view":
        # A typed view declares its own element geometry. The source's
        # capacity is measured in a different dtype and cannot be reused.
        parent_type = unwrap_operand(definition.operands[0]).type
        result_type = raw.type
        if isinstance(parent_type, cannir.ChannelType):
            parent_type = parent_type.element
        if isinstance(result_type, cannir.ChannelType):
            result_type = result_type.element
        if (cannir.TensorType(parent_type).pointer.dtype
                != cannir.TensorType(result_type).pointer.dtype):
            return _static_declared_shape(raw)
    if definition is not None and definition.name in (
        "cannir.local_slice", "cannir.reinterpret_view",
    ):
        root_shape = _static_full_shape_raw(unwrap_operand(definition.operands[0]))
        tile = definition.operands[1]
        window = None
        if isinstance(tile, ir.Value) and isinstance(tile.type, cannir.TileType):
            window = _flatten_shape_tree(tile.type.as_tuple)
        full = []
        for index, root_dim in enumerate(root_shape):
            leaf = window[index] if window and index < len(window) else None
            if isinstance(leaf, int) and not isinstance(leaf, bool) and leaf > 0:
                full.append(leaf)
            else:
                full.append(root_dim)
        return tuple(full)
    return _static_declared_shape(raw)


def _static_full_shape(value) -> tuple[int, int]:
    """Recover the statically declared rank-2 capacity for a two-part copy."""
    return _static_full_shape_raw(unwrap_operand(value))


def _tile_alignment_list(alignment, leaf_count: int):
    """Normalize a user alignment argument to a flat positive-int list."""
    if isinstance(alignment, bool) or not isinstance(
        alignment, (int, tuple, list)
    ):
        raise TypeError(
            f"alignment must be an int or a sequence of ints, got {type(alignment).__name__}"
        )
    flat = [alignment] if isinstance(alignment, int) else list(alignment)
    for index, entry in enumerate(flat):
        if isinstance(entry, bool) or not isinstance(entry, int):
            raise TypeError(
                f"alignment leaf {index} must be an int, got {type(entry).__name__}"
            )
        if entry <= 0:
            raise ValueError(
                f"alignment leaf {index} must be positive, got {entry}"
            )
    if len(flat) == 1 and leaf_count > 1:
        flat = flat * leaf_count
    if len(flat) != leaf_count:
        raise ValueError(
            f"alignment rank ({len(flat)}) must match the flattened tile leaf count ({leaf_count})"
        )
    return flat


def _count_tree_leaves(tree) -> int:
    if isinstance(tree, (tuple, list)):
        return sum(_count_tree_leaves(child) for child in tree)
    return 1


def make_tiler(tiler: Tiler, *, alignment=None):
    """Create a reusable tile value, optionally declaring leaf alignment."""
    tile_tree, dynamic_values = _tiler_to_type_and_dynamic_values(tiler)
    if alignment is None:
        tile_type = cannir.TileType.get(tile_tree)
    else:
        flat_alignment = _tile_alignment_list(
            alignment, _count_tree_leaves(tile_tree)
        )
        tile_type = cannir.TileType.get(tile_tree, alignment=flat_alignment)
    return cannir.make_tile(tile_type, dynamic_values)


# Tensor construction, metadata, indexing, and SSBUF access.


_MEMLOC_DEFAULT_PHYSICAL_FORMAT = {
    MemLoc.GM: "nd",
    MemLoc.UB: "nd",
    MemLoc.L1: "nz",
    MemLoc.L0A: "nz",
    MemLoc.L0B: "nz",
    MemLoc.L0C: "nz",
    MemLoc.SSBUF: "nd",
}


def _layout_map_kind_for(logical_format: str, physical_format: str) -> LayoutMapKind:
    if logical_format == physical_format:
        return LayoutMapKind.Identity
    if logical_format == "nd" and physical_format == "nz":
        return LayoutMapKind.ND2NZ
    if logical_format == "nd" and physical_format == "zn":
        return LayoutMapKind.DN2NZ
    if logical_format == "nz" and physical_format == "nd":
        return LayoutMapKind.NZ2ND
    if logical_format == "zn" and physical_format == "nd":
        return LayoutMapKind.ZN2ND
    raise ValueError(f"Unsupported logical/physical format mapping: {logical_format!r} -> {physical_format!r}")


def _logical_format_for_map(layout_map_kind: LayoutMapKind) -> str:
    if layout_map_kind == LayoutMapKind.NZ2ND:
        return "nz"
    if layout_map_kind == LayoutMapKind.ZN2ND:
        return "zn"
    return "nd"


def _physical_format_for_map(layout_map_kind: LayoutMapKind) -> str:
    if layout_map_kind == LayoutMapKind.ND2NZ:
        return "nz"
    if layout_map_kind == LayoutMapKind.DN2NZ:
        return "zn"
    return "nd"


def _normalize_layout_map_kind(layout_map_kind: LayoutMapKind | str | int) -> LayoutMapKind:
    if isinstance(layout_map_kind, LayoutMapKind):
        return layout_map_kind
    if isinstance(layout_map_kind, str):
        normalized = layout_map_kind.replace("-", "_").upper()
        name_map = {
            "IDENTITY": LayoutMapKind.Identity,
            "ND2NZ": LayoutMapKind.ND2NZ,
            "DN2NZ": LayoutMapKind.DN2NZ,
            "NZ2ND": LayoutMapKind.NZ2ND,
            "ZN2ND": LayoutMapKind.ZN2ND,
        }
        return name_map[normalized]
    return LayoutMapKind(layout_map_kind)


def _mapped_physical_layout(
    dtype, logical_shape, physical_format, n1_pad, *, mem_loc=MemLoc.L1
):
    """Call the canonical C++ physical-layout implementation."""
    if mem_loc is None:
        mem_loc = MemLoc.L1
    from cannbotdsl.core.contracts.elements import storage_mlir_type_for_dtype
    from cannbotdsl.core.mlir_context import _has_current_context

    def derive():
        layout_map_kind = {"nz": 1, "zn": 2}[physical_format]
        logical_layout = cannir.LayoutType.get(
            logical_shape, _suffix_product(tuple(logical_shape))
        )
        pointer = cannir.PointerType.get(
            int(mem_loc), storage_mlir_type_for_dtype(dtype)
        )
        physical_layout = cannir.derive_physical_layout(
            pointer, logical_layout, layout_map_kind, n1_pad
        )
        return tuple(physical_layout.shape), tuple(physical_layout.stride)

    if _has_current_context():
        return derive()
    with ir.Context():
        return derive()


def _physical_layout_spec(
    dtype, logical_shape, physical_format, n1_pad, *, mem_loc=None
):
    """Return ``(physical_shape, physical_stride)`` for on-chip storage."""
    if mem_loc == MemLoc.SSBUF:
        if physical_format != "nd":
            raise ValueError("SSBUF buffers require data_format='nd'")
        if n1_pad:
            raise ValueError("n1_pad is not supported for SSBUF buffers")
        return logical_shape, None

    if mem_loc == MemLoc.BIAS:
        if physical_format != "nd" or len(logical_shape) != 1:
            raise ValueError("BIAS buffers require rank-1 data_format='nd'")
        if dtype.width != 32:
            raise ValueError("BIAS buffers require float32 or int32 elements")
        if n1_pad:
            raise ValueError("n1_pad is not supported for BIAS buffers")
        n = logical_shape[0]
        if not isinstance(n, int) or n <= 0:
            raise ValueError("BIAS buffers require a positive static N")
        # L1 -> BT writes float32/int32 data in 64-byte units.
        return (math.ceil(n / 16) * 16,), None

    if physical_format == "nz" and len(logical_shape) in (2, 3):
        return _mapped_physical_layout(
            dtype, logical_shape, physical_format, n1_pad, mem_loc=mem_loc
        )
    if physical_format == "zn" and len(logical_shape) in (2, 3):
        if n1_pad:
            raise ValueError("n1_pad only meaningful for data_format='nz'")
        return _mapped_physical_layout(
            dtype, logical_shape, physical_format, n1_pad, mem_loc=mem_loc
        )
    if n1_pad:
        raise ValueError("n1_pad only meaningful for data_format='nz'")
    return logical_shape, None


def _tensor_type_from_layouts(
    dtype,
    mem_loc: MemLoc,
    logical_layout: Layout,
    physical_layout: Layout,
    *,
    data_format: str,
):
    """Build a Tensor type from logical and physical layouts for storage or a view."""
    from cannbotdsl.core.contracts.elements import storage_mlir_type_for_dtype

    pointer_type = cannir.PointerType.get(mem_loc, storage_mlir_type_for_dtype(dtype))
    logical_layout_value = unwrap_operand(logical_layout)
    physical_layout_value = unwrap_operand(physical_layout)
    layout_map_kind = _layout_map_kind_for("nd", data_format)
    return cannir.TensorType.get(
        pointer_type,
        logical_layout_value.type,
        physical_layout_value.type,
        int(layout_map_kind),
    )


def make_pointer(dtype: Any, addr: Union[int, ir.Value], mem_loc: MemLoc) -> _tensor_values._Pointer:
    """Create a typed pointer from a byte address.

    The address is always an absolute byte address in ``mem_loc``. A Python
    ``int`` supplies a non-negative compile-time-known address. A canonical
    signless ``i64`` SSA value supplies a runtime address and is accepted only
    for ``MemLoc.GM``; it is not an element index or an offset relative to any
    Tensor argument. Use ``dtypes.int64(value)`` or ``dtypes.uint64(value)``
    for an explicit frontend conversion.
    """
    from cannbotdsl.core.contracts.elements import storage_mlir_type_for_dtype

    dtype_ty = storage_mlir_type_for_dtype(dtype)
    pointer_ty = cannir.PointerType.get(mem_loc, dtype_ty)
    if isinstance(addr, ir.Value):
        if mem_loc != MemLoc.GM:
            raise ValueError(
                "make_pointer SSA addresses are supported only for "
                "MemLoc.GM; non-GM backend binding requires a Python int"
            )
        addr_type = addr.type
        if not (isinstance(addr_type, ir.IntegerType) and addr_type.width == 64 and addr_type.is_signless):
            raise TypeError(
                "make_pointer GM SSA addr must have canonical signless i64 "
                f"type, got {addr_type}; convert explicitly with "
                "dtypes.int64(value) or dtypes.uint64(value)"
            )
        return cannir.make_pointer(pointer_ty, addr)
    else:
        if type(addr) is not int:
            raise TypeError(
                "make_pointer addr must be a non-negative Python int or a "
                "canonical signless i64 SSA value, got "
                f"{type(addr).__name__}; convert SSA values explicitly with "
                "dtypes.int64(value) or dtypes.uint64(value)"
            )
        if addr < 0:
            raise ValueError(f"make_pointer Python int addr must be non-negative, got {addr}")
        if addr > (1 << 63) - 1:
            raise ValueError(f"make_pointer Python int addr must not exceed INT64_MAX, got {addr}")
        addr_ty = ir.IntegerType.get_signless(64)
        addr_value = arith.ConstantOp(addr_ty, ir.IntegerAttr.get(addr_ty, addr)).result
    return cannir.make_pointer(pointer_ty, addr_value)


def make_tensor(
    pointer: _tensor_values._Pointer,
    layout: Layout,
    *,
    physical_layout: Layout | None = None,
    data_format: str | None = None,
    layout_map_kind: LayoutMapKind | str | int | None = None,
    storage_size_bytes: int | None = None,
) -> Tensor:
    physical_format = data_format
    if layout_map_kind is not None:
        layout_map_kind = _normalize_layout_map_kind(layout_map_kind)

    if physical_format is None:
        physical_format = (
            _physical_format_for_map(layout_map_kind)
            if layout_map_kind is not None
            else _MEMLOC_DEFAULT_PHYSICAL_FORMAT.get(MemLoc(pointer.memloc), "nd")
        )
    if layout_map_kind is None:
        layout_map_kind = _layout_map_kind_for("nd", physical_format)

    logical_layout_type = unwrap_operand(layout).type
    if physical_layout is None:
        physical_layout_type = cannir.derive_physical_layout(
            pointer.type,
            logical_layout_type,
            int(layout_map_kind),
        )
    else:
        physical_layout_type = unwrap_operand(physical_layout).type

    memref_type = cannir.TensorType.get(
        pointer.type,
        logical_layout_type,
        physical_layout_type,
        int(layout_map_kind),
    )
    result = cannir.make_memref(memref_type, pointer, unwrap_operand(layout))
    if storage_size_bytes is not None:
        if type(storage_size_bytes) is not int or storage_size_bytes <= 0:
            raise ValueError("storage_size_bytes must be a positive Python int")
        unwrap_operand(result).owner.attributes["storage_size_bytes"] = ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), storage_size_bytes
        )
    return result


def _tensor_memref_type(tensor: Tensor):
    ty = unwrap_operand(tensor).type
    if cannir.ChannelType.isinstance(ty):
        ty = cannir.ChannelType(ty).element
    return cannir.TensorType(ty)


def _tensor_pointer_type(tensor: Tensor):
    return cannir.PointerType(_tensor_memref_type(tensor).pointer)


def _tensor_layout(tensor: Tensor) -> Layout:
    # Keep dynamic leaves tied to the tensor SSA value so layout inference can
    # refine them after Python tracing.
    return cannir.extract_layout(unwrap_operand(tensor))


def _tensor_physical_layout(tensor: Tensor) -> Layout:
    return cannir.extract_physical_layout(unwrap_operand(tensor))


def _tensor_shape(tensor: Tensor) -> Shape:
    return _tensor_layout(tensor).shape


def _tensor_stride(tensor: Tensor) -> Stride:
    return _tensor_layout(tensor).stride


def _tensor_dtype(tensor: Tensor):
    from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type

    return dtype_for_storage_mlir_type(_tensor_pointer_type(tensor).dtype)


def _tensor_storage_type(tensor: Tensor):
    return _tensor_pointer_type(tensor).dtype


def _tensor_memloc(tensor: Tensor) -> MemLoc:
    return MemLoc(_tensor_pointer_type(tensor).memloc)


def _tensor_layout_map_kind(tensor: Tensor):
    try:
        return LayoutMapKind(_tensor_memref_type(tensor).layout_map_kind)
    except Exception:
        return LayoutMapKind.Identity


def _tensor_logical_format(tensor: Tensor) -> str:
    return _logical_format_for_map(_tensor_layout_map_kind(tensor))


def _tensor_physical_format(tensor: Tensor) -> str:
    return _physical_format_for_map(_tensor_layout_map_kind(tensor))


_I64_MIN = -(1 << 63)
_I64_MAX = (1 << 63) - 1

_TENSOR_VIEW_MEMLOCS = frozenset(
    (
        MemLoc.GM,
        MemLoc.UB,
        MemLoc.L1,
        MemLoc.L0A,
        MemLoc.L0B,
        MemLoc.L0C,
        MemLoc.SSBUF,
    )
)


def _validate_tensor_index_integer_type(value, where: str, *, bound: bool) -> None:
    """Validate only the Python/SSA type of one Tensor integer leaf."""

    noun = "slice bound" if bound else "integer coordinate"
    if isinstance(value, bool):
        raise TypeError(f"{where}: {noun} must not be bool")
    if type(value) is int:
        return
    _validate_index_value(value, operation=f"{where}: {noun}")


def _validate_tensor_index_integer(value, where: str, *, bound: bool) -> None:
    """Validate one route-selected Tensor integer leaf."""

    _validate_tensor_index_integer_type(value, where, bound=bound)
    if type(value) is not int:
        return
    if value < _I64_MIN or value > _I64_MAX:
        raise ValueError(f"{where}: integer {_render_literal(value)} is outside the signed i64 range")
    if value < 0:
        noun = "slice bounds" if bound else "integer Tensor coordinates"
        raise NotImplementedError(f"{where}: negative {noun} are not supported")


class _TensorIndexIntent(_IntEnum):
    """Semantic route selected for one complete Tensor index tree."""

    POINT = 0
    KEEP = 1
    INTERVAL = 2


def _classify_tensor_index_intent(index, *, api_name: str) -> _TensorIndexIntent:
    """Classify and syntax-check a Tensor index in one DFS traversal.

    Tuple children are visited left-to-right so a compound invalid key reports
    its first invalid node. A list or Ellipsis is rejected at the node itself
    without inspecting any value it contains. For valid trees, interval intent
    dominates keep intent, which in turn dominates point intent.
    """

    def visit(node, where: str) -> _TensorIndexIntent:
        if isinstance(node, list):
            raise TypeError(f"{where}: Tensor list/fancy indexing is not supported; use a tuple")
        if node is Ellipsis:
            raise TypeError(
                f"{where}: Tensor ellipsis indexing is not supported; explicitly cover the complete shape tree"
            )
        if isinstance(node, tuple):
            intent = _TensorIndexIntent.POINT
            for child_index, child in enumerate(node):
                child_intent = visit(child, f"{where}[{child_index}]")
                if child_intent > intent:
                    intent = child_intent
            return intent
        if node is None:
            return _TensorIndexIntent.KEEP
        if isinstance(node, slice):
            if node.step is not None:
                raise NotImplementedError(f"{where}: Tensor slice steps are not supported; omit slice.step")
            if node.start is None and node.stop is None:
                raise TypeError(
                    f"{where}: fully open Tensor slice ':' is not supported; use None to keep an axis or shape subtree"
                )
            for name, bound in (("start", node.start), ("stop", node.stop)):
                if bound is not None:
                    _validate_tensor_index_integer_type(bound, f"{where}.{name}", bound=True)
            return _TensorIndexIntent.INTERVAL

        # Classification owns accepted leaf types only. Value range, sign,
        # tree congruence, and bounds are checked after the route is known.
        _validate_tensor_index_integer_type(node, where, bound=False)
        return _TensorIndexIntent.POINT

    return visit(index, f"{api_name} key")


def _validate_static_fixed_coord(shape, coord, *, where: str) -> None:
    """Validate one fixed coordinate leaf against one logical shape leaf."""

    _validate_tensor_index_integer(coord, where, bound=False)
    if isinstance(coord, ir.Value) and shape != cannir.ShapeType.DYNAMIC and shape == 0:
        raise IndexError(f"{where}: dynamic coordinate is outside [0, 0)")
    if type(coord) is int and shape != cannir.ShapeType.DYNAMIC and coord >= shape:
        raise IndexError(f"{where}: coordinate {coord} is outside [0, {shape})")


def _make_point_coord(
    tensor: Tensor,
    index,
    *,
    api_name: str,
    intent: Optional[_TensorIndexIntent] = None,
):
    """Validate and encode a complete Tensor point coordinate.

    A scalar coordinate is accepted for a root one-dimensional shape only.
    Every other coordinate must be recursively congruent with the logical
    shape tree. Runtime coordinates and dynamic extents remain caller-managed.
    """

    if intent is None:
        intent = _classify_tensor_index_intent(index, api_name=api_name)
    if intent is not _TensorIndexIntent.POINT:
        raise TypeError(
            f"{api_name} requires one integer coordinate per axis/logical "
            "shape leaf; slice and None coordinates are not supported"
        )

    static_shape = _logical_shape_type_tree(tensor)
    validation_shape = static_shape
    if (
        isinstance(static_shape, tuple)
        and len(static_shape) == 1
        and not isinstance(static_shape[0], tuple)
        and not isinstance(index, tuple)
    ):
        # Preserve the sole compatibility shorthand: shape ``(N,)`` accepts
        # both ``x[i]`` and the exact-tree spelling ``x[(i,)]``. Do not peel a
        # nested single-leaf subtree.
        validation_shape = static_shape[0]
    dynamic_values = []

    def normalize(shape, coordinate, *, where: str):
        if isinstance(coordinate, tuple) and not coordinate:
            raise TypeError(f"{where}: empty tuple is not a Tensor point index")
        if isinstance(shape, tuple):
            if not isinstance(coordinate, tuple):
                raise TypeError(f"{where}: point index tree must match shape subtree {shape!r} exactly")
            if len(coordinate) != len(shape):
                raise ValueError(
                    f"{where}: point index tree has {len(coordinate)} children but shape subtree has {len(shape)}"
                )
            return tuple(
                normalize(
                    subshape,
                    child,
                    where=f"{where}[{child_index}]",
                )
                for child_index, (subshape, child) in enumerate(zip(shape, coordinate))
            )

        if isinstance(coordinate, tuple):
            raise TypeError(f"{where}: tuple point index cannot match scalar shape leaf {shape!r}")
        _validate_static_fixed_coord(shape, coordinate, where=where)
        if isinstance(coordinate, ir.Value):
            dynamic_values.append(_index_value(coordinate, operation=where))
            return cannir.CoordType.DYNAMIC
        return coordinate

    coord_tree = normalize(validation_shape, index, where=f"{api_name} coordinate")
    return cannir.make_coord(cannir.CoordType.get(coord_tree), dynamic_values)


def _validate_keep_index_tree(shape, index, where: str = "key") -> None:
    """Validate a legacy keep view without interpreting slices."""

    if index is None:
        return
    if isinstance(shape, tuple):
        if isinstance(index, slice):
            raise TypeError(f"{where}: Tensor slices are not valid in a keep-only view")
        if not isinstance(index, tuple):
            raise TypeError(f"{where}: keep index tree must match shape subtree {shape!r} exactly")
        if len(index) != len(shape):
            raise ValueError(f"{where}: keep index tree has {len(index)} children but shape subtree has {len(shape)}")
        for child_index, (subshape, child) in enumerate(zip(shape, index)):
            _validate_keep_index_tree(subshape, child, f"{where}[{child_index}]")
        return

    if isinstance(index, tuple):
        raise TypeError(f"{where}: tuple index cannot match scalar shape leaf {shape!r}")
    if isinstance(index, slice):
        raise TypeError(f"{where}: Tensor slices are not valid in a keep-only view")
    _validate_static_fixed_coord(shape, index, where=where)


def _validate_interval_index_tree(shape, index, where: str = "key") -> None:
    # None preserves every leaf in this exact shape subtree. Tuples otherwise
    # have to mirror the complete shape tree.
    if index is None:
        return
    if isinstance(shape, tuple):
        if isinstance(index, slice):
            raise TypeError(
                f"{where}: a non-trivial Tensor slice may only index a shape leaf; "
                "use None to preserve a complete subtree"
            )
        if not isinstance(index, tuple):
            raise TypeError(f"{where}: index tree must match shape subtree {shape!r} exactly")
        if len(index) != len(shape):
            raise ValueError(f"{where}: index tree has {len(index)} children but shape subtree has {len(shape)}")
        for child_index, (subshape, child) in enumerate(zip(shape, index)):
            _validate_interval_index_tree(subshape, child, f"{where}[{child_index}]")
        return

    if isinstance(index, tuple):
        raise TypeError(f"{where}: tuple index cannot match scalar shape leaf {shape!r}")
    if isinstance(index, slice):
        if index.start is not None:
            _validate_tensor_index_integer(index.start, f"{where}.start", bound=True)
        if index.stop is not None:
            _validate_tensor_index_integer(index.stop, f"{where}.stop", bound=True)
        return
    _validate_static_fixed_coord(shape, index, where=where)


def _logical_shape_type_tree(tensor: Tensor):
    memref_type = _tensor_memref_type(tensor)
    return cannir.LayoutType(memref_type.logical_layout).shape


def _materialize_logical_shape_tree(tensor: Tensor, static_shape):
    if not _has_dynamic_layout_leaf(static_shape):
        return static_shape
    carrier = unwrap_operand(tensor)
    layout = cannir.extract_layout(carrier)
    return _materialize_type_tree(
        static_shape,
        cannir.extract_shape(unwrap_operand(layout)),
    )


class _SliceNormalizer:
    """Build strict interval starts and trusted-positive extents.

    Only non-negative Python literals are clipped, and only when the parent
    extent is static.  SSA values are absolute caller-managed coordinates and
    never cause runtime clipping or checking IR to be emitted.
    """

    def __init__(self) -> None:
        self.i64_type = ir.IntegerType.get_signless(64)

    def as_i64(self, value):
        return _index_value(value, operation="slice bound")

    def normalize(self, bound, extent):
        if type(bound) is int:
            if bound < 0:
                raise NotImplementedError("negative Tensor slice bounds are not supported")
            return min(bound, extent) if type(extent) is int else bound
        return bound

    @staticmethod
    def _known(value):
        return _constant_i64(value)

    @staticmethod
    def _raise_non_empty(start, stop):
        raise ValueError(f"Tensor interval must be strictly non-empty, got [{start}:{stop}]")

    def interval(self, interval: slice, extent):
        start = 0 if interval.start is None else self.normalize(interval.start, extent)
        stop = extent if interval.stop is None else self.normalize(interval.stop, extent)

        known_start = self._known(start)
        known_stop = self._known(stop)
        if known_start is not None and known_start < 0:
            raise NotImplementedError("negative Tensor slice start is not supported")
        if known_stop is not None and known_stop < 0:
            raise NotImplementedError("negative Tensor slice stop is not supported")

        if type(extent) is int:
            if extent == 0:
                raise ValueError("Tensor interval cannot slice a zero extent")
            # Python literals have already been clipped above.  Constant SSA
            # bounds remain absolute and are diagnosed rather than acquiring
            # Python-literal clipping semantics.
            if known_start is not None and known_start > extent:
                raise ValueError(f"Tensor interval start {known_start} exceeds parent extent {extent}")
            if known_stop is not None and known_stop > extent:
                raise ValueError(f"Tensor interval stop {known_stop} exceeds parent extent {extent}")

        if known_start is not None and known_stop is not None:
            if known_start >= known_stop:
                self._raise_non_empty(known_start, known_stop)
        else:
            if type(extent) is int and known_start == extent:
                raise ValueError("Tensor interval with start equal to the parent extent cannot have a dynamic stop")
            if known_stop == 0:
                raise ValueError("Tensor interval with stop zero cannot have a dynamic start")

        # The same SSA value at both ends is statically an empty interval even
        # when it is not an arith.constant.  Avoid overloaded Value equality,
        # which would itself materialize a comparison operation.
        if known_start is None and known_stop is None and start is stop:
            self._raise_non_empty("dynamic", "dynamic")

        if type(start) is int and type(stop) is int:
            return start, stop - start

        if interval.start is None:
            dynamic_size = self.as_i64(stop)
        else:
            start_value = self.as_i64(start)
            stop_value = self.as_i64(stop)
            dynamic_size = arith.subi(stop_value, start_value)
        return start, cannir.assume_positive(dynamic_size)

    def coordinate(self, value):
        if isinstance(value, ir.Value):
            return _index_value(value, operation="slice coordinate")
        return value


def _fill_index_subtree(shape, coord_leaf, size_leaf):
    if isinstance(shape, tuple):
        children = [_fill_index_subtree(child, coord_leaf, size_leaf) for child in shape]
        return (
            tuple(child_coord for child_coord, _ in children),
            tuple(child_size for _, child_size in children),
        )
    return coord_leaf, size_leaf


def _build_interval_index_trees(shape, index, normalizer: _SliceNormalizer):
    if index is None:
        return _fill_index_subtree(shape, None, 1)
    if isinstance(shape, tuple):
        # Validation requires an exact tuple here. A slice never broadcasts
        # across a shape subtree; only None may preserve a complete subtree.
        children = [_build_interval_index_trees(subshape, child, normalizer) for subshape, child in zip(shape, index)]
        return (
            tuple(child_coord for child_coord, _ in children),
            tuple(child_size for _, child_size in children),
        )
    if isinstance(index, slice):
        return normalizer.interval(index, shape)
    return normalizer.coordinate(index), 1


def _tensor_interval_slice(tensor: Tensor, index):
    static_shape = _logical_shape_type_tree(tensor)
    _validate_interval_index_tree(static_shape, index)
    layout_map_kind = _tensor_layout_map_kind(tensor)
    if layout_map_kind != LayoutMapKind.Identity:
        raise NotImplementedError(
            f"Tensor range slicing currently supports only Identity/ND layouts; got {layout_map_kind.name}"
        )

    shape = _materialize_logical_shape_tree(tensor, static_shape)
    coord, sizes = _build_interval_index_trees(shape, index, _SliceNormalizer())
    coord_tree, coord_dynamic = _coord_to_type_and_dynamic_values(coord)
    sizes_tree, sizes_dynamic = _shape_to_type_and_dynamic_values(sizes)
    coord_value = cannir.make_coord(cannir.CoordType.get(coord_tree), coord_dynamic)
    sizes_value = cannir.make_shape(cannir.ShapeType.get(sizes_tree), sizes_dynamic)
    return cannir.memref_slice(unwrap_operand(tensor), coord_value, sizes=sizes_value)


def _tensor_getitem(tensor: Tensor, coord):
    intent = _classify_tensor_index_intent(coord, api_name="Tensor.__getitem__")
    if _tensor_memloc(tensor) == MemLoc.SSBUF:
        raise TypeError("SSBUF access requires an execution-core view; use ssbuf.vec[index] or ssbuf.cube[index]")
    if intent is _TensorIndexIntent.INTERVAL:
        return _tensor_interval_slice(tensor, coord)

    carrier = unwrap_operand(tensor)
    if intent is _TensorIndexIntent.KEEP:
        _validate_keep_index_tree(_logical_shape_type_tree(tensor), coord)
        coord_tree, coord_dyn = _coord_to_type_and_dynamic_values(coord)
        coord_value = cannir.make_coord(cannir.CoordType.get(coord_tree), coord_dyn)
        return cannir.memref_slice(carrier, coord_value)
    coord_value = _make_point_coord(tensor, coord, api_name="Tensor load", intent=intent)
    from cannbotdsl.core.contracts.elements import wrap_produced_scalar

    value = cannir.memref_load(carrier, coord_value)
    return wrap_produced_scalar(value, storage_type=_tensor_storage_type(tensor))


def _tensor_setitem(tensor: Tensor, coord, value) -> None:
    intent = _classify_tensor_index_intent(coord, api_name="Tensor.__setitem__")
    if intent is not _TensorIndexIntent.POINT:
        raise TypeError(
            "Tensor point assignment requires one integer coordinate per axis; "
            "slice and None coordinates are not supported"
        )
    if _tensor_memloc(tensor) == MemLoc.SSBUF:
        raise TypeError("SSBUF access requires an execution-core view; use ssbuf.vec[index] or ssbuf.cube[index]")
    memloc = _tensor_memloc(tensor)
    if memloc != MemLoc.GM:
        from cannbotdsl.lang.vf import _current_vf_mode

        if _current_vf_mode() != "simt" or memloc != MemLoc.UB:
            raise NotImplementedError(
                "Tensor point assignment currently supports only GM tensors outside SIMT VF; "
                "UB tensors are supported inside SIMT VF"
            )

    coord_value = _make_point_coord(
        tensor,
        coord,
        api_name="Tensor point assignment",
        intent=intent,
    )

    from cannbotdsl.core.contracts.elements import coerce_scalar_to_storage

    storage_type = _tensor_storage_type(tensor)
    storage_value = coerce_scalar_to_storage(value, storage_type, path="Tensor point assignment value")
    cannir.memref_store(storage_value, unwrap_operand(tensor), coord_value)


class _SSBufCoreView:
    """Core-affine point-access proxy over an SSBUF Tensor."""

    __slots__ = ("_tensor", "_core")

    def __init__(self, tensor: Tensor, core: str):
        self._tensor = tensor
        self._core = core

    def __getitem__(self, coord):
        return _ssbuf_tensor_getitem(self._tensor, coord, core=self._core)

    def __setitem__(self, coord, value) -> None:
        _ssbuf_tensor_setitem(self._tensor, coord, value, core=self._core)

    @property
    def tensor(self):
        return self._tensor

    @property
    def core(self):
        return self._core

    @property
    def shape(self):
        return self._tensor.shape

    @property
    def stride(self):
        return self._tensor.stride

    @property
    def dtype(self):
        return self._tensor.dtype

    @property
    def memloc(self):
        return self._tensor.memloc

    @property
    def rank(self):
        return self._tensor.rank


def _tensor_ssbuf_core_view(tensor: Tensor, core: str):
    if _tensor_memloc(tensor) != MemLoc.SSBUF:
        raise AttributeError(f"Tensor.{core} is available only for MemLoc.SSBUF")
    return _SSBufCoreView(tensor, core)


def _ssbuf_point_coord(tensor: Tensor, coord, *, api_name: str):
    intent = _classify_tensor_index_intent(coord, api_name=api_name)
    if _tensor_memloc(tensor) != MemLoc.SSBUF:
        raise TypeError(f"{api_name} requires a MemLoc.SSBUF tensor")
    return _make_point_coord(tensor, coord, api_name=api_name, intent=intent)


def _ssbuf_tensor_getitem(tensor: Tensor, coord, *, core: str):
    coord_value = _ssbuf_point_coord(tensor, coord, api_name=f"SSBUF {core} load")
    if core == "vec":
        value = cannir.vec_ssbuf_load(unwrap_operand(tensor), coord_value)
    elif core == "cube":
        value = cannir.cube_ssbuf_load(unwrap_operand(tensor), coord_value)
    else:  # pragma: no cover - _SSBufCoreView owns this invariant.
        raise ValueError(f"unknown SSBUF core view {core!r}")

    from cannbotdsl.core.contracts.elements import wrap_produced_scalar

    return wrap_produced_scalar(value, storage_type=_tensor_storage_type(tensor))


def _ssbuf_tensor_setitem(tensor: Tensor, coord, value, *, core: str) -> None:
    coord_value = _ssbuf_point_coord(tensor, coord, api_name=f"SSBUF {core} store")
    from cannbotdsl.core.contracts.elements import coerce_scalar_to_storage

    storage_type = _tensor_storage_type(tensor)
    storage_value = coerce_scalar_to_storage(value, storage_type, path=f"SSBUF {core} store value")
    if core == "vec":
        cannir.vec_ssbuf_store(storage_value, unwrap_operand(tensor), coord_value)
    elif core == "cube":
        cannir.cube_ssbuf_store(storage_value, unwrap_operand(tensor), coord_value)
    else:  # pragma: no cover - _SSBufCoreView owns this invariant.
        raise ValueError(f"unknown SSBUF core view {core!r}")


# Tensor views and partitioning.


def reinterpret(input, dtype=None, shape=None, *, stride=None, offset: int = 0,
                data_format=None, n1_pad=0):
    """Create a zero-copy view of a Tensor, including a selected Channel slot.

    An explicit same-dtype ``shape`` declares an on-chip access window. Its
    default stride is packed on the physically aligned shape; ``stride`` is
    measured in target-dtype elements. Shapes accept Tiler trees, SSA leaves
    and prebuilt ``make_tiler(..., alignment=...)`` values. Omitting shape retains the input logical shape and stride.

    ``offset`` is a non-negative byte displacement from the input view. An
    explicit same-dtype shape also accepts an i64 SSA offset, carrying the
    caller's guarantee of a positive, aligned, in-bounds runtime displacement.
    Same-dtype windows must fit the parent view. A true dtype change requires
    static whole-byte layouts and must fit every backing allocation at an
    aligned address. Views preserve the selected Tensor's buffer identity.
    No data is converted or copied; use cast for numerical conversion.

    Explicit ``data_format='nd'/'nz'/'zn'`` describes a static on-chip storage
    window with that layout, optionally with NZ ``n1_pad``. It requires an
    explicit flat static shape and byte offset, and checks the window against
    every backing allocation. This reinterprets bytes; it does not transpose
    existing data. The view retains its parent's synchronization identity.
    """
    from cannbotdsl.core.contracts.elements import (
        normalize_storage_dtype,
        storage_mlir_type_for_dtype,
    )

    if type(input) is not Tensor:
        raise TypeError("reinterpret expects a Tensor; select a Channel slot with produce()/consume() first")
    runtime_offset = isinstance(offset, ir.Value)
    if type(offset) is not int and not runtime_offset:
        raise TypeError("reinterpret offset must be a compile-time int (bytes) or an i64 SSA value")
    if not runtime_offset and offset < 0:
        raise ValueError("reinterpret offset must be non-negative")
    if not runtime_offset and offset > (1 << 63) - 1:
        raise OverflowError("reinterpret offset exceeds signed int64")
    user_stride = None
    if stride is not None:
        if not isinstance(stride, (list, tuple)):
            raise TypeError("reinterpret stride must be a static sequence of ints")
        for index, value in enumerate(stride):
            if type(value) is not int:
                raise TypeError(
                    f"reinterpret stride[{index}] must be a Python int, "
                    f"got {type(value).__name__}"
                )
        for index, value in enumerate(stride):
            if value < -(1 << 63) or value >= (1 << 63):
                raise OverflowError(
                    f"reinterpret stride[{index}] exceeds signed int64: {value}"
                )
        for index, value in enumerate(stride):
            if value < 0:
                raise ValueError(
                    f"reinterpret stride[{index}] must be non-negative, got {value}"
                )
        user_stride = ir.ArrayAttr.get([
            ir.IntegerAttr.get(ir.IntegerType.get_signless(64), s) for s in stride
        ])
    dtype = input.dtype if dtype is None else normalize_storage_dtype(dtype)
    if data_format is not None:
        if data_format not in ("nd", "nz", "zn"):
            raise ValueError("reinterpret data_format must be 'nd', 'nz', or 'zn'")
        if input.memloc == MemLoc.GM:
            raise ValueError("formatted reinterpret requires on-chip storage")
        if runtime_offset:
            raise TypeError("formatted reinterpret requires a static byte offset")
        if (not isinstance(shape, (tuple, list)) or not shape or
                any(type(dim) is not int or dim <= 0 for dim in shape)):
            raise TypeError("formatted reinterpret requires an explicit flat positive static shape")
        if data_format != "nd" and len(shape) not in (2, 3):
            raise ValueError("NZ/ZN reinterpret requires rank 2 or 3")
        if type(n1_pad) is not int or n1_pad < 0:
            raise ValueError("reinterpret n1_pad must be a non-negative Python int")
        if stride is not None and (len(stride) != len(shape) or any(s <= 0 for s in stride)):
            raise ValueError("formatted reinterpret stride must have one positive entry per dimension")
        logical = make_layout(tuple(shape), stride=None if stride is None else tuple(stride))
        physical_shape, physical_stride = _physical_layout_spec(
            dtype, tuple(shape), data_format, n1_pad, mem_loc=input.memloc)
        if data_format == "nd" and stride is not None:
            physical_stride = tuple(stride)
        physical = make_layout(physical_shape, stride=physical_stride)
        result_type = _tensor_type_from_layouts(
            dtype, input.memloc, logical, physical, data_format=data_format)
        return cannir.storage_cast(
            result_type, unwrap_operand(input),
            dtype=ir.TypeAttr.get(storage_mlir_type_for_dtype(dtype)),
            offset_bytes=offset)
    if n1_pad:
        raise ValueError("reinterpret n1_pad requires an explicit data_format")
    if runtime_offset and (shape is None or dtype != input.dtype):
        raise NotImplementedError("a runtime reinterpret offset requires an explicit same-dtype shape")
    tiler = input.shape if shape is None else shape
    if isinstance(tiler, ir.Value) and isinstance(tiler.type, cannir.TileType):
        tile_value = tiler
    else:
        tile_tree, tile_dyn = _tiler_to_type_and_dynamic_values(tiler)
        tile_value = cannir.make_tile(cannir.TileType.get(tile_tree), tile_dyn)
    # Omitting shape preserves the selected Tensor's actual access layout.
    input_value = unwrap_operand(input)
    if runtime_offset:
        offset_operand = cannir.assume_positive(
            _index_value(offset, operation="reinterpret offset")
        )
        result = cannir.local_slice(
            input_value, tile_value, offset=offset_operand,
            user_stride=user_stride,
        )
        if user_stride is None:
            unwrap_operand(result).owner.attributes["cannir.reinterpret.explicit_packing"] = ir.UnitAttr.get()
        return result
    result = cannir.reinterpret_view(
        input_value, tile_value,
        dtype=ir.TypeAttr.get(storage_mlir_type_for_dtype(dtype)),
        offset_bytes=offset, user_stride=user_stride,
        preserve_layout=shape is None,
    )
    return result


def _flat_view_rank(memref_type, op_name: str) -> int:
    logical = cannir.LayoutType(memref_type.logical_layout).shape
    physical = cannir.LayoutType(memref_type.physical_layout).shape

    # ShapeType's recursive representation spells the empty Python tuple as
    # the scalar value 0.  No non-empty public TensorSpec uses that spelling,
    # so it is the canonical rank-zero representation here.
    if logical == 0 and physical == 0:
        return 0
    if not isinstance(logical, tuple) or not isinstance(physical, tuple):
        raise NotImplementedError(f"{op_name} currently supports only flat Tensor layouts")
    if any(isinstance(dim, (tuple, list)) for dim in logical) or any(
        isinstance(dim, (tuple, list)) for dim in physical
    ):
        raise NotImplementedError(f"{op_name} currently supports only flat Tensor layouts")
    if len(logical) != len(physical):
        raise NotImplementedError(f"{op_name} requires logical and physical layouts with matching rank")
    return len(logical)


def _normalize_permutation(dims, rank: int) -> tuple[int, ...]:
    if not isinstance(dims, (tuple, list)):
        raise TypeError("permute dims must be a compile-time tuple or list of integers")
    if len(dims) != rank:
        raise ValueError(f"permute dims must contain exactly {rank} axes, got {len(dims)}")

    normalized = []
    for index, dim in enumerate(dims):
        if isinstance(dim, bool) or not isinstance(dim, int):
            raise TypeError(
                f"permute dims must contain only compile-time integers; dims[{index}] is {type(dim).__name__}"
            )
        if dim < 0:
            dim += rank
        if dim < 0 or dim >= rank:
            raise ValueError(f"permute dims[{index}] is out of range for rank {rank}")
        normalized.append(dim)
    if len(set(normalized)) != rank:
        raise ValueError(f"permute dims must be a complete permutation, got {tuple(normalized)!r}")
    return tuple(normalized)


def permute(input: Tensor, dims: tuple[int, ...] | list[int]) -> Tensor:
    """Return a zero-copy GM Tensor view with its axes reordered by ``dims``.

    ``dims`` is a complete compile-time permutation. Negative axes are
    normalized in Python. The result retains the input pointer, dtype,
    storage provenance, and accumulated view offset while reordering logical
    and physical shape/stride metadata together.
    """
    from cannbotdsl.channel import Channel

    if isinstance(input, Channel):
        raise NotImplementedError("permute does not currently support Channel values")
    if not isinstance(input, Tensor):
        raise TypeError(f"permute expects a Tensor as its first argument, got {type(input).__name__}")

    memref_type = _tensor_memref_type(input)
    if _tensor_memloc(input) != MemLoc.GM:
        raise NotImplementedError("permute currently supports only GM Tensors")
    layout_map_kind = _tensor_layout_map_kind(input)
    if layout_map_kind != LayoutMapKind.Identity:
        raise NotImplementedError(f"permute currently supports only Identity/ND Tensors; got {layout_map_kind.name}")

    rank = _flat_view_rank(memref_type, "permute")
    normalized = _normalize_permutation(dims, rank)
    dims_attr = ir.DenseI64ArrayAttr.get(normalized)
    return cannir.permute_view(unwrap_operand(input), dims=dims_attr)


def _runtime_extent_carrier(dim):
    """Return the i64 SSA carrier for a runtime extent, else None.

    DSL integer wrappers (``Int64`` and friends) subclass ``ir.Value``, so one
    isinstance check covers both a raw SSA value and a wrapped one.
    """

    if not isinstance(dim, ir.Value):
        return None
    return _index_value(dim, operation="Tensor.view runtime extent")


def _checked_view_product(values, *, what: str) -> int:
    product = 1
    for value in values:
        product *= value
        if product > _I64_MAX:
            raise OverflowError(f"{what} element count overflows int64")
    return product


def _normalize_tensor_view_shape(input: Tensor, shape) -> tuple:
    if not isinstance(shape, (tuple, list)):
        raise TypeError("Tensor.view size must be a tuple/list or dimensions")
    if not shape:
        raise ValueError("Tensor.view size must not be empty")

    normalized = []
    inferred_axis = None
    for index, extent in enumerate(shape):
        carrier = _runtime_extent_carrier(extent)
        if carrier is not None:
            integer_type = ir.IntegerType(carrier.type)
            if not integer_type.is_signless:
                raise TypeError(f"Tensor.view size[{index}] must be a signless i64 value")
            constant = _constant_i64(carrier)
            if constant is None:
                normalized.append(carrier)
                continue
            extent = constant
        if isinstance(extent, bool) or not isinstance(extent, int):
            raise TypeError(
                "Tensor.view size entries must be Python ints or signless i64 "
                f"values; size[{index}] is {type(extent).__name__}"
            )
        if extent == -1:
            if inferred_axis is not None:
                raise ValueError("Tensor.view permits at most one inferred -1 axis")
            inferred_axis = index
        elif extent <= 0:
            raise ValueError(f"Tensor.view size[{index}] = {extent} must be positive or -1")
        normalized.append(extent)

    if inferred_axis is not None:
        source_type = _tensor_memref_type(input)
        source_shape = cannir.LayoutType(source_type.logical_layout).shape
        if not isinstance(source_shape, tuple) or any(
            type(extent) is not int or extent <= 0 for extent in source_shape
        ):
            raise ValueError("Tensor.view can infer -1 only when the source shape is positive and fully static")
        other = []
        for index, extent in enumerate(normalized):
            if index == inferred_axis:
                continue
            constant = _constant_i64(extent)
            if constant is None or constant <= 0:
                raise ValueError(
                    "Tensor.view can infer -1 only when every other target "
                    "dimension is statically evaluable and positive"
                )
            other.append(constant)
        source_numel = _checked_view_product(source_shape, what="source shape")
        known_numel = _checked_view_product(other, what="target shape")
        if source_numel % known_numel:
            raise ValueError(
                "Tensor.view inferred dimension is not integral: source "
                f"numel {source_numel} is not divisible by {known_numel}"
            )
        inferred = source_numel // known_numel
        if inferred <= 0:
            raise ValueError("Tensor.view inferred dimension must be positive")
        normalized[inferred_axis] = inferred
    return tuple(normalized)


def _shape_view(input: Tensor, target_shape) -> Tensor:
    from cannbotdsl.channel import Channel

    if isinstance(input, Channel):
        raise NotImplementedError("Tensor.view does not support Channel values")
    if type(input) is not Tensor:
        raise TypeError(f"Tensor.view expects a Tensor, got {type(input).__name__}")
    memref_type = _tensor_memref_type(input)
    if input.dtype.bits not in (8, 16, 32, 64):
        raise ValueError("Tensor.view supports only canonical 8/16/32/64-bit non-bool dtypes")
    if input.memloc not in _TENSOR_VIEW_MEMLOCS:
        raise NotImplementedError(f"Tensor.view does not support memory location {input.memloc.name}")
    if _tensor_layout_map_kind(input) != LayoutMapKind.Identity:
        raise NotImplementedError("Tensor.view supports only Identity/ND Tensors")
    rank = _flat_view_rank(memref_type, "Tensor.view")
    if rank == 0:
        raise ValueError("Tensor.view does not support rank-0 Tensors")

    normalized = _normalize_tensor_view_shape(input, target_shape)
    encoded = []
    dynamic_values = []
    for extent in normalized:
        carrier = _runtime_extent_carrier(extent)
        if carrier is None:
            encoded.append(extent)
        else:
            encoded.append(cannir.ShapeType.DYNAMIC)
            dynamic_values.append(carrier)
    return cannir.reshape_view(
        unwrap_operand(input),
        ir.DenseI64ArrayAttr.get(encoded),
        dynamic_values,
    )


def _dtype_view(input: Tensor, dtype) -> Tensor:
    from cannbotdsl.channel import Channel
    from cannbotdsl.core.contracts.elements import (
        normalize_storage_dtype,
        storage_mlir_type_for_dtype,
    )

    if isinstance(input, Channel):
        raise NotImplementedError("Tensor.view does not support Channel values")
    if type(input) is not Tensor:
        raise TypeError(f"Tensor.view expects a Tensor, got {type(input).__name__}")
    dtype = normalize_storage_dtype(dtype)
    source_dtype = input.dtype
    if source_dtype.bits not in (8, 16, 32, 64) or dtype.bits not in (
        8,
        16,
        32,
        64,
    ):
        raise ValueError("Tensor.view dtype overload supports only canonical 8/16/32/64-bit non-bool dtypes")

    memref_type = _tensor_memref_type(input)
    if input.memloc not in _TENSOR_VIEW_MEMLOCS:
        raise NotImplementedError(f"Tensor.view dtype overload does not support memory location {input.memloc.name}")
    if _tensor_layout_map_kind(input) != LayoutMapKind.Identity:
        raise NotImplementedError("Tensor.view dtype overload supports only Identity/ND Tensors")
    rank = _flat_view_rank(memref_type, "Tensor.view(dtype)")
    if rank == 0:
        raise ValueError("Tensor.view dtype overload requires rank > 0")
    layout = cannir.LayoutType(memref_type.logical_layout)
    shape = layout.shape
    stride = layout.stride
    if not isinstance(shape, tuple) or not isinstance(stride, tuple):
        raise NotImplementedError("Tensor.view dtype overload requires a flat layout")
    if len(shape) != len(stride) or stride[-1] != 1:
        raise ValueError("Tensor.view dtype overload requires last stride == 1")
    if any(extent != cannir.ShapeType.DYNAMIC and extent <= 0 for extent in shape) or any(
        step != cannir.StrideType.DYNAMIC and step <= 0 for step in stride
    ):
        raise ValueError("Tensor.view dtype overload requires positive extents/strides")

    if dtype.bits > source_dtype.bits:
        ratio = dtype.bits // source_dtype.bits
        affected = (shape[-1], *stride[:-1])
        if any(value != cannir.ShapeType.DYNAMIC and value % ratio for value in affected):
            raise ValueError(
                "Tensor.view dtype widening requires every affected static "
                "final extent and non-final stride to be statically divisible "
                "by the "
                f"byte-width ratio {ratio}"
            )

    if source_dtype == dtype:
        return input
    target_type = storage_mlir_type_for_dtype(dtype)
    return cannir.dtype_view(unwrap_operand(input), dtype=ir.TypeAttr.get(target_type))


def _tensor_view_dispatch(input: Tensor, *shape, size=None, dtype=None) -> Tensor:
    """Private overload dispatcher backing :meth:`Tensor.view`."""

    from cannbotdsl.types.dtypes import DType

    if shape and (size is not None or dtype is not None):
        raise TypeError("Tensor.view positional arguments, size=, and dtype= are mutually exclusive")
    if size is not None and dtype is not None:
        raise TypeError("Tensor.view size= and dtype= are mutually exclusive")
    if dtype is not None:
        return _dtype_view(input, dtype)
    if size is not None:
        return _shape_view(input, size)
    if len(shape) == 1 and type(shape[0]) is DType:
        return _dtype_view(input, shape[0])
    if not shape:
        raise TypeError("Tensor.view requires a size or dtype")
    target = shape[0] if len(shape) == 1 and isinstance(shape[0], (tuple, list)) else shape
    return _shape_view(input, target)


def tile_slice(
    input: Tensor,
    tiler: Tiler,
    coord: Coord,
    *,
    alignment=None,
) -> Tensor:
    """Create a zero-copy alias view of one logical tile.

    For an input of rank ``N`` and a ``tiler`` with ``K`` leaves, ``tiler`` and
    ``coord`` address the trailing ``K`` logical dimensions. The view origin is
    shifted by
    ``sum(coord[i] * tiler[i] * input.stride[N - K + i])``. ``coord`` is a
    tile index, not an element coordinate, and ``tiler`` is the nominal tile
    used to compute that origin.

    The result shape follows the tiler tree. A final partial tile reports its
    tail-aware actual extent while retaining the input's corresponding
    trailing strides; no data is copied or repacked. Every tiler leaf must be a
    positive compile-time constant, unless it comes from
    Dynamic leaves require a TileType alignment declaration. A fully static, non-divisible tail rejects
    an origin at or beyond the parent. Divisible, oversized-tile, and dynamic
    coordinate fast paths do not provide a general bounds check or rewrite the
    origin; callers must keep coordinates within the valid tile domain. Dynamic
    tail extents are clipped to the remaining parent range. ND2NZ/DN2NZ mapped
    layouts additionally require fractal-aligned interior tile boundaries.

    Select a Channel slot with produce()/consume() before taking a tile. The
    resulting view keeps that Tensor snapshot and its buffer identity.
    """
    if tiler is None or coord is None:
        raise TypeError("tile_slice requires (tiler, coord)")
    if isinstance(tiler, ir.Value) and isinstance(tiler.type, cannir.TileType):
        if alignment is not None:
            raise ValueError(
                "tiler is already a TileType value carrying its own alignment; "
                "pass alignment only with a Python tiler tree"
            )
        alignment_validated = None
    else:
        alignment_validated = (
            None
            if alignment is None
            else _tile_alignment_list(alignment, _count_tree_leaves(tiler))
        )
    if not isinstance(input, Tensor):
        raise TypeError("tile_slice expects a Tensor; select a Channel slot with produce()/consume() first")

    # A view retains the selected Tensor's storage identity. Slot selection
    # already happened in the caller; creating the view never advances it.
    src = unwrap_operand(input)
    if isinstance(tiler, ir.Value) and isinstance(tiler.type, cannir.TileType):
        tile_value = tiler
    else:
        tile_value = make_tiler(tiler, alignment=alignment_validated)
    coord_tree, coord_dyn = _coord_to_type_and_dynamic_values(coord)
    coord_ty = cannir.CoordType.get(coord_tree)
    coord_value = cannir.make_coord(coord_ty, coord_dyn)
    res = cannir.tile_slice(src, tile_value, coord_value)
    return res


__all__ = [
    "Shape", "Stride", "Coord", "Tile", "Tiler",
    "Layout", "Tensor", "PartitionTiler",
    "make_layout", "make_pointer", "make_tiler", "make_tensor",
    "ceil_div", "size", "crd2idx", "idx2crd",
    "reinterpret", "permute",
    "tile_slice",
    "MemLoc", "LayoutMapKind",
]
