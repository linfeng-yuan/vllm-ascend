# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""On-chip Tensor allocation, static UB storage and Buffer resource binding."""

from __future__ import annotations

from functools import reduce
from operator import mul

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl._onchip import _current_onchip_trace
from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.types import dtypes
from cannbotdsl._onchip import (
    _make_onchip_allocation,
    _normalize_shape_capacity,
)
from cannbotdsl.tensor import (
    _infer_contiguous_stride,
    _physical_layout_spec,
    _tensor_type_from_layouts,
    make_layout,
)
from cannbotdsl.tensor import Layout, Tensor
from cannbotdsl.tensor import MemLoc


_BUFFER_MEM_LOCS = frozenset(
    (MemLoc.UB, MemLoc.L1, MemLoc.L0A, MemLoc.L0B, MemLoc.L0C,
     MemLoc.BIAS, MemLoc.SSBUF, MemLoc.FBUF)
)
_BUFFER_FORMATS = frozenset(("nd", "nz", "zn"))


def _normalize_mem_loc(mem_loc):
    if not isinstance(mem_loc, MemLoc):
        raise TypeError(f"Buffer mem_loc must be a MemLoc value, got {type(mem_loc).__name__}")
    if mem_loc not in _BUFFER_MEM_LOCS:
        supported = ", ".join(item.name for item in _BUFFER_MEM_LOCS)
        raise ValueError(f"Buffer does not support MemLoc.{mem_loc.name}; supported: {supported}")
    return mem_loc


def _normalize_stride(stride, shape):
    if stride is None:
        return _infer_contiguous_stride(shape)
    if not isinstance(stride, tuple):
        raise TypeError("Buffer stride must be a flat tuple of positive ints")
    if len(stride) != len(shape):
        raise ValueError(f"Buffer stride rank {len(stride)} does not match shape rank {len(shape)}")
    for index, value in enumerate(stride):
        if type(value) is not int:
            raise TypeError(f"Buffer stride[{index}] must be a positive Python int, got {type(value).__name__}")
        if value <= 0:
            raise ValueError(f"Buffer stride[{index}] must be positive, got {value}")
    return stride


def _normalize_dtype(dtype):
    from cannbotdsl.core.contracts.elements import normalize_storage_dtype

    dtype = normalize_storage_dtype(dtype)
    width = getattr(dtype, "width", None)
    if type(width) is not int or width <= 0 or width % 8:
        raise ValueError(f"Buffer dtype must have a positive whole-byte storage width, got {dtype!r} ({width!r} bits)")
    return dtype


def _normalize_addr(addr):
    if addr is None:
        return None
    if type(addr) is not int:
        raise TypeError(f"Buffer addr must be a non-negative Python int or None, got {type(addr).__name__}")
    if addr < 0:
        raise ValueError(f"Buffer addr must be non-negative, got {addr}")
    return addr


def _normalize_format(mem_loc, shape, data_format, n1_pad):
    if data_format is None:
        data_format = "nd" if mem_loc in (MemLoc.UB, MemLoc.BIAS, MemLoc.SSBUF, MemLoc.FBUF) else "nz"
    if type(data_format) is not str:
        raise TypeError(f"Buffer data_format must be one of 'nd', 'nz', or 'zn', got {type(data_format).__name__}")
    if data_format not in _BUFFER_FORMATS:
        raise ValueError(f"Buffer data_format must be one of 'nd', 'nz', or 'zn', got {data_format!r}")
    if mem_loc in (MemLoc.BIAS, MemLoc.SSBUF, MemLoc.FBUF) and data_format != "nd":
        raise ValueError(f"{mem_loc.name} Buffer requires data_format='nd'")
    if data_format in ("nz", "zn") and len(shape) not in (2, 3):
        raise ValueError(f"Buffer data_format={data_format!r} requires rank 2 or 3, got rank {len(shape)}")
    if type(n1_pad) is not int:
        raise TypeError(f"Buffer n1_pad must be a non-negative Python int, got {type(n1_pad).__name__}")
    if n1_pad < 0:
        raise ValueError(f"Buffer n1_pad must be non-negative, got {n1_pad}")
    if n1_pad and data_format != "nz":
        raise ValueError("Buffer n1_pad is only supported for data_format='nz'")
    return data_format, n1_pad


def _build_buffer_tensor(
    mem_loc,
    shape,
    dtype,
    fixed_addr,
    stride,
    data_format,
    n1_pad,
):
    physical_shape, physical_stride = _physical_layout_spec(dtype, shape, data_format, n1_pad, mem_loc=mem_loc)
    if data_format == "nd":
        physical_stride = stride
    logical_layout = make_layout(shape, stride=stride)
    physical_layout = (
        make_layout(physical_shape) if physical_stride is None else make_layout(physical_shape, stride=physical_stride)
    )
    tensor = _make_onchip_allocation(
        dtype,
        mem_loc,
        logical_layout,
        physical_layout,
        data_format=data_format,
        fixed_addr=fixed_addr,
    )[0]
    unwrap_operand(tensor).owner.attributes["cannir.infer_physical_layout"] = ir.UnitAttr.get()
    return tensor


def Buffer(
    mem_loc,
    shape=None,
    dtype=None,
    *,
    capacity=None,
    layout=None,
    physical_layout=None,
    addr=None,
    stride=None,
    data_format=None,
    n1_pad=0,
) -> Tensor:
    """Construct one ordinary on-chip Tensor.

    ``Buffer`` has no runtime value kind of its own. It emits an on-chip
    allocation declaration; the memory-planning pass assigns its byte address
    and materializes the pointer/Tensor root.
    """

    mem_loc = _normalize_mem_loc(mem_loc)
    # Once a function opts into the explicit UB-space model, every UB tensor
    # must be a view of that root.  The root itself is created by UB.view before
    # it is recorded in the trace_state, so this check does not reject root creation.
    if mem_loc == MemLoc.UB:
        try:
            trace_state = _current_onchip_trace()
        except RuntimeError:
            trace_state = None
        if trace_state is not None and trace_state._ub_space_root is not None:
            raise ValueError(
                "ordinary UB Buffer is not allowed after dsl.UB.view(); "
                "derive it from the UB space and call make_buffer(view)"
            )
        if trace_state is not None and not trace_state._ub_space_bootstrap:
            trace_state._ub_space_legacy_allocs += 1
    if dtype is None:
        raise TypeError("Buffer requires dtype and a declared layout")
    if layout is not None:
        if shape is not None or stride is not None:
            raise TypeError("Buffer layout form does not accept shape or stride")
        if not isinstance(layout, Layout):
            raise TypeError(
                f"Buffer layout must be a Layout, got {type(layout).__name__}"
            )
        if not isinstance(physical_layout, Layout):
            raise TypeError("Buffer layout form requires physical_layout as a Layout")
        if capacity is None:
            raise TypeError("Buffer layout form requires a static capacity tuple")
        shape = layout.shape
    elif shape is None:
        raise TypeError("Buffer requires shape/dtype or layout/dtype")
    elif physical_layout is not None:
        raise TypeError("Buffer physical_layout is accepted only with layout")

    shape, capacity, has_dynamic_shape = _normalize_shape_capacity(
        shape, capacity, owner="Buffer"
    )
    addr = _normalize_addr(addr)
    if mem_loc == MemLoc.SSBUF and addr is None:
        raise TypeError("SSBUF Buffer requires an explicit byte address via addr=")
    dtype = _normalize_dtype(dtype)
    capacity_stride = _normalize_stride(stride, capacity)
    data_format, n1_pad = _normalize_format(
        mem_loc, capacity, data_format, n1_pad
    )
    if layout is not None:
        capacity_physical_shape, capacity_physical_stride = (
            _physical_layout_spec(
                dtype,
                capacity,
                data_format,
                n1_pad,
                mem_loc=mem_loc,
            )
        )
        if data_format == "nd":
            capacity_physical_stride = capacity_stride
        capacity_layout = make_layout(capacity, stride=capacity_stride)
        capacity_physical_layout = (
            make_layout(capacity_physical_shape)
            if capacity_physical_stride is None
            else make_layout(
                capacity_physical_shape,
                stride=capacity_physical_stride,
            )
        )
        storage_type = _tensor_type_from_layouts(
            dtype,
            mem_loc,
            capacity_layout,
            capacity_physical_layout,
            data_format=data_format,
        )
        declared_layout = make_layout(layout.shape, stride=layout.stride)
        return _make_onchip_allocation(
            dtype,
            mem_loc,
            declared_layout,
            physical_layout,
            data_format=data_format,
            fixed_addr=addr,
            storage_type=storage_type,
        )[0]

    root = _build_buffer_tensor(
        mem_loc,
        capacity,
        dtype,
        addr,
        capacity_stride,
        data_format,
        n1_pad,
    )
    if not has_dynamic_shape and shape == capacity:
        return root

    from cannbotdsl.tensor import reinterpret, make_tiler

    dynamic_tiler = make_tiler(shape)
    return reinterpret(root, shape=dynamic_tiler, stride=capacity_stride)


_UB_CAPACITY_BYTES = 256 * 1024
_STATIC_VIEW_OPS = frozenset(
    {
        "cannir.reshape_view",
        "cannir.memref_slice",
        "cannir.local_slice",
        "cannir.tile_slice",
        "cannir.reinterpret_view",
        "cannir.storage_cast",
        "cannir.dtype_view",
        "cannir.permute_view",
        "cannir.make_buf",
    }
)


def _static_product(shape) -> int:
    values = []
    for dim in shape:
        if type(dim) is not int or dim <= 0:
            raise TypeError(
                "UB space views require a non-empty static shape of positive ints"
            )
        values.append(dim)
    if not values:
        raise ValueError("UB space view shape must not be empty")
    return reduce(mul, values, 1)


def _ensure_static_view(view: Tensor) -> None:
    shape = view.shape
    stride = view.stride
    _static_product(shape)
    for name, values in (("stride", stride),):
        for index, value in enumerate(values):
            if type(value) is not int or value <= 0:
                raise TypeError(
                    f"UB space view {name}[{index}] must be a positive static int"
                )


def _find_ub_root(value):
    """Find the explicit UB root through the supported static view chain."""

    current = unwrap_operand(value)
    visited = set()
    while current is not None and current not in visited:
        visited.add(current)
        owner = getattr(current, "owner", None)
        name = str(getattr(owner, "name", ""))
        if name == "cannir.onchip_alloc":
            if "cannir.ub_space_root" in owner.attributes:
                return current
            return None
        if name not in _STATIC_VIEW_OPS:
            return None
        current = unwrap_operand(owner.operands[0])
    return None


def _has_bound_resource(value) -> bool:
    """Return whether a view chain already contains a make_buf boundary."""

    current = unwrap_operand(value)
    visited = set()
    while current is not None and current not in visited:
        visited.add(current)
        owner = getattr(current, "owner", None)
        name = str(getattr(owner, "name", ""))
        if name == "cannir.make_buf":
            return True
        if name not in _STATIC_VIEW_OPS:
            return False
        current = unwrap_operand(owner.operands[0])
    return False


class _UBSpace:
    """Function-local static UB storage root facade."""

    __slots__ = ()

    def view(self, *shape, dtype=None):
        """Return a static view covering the complete UB space.

        The root is byte-addressed in the MVP.  ``shape`` must therefore
        contain exactly 256 KiB worth of uint8 elements.  All later UB
        resources must be derived from the returned view.
        """

        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        else:
            shape = tuple(shape)
        if dtype is not None and dtype != dtypes.uint8:
            raise ValueError(
                "dsl.UB.view is byte-addressed in the MVP; dtype must be dtypes.uint8"
            )
        if _static_product(shape) != _UB_CAPACITY_BYTES:
            raise ValueError(
                "dsl.UB.view must cover the complete 256 KiB UB space "
                f"({ _UB_CAPACITY_BYTES } uint8 elements), got shape={shape!r}"
            )

        trace_state = _current_onchip_trace()
        if trace_state._ub_space_legacy_allocs:
            raise ValueError(
                "dsl.UB.view must be declared before ordinary UB Buffer allocations"
            )
        root = trace_state._ub_space_root
        if root is None:
            trace_state._ub_space_bootstrap = True
            try:
                root = Buffer(
                    MemLoc.UB,
                    shape=(_UB_CAPACITY_BYTES,),
                    dtype=dtypes.uint8,
                    addr=0,
                )
            finally:
                trace_state._ub_space_bootstrap = False
            root_value = unwrap_operand(root)
            root_value.owner.attributes["cannir.ub_space_root"] = ir.UnitAttr.get()
            trace_state._ub_space_root = root
        return root.view(shape)


UB = _UBSpace()


def make_buffer(view: Tensor, *, dtype=None) -> Tensor:
    """Bind a static UB view to a hardware Buffer identity.

    The operation reuses the view's storage root and address.  It emits no
    ``onchip_alloc``; only a ``make_buf`` marker and a buf-id are added.
    """

    if not isinstance(view, Tensor):
        raise TypeError(
            f"make_buffer expects a Tensor view, got {type(view).__name__}"
        )
    if view.memloc != MemLoc.UB:
        raise ValueError("make_buffer currently supports only UB views")
    _ensure_static_view(view)

    root = _find_ub_root(view)
    if root is None:
        raise ValueError(
            "make_buffer requires a static view derived from dsl.UB.view()"
        )

    # A view of an already-bound Buffer keeps that resource.  A dtype view is
    # formed before this check by the caller (or by the implementation below),
    # so no second buf-id can be introduced accidentally.
    if dtype is not None:
        from cannbotdsl.core.contracts.elements import normalize_storage_dtype

        dtype = normalize_storage_dtype(dtype)
        if dtype != view.dtype:
            view = view.view(dtype=dtype)
            _ensure_static_view(view)
    if _has_bound_resource(view):
        return view

    _current_onchip_trace()
    identity = cannir.BufferResourceOp.build_generic(
        results=[ir.IntegerType.get_signless(64)], operands=[unwrap_operand(view)]
    ).results[0]
    marker = cannir.make_buf(unwrap_operand(view), identity)
    marker_value = unwrap_operand(marker)
    marker_value.owner.attributes["cannir.buffer.explicit_binding"] = ir.UnitAttr.get()
    marker_value.owner.attributes["cannir.buffer.logical"] = ir.UnitAttr.get()
    return Tensor._from_ir(marker_value)


__all__ = ["Buffer", "UB", "make_buffer"]
