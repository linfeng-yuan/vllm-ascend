# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Shared shape/capacity validation and on-chip allocation declarations."""

from __future__ import annotations

from contextvars import ContextVar

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir
from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.tensor import Layout, MemLoc, Tensor, _tensor_type_from_layouts


class _OnChipTraceState:
    """Function-local UB-space state; hardware IDs are allocated by MLIR."""

    def __init__(self):
        self._ub_space_root = None
        self._ub_space_legacy_allocs = 0
        self._ub_space_bootstrap = False


_CURRENT_ONCHIP_TRACE: ContextVar[_OnChipTraceState | None] = ContextVar(
    "cannbotdsl_current_onchip_trace", default=None
)


def _set_current_onchip_trace(state):
    return _CURRENT_ONCHIP_TRACE.set(state)


def _reset_current_onchip_trace(token):
    _CURRENT_ONCHIP_TRACE.reset(token)


def _current_onchip_trace():
    state = _CURRENT_ONCHIP_TRACE.get()
    if state is None:
        raise RuntimeError("Buffer and Channel require an active CANNBotDSL lowering context")
    return state


def _normalize_shape_capacity(shape, capacity, *, owner):
    """Validate a flat logical shape and its static allocation capacity."""
    if not isinstance(shape, tuple):
        raise TypeError(
            f"{owner} shape must be a flat tuple of positive ints or i64 SSA values"
        )
    if not shape:
        raise ValueError(f"{owner} shape must not be empty")

    has_dynamic = False
    for index, dim in enumerate(shape):
        if type(dim) is int:
            if dim <= 0:
                raise ValueError(
                    f"{owner} shape[{index}] must be positive, got {dim}"
                )
            continue
        if isinstance(dim, ir.Value):
            dim_type = dim.type
            if not (
                isinstance(dim_type, ir.IntegerType)
                and dim_type.width == 64
                and dim_type.is_signless
            ):
                raise TypeError(
                    f"{owner} shape[{index}] SSA value must have canonical "
                    f"signless i64 type, got {dim_type}"
                )
            has_dynamic = True
            continue
        raise TypeError(
            f"{owner} shape[{index}] must be a positive Python int or i64 "
            f"SSA value, got {type(dim).__name__}"
        )

    if capacity is None:
        if has_dynamic:
            raise TypeError(
                f"{owner} dynamic shape requires a static capacity tuple"
            )
        capacity = shape
    if not isinstance(capacity, tuple):
        raise TypeError(
            f"{owner} capacity must be a flat tuple of positive ints"
        )
    if len(capacity) != len(shape):
        raise ValueError(
            f"{owner} capacity rank {len(capacity)} does not match shape rank "
            f"{len(shape)}"
        )
    for index, (dim, bound) in enumerate(zip(shape, capacity)):
        if type(bound) is not int:
            raise TypeError(
                f"{owner} capacity[{index}] must be a positive Python int, "
                f"got {type(bound).__name__}"
            )
        if bound <= 0:
            raise ValueError(
                f"{owner} capacity[{index}] must be positive, got {bound}"
            )
        if type(dim) is int and dim > bound:
            raise ValueError(
                f"{owner} shape[{index}] ({dim}) exceeds capacity[{index}] "
                f"({bound})"
            )
    return shape, capacity, has_dynamic


def _make_onchip_allocation(
    dtype,
    mem_loc: MemLoc,
    logical_layout: Layout,
    physical_layout: Layout,
    *,
    data_format: str,
    slots: int = 1,
    fixed_addr: int | None = None,
    storage_type=None,
):
    """Emit pass-planned allocation intent for one group of tensor slots."""
    if type(slots) is not int or slots < 1:
        raise ValueError("on-chip allocation slots must be a positive int")
    logical_layout_value = unwrap_operand(logical_layout)
    tensor_type = _tensor_type_from_layouts(
        dtype,
        mem_loc,
        logical_layout,
        physical_layout,
        data_format=data_format,
    )
    attributes = {}
    if fixed_addr is not None:
        i64 = ir.IntegerType.get_signless(64)
        attributes["fixed_addr"] = ir.IntegerAttr.get(i64, fixed_addr)
    if storage_type is not None:
        attributes["storage_type"] = ir.TypeAttr.get(storage_type)
    operation = cannir.OnChipAllocOp.build_generic(
        results=[tensor_type] * slots,
        operands=[logical_layout_value],
        attributes=attributes,
    )
    return tuple(Tensor._from_ir(result) for result in operation.results)
