# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""On-chip slots with independent explicit write and read cursors.

``produce()`` and ``consume()`` select a Tensor and advance their respective
cursor immediately. Data accesses determine synchronization; selecting a slot
does not initialize data, wait, check fullness, or copy the stored data. Both
returned Tensors support reads, writes and in-place updates.

SameCore and CrossCore declarations use the same selection interface.
The compiler derives local and cross-core synchronization from Tensor accesses.

For single-slot VF-internal scratch space (no ring-buffer semantics), use
``cannbotdsl.buffer.Buffer``. Buffer and Channel allocation declarations share
the pass-side address planner, and ``reinterpret`` creates a same-storage typed
alias without requesting another allocation.
"""
from __future__ import annotations

from enum import IntEnum as _IntEnum

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl._onchip import _normalize_shape_capacity
from cannbotdsl._onchip import _current_onchip_trace
from cannbotdsl.ops.sync import channel_rewind
from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.tensor import MemLoc
from cannbotdsl.tensor import Tensor
from cannbotdsl.tensor import _physical_layout_spec


_CUBE_MEM_LOCS = {MemLoc.L1, MemLoc.L0A, MemLoc.L0B, MemLoc.L0C, MemLoc.BIAS}


class ChannelKind(_IntEnum):
    SameCore = 0
    CrossCore = 1


@ir.register_value_caster(cannir.ChannelType.get_static_typeid())
class _ChannelValue(ir.Value):
    """SSA-level Channel value. Auto-cast from ChannelType SSA values."""

    @property
    def dtype(self):
        memref_ty = cannir.TensorType(self.type.element)
        from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type

        return dtype_for_storage_mlir_type(
            cannir.PointerType(memref_ty.pointer).dtype
        )

    @property
    def memloc(self):
        memref_ty = cannir.TensorType(self.type.element)
        return cannir.PointerType(memref_ty.pointer).memloc

    @property
    def layout(self):
        return cannir.extract_layout(self)

    @property
    def physical_layout(self):
        return cannir.extract_physical_layout(self)

    @property
    def shape(self):
        return self.layout.shape

    @property
    def stride(self):
        return self.layout.stride

    @property
    def physical_shape(self):
        return self.physical_layout.shape

    @property
    def physical_stride(self):
        return self.physical_layout.stride

    @property
    def depth(self):
        return self.type.depth

    @property
    def element(self):
        return self.type.element

    @property
    def kind(self):
        return self.type.kind

    @property
    def layout_map_kind(self):
        from cannbotdsl.tensor import LayoutMapKind

        memref_ty = cannir.TensorType(self.type.element)
        return LayoutMapKind(memref_ty.layout_map_kind)

    @property
    def logical_format(self):
        # Channel logical views are ND; still validate the carried map kind.
        self.layout_map_kind
        return "nd"

    @property
    def physical_format(self):
        from cannbotdsl.tensor import _physical_format_for_map

        return _physical_format_for_map(self.layout_map_kind)

    @property
    def data_format(self):
        return self.physical_format


def _build_typed_channel_ir(
    mem_loc, dtype, shape, kind, data_format, n1_pad, stride,
    fixed_addr, depth, resource,
):
    """Build one typed Channel declaration and its planned storage slots."""
    from cannbotdsl._onchip import _make_onchip_allocation
    from cannbotdsl.tensor import make_layout

    physical_shape, physical_stride = _physical_layout_spec(
        dtype, shape, data_format, n1_pad, mem_loc=mem_loc
    )
    if data_format == "nd" and physical_stride is None and stride is not None:
        physical_stride = stride
    logical_layout = (
        make_layout(shape) if stride is None
        else make_layout(shape, stride=stride)
    )
    physical_layout = (
        make_layout(physical_shape)
        if physical_stride is None
        else make_layout(physical_shape, stride=physical_stride)
    )
    raw_slots = _make_onchip_allocation(
        dtype,
        mem_loc,
        logical_layout,
        physical_layout,
        data_format=data_format,
        slots=depth,
        fixed_addr=fixed_addr,
    )
    for slot in raw_slots:
        unwrap_operand(slot).owner.attributes["cannir.infer_physical_layout"] = ir.UnitAttr.get()

    slots = []
    for index, memref in enumerate(raw_slots):
        value = unwrap_operand(memref)
        slot = cannir.ChannelSlotOp.build_generic(
            results=[value.type], operands=[value, resource],
            attributes={"slot": ir.IntegerAttr.get(ir.IntegerType.get_signless(64), index)},
        )
        slots.append(unwrap_operand(slot.results[0]))

    raw_op = cannir.MakeChannelOp.build_generic(
        operands=slots,
        attributes={"cannir.channel.kind": ir.IntegerAttr.get(
            ir.IntegerType.get_signless(32), int(kind))},
    )
    return raw_op.results[0], tuple(unwrap_operand(slot) for slot in raw_slots)


class Channel:
    """A depth-N slot pool with independent advancing cursors.

    ``produce()`` selects ``slots[write_cursor]`` and advances write_cursor;
    ``consume()`` does the same for read_cursor. Both start at zero whenever
    the declaration executes. Views apply to the selected Tensor.
    """

    def __init_subclass__(cls, **kwargs):
        del cls, kwargs
        raise TypeError("Channel is a sealed CANNBotDSL resource type")

    def __init__(self, mem_loc, shape=None, dtype=None, *, depth,
                 capacity=None,
                 kind=ChannelKind.SameCore,
                 addr=None,
                 stride=None, data_format=None, n1_pad=0):
        if dtype is None or shape is None:
            raise TypeError("Channel requires shape and dtype")
        # Validate an explicit address before creating resource IR.
        if addr is not None:
            if type(addr) is not int:
                raise TypeError(
                    "Channel addr must be a non-negative Python int or None, "
                    f"got {type(addr).__name__}"
                )
            if addr < 0:
                raise ValueError(
                    f"Channel addr must be non-negative, got {addr}"
                )
        from cannbotdsl.core.contracts.elements import normalize_storage_dtype
        from cannbotdsl.tensor import _infer_contiguous_stride

        dtype = normalize_storage_dtype(dtype)
        shape, capacity, has_dynamic_shape = _normalize_shape_capacity(
            shape, capacity, owner="Channel"
        )
        if stride is None:
            capacity_stride = _infer_contiguous_stride(capacity)
            has_dynamic_stride = False
        else:
            if not isinstance(stride, tuple):
                raise TypeError(
                    "Channel stride must be a flat tuple of non-negative ints"
                )
            if len(stride) != len(capacity):
                raise ValueError(
                    f"Channel stride rank {len(stride)} does not match shape "
                    f"rank {len(capacity)}"
                )
            has_dynamic_stride = False
            for index, value in enumerate(stride):
                if type(value) is int:
                    if value < -(1 << 63) or value >= (1 << 63):
                        raise OverflowError(
                            f"Channel stride[{index}] exceeds signed int64: {value}"
                        )
                    if value < 0:
                        raise ValueError(
                            f"Channel stride[{index}] must be non-negative, got {value}"
                        )
                    continue
                if isinstance(value, ir.Value):
                    # A Channel's backing stride is an internal layout
                    # contract.  Keep its canonical dynamic i64 sentinel for
                    # staged kernels; the public reinterpret() entry point
                    # rejects SSA strides before constructing a view.
                    value_type = value.type
                    if not (
                        isinstance(value_type, ir.IntegerType)
                        and value_type.width == 64
                        and value_type.is_signless
                    ):
                        raise TypeError(
                            f"Channel stride[{index}] SSA value must have "
                            f"canonical signless i64 type, got {value_type}"
                        )
                    has_dynamic_stride = True
                    continue
                else:
                    raise TypeError(
                        f"Channel stride[{index}] must be a non-negative Python "
                        f"int, got {type(value).__name__}"
                    )
            capacity_stride = stride
        if (has_dynamic_shape or shape != capacity) and has_dynamic_stride:
            raise TypeError(
                "Channel dynamic shape requires a static backing stride"
            )
        trace_state = _current_onchip_trace()
        if mem_loc == MemLoc.UB and trace_state._ub_space_root is not None:
            raise ValueError(
                "ordinary UB Channel is not allowed after dsl.UB.view(); "
                "construct it from static UB views with make_channel"
            )
        if mem_loc not in _CUBE_MEM_LOCS and mem_loc != MemLoc.UB:
            raise ValueError(f"unsupported mem_loc for channel: {mem_loc!r}")
        if type(depth) is not int:
            raise TypeError("Channel depth must be a positive compile-time Python int")
        if depth < 1:
            raise ValueError(f"Channel depth must be >= 1, got {depth}")
        is_cross_core = (kind == ChannelKind.CrossCore)
        if is_cross_core and depth > 8:
            raise ValueError(
                f"cross-core Channel depth must be <= 8, got {depth} "
                "(per-Channel select-chain policy; the allocation epoch has "
                "16 logical sync ids; see channel_design.md §7.5)"
            )
        self._kind = kind
        self._depth = depth
        self._mem_loc = mem_loc
        self._dtype = dtype
        self._shape = shape
        self._capacity = capacity
        self._has_dynamic_shape = has_dynamic_shape
        self._stride = capacity_stride
        if data_format is None:
            data_format = (
                "nz"
                if mem_loc in _CUBE_MEM_LOCS and mem_loc != MemLoc.BIAS
                else "nd"
            )
        self._data_format = data_format
        self._n1_pad = n1_pad

        self._resource = cannir.ChannelResourceOp.build_generic(
            results=[ir.NoneType.get()], operands=[]
        ).results[0]

        # Capacity fixes the storage of every slot. Each selected Tensor carries
        # this declaration's actual shape; callers express narrower accesses
        # with Tensor views, independently of later cursor advances.
        self._addr = addr
        root, self._slot_storage_values = _build_typed_channel_ir(
            mem_loc, dtype, capacity, kind, data_format, n1_pad,
            capacity_stride,
            addr, depth, self._resource,
        )
        self._root_ir_value = root
        self._layout_ir_value = root
        self._dynamic_tiler = None
        if has_dynamic_shape or shape != capacity:
            from cannbotdsl.tensor import reinterpret, make_tiler

            self._dynamic_tiler = make_tiler(shape)
            view = reinterpret(
                Tensor._from_ir(self._slot_storage_values[0]),
                shape=self._dynamic_tiler,
                stride=capacity_stride,
            )
            self._layout_ir_value = unwrap_operand(view)
            self._layout_ir_value.owner.attributes[
                "cannir.channel.declared_layout"
            ] = ir.UnitAttr.get()
        self._ir_value = root




    def _select(self, operation):
        from cannbotdsl.lang.vf import _current_vf_mode
        if _current_vf_mode() is not None:
            raise ValueError("Channel cursors must be advanced outside VF regions; pass a selected Tensor into the VF")
        slot = Tensor._from_ir(operation(self._root_ir_value).res)
        if self._dynamic_tiler is not None:
            from cannbotdsl.tensor import reinterpret

            slot = reinterpret(slot, shape=self._dynamic_tiler, stride=self._stride)
            unwrap_operand(slot).owner.attributes["cannir.declared_slot_layout"] = ir.UnitAttr.get()
        return slot

    def produce(self) -> Tensor:
        """Select the write slot, then advance the independent write cursor.

        The returned Tensor is an ordinary alias, not a snapshot or a lease.
        Selection neither accesses storage nor waits for another operation.
        """
        return self._select(cannir.ChannelProduceOp)

    def consume(self) -> Tensor:
        """Select the read slot, then advance the independent read cursor.

        No pairing or FIFO full/empty checks are performed. Both selected
        Tensors may be read, written, or updated in place.
        """
        return self._select(cannir.ChannelConsumeOp)







    @property
    def dtype(self):
        memref_ty = cannir.TensorType(self._ir_value.type.element)
        from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type

        return dtype_for_storage_mlir_type(
            cannir.PointerType(memref_ty.pointer).dtype
        )

    @property
    def layout(self):
        return cannir.extract_layout(self._layout_ir_value)

    @property
    def physical_layout(self):
        return cannir.extract_physical_layout(self._layout_ir_value)

    @property
    def shape(self):
        return self.layout.shape

    @property
    def stride(self):
        return self.layout.stride

    @property
    def physical_shape(self):
        return self.physical_layout.shape

    @property
    def physical_stride(self):
        return self.physical_layout.stride




    @property
    def memloc(self):
        return cannir.PointerType(cannir.TensorType(self._ir_value.type.element).pointer).memloc

    @property
    def layout_map_kind(self):
        from cannbotdsl.tensor import LayoutMapKind

        return LayoutMapKind(cannir.TensorType(self._ir_value.type.element).layout_map_kind)

    @property
    def logical_format(self):
        self.layout_map_kind
        return "nd"

    @property
    def physical_format(self):
        from cannbotdsl.tensor import _physical_format_for_map

        return _physical_format_for_map(self.layout_map_kind)

    @property
    def data_format(self):
        return self.physical_format

    @property
    def depth(self):
        return self._ir_value.type.depth

    @property
    def is_cross_core(self):
        return self._ir_value.type.kind == int(ChannelKind.CrossCore)

    def __repr__(self):
        return (f"Channel({self.memloc}, {self.shape}, {self.dtype}, "
                f"depth={self.depth})")


def make_channel(views, *, dtype=None, kind=None):
    """Create a Channel whose slots are unbound static UB-space views.

    Slots may have different origins, but must have identical Tensor types.
    Buffer-to-Channel ownership transfer is outside the first version.
    """
    from cannbotdsl.buffer import (
        _ensure_static_view,
        _find_ub_root,
        _has_bound_resource,
    )

    if kind is None:
        kind = ChannelKind.SameCore
    if kind not in (ChannelKind.SameCore, ChannelKind.CrossCore):
        raise ValueError("make_channel kind must be SameCore or CrossCore")
    if not isinstance(views, (list, tuple)) or not views:
        raise ValueError("make_channel requires a non-empty list or tuple of views")
    if kind == ChannelKind.CrossCore and len(views) > 8:
        raise ValueError("cross-core Channel depth must be <= 8")
    slots = []
    for view in views:
        if not isinstance(view, Tensor) or _find_ub_root(view) is None:
            raise ValueError("make_channel requires views derived from dsl.UB.view()")
        if _has_bound_resource(view):
            raise ValueError("make_channel requires unbound views; Buffer ownership transfer is not supported")
        if dtype is not None:
            from cannbotdsl.core.contracts.elements import normalize_storage_dtype

            target = normalize_storage_dtype(dtype)
            if view.dtype != target:
                view = view.view(dtype=target)
        _ensure_static_view(view)
        if slots and unwrap_operand(view).type != unwrap_operand(slots[0]).type:
            raise ValueError("make_channel slots must have identical dtype, shape, stride and layout")
        slots.append(view)

    _current_onchip_trace()
    ch = object.__new__(Channel)
    ch._kind = kind
    ch._depth = len(slots)
    ch._mem_loc = MemLoc.UB
    ch._dtype = slots[0].dtype
    ch._shape = ch._capacity = slots[0].shape
    ch._stride = slots[0].stride
    ch._has_dynamic_shape = False
    ch._data_format = "nd"
    ch._n1_pad = 0
    ch._addr = None
    ch._resource = cannir.ChannelResourceOp.build_generic(
        results=[ir.NoneType.get()], operands=[]
    ).results[0]
    ch._slot_storage_values = tuple(unwrap_operand(slot) for slot in slots)
    bound = []
    for index, slot in enumerate(slots):
        marker = cannir.ChannelSlotOp.build_generic(
            results=[unwrap_operand(slot).type], operands=[unwrap_operand(slot), ch._resource],
            attributes={"slot": ir.IntegerAttr.get(ir.IntegerType.get_signless(64), index),
                        "cannir.buffer.explicit_binding": ir.UnitAttr.get()},
        ).results[0]
        bound.append(unwrap_operand(marker))
    op = cannir.MakeChannelOp.build_generic(operands=bound, attributes={
        "cannir.channel.kind": ir.IntegerAttr.get(ir.IntegerType.get_signless(32), int(kind))})
    ch._ir_value = ch._root_ir_value = ch._layout_ir_value = op.results[0]
    ch._dynamic_tiler = None
    ch._ub_space_slots = True
    return ch
