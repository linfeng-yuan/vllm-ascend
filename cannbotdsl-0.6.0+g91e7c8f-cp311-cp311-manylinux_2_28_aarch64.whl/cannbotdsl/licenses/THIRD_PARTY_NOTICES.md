# Third-party notices

CANNBotDSL wheels embed selected components from LLVM/MLIR 19.1.7. LLVM is licensed under Apache
License 2.0 with LLVM Exceptions. The complete text is included in
`LICENSES/LLVM-Apache-2.0-WITH-LLVM-exception.txt` and in the installed `cannbotdsl/licenses`
directory.

The native Python glue uses pybind11 2.11.1 headers. pybind11 is licensed under the BSD 3-Clause
License; its complete license text is included as `LICENSES/pybind11-BSD-3-Clause.txt` and in the
installed `cannbotdsl/licenses` directory.

The framework-independent tensor exchange extension includes the DLPack 1.0 C ABI declarations.
DLPack is licensed under the Apache License 2.0; its license text is included as
`LICENSES/DLPack-Apache-2.0.txt` and in the installed `cannbotdsl/licenses` directory.

The wheel is intentionally limited to the LLVM/MLIR libraries required for the MLIR Python core,
arith/func/scf dialect wrappers, CANNIR transforms, and AscendC translation. The CANN SDK, Bisheng,
CANN runtime libraries, drivers, PyTorch, and torch_npu are not copied into or redistributed by the
wheel.

The CANNBotDSL distribution remains governed by the CANN Open Software License Agreement Version 2.0
in the repository root `LICENSE`.
