# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software and is made available under the terms and
# conditions of CANN Open Software License Agreement Version 2.0 (the "License).
# See LICENSE for the full text of the License.

"""bisheng toolchain integration for AICPU kernels.

Compile chain for the CANN 9.2 baseline:

* device:  bisheng -x aicpu  (+ --cce-aicpu-launch-with-interface for the
  struct-by-value launch ABI; legacy single-pointer mode omits the flag)
* shim:    bisheng -x asc --npu-arch=<arch> (same interface flag)
* link:    bisheng -shared --npu-arch=<arch>
* x86:     system c++ (portable body cross-check, no CANN needed)

Flag spelling matters: ``--cce-aicpu-L<dir>`` concatenates while
``--cce-aicpu-sysroot=<dir>`` uses ``=``.
"""

from __future__ import annotations

import ctypes
import os
import shutil
import subprocess

from cannbotdsl.aicpu.types import GmFieldType
from cannbotdsl.core.toolchain.ascendc import resolve_bisheng


def _run(cmd, *, env=None, cwd=None):
    proc = subprocess.run(cmd, capture_output=True, text=True, env=env, cwd=cwd)
    if proc.returncode != 0:
        failed = " ".join(str(c) for c in cmd)
        raise RuntimeError(
            f"command failed ({proc.returncode}):\n{failed}\n"
            f"stdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
        )
    return proc


def _ascend_home():
    if os.environ.get("ASCEND_HOME_PATH"):
        return os.environ["ASCEND_HOME_PATH"]
    import glob

    for cand in sorted(glob.glob(os.path.expanduser("~/Ascend/cann-*")), reverse=True):
        home = os.path.join(cand, os.uname().machine + "-linux")
        if os.path.isdir(home):
            return home
    raise RuntimeError(
        "cannot locate CANN: set ASCEND_HOME_PATH or install under ~/Ascend/cann-*"
    )


class AicpuToolchain:
    def __init__(self, npu_arch: str = "dav-3510", launch_mode: str = "interface"):
        self.npu_arch = npu_arch
        self.launch_mode = launch_mode
        res = resolve_bisheng(required=True)
        self.bisheng = res.path
        self.ascend_home = _ascend_home()
        self.toolkit = self._toolkit_root()

    def _toolkit_root(self):
        home = os.path.abspath(self.ascend_home)
        for _ in range(3):
            cand = os.path.join(home, "toolkit", "toolchain", "hcc")
            if os.path.isdir(cand):
                return os.path.dirname(os.path.dirname(os.path.dirname(cand)))
            home = os.path.dirname(home)
        raise RuntimeError(f"cannot locate toolkit/toolchain/hcc under {self.ascend_home}")

    def aicpu_compile_flags(self):
        asc = self.toolkit
        home = self.ascend_home
        flags = [
            "-O2",
            "-c",
            "-std=c++17",
            "-D_GLIBCXX_USE_CXX11_ABI=0",
            f"-I{home}/asc/include/aicpu_api",
            f"--cce-aicpu-L{home}/lib64/device/lib64",
            "--cce-aicpu-laicpu_api",
            f"--cce-aicpu-sysroot={asc}/toolkit/toolchain/hcc/sysroot",
            "-isystem",
            f"{asc}/toolkit/toolchain/hcc/aarch64-target-linux-gnu/include",
            "-isystem",
            f"{asc}/toolkit/toolchain/hcc/aarch64-target-linux-gnu/include/c++/7.3.0",
            "-isystem",
            f"{asc}/toolkit/toolchain/hcc/aarch64-target-linux-gnu/include/c++/7.3.0/aarch64-target-linux-gnu",
            "-isystem",
            f"{asc}/toolkit/toolchain/hcc/aarch64-target-linux-gnu/include/c++/7.3.0/backward",
        ]
        if self.launch_mode == "interface":
            flags.append("--cce-aicpu-launch-with-interface")
        return flags

    def compile_kernel_obj(self, src, out):
        _run([self.bisheng, *self.aicpu_compile_flags(), "-o", out, "-x", "aicpu", src])

    def compile_shim_obj(self, src, out):
        # The interface flag also governs how the <<<>>> launch stub parses
        # kernel declarations in the host shim; single-pointer legacy kernels
        # launch fine under it too (verified locally and on 8P), so it is
        # always passed here.
        _run(
            [
                self.bisheng,
                "-fPIC",
                f"--npu-arch={self.npu_arch}",
                "-c",
                "-O3",
                "--cce-aicpu-launch-with-interface",
                "-x",
                "asc",
                src,
                "-o",
                out,
            ]
        )

    def link_so(self, objs, out_so):
        _run(
            [self.bisheng, "-shared", "-fPIC", f"--npu-arch={self.npu_arch}", "-o", out_so, *objs, "-lm"]
        )


def compile_x86(kernel, workdir: str) -> str:
    """Compile the portable body as a host x86 .so for golden cross-checks."""
    name = kernel.fn.__name__
    src = os.path.join(workdir, f"{name}_x86.cpp")
    out = os.path.join(workdir, f"{name}_x86.so")
    compiler = shutil.which("c++") or shutil.which("g++")
    if compiler is None:
        raise RuntimeError("no host c++/g++ found for the x86 cross-check build")
    _run([compiler, "-O2", "-shared", "-fPIC", "-o", out, src])
    return out


def compile_aicpu_kernel(
    kernel, *, workdir: str, launch_mode: str, npu_arch: str = "dav-3510", build_x86: bool = False
):
    """Generate sources, compile device+shim, link the launchable .so."""
    name = kernel.fn.__name__
    workdir = os.path.abspath(workdir)
    os.makedirs(workdir, exist_ok=True)
    files = kernel.generate_sources(name=name, launch_mode=launch_mode)
    for fname, text in files.items():
        with open(os.path.join(workdir, fname), "w", encoding="utf-8") as f:
            f.write(text)

    tc = AicpuToolchain(npu_arch=npu_arch, launch_mode=launch_mode)
    kernel_obj = os.path.join(workdir, f"{name}_kernel.o")
    shim_obj = os.path.join(workdir, f"{name}_shim.o")
    so_path = os.path.join(workdir, f"{name}.so")
    tc.compile_kernel_obj(os.path.join(workdir, f"{name}_kernel.aicpu"), kernel_obj)
    tc.compile_shim_obj(os.path.join(workdir, f"{name}_shim.asc"), shim_obj)
    tc.link_so([kernel_obj, shim_obj], so_path)
    x86_so = compile_x86(kernel, workdir) if build_x86 else None
    return CompiledAicpuKernel(
        so_path, kernel.spec, name=name, launch_mode=launch_mode, x86_so_path=x86_so
    )


class CompiledAicpuKernel:
    def __init__(self, so_path, spec, *, name, launch_mode, x86_so_path=None):
        self.so_path = so_path
        self.spec = spec
        self.name = name
        self.launch_mode = launch_mode
        self.x86_so_path = x86_so_path
        self._lib = None
        self._x86_lib = None

    def _ctypes_fields(self):
        out = []
        for _fname, ann in self.spec.fields:
            if isinstance(ann, GmFieldType):
                out.append(ctypes.c_uint64)
            else:
                out.append(ann.ctypes_type)
        return out

    def launch(self, stream_handle: int, **kwargs):
        """Launch on the given raw stream.

        interface mode: one flat argument per args field (GM fields are device
        addresses). legacy mode: a single ``param_addr`` device address that
        already holds the packed args struct bytes.
        """
        if self._lib is None:
            self._lib = ctypes.CDLL(self.so_path)
        entry = getattr(self._lib, f"{self.name}_do")
        entry.restype = None
        if self.launch_mode == "legacy":
            entry.argtypes = [ctypes.c_void_p, ctypes.c_uint64]
            entry(ctypes.c_void_p(stream_handle), ctypes.c_uint64(int(kwargs["param_addr"])))
            return 0
        entry.argtypes = [ctypes.c_void_p, *self._ctypes_fields()]
        args = []
        for fname, ann in self.spec.fields:
            v = kwargs.get(fname, 0) if isinstance(ann, GmFieldType) else kwargs[fname]
            ct = ctypes.c_uint64 if isinstance(ann, GmFieldType) else ann.ctypes_type
            args.append(ct(int(v)))
        entry(ctypes.c_void_p(stream_handle), *args)
        return 0

    def run_x86(self, **kwargs):
        """Run the portable body on host x86; GM fields are host buffers."""
        if self.x86_so_path is None:
            raise RuntimeError("kernel was not built with build_x86=True")
        if self._x86_lib is None:
            self._x86_lib = ctypes.CDLL(self.x86_so_path)
        entry = getattr(self._x86_lib, f"{self.name}_run_x86")
        entry.argtypes = self._ctypes_fields()
        entry.restype = ctypes.c_int64
        args = []
        for fname, ann in self.spec.fields:
            v = kwargs[fname]
            if isinstance(ann, GmFieldType):
                buf = (ctypes.c_char * 0).from_buffer(bytearray(0)) if False else None
                addr = getattr(v, "x86_addr", None)
                if addr is None:
                    arr = getattr(v, "x86_buffer", None)
                    if arr is None:
                        raise RuntimeError(
                            f"x86 run needs an X86Buffer for GM field {fname!r}"
                        )
                    addr = ctypes.addressof(arr.data)
                args.append(ctypes.c_uint64(int(addr)))
            else:
                args.append(ann.ctypes_type(int(v)))
        return entry(*args)
