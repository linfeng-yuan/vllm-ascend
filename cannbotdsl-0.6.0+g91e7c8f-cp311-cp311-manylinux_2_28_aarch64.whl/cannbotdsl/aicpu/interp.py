# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software and is made available under the terms and
# conditions of CANN Open Software License Agreement Version 2.0 (the "License").
# See LICENSE for the full text of the License.

"""Dual-mode AST interpreter for AICPU tiling kernels (Phase-1).

One traced Python program, two backends:

* ``cpp``  — walks the function AST and emits portable scalar C++
  (``int64_t`` arithmetic, ``AArr<T>`` arrays, plain structs, one C++
  function per Python helper specialized at its call sites).
* ``host`` — executes the very same AST with Python values, numpy-backed GM
  views and Python lists, producing the golden reference for on-device runs.

Supported subset (violations raise ``AicpuTraceError`` with the Python line):

* statements: Assign (name/tuple/subscript/struct-field), AugAssign, AnnAssign,
  If, While (incl. ``while True`` + break), For over range/static lists/traced
  arrays, Break, Continue, Return (single value or bare), Expr, Pass, ClassDef
  (annotation-only struct), Assert (ignored)
* expressions: int64 arithmetic (``//`` emits C++ ``/``; requires non-negative
  operands, matching the reference algorithms), comparisons, short-circuit
  and/or, ternary, subscripts, struct/args field access, calls to module-level
  helpers, ``min``/``max``/``abs``/``ceil_div``/``floor_div_safe`` builtins,
  ``array``/``zeros`` allocators, array methods ``append``/``reset``,
  ``dbp`` device printf
* struct/array creation must be a direct top-level assignment
"""

from __future__ import annotations

import ast
import inspect
import types

INT64_MIN = -(2**63)
INT64_MAX = 2**63 - 1


class AicpuTraceError(Exception):
    pass


def _err(node, msg):
    line = getattr(node, "lineno", "?")
    raise AicpuTraceError(f"[line {line}] {msg}")


# ---------------------------------------------------------------------------
# cpp-mode traced values
# ---------------------------------------------------------------------------


class CVal:
    """Traced int64 scalar (expression string)."""

    __slots__ = ("expr",)

    def __init__(self, expr: str) -> None:
        self.expr = f"({expr})"


class CPtrView:
    """Traced GM pointer (args-struct field or function parameter)."""

    __slots__ = ("expr", "elem", "mutable")

    def __init__(self, expr, elem, mutable) -> None:
        self.expr = expr
        self.elem = elem
        self.mutable = mutable


class CArrRef:
    """Reference to an ``AArr<T>``: value (``.``) or pointer (``->``)."""

    __slots__ = ("expr", "elem", "is_pointer")

    def __init__(self, expr, elem, is_pointer: bool) -> None:
        self.expr = expr
        self.elem = elem
        self.is_pointer = is_pointer

    @property
    def data(self) -> str:
        return f"{self.expr}->data" if self.is_pointer else f"{self.expr}.data"

    @property
    def ln(self) -> str:
        return f"{self.expr}->len" if self.is_pointer else f"{self.expr}.len"


class StructFieldDef:
    __slots__ = ("name", "kind", "payload", "default")

    def __init__(self, name, kind, payload, default=0) -> None:
        self.name = name
        self.kind = kind  # "scalar" | "array" | "struct"
        self.payload = payload  # None | CScalarType | StructDef
        self.default = default


class StructDef:
    def __init__(self, cname: str) -> None:
        self.cname = cname
        self.fields: list = []

    def decl(self) -> str:
        lines = [f"struct {self.cname} {{"]
        for f in self.fields:
            if f.kind == "scalar":
                lines.append(f"    int64_t {f.name};")
            elif f.kind == "array":
                lines.append(f"    AArr<{f.payload.cname}> {f.name};")
            else:
                lines.append(f"    {f.payload.cname} {f.name};")
        lines.append("};")
        return "\n".join(lines)


class CStructVal:
    __slots__ = ("expr", "sdef", "is_pointer")

    def __init__(self, expr, sdef: StructDef, is_pointer: bool) -> None:
        self.expr = expr
        self.sdef = sdef
        self.is_pointer = is_pointer

    def acc(self, field: str) -> str:
        return f"{self.expr}->{field}" if self.is_pointer else f"{self.expr}.{field}"

    def field_def(self, name, node):
        for f in self.sdef.fields:
            if f.name == name:
                return f
        _err(node, f"struct {self.sdef.cname} has no field {name!r}")


class ArgsWrapper:
    """Entry kernel parameter bound to the args struct pointer."""

    __slots__ = ("cname", "spec")

    def __init__(self, cname: str, spec) -> None:
        self.cname = cname
        self.spec = spec

    def field_ann(self, name, node):
        for fname, ann in self.spec.fields:
            if fname == name:
                return ann
        _err(node, f"args struct has no field {name!r}")


def _is_gm_ann(ann) -> bool:
    return type(ann).__name__ == "GmFieldType"


# ---------------------------------------------------------------------------
# host-mode values
# ---------------------------------------------------------------------------


class HostView:
    __slots__ = ("array", "elem")

    def __init__(self, array, elem) -> None:
        self.array = array
        self.elem = elem


class HostArr:
    __slots__ = ("data", "elem")

    def __init__(self, data: list, elem) -> None:
        self.data = data
        self.elem = elem


class HostStruct:
    __slots__ = ("sdef", "fields")

    def __init__(self, sdef: StructDef) -> None:
        self.sdef = sdef
        self.fields = {}
        for f in sdef.fields:
            if f.kind == "scalar":
                self.fields[f.name] = f.default
            elif f.kind == "array":
                self.fields[f.name] = HostArr([], f.payload)
            else:
                self.fields[f.name] = HostStruct(f.payload)


class HostArgs:
    __slots__ = ("fields",)

    def __init__(self, fields) -> None:
        self.fields = fields


# ---------------------------------------------------------------------------
# interpreter
# ---------------------------------------------------------------------------

_BINOPS = {
    ast.Add: "+",
    ast.Sub: "-",
    ast.Mult: "*",
    ast.FloorDiv: "/",
    ast.Mod: "%",
    ast.LShift: "<<",
    ast.RShift: ">>",
    ast.BitAnd: "&",
    ast.BitOr: "|",
    ast.BitXor: "^",
}

_CMPOPS = {
    ast.Eq: "==",
    ast.NotEq: "!=",
    ast.Lt: "<",
    ast.LtE: "<=",
    ast.Gt: ">",
    ast.GtE: ">=",
}


class _Return(Exception):
    def __init__(self, value=None) -> None:
        self.value = value


class _Break(Exception):
    pass


class _Continue(Exception):
    pass


class Interp:
    def __init__(self, entry_fn, *, host: bool) -> None:
        self.host = host
        self.entry_fn = entry_fn
        self.globals = entry_fn.__globals__
        self.lines: list[str] = []
        self.indent = 0
        self.tmp = 0
        self.chunks: list[str] = []
        self.func_memo: dict = {}
        self.cname_counts: dict = {}
        self.struct_defs: dict = {}  # python class name -> StructDef

    # -- emission helpers ---------------------------------------------------
    def w(self, text: str) -> None:
        self.lines.append("    " * self.indent + text)

    def fresh(self, prefix: str) -> str:
        self.tmp += 1
        return f"_{prefix}{self.tmp}"

    def unique_cname(self, base: str) -> str:
        n = self.cname_counts.get(base, 0)
        self.cname_counts[base] = n + 1
        return base if n == 0 else f"{base}_v{n + 1}"

    # -- entry points -------------------------------------------------------
    def run_cpp_entry(self, spec) -> str:
        node = self._fn_ast(self.entry_fn)
        if len(node.args.args) != 1:
            _err(node, "kernel entry takes exactly one args parameter")
        self._compile_function(
            node,
            [ArgsWrapper("a", spec)],
            cname=f"{self.entry_fn.__name__}_body",
            ret="int64_t",
        )
        prelude = [
            "template <typename T> struct AArr { T* data; int64_t len; int64_t cap; };",
            "static uint8_t g_arena[1 << 22];",
            "static int64_t g_arena_off = 0;",
            "static void* arena_alloc(int64_t bytes) {",
            "    int64_t base = (g_arena_off + 15) & ~int64_t(15);",
            "    g_arena_off = base + bytes;",
            "    return g_arena + base;",
            "}",
        ]
        return "\n".join(prelude) + "\n" + "\n".join(self.chunks)

    def run_host_entry(self, spec, kwargs: dict):
        node = self._fn_ast(self.entry_fn)
        fields = {}
        for name, ann in spec.fields:
            if name not in kwargs:
                raise AicpuTraceError(f"missing host arg {name!r}")
            v = kwargs[name]
            if _is_gm_ann(ann):
                fields[name] = HostView(v, ann.elem)
            else:
                fields[name] = int(v)
        scope = {node.args.args[0].arg: HostArgs(fields)}
        try:
            self.st_block(node.body, scope)
        except _Return as r:
            return r.value
        return 0

    def _fn_ast(self, fn) -> ast.FunctionDef:
        src = inspect.getsource(fn)
        tree = ast.parse(src)
        matches = [
            n
            for n in ast.walk(tree)
            if isinstance(n, ast.FunctionDef) and n.name == fn.__name__
        ]
        if len(matches) == 1:
            return matches[0]
        if matches:
            return matches[0]
        raise AicpuTraceError(f"cannot locate AST for {fn.__name__!r}")

    # -- function compilation (cpp) ------------------------------------------
    def _sig_key(self, vals):
        parts = []
        for v in vals:
            if isinstance(v, (bool, int)):
                parts.append("i")
            elif isinstance(v, CVal):
                parts.append("i")
            elif isinstance(v, CPtrView):
                parts.append(f"p{v.elem.cname}{int(v.mutable)}")
            elif isinstance(v, CArrRef):
                parts.append(f"a{v.elem.cname}")
            elif isinstance(v, CStructVal):
                parts.append(f"s{v.sdef.cname}")
            elif isinstance(v, ArgsWrapper):
                parts.append(f"A{v.spec.name}")
            else:
                _err(None, f"unsupported argument kind {type(v).__name__}")
        return "|".join(parts)

    def compile_user_call(self, fn, vals, node):
        if not isinstance(fn, types.FunctionType):
            _err(node, "cannot call a non-function in traced code")
        key = (id(fn), self._sig_key(vals))
        if key in self.func_memo:
            return self.func_memo[key]
        fnnode = self._fn_ast(fn)
        cname = self.unique_cname(fn.__name__)
        ret = self._infer_ret(fnnode)
        saved = (self.lines, self.indent)
        self.lines, self.indent = [], 0
        try:
            self._compile_function(fnnode, vals, cname=cname, ret=ret)
        finally:
            self.lines, self.indent = saved
        self.func_memo[key] = (cname, ret)
        return cname, ret

    def _infer_ret(self, node):
        rets = [n for n in ast.walk(node) if isinstance(n, ast.Return)]
        if not rets:
            return "void"
        if any(r.value is None for r in rets):
            if any(r.value is not None for r in rets):
                _err(node, f"{node.name}: mixed value/bare returns are unsupported")
            return "void"
        return "int64_t"

    def _compile_function(self, node, arg_vals, *, cname, ret):
        params = []
        scope = {}
        for arg, val in zip(node.args.args, arg_vals):
            nm = arg.arg
            if isinstance(val, (bool, int, CVal)):
                params.append(f"int64_t {nm}")
                scope[nm] = CVal(nm)
            elif isinstance(val, CPtrView):
                const = "" if val.mutable else "const "
                params.append(f"{const}{val.elem.cname}* {nm}")
                scope[nm] = CPtrView(nm, val.elem, val.mutable)
            elif isinstance(val, CArrRef):
                params.append(f"AArr<{val.elem.cname}>* {nm}")
                scope[nm] = CArrRef(nm, val.elem, True)
            elif isinstance(val, CStructVal):
                params.append(f"{val.sdef.cname}* {nm}")
                scope[nm] = CStructVal(nm, val.sdef, True)
            elif isinstance(val, ArgsWrapper):
                params.append(f"const {val.spec.name}* {nm}")
                scope[nm] = ArgsWrapper(nm, val.spec)
            else:
                _err(node, f"unsupported parameter for {nm!r}")
        locals_scan = self._scan_locals(node, scope)
        decls = []
        for nm, kind, payload in locals_scan:
            if nm in scope:
                continue
            if kind == "scalar":
                decls.append(f"int64_t {nm} = 0;")
                scope[nm] = CVal(nm)
        body_lines = []
        try:
            self.st_block(node.body, scope)
        except _Return:
            pass
        body_lines = self.lines
        self.lines = []
        head = f"{ret} {cname}({', '.join(params)})\n{{"
        parts = [head]
        parts.extend(decls)
        parts.extend(body_lines)
        parts.append("}")
        self.emit_chunk("\n".join(parts) + "\n")

    def emit_chunk(self, text: str) -> None:
        self.chunks.append(text)

    # ordered env-inference scan: [(name, kind, payload)]
    def _scan_locals(self, node, bound_scope):
        env: dict = {}
        order: list = []
        seen: set = set()

        def add(nm, kind, payload=None):
            if nm in bound_scope:
                return
            if nm in seen:
                if env[nm] != kind:
                    _err(node, f"variable {nm!r} changes kind across the function")
                return
            seen.add(nm)
            env[nm] = kind
            order.append((nm, kind, payload))

        def classify(value, scope_names):
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name):
                callee = value.func.id
                if callee in ("array", "zeros"):
                    return ("array", None)
                if callee in local_classes or callee in self.struct_defs:
                    return ("struct", callee)
                return ("scalar", None)
            if isinstance(value, ast.Name) and value.id in env:
                kind = env[value.id]
                return (kind, None)
            return ("scalar", None)

        local_classes: set = set()
        for n in ast.walk(node):
            if isinstance(n, ast.ClassDef):
                local_classes.add(n.name)

        class V(ast.NodeVisitor):
            def __init__(self, outer):
                self.outer = outer

            def visit_FunctionDef(self, n):
                return

            visit_AsyncFunctionDef = visit_FunctionDef

            def visit_ClassDef(self, n):
                return

            def visit_Lambda(self, n):
                return

            def _target(self, t, value):
                if isinstance(t, ast.Name):
                    kind, payload = classify(value, None)
                    add(t.id, kind, payload)
                elif isinstance(t, ast.Tuple):
                    for e in t.elts:
                        self._target(e, None)

            def visit_Assign(self, n):
                for t in n.targets:
                    self._target(t, n.value)
                self.generic_visit(n)

            def visit_AnnAssign(self, n):
                if n.value is not None:
                    self._target(n.target, n.value)
                self.generic_visit(n)

            def visit_AugAssign(self, n):
                if isinstance(n.target, ast.Name):
                    add(n.target.id, "scalar", None)
                self.generic_visit(n)

            def visit_For(self, n):
                if isinstance(n.target, ast.Name):
                    add(n.target.id, "scalar", None)
                self.generic_visit(n)

        V(self).visit(node)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for stmt in node.body:
                V(self).visit(stmt)
        return order

    def _is_global_struct_class(self, name):
        g = self.globals.get(name)
        return isinstance(g, type) and g.__name__ in self.struct_defs

    # -- statements -----------------------------------------------------------
    def st_block(self, body, scope):
        for st in body:
            self.st(st, scope)

    def st(self, node, scope):
        method = getattr(self, "st_" + type(node).__name__, None)
        if method is None:
            _err(node, f"unsupported statement {type(node).__name__}")
        method(node, scope)

    def st_Pass(self, node, scope):
        pass

    def st_Assert(self, node, scope):
        pass

    def st_Expr(self, node, scope):
        if isinstance(node.value, ast.Call):
            self.ev_call(node.value, scope, want_value=False)
        else:
            self.ev(node.value, scope)

    def st_ClassDef(self, node, scope):
        sdef = StructDef(node.name)
        for stmt in node.body:
            if not isinstance(stmt, ast.AnnAssign):
                _err(stmt, "struct class body supports only annotated fields")
            fname = stmt.target.id
            kind, payload, default = "scalar", None, 0
            ann = stmt.annotation
            if isinstance(ann, ast.Call) and isinstance(ann.func, ast.Name) and ann.func.id == "array":
                if len(ann.args) != 1 or not isinstance(ann.args[0], ast.Name):
                    _err(ann, "array(...) field annotation takes one type name")
                elem = self._lookup_type(ann.args[0].id, ann)
                kind, payload = "array", elem
            elif isinstance(ann, ast.Subscript):
                base = ast.unparse(ann.value)
                if base != "array":
                    _err(ann, "only array[T] field annotations are supported")
                elem_name = ann.slice.id if isinstance(ann.slice, ast.Name) else None
                elem = self._lookup_type(elem_name, ann)
                kind, payload = "array", elem
            elif (
                isinstance(ann, ast.Name)
                and ann.id in self.struct_defs
            ):
                kind, payload = "struct", self.struct_defs[ann.id]
            else:
                if stmt.value is not None:
                    v = self.ev(stmt.value, scope)
                    if isinstance(v, CVal) or not isinstance(v, (int, bool)):
                        _err(stmt, "struct field default must be a compile-time int")
                    default = int(v)
            sdef.fields.append(StructFieldDef(fname, kind, payload, default))
        if node.name in self.struct_defs:
            _err(node, f"struct class {node.name!r} defined twice")
        self.struct_defs[node.name] = sdef
        self.emit_chunk(sdef.decl() + "\n")
        scope[node.name] = ("structclass", sdef)

    def _lookup_type(self, name, node):
        g = self.globals.get(name)
        if type(g).__name__ != "CScalarType":
            _err(node, f"unknown element type {name!r}")
        return g

    def st_Assign(self, node, scope):
        value_node = node.value
        if isinstance(value_node, ast.Call) and isinstance(value_node.func, ast.Name):
            callee = value_node.func.id
            if callee in ("array", "zeros"):
                for t in node.targets:
                    self._exec_array_alloc(t, value_node, scope)
                return
            target_cls = None
            if callee in self.struct_defs:
                target_cls = self.struct_defs[callee]
            if target_cls is not None:
                for t in node.targets:
                    self._exec_struct_alloc(t, target_cls, scope)
                return
        val = self.ev(value_node, scope)
        for t in node.targets:
            self._store(t, val, scope)

    def st_AnnAssign(self, node, scope):
        if node.value is None:
            nm = node.target.id
            if nm not in scope:
                self.w(f"int64_t {nm} = 0;")
                scope[nm] = CVal(nm)
            return
        val = self.ev(node.value, scope)
        self._store(node.target, val, scope)

    def st_AugAssign(self, node, scope):
        target = node.target
        if isinstance(target, ast.Name):
            nm = target.id
            if nm not in scope:
                _err(node, f"augmented assignment to undeclared {nm!r}")
            rhs = self._binop(node.op, scope[nm], self.ev(node.value, scope), node)
            self._store(target, rhs, scope)
            return
        if isinstance(target, ast.Subscript):
            base = self.ev(target.value, scope)
            idx = self.ev(target.slice, scope)
            cur = self._load_subscript(base, idx, node)
            rhs = self._binop(node.op, cur, self.ev(node.value, scope), node)
            self._store_subscript(base, idx, rhs, node)
            return
        if isinstance(target, ast.Attribute):
            obj = self.ev(target.value, scope)
            cur = self._field_get(obj, target.attr, node)
            rhs = self._binop(node.op, cur, self.ev(node.value, scope), node)
            self._store_field(obj, target.attr, rhs, node)
            return
        _err(node, "unsupported augmented assignment target")

    def _load_subscript(self, base, idx, node):
        if self.host:
            if isinstance(base, HostView):
                return int(base.array[int(idx)])
            if isinstance(base, HostArr):
                return int(base.data[int(idx)])
            if isinstance(base, list):
                return int(base[int(idx)])
        if isinstance(base, CPtrView):
            return CVal(f"(int64_t){base.expr}[(int64_t){self._cx(idx)}]")
        if isinstance(base, CArrRef):
            return CVal(f"(int64_t){base.data}[(int64_t){self._cx(idx)}]")
        _err(node, "unsupported subscript load")

    def _store(self, target, val, scope):
        if isinstance(target, ast.Name):
            nm = target.id
            if self.host:
                scope[nm] = val
                return
            if isinstance(val, CVal):
                if nm not in scope:
                    _err(target, f"assignment to undeclared variable {nm!r}")
                self.w(f"{nm} = {val.expr};")
                scope[nm] = CVal(nm)
            elif isinstance(val, (bool, int)):
                if nm not in scope:
                    _err(target, f"assignment to undeclared variable {nm!r}")
                self.w(f"{nm} = {self._cx(val)};")
                scope[nm] = CVal(nm)
            elif isinstance(val, CStructVal) and not val.is_pointer:
                if nm not in scope:
                    _err(target, f"struct assignment to undeclared {nm!r}")
                self.w(f"{nm} = {val.expr};")
                scope[nm] = CStructVal(nm, val.sdef, False)
            else:
                _err(target, f"cannot assign value of kind {type(val).__name__}")
            return
        if isinstance(target, ast.Tuple):
            if not isinstance(val, tuple):
                _err(target, "cannot unpack non-tuple")
            if len(val) != len(target.elts):
                _err(target, "arity mismatch in unpack")
            for t, v in zip(target.elts, val):
                self._store(t, v, scope)
            return
        if isinstance(target, ast.Subscript):
            base = self.ev(target.value, scope)
            idx = self.ev(target.slice, scope)
            self._store_subscript(base, idx, val, target)
            return
        if isinstance(target, ast.Attribute):
            obj = self.ev(target.value, scope)
            self._store_field(obj, target.attr, val, target)
            return
        _err(target, "unsupported assignment target")

    def _store_subscript(self, base, idx, val, node):
        if self.host:
            if isinstance(base, HostView):
                base.array[int(idx)] = int(val)
                return
            if isinstance(base, HostArr):
                base.data[int(idx)] = int(val)
                return
            if isinstance(base, list):
                base[int(idx)] = int(val)
                return
            _err(node, "unsupported subscript store")
        if isinstance(base, CPtrView):
            if not base.mutable:
                _err(node, "store into a read-only GM view")
            self.w(
                f"{base.expr}[(int64_t){self._cx(idx)}] = ({base.elem.cname}){self._cx(val)};"
            )
            return
        if isinstance(base, CArrRef):
            self.w(
                f"{base.data}[(int64_t){self._cx(idx)}] = ({base.elem.cname}){self._cx(val)};"
            )
            return
        _err(node, "unsupported subscript store")

    def _store_field(self, obj, attr, val, node):
        if self.host:
            if isinstance(obj, HostStruct):
                obj.fields[attr] = val
                return
            if isinstance(obj, HostArgs):
                _err(node, "kernel args are read-only")
            _err(node, "unsupported field store")
        if isinstance(obj, CStructVal):
            fd = obj.field_def(attr, node)
            if fd.kind == "array":
                if isinstance(val, CArrRef) and not val.is_pointer:
                    self.w(f"{obj.acc(attr)} = {val.expr};")
                    return
                _err(node, f"field {attr!r} expects an array value")
            if fd.kind != "scalar":
                if isinstance(val, CStructVal) and not val.is_pointer:
                    self.w(f"{obj.acc(attr)} = {val.expr};")
                    return
                _err(node, f"field {attr!r} expects a struct value")
            self.w(f"{obj.acc(attr)} = {self._cx(val)};")
            return
        if isinstance(obj, ArgsWrapper):
            _err(node, "kernel args are read-only")
        _err(node, "unsupported field store")

    def _exec_array_alloc(self, target, call, scope):
        elem_ann = call.args[0]
        if not isinstance(elem_ann, ast.Name):
            _err(call, "array element type must be a plain type name")
        elem = self._lookup_type(elem_ann.id, elem_ann)
        cap_v = self.ev(call.args[1], scope)
        init_zero = call.func.id == "zeros"
        if isinstance(target, ast.Attribute):
            obj = self.ev(target.value, scope)
            if self.host:
                if not isinstance(obj, HostStruct):
                    _err(target, "array field allocation expects a struct")
                cap = int(cap_v) if isinstance(cap_v, int) else None
                if cap is None:
                    _err(call, "host-mode array capacity must be static")
                obj.fields[target.attr] = HostArr([0] * cap if init_zero else [], elem)
                return
            obj.field_def(target.attr, target)
            tmp = self.fresh("av")
            capx = self._cx(cap_v)
            self.w(f"AArr<{elem.cname}> {tmp};")
            self.w(f"{tmp}.cap = (int64_t){capx};")
            self.w(f"{tmp}.len = (int64_t){capx if init_zero else 0};")
            self.w(
                f"{tmp}.data = ({elem.cname}*)arena_alloc((int64_t){capx} * sizeof({elem.cname}));"
            )
            if init_zero:
                z = self.fresh("z")
                self.w(
                    f"for (int64_t {z} = 0; {z} < (int64_t){capx}; {z} += 1) "
                    f"{{ {tmp}.data[{z}] = 0; }}"
                )
            self.w(f"{obj.acc(target.attr)} = {tmp};")
            return
        if not isinstance(target, ast.Name):
            _err(target, "array allocation must assign to a plain name or struct field")
        nm = target.id
        if self.host:
            if isinstance(cap_v, CVal) or not isinstance(cap_v, int):
                _err(call, "host-mode array capacity must be static")
            data = [0] * int(cap_v) if init_zero else []
            scope[nm] = HostArr(data, elem)
            return
        capx = self._cx(cap_v)
        self.w(f"AArr<{elem.cname}> {nm};")
        self.w(f"{nm}.cap = (int64_t){capx};")
        self.w(f"{nm}.len = (int64_t){capx if init_zero else 0};")
        self.w(
            f"{nm}.data = ({elem.cname}*)arena_alloc((int64_t){capx} * sizeof({elem.cname}));"
        )
        if init_zero:
            z = self.fresh("z")
            self.w(
                f"for (int64_t {z} = 0; {z} < (int64_t){capx}; {z} += 1) "
                f"{{ {nm}.data[{z}] = 0; }}"
            )
        scope[nm] = CArrRef(nm, elem, False)

    def _exec_struct_alloc(self, target, sdef: StructDef, scope):
        if isinstance(target, ast.Name):
            nm = target.id
            if self.host:
                scope[nm] = HostStruct(sdef)
                return
            self.w(f"{sdef.cname} {nm} = {{}};")
            for f in sdef.fields:
                if f.kind == "scalar" and f.default != 0:
                    self.w(f"{nm}.{f.name} = {f.default};")
            scope[nm] = CStructVal(nm, sdef, False)
            return
        if isinstance(target, ast.Attribute):
            obj = self.ev(target.value, scope)
            if self.host:
                if isinstance(obj, HostStruct):
                    obj.fields[target.attr] = HostStruct(sdef)
                    return
            else:
                obj.field_def(target.attr, target)
                tmp = self.fresh("sv")
                self.w(f"{sdef.cname} {tmp};")
                self.w(f"{obj.acc(target.attr)} = {tmp};")
                return
        _err(target, "unsupported struct allocation target")

    def _region(self, open_line, body, scope, *, body_fn=None):
        """Emit a traced control-flow region.

        Break/continue/return signals stop emitting the remainder of THIS
        region's body only (the C++ statement is already emitted and only
        fires when the runtime condition holds); after the region closes,
        emission resumes after it, matching C++ reachability.
        """
        self.w(open_line)
        self.indent += 1
        try:
            try:
                if body_fn is not None:
                    body_fn()
                else:
                    self.st_block(body, scope)
            except _Break:
                self.w("break;")
            except _Continue:
                self.w("continue;")
            except _Return:
                pass
        finally:
            self.indent -= 1
            self.w("}")

    def st_If(self, node, scope):
        if self.host:
            taken = self._host_truth(self.ev(node.test, scope))
            if taken:
                self.st_block(node.body, scope)
            else:
                self.st_block(node.orelse, scope)
            return
        v = self.ev(node.test, scope)
        if isinstance(v, (bool, int)) and not isinstance(v, CVal):
            if v:
                self.st_block(node.body, scope)
            else:
                self.st_block(node.orelse, scope)
            return
        cond = self._boolify(v)
        if node.orelse:
            self._region(f"if ({cond}) {{", node.body, scope)
            self._region("else {", node.orelse, scope)
        else:
            self._region(f"if ({cond}) {{", node.body, scope)

    def st_While(self, node, scope):
        if node.orelse:
            _err(node, "while/else is unsupported")
        if self.host:
            while True:
                if not self._host_truth(self.ev(node.test, scope)):
                    break
                try:
                    self.st_block(node.body, scope)
                except _Break:
                    break
                except _Continue:
                    continue
            return
        if isinstance(node.test, ast.Constant) and node.test.value is True:
            self._region("for (;;) {", node.body, scope)
            return
        v = self.ev(node.test, scope)
        if isinstance(v, (bool, int)) and not isinstance(v, CVal):
            if not v:
                return
            self._region("for (;;) {", node.body, scope)
            return
        cond = self._boolify(v)
        self._region(f"while ({cond}) {{", node.body, scope)

    def st_For(self, node, scope):
        if node.orelse:
            _err(node, "for/else is unsupported")
        target = node.target
        if not isinstance(target, ast.Name):
            _err(node, "for target must be a plain name")
        nm = target.id
        it = node.iter
        if (
            isinstance(it, ast.Call)
            and isinstance(it.func, ast.Name)
            and it.func.id == "range"
        ):
            vals = [self.ev(a, scope) for a in it.args]
            if len(vals) == 1:
                lo, hi, step = 0, vals[0], 1
            elif len(vals) == 2:
                lo, hi, step = vals[0], vals[1], 1
            elif len(vals) == 3:
                lo, hi, step = vals
            else:
                _err(node, "range() takes 1-3 arguments")
            static = all(
                isinstance(v, int) and not isinstance(v, CVal) for v in (lo, hi, step)
            )
            if static:
                for i in range(lo, hi, step):
                    scope[nm] = i if self.host else CVal(f"({i})")
                    try:
                        self.st_block(node.body, scope)
                    except _Break:
                        break
                    except _Continue:
                        continue
                return
            if self.host:
                _err(node, "host-mode dynamic range loops need static bounds")
            if isinstance(step, CVal) or (isinstance(step, int) and step != 1):
                _err(node, "traced range loops support step == 1 only")
            open_line = (
                f"for (int64_t {nm} = {self._cx(lo)}; {nm} < {self._cx(hi)}; {nm} += 1) {{"
            )
            scope[nm] = CVal(nm)

            def _body():
                self.st_block(node.body, scope)

            self._region(open_line, None, scope, body_fn=_body)
            return
        if isinstance(it, (ast.List, ast.Tuple)):
            items = [self.ev(e, scope) for e in it.elts]
            if all(not isinstance(v, CVal) for v in items):
                for item in items:
                    scope[nm] = item if self.host else CVal(f"({int(item)})")
                    try:
                        self.st_block(node.body, scope)
                    except _Break:
                        break
                    except _Continue:
                        continue
                return
            _err(node, "mixed static/traced list iteration is unsupported")
        base = self.ev(it, scope)
        if self.host:
            if not isinstance(base, HostArr):
                _err(node, "host-mode for over an array expects a device list")
            for item in list(base.data):
                scope[nm] = item
                try:
                    self.st_block(node.body, scope)
                except _Break:
                    break
                except _Continue:
                    continue
            return
        if isinstance(base, CArrRef):
            z = self.fresh("it")

            def _body_arr():
                self.w(f"{nm} = (int64_t){base.data}[{z}];")
                self.st_block(node.body, scope)

            scope[nm] = CVal(nm)
            self._region(
                f"for (int64_t {z} = 0; {z} < {base.ln}; {z} += 1) {{",
                None,
                scope,
                body_fn=_body_arr,
            )
            return
        _err(node, "unsupported for iterable")

    def st_Break(self, node, scope):
        raise _Break()

    def st_Continue(self, node, scope):
        raise _Continue()

    def st_Return(self, node, scope):
        val = self.ev(node.value, scope) if node.value is not None else None
        if self.host:
            raise _Return(val)
        if val is None:
            self.w("return;")
        elif isinstance(val, CVal):
            self.w(f"return {val.expr};")
        elif isinstance(val, (bool, int)):
            self.w(f"return ({int(val)});")
        else:
            _err(node, "only scalar returns are supported")
        raise _Return(None)

    # -- expressions -----------------------------------------------------------
    def ev(self, node, scope):
        method = getattr(self, "ev_" + type(node).__name__, None)
        if method is None:
            _err(node, f"unsupported expression {type(node).__name__}")
        return method(node, scope)

    def ev_Constant(self, node, scope):
        v = node.value
        if isinstance(v, bool):
            return 1 if v else 0
        if isinstance(v, int):
            return v
        if isinstance(v, type(None)):
            return None
        _err(node, f"unsupported constant {v!r}")

    def ev_Name(self, node, scope):
        if node.id in scope:
            return scope[node.id]
        if node.id in self.globals:
            g = self.globals[node.id]
            if isinstance(g, (int, bool, float, str, type(None), types.FunctionType, type)):
                return g
            _err(
                node,
                f"global {node.id!r} of type {type(g).__name__} is not usable in traced code",
            )
        import builtins

        if hasattr(builtins, node.id):
            return ("builtin", getattr(builtins, node.id))
        _err(node, f"name {node.id!r} is not defined")

    def ev_BinOp(self, node, scope):
        return self._binop(
            node.op, self.ev(node.left, scope), self.ev(node.right, scope), node
        )

    def _binop(self, op, l, r, node):
        sop = _BINOPS.get(type(op))
        if sop is None:
            _err(node, "unsupported binary operator (use // for integer division)")
        if self.host:
            l, r = self._hv(l), self._hv(r)
            if sop == "+":
                return l + r
            if sop == "-":
                return l - r
            if sop == "*":
                return l * r
            if sop == "/":
                return l // r
            if sop == "%":
                return l % r
            if sop == "<<":
                return l << r
            if sop == ">>":
                return l >> r
            if sop == "&":
                return l & r
            if sop == "|":
                return l | r
            if sop == "^":
                return l ^ r
        return CVal(f"{self._cx(l)} {sop} {self._cx(r)}")

    def ev_UnaryOp(self, node, scope):
        v = self.ev(node.operand, scope)
        if isinstance(node.op, ast.USub):
            if self.host:
                return -self._hv(v)
            return CVal(f"-{self._cx(v)}")
        if isinstance(node.op, ast.UAdd):
            return v
        if isinstance(node.op, ast.Not):
            if self.host:
                return 0 if self._host_truth(v) else 1
            if isinstance(v, CPtrView):
                return CVal(f"({v.expr} == nullptr)")
            return CVal(f"({self._cx(v)} == 0)")
        _err(node, "unsupported unary operator")

    def ev_BoolOp(self, node, scope):
        vals = [self.ev(v, scope) for v in node.values]
        join = "&&" if isinstance(node.op, ast.And) else "||"
        if self.host:
            acc = self._host_truth(vals[0])
            for v in vals[1:]:
                b = self._host_truth(v)
                acc = (acc and b) if join == "&&" else (acc or b)
            return 1 if acc else 0
        return CVal(
            (f" {join} ").join(self._boolify(v) for v in vals)
        )

    def _boolify(self, v):
        if isinstance(v, CVal):
            return f"({v.expr} != 0)"
        if isinstance(v, CPtrView):
            return f"({v.expr} != nullptr)"
        if isinstance(v, (int, bool)):
            return "(1)" if v else "(0)"
        _err(None, f"cannot use {type(v).__name__} in boolean context")

    def ev_Compare(self, node, scope):
        cur = self.ev(node.left, scope)
        parts = []
        for op, comp in zip(node.ops, node.comparators):
            nxt = self.ev(comp, scope)
            sop = _CMPOPS.get(type(op))
            if sop is None:
                _err(node, "unsupported comparison operator")
            if self.host:
                parts.append(_cmp(self._hv(cur), sop, self._hv(nxt)))
            else:
                parts.append(f"{self._cx(cur)} {sop} {self._cx(nxt)}")
            cur = nxt
        if self.host:
            return 1 if all(parts) else 0
        if len(parts) == 1:
            return CVal(parts[0])
        return CVal(" && ".join(f"({p})" for p in parts))

    def ev_IfExp(self, node, scope):
        if self.host:
            taken = self._host_truth(self.ev(node.test, scope))
            return self.ev(node.body if taken else node.orelse, scope)
        v = self.ev(node.test, scope)
        if isinstance(v, (bool, int)) and not isinstance(v, CVal):
            return self.ev(node.body if v else node.orelse, scope)
        a = self.ev(node.body, scope)
        b = self.ev(node.orelse, scope)
        return CVal(f"({self._boolify(v)}) ? {self._cx(a)} : {self._cx(b)}")

    def ev_Subscript(self, node, scope):
        base = self.ev(node.value, scope)
        sl = node.slice
        if isinstance(sl, ast.Slice):
            _err(node, "slicing is unsupported")
        idx = self.ev(sl, scope)
        if self.host:
            if isinstance(base, HostView):
                if base.array is None:
                    _err(node, "read from a null GM view")
                return int(base.array[int(idx)])
            if isinstance(base, HostArr):
                return int(base.data[int(idx)])
            if isinstance(base, list):
                return int(base[int(idx)])
            _err(node, "unsupported subscript base")
        if isinstance(base, CPtrView):
            return CVal(f"(int64_t){base.expr}[(int64_t){self._cx(idx)}]")
        if isinstance(base, CArrRef):
            return CVal(f"(int64_t){base.data}[(int64_t){self._cx(idx)}]")
        _err(node, "unsupported subscript base")

    def ev_Attribute(self, node, scope):
        return self._field_get(self.ev(node.value, scope), node.attr, node)

    def _field_get(self, obj, attr, node):
        if self.host:
            if isinstance(obj, HostArgs):
                return obj.fields[attr]
            if isinstance(obj, HostStruct):
                return obj.fields[attr]
            _err(node, f"cannot read field {attr!r} in host mode")
        if isinstance(obj, ArgsWrapper):
            ann = obj.field_ann(attr, node)
            if _is_gm_ann(ann):
                return CPtrView(f"{obj.cname}->{attr}", ann.elem, ann.mutable)
            return CVal(f"(int64_t){obj.cname}->{attr}")
        if isinstance(obj, CStructVal):
            fd = obj.field_def(attr, node)
            if fd.kind == "scalar":
                return CVal(f"(int64_t){obj.acc(attr)}")
            if fd.kind == "array":
                return CArrRef(obj.acc(attr), fd.payload, False)
            return CStructVal(obj.acc(attr), fd.payload, False)
        _err(node, f"cannot read field {attr!r} from {type(obj).__name__}")

    def ev_Call(self, node, scope):
        return self.ev_call(node, scope, want_value=True)

    def ev_call(self, node, scope, want_value):
        func = node.func
        if isinstance(func, ast.Attribute):
            recv = self.ev(func.value, scope)
            return self._method_call(recv, func.attr, node, scope, want_value)
        if not isinstance(func, ast.Name):
            _err(node, "only plain-name calls are supported")
        name = func.id
        if name in ("array", "zeros"):
            _err(node, "array creation must be a direct top-level assignment")
        if name == "dbp":
            return self._emit_dbp(node, scope)
        if self.host and name in ("min", "max", "abs", "len", "ceil_div", "floor_div_safe", "int"):
            args = [self._hv(self.ev(a, scope)) for a in node.args]
            if name == "min":
                return min(args)
            if name == "max":
                return max(args)
            if name == "abs":
                return abs(args[0])
            if name == "len":
                return len(args[0].data) if isinstance(args[0], HostArr) else len(args[0])
            if name == "ceil_div":
                return args[0] // args[1] + (1 if args[0] % args[1] else 0)
            if name == "floor_div_safe":
                return args[0] // args[1] if args[1] != 0 else args[2]
            return int(args[0])
        if name in ("min", "max", "abs", "len", "ceil_div", "floor_div_safe", "int"):
            args = [self.ev(a, scope) for a in node.args]
            if name == "int":
                return args[0]
            if name == "len":
                if isinstance(args[0], CArrRef):
                    return CVal(f"(int64_t){args[0].ln}")
                _err(node, "len() expects an array")
            if name in ("min", "max"):
                if len(args) < 2:
                    _err(node, f"{name} needs >= 2 arguments")
                cur = self._cx(args[0])
                for a in args[1:]:
                    b = self._cx(a)
                    op = "<" if name == "min" else ">"
                    cur = f"({cur} {op} {b} ? {cur} : {b})"
                return CVal(cur)
            if name == "abs":
                e = self._cx(args[0])
                return CVal(f"({e} < 0 ? -{e} : {e})")
            if name == "ceil_div":
                a, b = self._cx(args[0]), self._cx(args[1])
                return CVal(f"({a} / {b} + (({a} % {b}) != 0))")
            a, b, d = self._cx(args[0]), self._cx(args[1]), self._cx(args[2])
            return CVal(f"({b} == 0 ? {d} : {a} / {b})")
        g = self.globals.get(name)
        if isinstance(g, types.FunctionType):
            args = [self.ev(a, scope) for a in node.args]
            if self.host:
                return self._host_call(g, node, args, scope)
            cname, ret = self.compile_user_call(g, args, node)
            call = f"{cname}({', '.join(self._call_args(a) for a in args)})"
            if ret == "void" or not want_value:
                self.w(f"{call};")
                return None
            return CVal(call)
        if isinstance(g, type):
            _err(node, "struct creation must be a direct top-level assignment")
        _err(node, f"cannot resolve call to {name!r}")

    def _emit_dbp(self, node, scope):
        if self.host:
            return None
        label_node = node.args[0]
        label = (
            label_node.value
            if isinstance(label_node, ast.Constant) and isinstance(label_node.value, str)
            else "v"
        )
        vals = [self.ev(a, scope) for a in node.args[1:]]
        if not vals:
            self.w(f'AscendC::printf("%s\\n", "{label}");')
        else:
            fmt = " ".join(["%ld"] * len(vals))
            joined = ", ".join(f"(long){self._cx(v)}" for v in vals)
            self.w(f'AscendC::printf("{label} {fmt}\\n", {joined});')
        return None

    def _host_call(self, g, node, args, scope):
        fnnode = self._fn_ast(g)
        if len(fnnode.args.args) != len(args):
            _err(node, f"arity mismatch calling {g.__name__}")
        scope2 = {}
        for p, a in zip(fnnode.args.args, args):
            scope2[p.arg] = a
        try:
            self.st_block(fnnode.body, scope2)
        except _Return as r:
            return r.value
        return None

    def _call_args(self, a):
        if isinstance(a, (bool, int)):
            return f"({int(a)})"
        if isinstance(a, CVal):
            return a.expr
        if isinstance(a, CPtrView):
            return a.expr
        if isinstance(a, CArrRef):
            return a.expr if a.is_pointer else f"&{a.expr}"
        if isinstance(a, CStructVal):
            return a.expr if a.is_pointer else f"&{a.expr}"
        if isinstance(a, ArgsWrapper):
            return a.cname
        _err(None, f"unsupported call argument {type(a).__name__}")

    def _method_call(self, recv, attr, node, scope, want_value):
        args = [self.ev(a, scope) for a in node.args]
        if attr == "append":
            if self.host:
                if not isinstance(recv, HostArr):
                    _err(node, "append expects a device array")
                recv.data.append(int(args[0]))
                return None
            if isinstance(recv, CArrRef):
                self.w(
                    f"{recv.data}[{recv.ln}] = ({recv.elem.cname}){self._cx(args[0])};"
                )
                self.w(f"{recv.ln} += 1;")
                return None
            _err(node, "append expects a device array")
        if attr == "reset":
            if self.host:
                val, n = int(args[0]), int(args[1])
                recv.data[:] = [val] * n
                return None
            if isinstance(recv, CArrRef):
                val, n = args[0], args[1]
                z = self.fresh("z")
                self.w(f"{recv.ln} = (int64_t){self._cx(n)};")
                self.w(
                    f"for (int64_t {z} = 0; {z} < (int64_t){self._cx(n)}; {z} += 1) "
                    f"{{ {recv.data}[{z}] = ({recv.elem.cname}){self._cx(val)}; }}"
                )
                return None
            _err(node, "reset expects a device array")
        _err(node, f"unsupported method {attr!r}")

    # -- misc -------------------------------------------------------------------
    def _cx(self, v):
        if isinstance(v, CVal):
            return v.expr
        if isinstance(v, bool):
            return "(1)" if v else "(0)"
        if isinstance(v, int):
            if v == INT64_MIN:
                return "(-9223372036854775807LL - 1)"
            return f"({v})" if v < 0 else str(v)
        _err(None, f"expected a scalar, got {type(v).__name__}")

    def _hv(self, v):
        if isinstance(v, CVal):
            _err(None, "internal: CVal leaked into host mode")
        return v

    def _host_truth(self, v):
        if isinstance(v, HostView):
            return v.array is not None
        if isinstance(v, HostArr):
            return len(v.data) > 0
        return bool(v)


def _cmp(a, op, b):
    return {
        "==": a == b,
        "!=": a != b,
        "<": a < b,
        "<=": a <= b,
        ">": a > b,
        ">=": a >= b,
    }[op]
