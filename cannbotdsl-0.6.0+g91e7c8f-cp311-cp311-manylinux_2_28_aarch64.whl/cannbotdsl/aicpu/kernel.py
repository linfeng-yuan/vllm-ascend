# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software and is made available under the terms and
# conditions of CANN Open Software License Agreement Version 2.0 (the "License").
# See LICENSE for the full text of the License.

"""``@aicpu_kernel`` decorator: Python tiling function -> AICPU kernel.

Phase-1 source-to-source pipeline:

    traced Python --interp(cpp)--> portable C++ body
        + args header  (shared by device image, host shim and x86 harness)
        + .aicpu device kernel (__global__ __aicpu__, single core)
        + .asc host shim (extern "C" <name>_do + <<<1, 0, stream>>> launch)
        --> bisheng --> .so --> ctypes launch on the current device stream

The same traced Python --interp(host)--> produces the golden values used to
cross-check the compiled kernel (x86 locally, AICPU on board).
"""

from __future__ import annotations

import functools
import os
import subprocess
import tempfile
import shutil

from cannbotdsl.aicpu.interp import Interp, AicpuTraceError
from cannbotdsl.aicpu.types import collect_args_struct

_LEGACY = "legacy"
_INTERFACE = "interface"


def aicpu_kernel(fn):
    spec_holder = {}

    @functools.wraps(fn)
    def missing_spec():
        raise AicpuTraceError(
            "annotate the kernel parameter with an args struct class, e.g. "
            "def k(a: MyArgs):"
        )

    annotations = getattr(fn, "__annotations__", {})
    ann_class = None
    for name, ann in annotations.items():
        if isinstance(ann, type):
            ann_class = ann
            break
    if ann_class is None:
        return missing_spec

    spec = collect_args_struct(ann_class)

    class Kernel:
        def __init__(self, fn, spec):
            self.fn = fn
            self.spec = spec

        # -- host golden -----------------------------------------------------
        def run_host(self, **kwargs):
            interp = Interp(self.fn, host=True)
            return interp.run_host_entry(self.spec, kwargs)

        # -- source generation ------------------------------------------------
        def cpp_body(self) -> str:
            interp = Interp(self.fn, host=False)
            return interp.run_cpp_entry(self.spec)

        def generate_sources(self, name: str | None = None, *, launch_mode: str = _INTERFACE):
            name = name or self.fn.__name__
            header = self.spec.emit_header()
            body = self.cpp_body()
            args_t = self.spec.name
            flat = self._flat_param_list()
            files = {}
            files[f"{name}_args.h"] = header
            files[f"{name}_body.inc"] = body + "\n"
            if launch_mode == _INTERFACE:
                files[f"{name}_kernel.aicpu"] = (
                    '#include "aicpu_api.h"\n'
                    f'#include "{name}_args.h"\n'
                    f'#include "{name}_body.inc"\n'
                    f"__global__ __aicpu__ uint32_t {name}({args_t} a)\n"
                    "{\n"
                    "    g_arena_off = 0;\n"
                    f"    int64_t st = {name}_body(&a);\n"
                    "    AscendC::DataStoreBarrier();\n"
                    "    return (uint32_t)st;\n"
                    "}\n"
                )
                extra = (", " + ", ".join(flat)) if flat else ""
                files[f"{name}_shim.asc"] = (
                    f'#include "{name}_args.h"\n'
                    f"extern __global__ __aicpu__ uint32_t {name}({args_t});\n"
                    f'extern "C" void {name}_do(void* stream{extra})\n'
                    "{\n"
                    f"    {args_t} s;\n"
                    + self._shim_field_fills()
                    + f"    {name}<<<1, 0, stream>>>(s);\n"
                    "}\n"
                )
            else:
                files[f"{name}_kernel.aicpu"] = (
                    '#include "aicpu_api.h"\n'
                    f'#include "{name}_args.h"\n'
                    f'#include "{name}_body.inc"\n'
                    f"__global__ __aicpu__ uint32_t {name}(void* p)\n"
                    "{\n"
                    "    g_arena_off = 0;\n"
                    f"    int64_t st = {name}_body(({args_t}*)p);\n"
                    "    AscendC::DataStoreBarrier();\n"
                    "    return (uint32_t)st;\n"
                    "}\n"
                )
                files[f"{name}_shim.asc"] = (
                    f'#include "{name}_args.h"\n'
                    f"extern __global__ __aicpu__ uint32_t {name}(void*);\n"
                    f'extern "C" void {name}_do(void* stream, uint64_t {name}_param_addr)\n'
                    "{\n"
                    f"    {name}<<<1, 0, stream>>>((void*){name}_param_addr);\n"
                    "}\n"
                )
            files[f"{name}_x86.cpp"] = (
                "#include <cstdio>\n"
                "#include <cstdarg>\n"
                "namespace AscendC {\n"
                "void printf(const char* fmt, ...)\n"
                "{\n"
                "    va_list ap;\n"
                "    va_start(ap, fmt);\n"
                "    std::vprintf(fmt, ap);\n"
                "    va_end(ap);\n"
                "}\n"
                "}\n"
                f'#include "{name}_args.h"\n'
                f'#include "{name}_body.inc"\n'
                f'extern "C" int64_t {name}_run_x86({", ".join(flat)})\n'
                "{\n"
                f"    {args_t} s;\n"
                + self._shim_field_fills()
                + f"    return {name}_body(&s);\n"
                "}\n"
            )
            return files

        def _flat_param_list(self):
            parts = []
            for fname, ann in self.spec.fields:
                if type(ann).__name__ == "GmFieldType":
                    parts.append(f"uint64_t a_{fname}")
                else:
                    parts.append(f"{ann.cname} a_{fname}")
            return parts

        def _shim_field_fills(self):
            lines = []
            for fname, ann in self.spec.fields:
                if type(ann).__name__ == "GmFieldType":
                    const = "" if ann.mutable else "const "
                    lines.append(f"    s.{fname} = ({const}{ann.elem.cname}*)a_{fname};")
                else:
                    lines.append(f"    s.{fname} = a_{fname};")
            return ("\n".join(lines) + "\n") if lines else ""

        # -- compilation -------------------------------------------------------
        def compile(self, workdir: str | None = None, *, launch_mode: str = _INTERFACE, keep_sources=None):
            from cannbotdsl.aicpu.toolchain import compile_aicpu_kernel

            return compile_aicpu_kernel(
                self,
                workdir=workdir,
                launch_mode=launch_mode,
                keep_sources=keep_sources,
            )

    return Kernel(fn, spec)


aicpu_kernel.launch_modes = (_INTERFACE, _LEGACY)
