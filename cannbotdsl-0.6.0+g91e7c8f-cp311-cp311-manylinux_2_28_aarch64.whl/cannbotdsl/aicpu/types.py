# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software and is made available under the terms and
# conditions of CANN Open Software License Agreement Version 2.0 (the "License").
# See LICENSE for the full text of the License.

"""Type descriptors for the AICPU kernel frontend (Phase-1 source-to-source).

Scalars are all carried as int64_t inside generated device code; the element
type declared here matters for GM pointer types, GM store narrowing casts and
the ``AArr<T>`` element type of device arrays.
"""

from __future__ import annotations

import ctypes


class CScalarType:
    def __init__(self, cname: str, ctypes_type) -> None:
        self.cname = cname
        self.ctypes_type = ctypes_type


I32 = CScalarType("int32_t", ctypes.c_int32)
U32 = CScalarType("uint32_t", ctypes.c_uint32)
I64 = CScalarType("int64_t", ctypes.c_int64)
U64 = CScalarType("uint64_t", ctypes.c_uint64)


class GmFieldType:
    """Annotation marker for a GM pointer field of the kernel args struct."""

    def __init__(self, elem: CScalarType, *, mutable: bool) -> None:
        self.elem = elem
        self.mutable = mutable


def GmIn(elem: CScalarType) -> GmFieldType:
    return GmFieldType(elem, mutable=False)


def GmOut(elem: CScalarType) -> GmFieldType:
    return GmFieldType(elem, mutable=True)


_FIELD_ORDER: list[str] = []


def collect_args_struct(cls) -> "ArgsStructSpec":
    fields: list[tuple[str, object]] = []
    for base in reversed(cls.__mro__):
        for name, ann in base.__dict__.get("__annotations__", {}).items():
            if isinstance(ann, (CScalarType, GmFieldType)):
                fields.append((name, ann))
    seen: set[str] = set()
    ordered: list[tuple[str, object]] = []
    for name, ann in fields:
        if name in seen:
            continue
        seen.add(name)
        ordered.append((name, ann))
    return ArgsStructSpec(cls.__name__, ordered)


class ArgsStructSpec:
    """Declarative description of the kernel args struct (single source)."""

    def __init__(self, name: str, fields: list[tuple[str, object]]) -> None:
        self.name = name
        self.fields = ordered = list(fields)

    def c_field_decl(self, name: str, ann: object) -> str:
        if isinstance(ann, GmFieldType):
            const = "" if ann.mutable else "const "
            return f"{const}{ann.elem.cname}* {name}"
        return f"{ann.cname} {name}"

    def emit_header(self) -> str:
        lines = ["#pragma once", "#include <cstdint>", f"struct {self.name} {{"]
        for name, ann in self.fields:
            lines.append(f"    {self.c_field_decl(name, ann)};")
        lines.append("};")
        return "\n".join(lines) + "\n"
