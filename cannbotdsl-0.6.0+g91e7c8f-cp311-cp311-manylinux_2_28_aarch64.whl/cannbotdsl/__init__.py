# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""CANNBotDSL: Python frontend for building CANNIR MLIR from Python."""

import sys

from cannbotdsl.core.utils.logger import init_logger as _init_logger

_init_logger()

# Complete types aggregation and tensor definitions before AttrBuilder
# registration and high-level APIs. Caster registration itself only stores
# callbacks; their first use requires the public Tensor/Layout definitions.
from cannbotdsl import types as _types
from cannbotdsl import tensor

# AttrBuilder registrations must run before any dialect op constructor sees
# a PipeEnum / RoundingModeEnum argument. Imported for side effect only.
from cannbotdsl.core.frontend import attr_builders  # noqa: F401

from cannbotdsl.ops.arch import (
    get_block_idx,
    get_block_num,
    get_core_id,
    get_squeeze_status,
    get_status,
    get_subblock_dim,
    get_subblock_id,
    get_system_cycle,
    get_vf_len,
)
from cannbotdsl.ops.info import (
    PlatformInfo,
    get_mem_size,
    get_platform_info,
)
from cannbotdsl.lang.constexpr import const_expr, range_constexpr, target_version
from cannbotdsl.ops.conv import (
    Conv2dSpec,
    Conv2dTile,
    conv2d_load_filter,
    conv2d_load_fmap,
    conv2d_load_im2col,
    conv2d_store_output,
    make_conv2d_fmap_l1,
    make_conv2d_spec,
)
from cannbotdsl.lang.control_flow import range
from cannbotdsl.types.delay_line import DelayLine, DelayLineGroup
from cannbotdsl.core.compiler import (
    ProviderCallable,
    clear_compile_cache,
    load,
)
from cannbotdsl.core.diag.diagnostics import (
    CANNBotError,
    CANNBotInternalError,
    CANNBotRuntimeError,
    CANNBotTypeError,
    CANNBotValueError,
    DiagnosticCode,
)
from cannbotdsl.core.diag.debug import print_scalar, print_tensor
from cannbotdsl.core.diag.native_dump import dump_reg, dump_tensor
from cannbotdsl.types.datastruct import (
    CArray,
    StructField,
    StructRef,
    StructSchema,
    datastruct,
)
from cannbotdsl.types import dtypes
from cannbotdsl.ops import cube
from cannbotdsl.ops import scalar
from cannbotdsl.ops import simt
from cannbotdsl.types.dtypes import DType
from cannbotdsl.lang.jit import jit
from cannbotdsl.lang.kernel import kernel
from cannbotdsl.core import profiling as profiler
from cannbotdsl.core.profiling import ProfileSpec
from cannbotdsl.core.frontend.runtime.expressions import select
from cannbotdsl.ops.matmul import matmul
from cannbotdsl.ops.memcpy import CopyBlockMapping, cv_valid_extent, make_copy_engine, mem_copy
from cannbotdsl.lang.spec import (
    Constexpr,
    Dim,
    StructSpec,
    TensorListSpec,
    TensorSpec,
)
from cannbotdsl.types.tensor_list import TensorList
from cannbotdsl.ops.sync import (
    cube_busy_wait,
    cube_get_buf,
    cube_release_buf,
    cube_sync_all,
    cube_sync_block_arrive,
    cube_sync_block_wait,
    cube_sync_intra_arrive,
    cube_sync_intra_wait,
    cube_sync_pipe,
    dcci_entire_atomic,
    dcci_entire_out,
    dcci_single,
    dci,
    global_sync_all,
    try_wait,
    vec_busy_wait,
    vec_get_buf,
    vec_release_buf,
    vec_sync_all,
    vec_sync_block_arrive,
    vec_sync_block_wait,
    vec_sync_intra_arrive,
    vec_sync_intra_wait,
    vec_sync_pipe,
)
from cannbotdsl.tensor import (
    Coord,
    Layout,
    PartitionTiler,
    Shape,
    Stride,
    Tensor,
    Tile,
    Tiler,
    ceil_div,
    crd2idx,
    reinterpret,
    make_layout,
    make_tiler,
    make_tensor,
    permute,
    idx2crd,
    make_tiler,
    size,
    tile_slice,
)
from cannbotdsl.channel import ChannelKind, make_channel
from cannbotdsl.types import ScalarValue
from cannbotdsl.tensor import MemLoc
from cannbotdsl.ops.sync import PIPE, CmpOp
from cannbotdsl.ops.reg.cast import RegLayout
from cannbotdsl.lang.vf import vf

# The raw-register and collective surfaces are namespaced, not flattened:
# `cb.reg.vadd(...)` and `cb.distributed.get_comm_context(...)`. Registering
# them in sys.modules under the short names keeps `import cannbotdsl.reg` and
# `from cannbotdsl.reg import vadd` working alongside attribute access.
#
# Namespacing `reg` is also what removes the old `vmax` / `vselect` collision:
from cannbotdsl.ops import distributed, reg  # noqa: F401

sys.modules[__name__ + ".reg"] = reg
sys.modules[__name__ + ".distributed"] = distributed

try:
    from cannbotdsl._version import __version__
except ModuleNotFoundError:
    try:
        from importlib.metadata import PackageNotFoundError, version

        __version__ = version("cannbotdsl")
    except PackageNotFoundError:
        __version__ = "0.0.0+source"

__all__ = [
    "tensor",
    "profiler",
    "ProfileSpec",
    "__version__",
    "Buffer",
    "CArray",
    "Channel",
    "ChannelKind",
    "CANNBotError",
    "CANNBotInternalError",
    "CANNBotRuntimeError",
    "CANNBotTypeError",
    "CANNBotValueError",
    "CmpOp",
    "Constexpr",
    "Conv2dSpec",
    "Conv2dTile",
    "Coord",
    "DelayLine",
    "DelayLineGroup",
    "DiagnosticCode",
    "Dim",
    "DType",
    "Layout",
    "MemLoc",
    "PIPE",
    "PartitionTiler",
    "PlatformInfo",
    "ProviderCallable",
    "RegLayout",
    "ScalarValue",
    "Shape",
    "Stride",
    "StructField",
    "StructRef",
    "StructSchema",
    "StructSpec",
    "Tensor",
    "UB",
    "TensorList",
    "TensorListSpec",
    "TensorSpec",
    "Tile",
    "Tiler",
    "ceil_div",
    "channel_rewind",
    "clear_compile_cache",
    "const_expr",
    "conv2d_load_filter",
    "conv2d_load_fmap",
    "conv2d_load_im2col",
    "conv2d_store_output",
    "crd2idx",
    "cube",
    "cube_busy_wait",
    "cube_get_buf",
    "cube_release_buf",
    "cube_sync_all",
    "cube_sync_block_arrive",
    "cube_sync_block_wait",
    "cube_sync_intra_arrive",
    "cube_sync_intra_wait",
    "cube_sync_pipe",
    "datastruct",
    "dcci_entire_atomic",
    "dcci_entire_out",
    "dcci_single",
    "dci",
    "distributed",
    "dtypes",
    "get_block_idx",
    "get_block_num",
    "get_core_id",
    "get_mem_size",
    "get_platform_info",
    "get_squeeze_status",
    "get_status",
    "get_subblock_dim",
    "get_subblock_id",
    "get_system_cycle",
    "get_vf_len",
    "global_sync_all",
    "idx2crd",
    "jit",
    "kernel",
    "load",
    "make_conv2d_fmap_l1",
    "make_conv2d_spec",
    "CopyBlockMapping",
    "make_copy_engine",
    "make_tiler",
    "cv_valid_extent",
    "make_layout",
    "make_tiler",
    "make_buffer",
    "make_channel",
    "make_tensor",
    "matmul",
    "mem_copy",
    "permute",
    "dump_tensor",
    "dump_reg",
    "print_scalar",
    "print_tensor",
    "range",
    "range_constexpr",
    "reg",
    "reinterpret",
    "scalar",
    "simt",
    "select",
    "size",
    "target_version",
    "tile_slice",
    "try_wait",
    "vec_busy_wait",
    "vec_get_buf",
    "vec_release_buf",
    "vec_sync_all",
    "vec_sync_block_arrive",
    "vec_sync_block_wait",
    "vec_sync_intra_arrive",
    "vec_sync_intra_wait",
    "vec_sync_pipe",
    "vf",
]


def __getattr__(name):
    if name in ("Buffer", "UB", "make_buffer"):
        from cannbotdsl import buffer

        value = getattr(buffer, name)
        globals()[name] = value
        return value
    if name == "Channel":
        from cannbotdsl.channel import Channel

        globals()[name] = Channel
        return Channel
    if name == "channel_rewind":
        from cannbotdsl.ops.sync import channel_rewind

        globals()[name] = channel_rewind
        return channel_rewind
    raise AttributeError(f"module 'cannbotdsl' has no attribute {name!r}")
