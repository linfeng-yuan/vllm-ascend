# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Semantic trace value for a non-empty same-dtype/rank runtime Tensor list."""

from __future__ import annotations


class TensorList:
    """One logical list carried by a rank-1 GM uint64 v2 descriptor Tensor."""

    __slots__ = ("_ssa_value", "_contract")

    def __init__(self, *args, **kwargs):
        del args, kwargs
        raise TypeError(
            "TensorList values are created by CANNBotDSL while tracing; "
            "pass a Python list or tuple at the host call boundary"
        )

    def __init_subclass__(cls, **kwargs):
        del kwargs
        raise TypeError("TensorList is a sealed CANNBotDSL value type")

    @classmethod
    def _from_ir(cls, value, *, contract):
        if type(value) is cls:
            existing = object.__getattribute__(value, "_contract")
            if existing != contract:
                raise TypeError("TensorList carrier contract does not match template")
            return value

        import cannbotdsl._mlir.ir as ir
        from cannbotdsl._mlir.dialects import cannir
        from cannbotdsl.core.contracts.model import TensorListContract
        from cannbotdsl.tensor import Tensor

        if not isinstance(contract, TensorListContract):
            raise TypeError(
                "TensorList trace construction requires TensorListContract, got "
                f"{type(contract).__name__}"
            )
        # MLIR's registered MemRef value caster presents block arguments as a
        # public Tensor facade. TensorList owns the same single physical
        # memref, but attaches a distinct logical contract to that carrier.
        if type(value) is Tensor:
            value = object.__getattribute__(value, "_ssa_value")
        if not isinstance(value, ir.Value) or not cannir.TensorType.isinstance(
            value.type
        ):
            actual = getattr(value, "type", type(value).__name__)
            raise TypeError(
                "TensorList requires a !cannir.tensor carrier, got "
                f"{actual}"
            )
        result = object.__new__(cls)
        object.__setattr__(result, "_ssa_value", value)
        object.__setattr__(result, "_contract", contract)
        return result

    @property
    def length(self):
        from cannbotdsl.tensor import Tensor
        from cannbotdsl.core.contracts.model import ConstantExpr

        contract = object.__getattribute__(self, "_contract")
        if isinstance(contract.length, ConstantExpr):
            return contract.length.value
        raw = Tensor._from_ir(object.__getattribute__(self, "_ssa_value"))
        return raw.shape[0] // contract.record_words

    def __len__(self):
        raise TypeError(
            "len(TensorList) is unavailable for a runtime-dynamic length; "
            "use xs.length"
        )

    def __iter__(self):
        raise TypeError(
            "TensorList does not support direct iteration; use "
            "for i in range(xs.length) and xs[i] inside @kernel"
        )

    def __getitem__(self, index):
        from cannbotdsl.lang.kernel import _IN_KERNEL_BODY

        if not _IN_KERNEL_BODY.get():
            raise RuntimeError(
                "TensorList element access is only supported inside an "
                "@kernel body; @jit may read xs.length and forward xs"
            )
        if isinstance(index, bool):
            raise TypeError("TensorList index must be an integer, got bool")

        import cannbotdsl._mlir.ir as ir

        if isinstance(index, ir.Value):
            if not (
                ir.IndexType.isinstance(index.type)
                or ir.IntegerType.isinstance(index.type)
            ):
                raise TypeError(
                    "TensorList index must be a Python int or DSL integer, "
                    f"got {index.type}"
                )
        elif not isinstance(index, int):
            raise TypeError(
                "TensorList index must be a Python int or DSL integer, got "
                f"{type(index).__name__}"
            )

        from cannbotdsl.core.contracts.model import (
            ConstantExpr,
            ExactLayouts,
            TemplateLayout,
        )

        contract = object.__getattribute__(self, "_contract")
        if isinstance(index, int):
            if index < 0:
                raise IndexError("TensorList does not support negative indices")
            if (
                isinstance(contract.length, ConstantExpr)
                and index >= contract.length.value
            ):
                raise IndexError(
                    f"TensorList index {index} is out of range for fixed "
                    f"length {contract.length.value}"
                )

        from cannbotdsl.core.scalar_conversion import _index_value
        from cannbotdsl.types._numeric import Int64
        from cannbotdsl.core.contracts.elements import element_for_tag
        from cannbotdsl.tensor import make_layout, make_pointer, make_tensor
        from cannbotdsl.tensor import MemLoc
        from cannbotdsl.tensor import Tensor

        raw = Tensor._from_ir(object.__getattribute__(self, "_ssa_value"))
        rank = contract.element_rank
        offset = Int64(_index_value(index, operation="TensorList index")) if isinstance(index, ir.Value) else index
        base = offset * contract.record_words
        address = raw[base]

        shape = []
        stride = []
        if isinstance(contract.layout, TemplateLayout):
            for axis, expression in enumerate(
                contract.layout.shape_expressions
            ):
                shape.append(
                    expression.value
                    if isinstance(expression, ConstantExpr)
                    else raw[base + 1 + axis]
                )
            for axis, expression in enumerate(
                contract.layout.stride_expressions
            ):
                stride.append(
                    expression.value
                    if isinstance(expression, ConstantExpr)
                    else raw[base + 1 + rank + axis]
                )
        elif isinstance(contract.layout, ExactLayouts):
            literal = contract.layout.items[index] if isinstance(index, int) else None
            for axis in range(rank):
                values = tuple(item.shape[axis] for item in contract.layout.items)
                if literal is not None:
                    shape.append(literal.shape[axis])
                elif all(value == values[0] for value in values[1:]):
                    shape.append(values[0])
                else:
                    shape.append(raw[base + 1 + axis])
            for axis in range(rank):
                values = tuple(item.stride[axis] for item in contract.layout.items)
                if literal is not None:
                    stride.append(literal.stride[axis])
                elif all(value == values[0] for value in values[1:]):
                    stride.append(values[0])
                else:
                    stride.append(
                        raw[base + 1 + rank + axis]
                    )
        else:  # pragma: no cover - CallContract validation owns this.
            raise TypeError(f"unknown TensorList layout {contract.layout!r}")

        dtype = element_for_tag(contract.element_type).dtype
        pointer = make_pointer(dtype, address, MemLoc.GM)
        layout = make_layout(tuple(shape), stride=tuple(stride))
        return make_tensor(pointer, layout)

    def __setitem__(self, index, value):
        del index, value
        raise TypeError("TensorList is immutable and does not support assignment")


__all__ = ["TensorList"]
