# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Internal fixed-format DSL floating-point SSA wrappers.

Public dtype positions and scalar conversions use ``cannbotdsl.types.dtypes``
descriptors.  The concrete classes in this module wrap produced SSA values at
implementation boundaries and are not public scalar constructors.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import arith
from cannbotdsl.types import dtypes as _dtypes

from cannbotdsl.core.scalar_conversion import (
    cast_value,
    is_float_type,
    materialize_literal,
    require_same_dynamic_type,
)

if TYPE_CHECKING:
    from cannbotdsl.types.dtypes import DType


@ir.register_value_caster(ir.F16Type.static_typeid)
@ir.register_value_caster(ir.BF16Type.static_typeid)
@ir.register_value_caster(ir.F32Type.static_typeid)
@ir.register_value_caster(ir.F64Type.static_typeid)
class Float(ir.Value):
    _dtype: "DType"

    def __init__(self, value, *, loc=None, ip=None):
        del loc, ip
        if not isinstance(value, ir.Value) or not is_float_type(value.type):
            actual = getattr(value, "type", type(value).__name__)
            raise TypeError(f"Float requires a floating SSA value, got {actual}")
        super().__init__(value)

    @property
    def dtype(self) -> "DType":
        """Return the canonical semantic dtype of this concrete wrapper."""

        return type(self)._dtype

    def _cast_literal_or_check(self, other, *, operation: str, loc=None, ip=None):
        if type(other) in {int, float}:
            return materialize_literal(other, self.type, loc=loc, ip=ip)
        if not isinstance(other, ir.Value) or not is_float_type(other.type):
            actual = getattr(other, "type", type(other).__name__)
            raise TypeError(f"{operation} expects a floating DSL value or numeric literal, got {actual}")
        require_same_dynamic_type(self, other, operation=operation)
        return other

    def __add__(self, other, *, loc=None, ip=None):
        other = self._cast_literal_or_check(other, operation="addition", loc=loc, ip=ip)
        return type(self)(arith.addf(self, other, loc=loc, ip=ip))

    def __sub__(self, other, *, loc=None, ip=None):
        other = self._cast_literal_or_check(other, operation="subtraction", loc=loc, ip=ip)
        return type(self)(arith.subf(self, other, loc=loc, ip=ip))

    def __mul__(self, other, *, loc=None, ip=None):
        other = self._cast_literal_or_check(other, operation="multiplication", loc=loc, ip=ip)
        return type(self)(arith.mulf(self, other, loc=loc, ip=ip))

    def __truediv__(self, other, *, loc=None, ip=None):
        other = self._cast_literal_or_check(other, operation="division", loc=loc, ip=ip)
        return type(self)(arith.divf(self, other, loc=loc, ip=ip))

    def __floordiv__(self, other, *, loc=None, ip=None):
        other = self._cast_literal_or_check(other, operation="floor division", loc=loc, ip=ip)
        # The scalar backend has no floor instruction.  DSL ``//`` is the
        # explicit fixed-format quotient spelling and intentionally matches
        # ``/`` rather than promising Python's arbitrary-precision semantics.
        return type(self)(arith.divf(self, other, loc=loc, ip=ip))

    def __mod__(self, other, *, loc=None, ip=None):
        # MLIR remf follows IEEE/C fmod sign semantics.  The DSL deliberately
        # uses that fixed-width operation instead of Python's floor remainder.
        other = self._cast_literal_or_check(other, operation="remainder", loc=loc, ip=ip)
        return type(self)(arith.remf(self, other, loc=loc, ip=ip))

    def __neg__(self, *, loc=None, ip=None):
        return type(self)(arith.negf(self, loc=loc, ip=ip))

    def _compare(self, other, predicate, *, operation, loc=None, ip=None):
        other = self._cast_literal_or_check(other, operation=operation, loc=loc, ip=ip)
        from cannbotdsl.types._numeric import Boolean

        return Boolean(arith.cmpf(predicate, self, other, loc=loc, ip=ip))

    def __eq__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpFPredicate.OEQ,
            operation="equality",
            loc=loc,
            ip=ip,
        )

    def __ne__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpFPredicate.ONE,
            operation="inequality",
            loc=loc,
            ip=ip,
        )

    def __lt__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpFPredicate.OLT,
            operation="less-than",
            loc=loc,
            ip=ip,
        )

    def __le__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpFPredicate.OLE,
            operation="less-than-or-equal",
            loc=loc,
            ip=ip,
        )

    def __gt__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpFPredicate.OGT,
            operation="greater-than",
            loc=loc,
            ip=ip,
        )

    def __ge__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpFPredicate.OGE,
            operation="greater-than-or-equal",
            loc=loc,
            ip=ip,
        )

    def __radd__(self, other, *, loc=None, ip=None):
        return self.__add__(other, loc=loc, ip=ip)

    def __rsub__(self, other, *, loc=None, ip=None):
        other = self._cast_literal_or_check(other, operation="subtraction", loc=loc, ip=ip)
        return type(self)(arith.subf(other, self, loc=loc, ip=ip))

    def __rmul__(self, other, *, loc=None, ip=None):
        return self.__mul__(other, loc=loc, ip=ip)

    def __rtruediv__(self, other, *, loc=None, ip=None):
        other = self._cast_literal_or_check(other, operation="division", loc=loc, ip=ip)
        return type(self)(arith.divf(other, self, loc=loc, ip=ip))

    def __rfloordiv__(self, other, *, loc=None, ip=None):
        other = self._cast_literal_or_check(other, operation="floor division", loc=loc, ip=ip)
        return type(self)(arith.divf(other, self, loc=loc, ip=ip))

    def __rmod__(self, other, *, loc=None, ip=None):
        other = self._cast_literal_or_check(other, operation="remainder", loc=loc, ip=ip)
        return type(self)(arith.remf(other, self, loc=loc, ip=ip))

    def __hash__(self):
        return super().__hash__()

    def __str__(self):
        return f"{type(self).__name__}(type={self.type}, value={super().__str__()})"

    def __repr__(self):
        return self.__str__()


class _ConcreteFloat(Float):
    width: int

    def __init__(self, value, *, loc=None, ip=None):
        target_type = type(self).mlir_type()
        if type(value) in {int, float}:
            value = materialize_literal(value, target_type, loc=loc, ip=ip)
        elif isinstance(value, ir.Value):
            value = cast_value(
                value,
                target_type,
                source_unsigned=bool(getattr(value, "unsigned", False)),
                loc=loc,
                ip=ip,
            )
        else:
            raise TypeError(
                f"{type(self).__name__} expects a numeric literal or numeric SSA value, got {type(value).__name__}"
            )
        super().__init__(value, loc=loc, ip=ip)


class Float16(_ConcreteFloat):
    width = 16
    _dtype = _dtypes.float16

    @staticmethod
    def mlir_type() -> ir.F16Type:
        return ir.F16Type.get()


class Float32(_ConcreteFloat):
    width = 32
    _dtype = _dtypes.float32

    @staticmethod
    def mlir_type() -> ir.F32Type:
        return ir.F32Type.get()


class Float64(_ConcreteFloat):
    width = 64
    _dtype = _dtypes.float64

    @staticmethod
    def mlir_type() -> ir.F64Type:
        return ir.F64Type.get()


class BFloat16(_ConcreteFloat):
    width = 16
    _dtype = _dtypes.bfloat16

    @staticmethod
    def mlir_type() -> ir.BF16Type:
        return ir.BF16Type.get()


__all__ = []
