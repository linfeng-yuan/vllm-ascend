# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""The public staged scalar value protocol."""

from __future__ import annotations

from typing import Protocol as _Protocol

from cannbotdsl.types import dtypes as _dtypes


class ScalarValue(_Protocol):
    """A staged DSL scalar whose concrete dtype is chosen at a call site.

    This protocol is intentionally not runtime-checkable.  It is the public
    annotation for the scalar *value category*; CANNBotDSL recognizes its own
    scalar wrappers through a closed internal registry rather than accepting
    arbitrary duck-typed objects.
    """

    @property
    def dtype(self) -> _dtypes.DType: ...

    def __add__(self, other: object, /) -> "ScalarValue": ...

    def __sub__(self, other: object, /) -> "ScalarValue": ...

    def __mul__(self, other: object, /) -> "ScalarValue": ...

    def __truediv__(self, other: object, /) -> "ScalarValue": ...

    def __floordiv__(self, other: object, /) -> "ScalarValue": ...

    def __mod__(self, other: object, /) -> "ScalarValue": ...

    def __radd__(self, other: object, /) -> "ScalarValue": ...

    def __rsub__(self, other: object, /) -> "ScalarValue": ...

    def __rmul__(self, other: object, /) -> "ScalarValue": ...

    def __rtruediv__(self, other: object, /) -> "ScalarValue": ...

    def __rfloordiv__(self, other: object, /) -> "ScalarValue": ...

    def __rmod__(self, other: object, /) -> "ScalarValue": ...

    def __neg__(self) -> "ScalarValue": ...

    def __lt__(self, other: object, /) -> "ScalarValue": ...

    def __le__(self, other: object, /) -> "ScalarValue": ...

    def __gt__(self, other: object, /) -> "ScalarValue": ...

    def __ge__(self, other: object, /) -> "ScalarValue": ...



__all__ = ["ScalarValue"]
