# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Private Tensor/Layout SSA wrappers and their value caster registration.

Importing this module only defines wrappers. The types aggregator registers
all eight casters once. Registration only stores wrappers and callbacks;
the Tensor/Layout callbacks import their public classes when first invoked.
"""

from __future__ import annotations

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir
from cannbotdsl.core.scalar_conversion import _index_value, _int64_result

__all__ = []


class _Shape(ir.Value):
    @property
    def as_tuple(self):
        return self.type.as_tuple


class _Stride(ir.Value):
    @property
    def as_tuple(self):
        return self.type.as_tuple


class _Tile(ir.Value):
    @property
    def as_tuple(self):
        return self.type.as_tuple


class _Coord(ir.Value):
    @property
    def as_tuple(self):
        return self.type.as_tuple

    def __len__(self):
        top = self.type.as_tuple
        if not isinstance(top, tuple):
            raise TypeError("scalar _Coord has no len(); use the value directly")
        return len(top)

    def __iter__(self):
        """Iterate top-level slots, yielding one i64 SSA per slot.

        Each slot is materialised by a `cannir.extract_dim` op, which lowers
        in CANNIRToAsc to either a constant (static leaf) or the matching
        dynamic operand of the producing `cannir.make_coord` (after
        SimplifyLayoutPass has lowered any `cannir.idx2crd` upstream).

        Nested top-level slots (sub-coords) are not yet supported because
        `extract_dim` returns a flat i64; supporting them would require
        either an `extract_sub_coord` op or in-Python rebuilding from the
        flat leaves. None of the current call sites use nested coords.
        """
        top = self.type.as_tuple
        if not isinstance(top, tuple):
            raise TypeError("scalar _Coord cannot be iterated")
        for i, slot in enumerate(top):
            if isinstance(slot, tuple):
                raise NotImplementedError(
                    "iterating a nested _Coord is not yet supported "
                    f"(slot {i} is sub-coord {slot}); flatten the shape first"
                )
            yield _int64_result(cannir.extract_dim(self, index=i))


class PartitionTiler(ir.Value):
    """Runtime balanced partition descriptor shared by Cube and Vector paths."""

    @property
    def full_shape(self):
        return tuple(self.type.full_shape)

    @property
    def axis(self) -> int:
        return int(self.type.axis)

    @property
    def parts(self) -> int:
        return int(self.type.parts)

    @property
    def alignment(self) -> int:
        return int(self.type.alignment)

    @property
    def max_part_shape(self):
        shape = list(self.full_shape)
        shape[self.axis] = int(self.type.max_span)
        return tuple(shape)

    @property
    def span(self):
        """Runtime physical span owned by one partition."""
        return _int64_result(cannir.partition_span(self))

    def valid_extent(self, part_id):
        """Return the runtime-valid logical extent of one partition."""
        return _int64_result(
            cannir.partition_valid(
                self, _index_value(part_id, operation="part_id")
            )
        )


class _Pointer(ir.Value):
    @property
    def memloc(self):
        return self.type.memloc

    @property
    def dtype(self):
        return self.type.dtype


def _cast_layout_value(value):
    from cannbotdsl.tensor import Layout

    return Layout._from_ir(value)


def _cast_tensor_value(value):
    from cannbotdsl.tensor import Tensor

    return Tensor._from_ir(value)


def _register_value_casters():
    """Register once from types initialization, without importing public classes."""
    for type_class, caster in (
        (cannir.ShapeType, _Shape),
        (cannir.StrideType, _Stride),
        (cannir.TileType, _Tile),
        (cannir.CoordType, _Coord),
        (cannir.PartitionTilerType, PartitionTiler),
        (cannir.LayoutType, _cast_layout_value),
        (cannir.PointerType, _Pointer),
        (cannir.TensorType, _cast_tensor_value),
    ):
        ir.register_value_caster(type_class.get_static_typeid())(caster)
