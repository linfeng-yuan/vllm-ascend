# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Self-contained tapped delay line for software-pipelined CANNBotDSL kernels.

A :class:`DelayLine` is a single-producer / multiple-fixed-lag-consumer ring that
memoizes per-iteration scalar coordinates so that delayed pipeline stages can
recover the loop context that produced the data they are now consuming. It is the
DSL-level name for the *tapped delay line* (modulo variable expansion) that
otherwise gets hand-rolled as parallel private scalar arrays indexed by
``global_idx % delay_slots``.

Like :class:`~cannbotdsl.channel.Channel`, it manages its own cursor: the cursor
lives in a private one-element int64 array and survives across runtime loops
via array load/store, instead of relying on the jit frontend's loop-carried (``scf.for`` iter_args) mechanism —
which only threads bare local names, not object attributes.

One instance carries one scalar stream; instantiate one per coordinate::

    dl_tile = DelayLine(delay_slots)
    dl_n    = DelayLine(delay_slots)
    for ...:
        dl_tile.push(tile_idx); dl_n.push(n_idx)   # stage 0 (write head, lag 0)
        ...
        delayed_tile_idx = dl_tile.tap(1)          # stage 1 reads 1 iter back
        ...
        dl_tile.advance(); dl_n.advance()          # once per iteration

``depth`` must be ``>= max tap lag + 1`` (so the write head never clobbers the
oldest live tap); it equals the number of in-flight pipeline stages.
"""

from __future__ import annotations

from types import SimpleNamespace

from cannbotdsl.types import dtypes
from cannbotdsl.types._array import _alloc_array


__all__ = ["DelayLine", "DelayLineGroup"]


def _delay_value(value):
    """A delay line has fixed i64 state, including when fed an i32 index."""
    if type(value) is int:
        return value
    from cannbotdsl.core.contracts.elements import element_for_dtype
    from cannbotdsl.core.scalar_conversion import _coerce_lossless_integer

    return _coerce_lossless_integer(value, element_for_dtype(dtypes.int64), operation="delay line state")


class DelayLine:
    """Single-producer, multiple-fixed-lag-consumer scalar delay line.

    Args:
        depth: Ring depth — number of in-flight pipeline stages, i.e.
            ``max tap lag + 1``. Compile-time positive int.

    Primitives:
        ``push(v)``    write the current iteration's value at the write head.
        ``tap(lag)``   read the value written ``lag`` iterations ago
                       (``0 < lag < depth``).
        ``advance()``  step the cursor by one; call once per loop iteration
                       (in both the main loop and the drain/epilogue loop).
    """

    def __init__(self, depth):
        self._depth = depth
        self._buf = _alloc_array(depth, dtype=dtypes.int64)
        self._clk = _alloc_array(1, dtype=dtypes.int64, init=[0])

    def push(self, value):
        self._buf[self._clk[0] % self._depth] = _delay_value(value)

    def tap(self, lag):
        if not isinstance(lag, int):
            raise TypeError(f"tap lag must be a Python int, got {type(lag).__name__}")
        assert 0 < lag < self._depth, "tap lag out of depth: write head would clobber this tap"
        return self._buf[(self._clk[0] - lag) % self._depth]

    def advance(self):
        self._clk[0] = self._clk[0] + 1


class _DelaySlot:
    """View of one field within a :class:`DelayLineGroup`.

    Shares the group's clock — ``advance()`` on the group advances this slot
    too. Supports ``push(v)`` and ``tap(lag)`` with the same semantics as
    :class:`DelayLine`.
    """

    __slots__ = ('_buf', '_clk', '_depth')

    def __init__(self, buf, clk, depth):
        self._buf = buf
        self._clk = clk
        self._depth = depth

    def push(self, value):
        self._buf[self._clk[0] % self._depth] = _delay_value(value)

    def tap(self, lag):
        if not isinstance(lag, int):
            raise TypeError(f"tap lag must be a Python int, got {type(lag).__name__}")
        assert 0 < lag < self._depth, f"tap lag {lag} out of range [1, {self._depth})"
        return self._buf[(self._clk[0] - lag) % self._depth]


class DelayLineGroup:
    """Shared-clock bundle of named delay lines.

    Eliminates per-line ``advance()`` boilerplate and provides bulk
    ``push``/``tap`` for single-lag kernels. Multi-lag kernels access
    individual lines via attribute syntax (``dl.tile.tap(1)``).

    Args:
        depth: Ring depth (``max tap lag + 1``). Compile-time positive int.
        *fields: Field names (positional strings).

    Two usage modes:

    **Mode A — bulk (single-lag kernels):** all fields pushed and tapped at
    the same lag. ``tap(lag)`` returns a :class:`~types.SimpleNamespace`
    with all field values::

        dl = DelayLineGroup(3, 'batch', 'head', 'm', 'n')
        dl.push(batch=b, head=h, m=m, n=n)
        snap = dl.tap(2)          # → SimpleNamespace(batch=..., head=..., m=..., n=...)
        dl.advance()

    **Mode B — individual (multi-lag kernels):** different fields tapped at
    different lags. Access lines via attributes::

        dl = DelayLineGroup(4, 'tile', 'n', 'phys', 'is_last')
        dl.push(tile=t, n=n, phys=p, is_last=il)
        tile_at_1 = dl.tile.tap(1)    # tile at lag-1
        phys_at_2 = dl.phys.tap(2)    # phys at lag-2
        last_at_3 = dl.is_last.tap(3) # is_last at lag-3
        dl.advance()                  # ONE call advances all 4 lines
    """

    def __init__(self, depth, *fields):
        if not fields:
            raise ValueError("DelayLineGroup requires at least one field")
        if depth < 2:
            raise ValueError(f"DelayLineGroup depth must be >= 2, got {depth}")
        self._depth = depth
        self._fields = fields
        self._clk = _alloc_array(1, dtype=dtypes.int64, init=[0])
        self._bufs = {f: _alloc_array(depth, dtype=dtypes.int64) for f in fields}

    def push(self, **kwargs):
        """Write all fields at the current write head.

        Every field declared at construction must be provided as a keyword
        argument. Missing fields raise :class:`KeyError`.
        """
        slot = self._clk[0] % self._depth
        missing = set(self._fields) - set(kwargs)
        if missing:
            raise KeyError(f"push missing fields: {missing}")
        for f in self._fields:
            self._bufs[f][slot] = _delay_value(kwargs[f])

    def tap(self, lag):
        """Read ALL fields at a fixed lag → :class:`~types.SimpleNamespace`.

        Efficient for single-lag kernels where every field is consumed at the
        same pipeline stage. For multi-lag access, use attribute syntax
        (``dl.field.tap(lag)``) instead.
        """
        if not isinstance(lag, int):
            raise TypeError(f"tap lag must be a Python int, got {type(lag).__name__}")
        assert 0 < lag < self._depth, f"tap lag {lag} out of range [1, {self._depth})"
        slot = (self._clk[0] - lag) % self._depth
        return SimpleNamespace(**{f: self._bufs[f][slot] for f in self._fields})

    def advance(self):
        """Step the shared clock by one. Call once per loop iteration."""
        self._clk[0] = self._clk[0] + 1

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(name)
        bufs = object.__getattribute__(self, '_bufs')
        if name in bufs:
            return _DelaySlot(bufs[name], self._clk, self._depth)
        raise AttributeError(f"DelayLineGroup has no field {name!r}")
