# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Kernel launcher: the ``@kernel`` decorator and its calling conventions.

``KernelLauncher`` is the trace-time launch facade. In ordinary mode it
materializes a device function and emits a ``cannir.kernel_launch`` operation;
``inline=True`` bypasses that launch boundary and emits the kernel body into
the enclosing trace. ``_BoundKernelLauncher`` owns its receiver and launch
configuration independently from the shared descriptor.

Calling conventions matrix (caller -> callee):

    Python      -> @jit         OK   (DSL runtime; see jit_function.JitFunction)
    Python      -> @kernel      ERR  (compiler.kernel_materialize._emit_kernel_call)
    @jit        -> @jit         OK   (compile-time inline; jit_function nested path)
    @jit        -> Python       OK   (trace-time inline)
    @jit        -> @kernel      OK   (cannir.kernel_launch op -> NPU runtime)
    @kernel     -> @jit         OK   (compile-time inline via nested path)
    @kernel     -> Python       OK   (trace-time inline)
    @kernel     -> @kernel      ERR  (rejected here via _IN_KERNEL_BODY)

The two error paths are distinguished:
  * Python -> @kernel: raised in kernel_materialize._emit_kernel_call when no
    ``JitLoweringState`` is active.
  * @kernel -> @kernel: raised at the ``KernelLauncher.__call__`` entry by
    inspecting the ``_IN_KERNEL_BODY`` ContextVar set while a kernel body is
    being expanded.

``@kernel`` on a class
----------------------

When ``@kernel`` decorates a class, the resulting object is a launch handle
factory. ``op = C(*ctor_args, **ctor_kwargs)`` does *not* execute ``__init__``
in the host scope -- it only records the ctor arguments. Each call of the form
``op[block_dim].method(*args)`` (or ``op.method(*args)`` with default
``block_dim=1``, or ``op[block_dim](*args)`` ≡ ``op[block_dim].__call__(*args)``)
synthesises a kernel function whose body is

    inst = cls.__new__(cls)
    cls.__init__(inst, *ctor_args, **ctor_kwargs)
    return cls.<method>(inst, *args, **kwargs)

so all class methods and attributes live exclusively inside the kernel body
trace (each method gets its own device function). Implications:

* ``__init__`` may emit IR ops (for example, Channel construction) -- they land in the
  device function entry block, shared across all entry methods.
* Ctor arguments may be ordinary Python objects and containers. Passing an
  ``ir.Value`` (a live SSA value from the enclosing trace) raises ``TypeError``
  because it cannot cross into a separately traced device function; pass
  runtime values via the entry method. The recursive host-side check covers
  standard containers, normal instance dictionaries, real slots, cycles, and
  shared references as an early diagnostic; it does not prove arbitrary opaque
  objects are free of hidden SSA values.
* ``__init__`` is *not* run through frontend lowering: Python ``for`` / ``if``
  there expand under Python semantics during trace, which matches construction
  intent (for example, constructing several Channel members in a loop). Entry
  method bodies are still preprocessed.
* Eligible entries are instance methods (``inspect.isfunction`` + a first
  positional receiver), inherited via MRO, plus ``__call__``. Receiver names
  are immaterial. ``staticmethod`` / ``classmethod`` / other dunder methods
  are excluded.
* Same ``op`` invoking the same method twice reuses the Python wrapper, but
  retraces a candidate device function on every syntax call. Identical
  candidates are committed once by the content registry.
* ``op.<non-entry attr>`` raises ``AttributeError`` (host scope has no live
  ``__init__``); the message lists available entries.
"""

import inspect
from contextvars import ContextVar
from typing import Union

from cannbotdsl.core.compiler.kernel_materialize import _emit_kernel_call
from cannbotdsl.core.contracts.surface import (
    SurfaceSignature,
    class_local_namespace,
)
from cannbotdsl.core.frontend.compiler import compile_function
from cannbotdsl.core.mlir_context import _has_current_insertion_point


_IN_KERNEL_BODY: ContextVar[bool] = ContextVar("cannbotdsl_in_kernel_body", default=False)


class _BoundKernelLauncher:
    """Per-instance receiver and launch configuration for a ``@kernel`` method."""

    __slots__ = ("_launcher", "_instance", "_block_dim", "_surface")

    def __init__(
        self,
        launcher: "KernelLauncher",
        instance,
        surface: SurfaceSignature,
    ):
        self._launcher = launcher
        self._instance = instance
        self._block_dim = None
        self._surface = surface

    @property
    def __signature__(self):
        return self._surface.public_signature

    def __call__(self, *args, **kwargs):
        if _IN_KERNEL_BODY.get():
            raise RuntimeError("@kernel cannot be called from inside another @kernel")
        call_args = (self._instance, *args)
        token = _IN_KERNEL_BODY.set(True)
        try:
            if self._launcher.inline:
                # Inline mode: emit IR directly into the current scope so that
                # Channel state on shared instances flows naturally across
                # the inlined kernel boundary.
                if _has_current_insertion_point():
                    ir_builder = compile_function(self._launcher.fn).function
                    return ir_builder(*call_args, **kwargs)
            block_dim = self._block_dim if self._block_dim is not None else 1
            try:
                _emit_kernel_call(
                    self._launcher.fn,
                    call_args,
                    kwargs,
                    block_dim=block_dim,
                    surface_signature=self._surface,
                    profile=self._launcher.profile,
                )
            finally:
                self._block_dim = None
            return None
        finally:
            _IN_KERNEL_BODY.reset(token)

    def __getitem__(self, launch_config: Union[int, tuple]):
        if isinstance(launch_config, tuple):
            self._block_dim = launch_config[0]
        else:
            self._block_dim = launch_config
        return self


class KernelLauncher:
    """Trace-time facade that materializes or inlines a kernel launch."""

    def __init__(
        self,
        fn,
        *,
        inline=False,
        profile=None,
        _surface_signature: SurfaceSignature | None = None,
    ):
        self.fn = fn
        self.inline = inline
        self.profile = profile
        self._block_dim = None
        self._surface = SurfaceSignature.from_callable(fn) if _surface_signature is None else _surface_signature
        self.__signature__ = self._surface.signature
        if profile is not None:
            from cannbotdsl.core.profiling import ProfileSpec
            if not isinstance(profile, ProfileSpec):
                raise TypeError("kernel(profile=...) requires ProfileSpec")
            if inline:
                raise ValueError("inline kernels have no profiling launch boundary")
            profile._validate_signature(self._surface.signature)

    def __set_name__(self, owner, name):
        del name
        self._surface = self._surface.with_local_namespace(class_local_namespace(owner))

    def __call__(self, *args, **kwargs):
        if _IN_KERNEL_BODY.get():
            raise RuntimeError("@kernel cannot be called from inside another @kernel")
        token = _IN_KERNEL_BODY.set(True)
        try:
            if self.inline:
                if _has_current_insertion_point():
                    ir_builder = compile_function(self.fn).function
                    return ir_builder(*args, **kwargs)
            block_dim = self._block_dim if self._block_dim is not None else 1
            try:
                _emit_kernel_call(
                    self.fn,
                    args,
                    kwargs,
                    block_dim=block_dim,
                    surface_signature=self._surface,
                    profile=self.profile,
                )
            finally:
                self._block_dim = None
            return None
        finally:
            _IN_KERNEL_BODY.reset(token)

    def __get__(self, instance, owner):
        if instance is None:
            return self
        surface = self._surface.bind_receiver(label=f"bound @kernel entry {owner.__qualname__}.{self.fn.__name__}")
        return _BoundKernelLauncher(self, instance, surface)

    def __getitem__(self, launch_config: Union[int, tuple]):
        if isinstance(launch_config, tuple):
            self._block_dim = launch_config[0]
        else:
            self._block_dim = launch_config
        return self


def kernel(
    fn=None,
    *,
    inline=False,
    profile=None,
):
    def decorator(target):
        if inspect.isclass(target):
            # Local import to break the kernel_launcher ↔ kernel_class cycle:
            # kernel_class itself imports KernelLauncher from this module.
            from cannbotdsl.lang.kernel_class import _KernelClassLauncher

            return _KernelClassLauncher(
                target,
                inline=inline,
                profile=profile,
            )
        return KernelLauncher(
            target,
            inline=inline,
            profile=profile,
        )

    if fn is None:
        return decorator
    return decorator(fn)
