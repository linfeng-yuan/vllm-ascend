# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Class-form ``@kernel`` with context-free entry lowering.

The host-side handle records constructor arguments but never simulates
``__init__``.  During the synthetic device trace the raw constructor executes
against a real instance first, then the already-lowered entry executes on that
same instance.  Source analysis is therefore independent of constructor and
entry arguments while ordinary Python object setup remains trace-time code.
"""

from __future__ import annotations

import inspect
from dataclasses import dataclass

from cannbotdsl.core.contracts.surface import (
    SurfaceSignature,
    class_local_namespace,
)
from cannbotdsl.core.frontend.compiler import compile_function
from cannbotdsl.lang.kernel import KernelLauncher


@dataclass(frozen=True, slots=True)
class _KernelEntry:
    raw: object
    lowered: object
    surface: SurfaceSignature


def _contains_trace_value(value, visited: set[int]) -> bool:
    """Return whether a Python ctor value reaches an SSA value.

    Constructor values are retained by a host-side launch handle and replayed
    while a separate device function is traced. Ordinary Python objects are
    valid compile-time state, but an SSA value owned by the enclosing function
    cannot cross that function boundary. This traversal is an early diagnostic
    for standard containers and ordinary object storage, not a proof about
    arbitrary opaque objects and not a receiver-capture mechanism.
    """

    from cannbotdsl.core.compiler.staging import find_active_ssa_path

    return find_active_ssa_path(
        value,
        path="kernel constructor argument",
        visited=visited,
    ) is not None


def _collect_kernel_entries(cls) -> dict[str, tuple[object, SurfaceSignature]]:
    """Statically scan the MRO without invoking descriptors."""

    entries: dict[str, tuple[object, SurfaceSignature]] = {}
    seen: set[str] = set()
    localns = class_local_namespace(cls)
    for base in type.__getattribute__(cls, "__mro__"):
        namespace = type.__getattribute__(base, "__dict__")
        for name, member in namespace.items():
            if name in seen:
                continue
            seen.add(name)
            if name.startswith("__") and name.endswith("__") and name != "__call__":
                continue
            if not inspect.isfunction(member):
                continue
            surface = SurfaceSignature.from_callable(
                member,
                localns=localns,
            ).bind_receiver(
                label=f"@kernel entry {cls.__qualname__}.{name}"
            )
            variadic = next(
                (
                    parameter
                    for parameter in surface.signature.parameters.values()
                    if parameter.kind
                    in {
                        inspect.Parameter.VAR_POSITIONAL,
                        inspect.Parameter.VAR_KEYWORD,
                    }
                ),
                None,
            )
            if variadic is not None:
                raise TypeError(
                    f"@kernel entry {cls.__qualname__}.{name} does not support "
                    f"variadic parameter {variadic.name!r} (*args/**kwargs)"
                )
            entries[name] = (
                member,
                surface,
            )
    return entries


def _build_synthetic_kernel_fn(
    cls,
    method_name,
    ctor_args,
    ctor_kwargs,
    *,
    raw_init,
    entry: _KernelEntry,
):
    """Create a source-backed wrapper that initializes then dispatches."""

    fn_name = f"{cls.__name__}_{method_name}"

    def function(*args, **kwargs):
        instance = cls.__new__(cls)
        raw_init(instance, *ctor_args, **ctor_kwargs)
        return entry.lowered(instance, *args, **kwargs)

    function.__signature__ = entry.surface.public_signature
    function.__annotations__ = {
        parameter.name: parameter.annotation
        for parameter in entry.surface.public_signature.parameters.values()
        if parameter.annotation is not inspect.Parameter.empty
    }
    return_annotation = entry.surface.public_signature.return_annotation
    if return_annotation is not inspect.Signature.empty:
        function.__annotations__["return"] = return_annotation
    function.__module__ = cls.__module__
    function.__qualname__ = f"{cls.__qualname__}.{method_name}"
    function.__name__ = fn_name
    function.__cannbotdsl_surface_signature__ = (
        entry.surface.retarget_without_receiver(function)
    )
    return function


class _KernelClassLauncher:
    __slots__ = (
        "_cls",
        "_inline",
        "_entries",
        "_raw_init",
        "_profile",
    )

    def __init__(self, cls, *, inline, profile=None):
        self._cls = cls
        self._inline = inline
        self._profile = profile
        if profile is not None:
            from cannbotdsl.core.profiling import ProfileSpec
            if not isinstance(profile, ProfileSpec):
                raise TypeError("kernel(profile=...) requires ProfileSpec")
            if inline:
                raise ValueError("inline kernels have no profiling launch boundary")
        collected = _collect_kernel_entries(cls)
        if not collected:
            raise TypeError(
                f"@kernel class {cls.__name__} must define at least one instance method"
            )
        self._raw_init = cls.__init__
        if profile is not None:
            for _, surface in collected.values():
                profile._validate_signature(surface.signature)
        self._entries = {
            name: _KernelEntry(
                raw,
                compile_function(raw).function,
                surface,
            )
            for name, (raw, surface) in collected.items()
        }

    def __call__(self, *ctor_args, **ctor_kwargs):
        from cannbotdsl.core.compiler.staging import validate_no_active_ssa

        for index, value in enumerate(ctor_args):
            validate_no_active_ssa(
                value,
                path=f"constructor[{index}]",
                subject="@kernel class constructor argument",
            )
        for name, value in ctor_kwargs.items():
            validate_no_active_ssa(
                value,
                path=f'constructor["{name}"]',
                subject="@kernel class constructor argument",
            )

        return _KernelClassInstance(self, ctor_args, ctor_kwargs)

    def __repr__(self):
        return f"<@kernel class wrapper for {self._cls.__qualname__}>"


class _KernelClassInstance:
    __slots__ = (
        "_parent",
        "_ctor_args",
        "_ctor_kwargs",
        "_fn_cache",
    )

    def __init__(self, parent, ctor_args, ctor_kwargs):
        object.__setattr__(self, "_parent", parent)
        object.__setattr__(self, "_ctor_args", ctor_args)
        object.__setattr__(self, "_ctor_kwargs", ctor_kwargs)
        object.__setattr__(self, "_fn_cache", {})

    def __getitem__(self, block_dim):
        return _BlockDimBoundView(self, block_dim)

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        entries = self._parent._entries
        if name not in entries:
            raise AttributeError(
                f"@kernel class instance has no host-side attribute {name!r}; "
                f"__init__ runs lazily inside kernel body. Available kernel entries: "
                f"{sorted(entries)}"
            )
        return _MethodLauncher(self, name, block_dim=1)

    def __call__(self, *args, **kwargs):
        return _MethodLauncher(self, "__call__", block_dim=1)(*args, **kwargs)


class _BlockDimBoundView:
    __slots__ = ("_inst", "_block_dim")

    def __init__(self, inst, block_dim):
        self._inst = inst
        self._block_dim = block_dim

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        entries = self._inst._parent._entries
        if name not in entries:
            raise AttributeError(
                f"@kernel class has no entry {name!r}. Available: {sorted(entries)}"
            )
        return _MethodLauncher(self._inst, name, block_dim=self._block_dim)

    def __call__(self, *args, **kwargs):
        return _MethodLauncher(
            self._inst, "__call__", block_dim=self._block_dim
        )(*args, **kwargs)


class _MethodLauncher:
    __slots__ = ("_inst", "_name", "_block_dim")

    def __init__(self, inst, name, block_dim):
        self._inst = inst
        self._name = name
        self._block_dim = block_dim

    def __call__(self, *args, **kwargs):
        inst = self._inst
        function = inst._fn_cache.get(self._name)
        if function is None:
            entry = inst._parent._entries[self._name]
            function = _build_synthetic_kernel_fn(
                inst._parent._cls,
                self._name,
                inst._ctor_args,
                inst._ctor_kwargs,
                raw_init=inst._parent._raw_init,
                entry=entry,
            )
            inst._fn_cache[self._name] = function
        raw_function = function
        surface = function.__cannbotdsl_surface_signature__
        launcher = KernelLauncher(
            raw_function,
            inline=inst._parent._inline,
            profile=inst._parent._profile,
            _surface_signature=surface,
        )
        launcher[self._block_dim]
        return launcher(*args, **kwargs)
