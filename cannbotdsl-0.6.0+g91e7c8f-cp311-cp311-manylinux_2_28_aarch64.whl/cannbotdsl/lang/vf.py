# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""User-facing SIMD/SIMT VF context.

The default mode is ``"raw_reg"``.  ``mode="raw"`` remains accepted as a
compatibility alias and uses the same raw-register implementation.
"""

from contextvars import ContextVar
from typing import Optional, Sequence

import cannbotdsl._mlir.ir as ir


class _VfContext:
    __slots__ = ("group_id", "unroll", "output_keys", "mode", "thread")

    def __init__(self, group_id: int, unroll: int, output_keys, mode, thread):
        self.group_id = group_id
        self.unroll = unroll
        self.output_keys = output_keys  # tuple[str, ...] or None
        self.mode = mode  # canonical raw-register mode ("raw")
        self.thread = thread


_CURRENT_VF: ContextVar[Optional[_VfContext]] = ContextVar(
    "cannbotdsl_current_vf", default=None
)


class vf:
    """SIMD raw-register or scalar-per-thread SIMT VF context manager.

    The default ``vf()`` and ``mode="raw_reg"`` tag operations for the VF
    passes.  ``mode="raw"`` is retained as a compatibility alias.  In
    ``mode="simt"``, ``thread`` selects the launch width and defaults to 1024.
    """

    def __init__(self, *, mode: str = "raw_reg", thread: int = 1024,
                 unroll: int = 1,
                 outputs: Optional[Sequence] = None):
        if mode in ("raw", "raw_reg"):
            # The compiler IR historically spells raw-register mode "raw";
            # accept the clearer public spelling without changing emitted IR.
            normalized_mode = "raw"
        elif mode == "simt":
            normalized_mode = "simt"
        else:
            raise ValueError(
                f"unsupported vf mode {mode!r}; expected 'raw', 'raw_reg', or 'simt'"
            )
        if normalized_mode in ("raw", "simt"):
            if unroll != 1:
                raise ValueError(
                    f"vf(mode={mode!r}) does not support unroll=; "
                    "do not pass unroll explicitly"
                )
            if outputs is not None:
                raise ValueError(
                    f"vf(mode={mode!r}) has no transit buffers; outputs= is not supported"
                )
        if not isinstance(unroll, int) or unroll < 1:
            raise ValueError(f"unroll must be a positive int, got {unroll!r}")
        if type(thread) is not int or thread < 1:
            raise ValueError(f"thread must be a positive int, got {thread!r}")
        # Keep the caller's spelling for introspection and diagnostics; the
        # legacy IR spelling is normalized only when creating the active
        # context below.
        self._mode = mode
        self._unroll = unroll
        self._thread = thread
        self._output_keys = None
        if outputs is not None:
            from cannbotdsl.channel import Channel
            from cannbotdsl.tensor import Tensor

            for b in outputs:
                if not isinstance(b, (Tensor, Channel)):
                    raise TypeError(
                        "vf(outputs=...) entries must be Channel slots or "
                        f"scratch tensors, got {type(b).__name__}"
                    )
        self._token = None
        self._scope_group = None

    def __enter__(self):
        if _CURRENT_VF.get() is not None:
            raise RuntimeError("nested cannbotdsl.lang.vf() is not allowed")
        # vf_group_counter lives on the active JitLoweringState so it
        # resets automatically per trace — there's no module-level
        # state to drift across compile invocations.
        #
        # Outside a JIT trace (e.g. host-only unit tests that exercise
        # ``vf(mode=...)`` to assert API rejections) no IR is built and
        # the group_id is never consulted; fall back to ``0`` instead
        # of raising so those tests don't need to fabricate a state.
        from cannbotdsl.core.frontend.lowering_state import _current_lowering_state

        state = _current_lowering_state()
        if state is not None:
            state.vf_group_counter += 1
            group_id = state.vf_group_counter
        else:
            group_id = 0
        ctx = _VfContext(
            group_id=group_id,
            unroll=self._unroll,
            output_keys=self._output_keys,
            mode="raw" if self._mode == "raw_reg" else self._mode,
            thread=self._thread,
        )
        self._token = _CURRENT_VF.set(ctx)
        from cannbotdsl.core.mlir_context import _has_current_insertion_point

        if ctx.mode == "simt" and _has_current_insertion_point():
            attrs = {
                "group": ir.IntegerAttr.get(ir.IntegerType.get_signless(64), group_id),
                "mode": ir.StringAttr.get(ctx.mode),
            }
            if ctx.mode == "simt":
                attrs["threads"] = ir.IntegerAttr.get(
                    ir.IntegerType.get_signless(64), ctx.thread
                )
            ir.Operation.create("cannir.vf_scope_begin", attributes=attrs)
            self._scope_group = group_id
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._scope_group is not None:
            ir.Operation.create(
                "cannir.vf_scope_end",
                attributes={
                    "group": ir.IntegerAttr.get(
                        ir.IntegerType.get_signless(64), self._scope_group
                    )
                },
            )
        _CURRENT_VF.reset(self._token)
        return False


def _current_vf_mode() -> Optional[str]:
    ctx = _CURRENT_VF.get()
    return ctx.mode if ctx is not None else None


def _require_raw_mode(api_name: str) -> None:
    """Raise if not currently inside a ``with vf(mode='raw'):`` block."""
    ctx = _CURRENT_VF.get()
    if ctx is None or ctx.mode != "raw":
        raise RuntimeError(
            f"cannbotdsl.{api_name} can only be called inside "
            f"`with cannbotdsl.lang.vf(mode='raw'):`"
        )


def _forbid_in_raw_mode(api_name: str) -> None:
    """Raise if currently inside a raw-mode vf — the memref-level
    `cannbotdsl.ops.math.*` API is incompatible with raw-register SSA dataflow.
    """
    mode = _current_vf_mode()
    if mode == "raw":
        raise RuntimeError(
            f"cannbotdsl.{api_name} (memref-level vector op) cannot be called inside "
            "`with cannbotdsl.lang.vf(mode='raw'):`; use the raw_reg API instead"
        )


def _tag_if_in_vf(op) -> None:
    """If called inside a ``with cannbotdsl.lang.vf():`` block, stamp the tag
    attributes on *op*. No-op otherwise. Safe to call on every vector op
    emission site.
    """
    ctx = _CURRENT_VF.get()
    if ctx is None:
        return
    operation = op.operation if hasattr(op, "operation") else op
    i64 = ir.IntegerType.get_signless(64)
    operation.attributes["cannir.vf_group"] = ir.IntegerAttr.get(i64, ctx.group_id)
    operation.attributes["cannir.vf_unroll"] = ir.IntegerAttr.get(i64, ctx.unroll)
    if ctx.output_keys is not None:
        operation.attributes["cannir.vf_outputs"] = ir.ArrayAttr.get(
            [ir.StringAttr.get(k) for k in ctx.output_keys]
        )
    if ctx.mode is not None:
        operation.attributes["cannir.vf_mode"] = ir.StringAttr.get(ctx.mode)
