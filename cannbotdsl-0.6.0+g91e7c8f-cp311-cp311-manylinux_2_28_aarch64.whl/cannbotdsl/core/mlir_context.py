# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Safe probes for thread-local MLIR construction state."""

from __future__ import annotations

import cannbotdsl._mlir.ir as ir


def _has_current_context() -> bool:
    """Return whether an MLIR context is bound without leaking binding errors."""

    try:
        return ir.Context.current is not None
    except (AttributeError, ValueError):
        return False


def _has_current_insertion_point() -> bool:
    """Return whether an MLIR insertion point is bound without leaking errors."""

    try:
        return ir.InsertionPoint.current is not None
    except (AttributeError, ValueError):
        return False


__all__: list[str] = []
