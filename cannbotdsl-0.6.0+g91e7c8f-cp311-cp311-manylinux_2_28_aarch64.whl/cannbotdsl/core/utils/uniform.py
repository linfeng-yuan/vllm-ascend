# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# Licensed under CANN Open Software License Agreement Version 2.0.
"""Internal contract for immutable launch metadata shared by an AIC/AIV block."""


def _assume_block_uniform(value):
    """Mark a metadata scalar guaranteed equal on the cooperating AIC/AIVs.

    This is a trusted metadata-ABI assertion, not an inference about arbitrary
    GM loads. Callers must guarantee immutable input and an identical value on
    both vector subblocks and their cube core for this execution of the load.
    It neither synchronizes the device nor allocates any hardware IDs.
    """
    from cannbotdsl._mlir import ir
    from cannbotdsl.core.ir_transport import unwrap_operand

    if isinstance(value, (int, bool)):
        return value
    raw = unwrap_operand(value)
    if not isinstance(raw, ir.BlockArgument):
        raw.owner.attributes["cannir.block_uniform"] = ir.UnitAttr.get()
    return value
