# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Scalar literals, explicit casts, and lossless integer adaptation."""

from __future__ import annotations

import math

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import arith
from cannbotdsl.core.mlir_context import (
    _has_current_context,
    _has_current_insertion_point,
)


_FLOAT_TYPES = (ir.F16Type, ir.F32Type, ir.F64Type, ir.BF16Type)


def _render_literal(value: object) -> str:
    """Render diagnostics without Python's huge-integer digit limit."""

    if type(value) is int and value.bit_length() > 4096:
        return f"<int with {value.bit_length()} bits>"
    return repr(value)


def is_float_type(value_type: ir.Type) -> bool:
    return isinstance(value_type, _FLOAT_TYPES)


def is_integer_type(value_type: ir.Type) -> bool:
    return isinstance(value_type, ir.IntegerType)


def integer_bounds(
    value_type: ir.IntegerType, *, semantic_unsigned: bool | None = None
) -> tuple[int, int]:
    width = value_type.width
    if width == 1:
        return 0, 1
    if semantic_unsigned is None:
        semantic_unsigned = value_type.is_unsigned
    if semantic_unsigned:
        return 0, (1 << width) - 1
    return -(1 << (width - 1)), (1 << (width - 1)) - 1


def _float_maximum(value_type: ir.Type) -> float:
    if isinstance(value_type, ir.F16Type):
        return 65504.0
    if isinstance(value_type, ir.BF16Type):
        return 3.3895313892515355e38
    if isinstance(value_type, ir.F32Type):
        return 3.4028234663852886e38
    return 1.7976931348623157e308


def validate_literal(
    value: object,
    value_type: ir.Type,
    *,
    semantic_unsigned: bool | None = None,
) -> None:
    """Check whether a Python literal can be contextually typed as ``value_type``."""

    if isinstance(value_type, ir.IntegerType):
        if value_type.width == 1:
            if type(value) is not bool:
                raise TypeError(
                    f"Boolean/i1 requires a bool literal, got {type(value).__name__}"
                )
            return
        if type(value) is not int:
            raise TypeError(
                f"integer type {value_type} requires an int literal, "
                f"got {type(value).__name__}"
            )
        lower, upper = integer_bounds(
            value_type, semantic_unsigned=semantic_unsigned
        )
        if value < lower or value > upper:
            rendered_type = (
                f"ui{value_type.width}"
                if semantic_unsigned and not value_type.is_unsigned
                else str(value_type)
            )
            raise ValueError(
                f"integer literal {_render_literal(value)} is outside "
                f"{rendered_type} range "
                f"[{lower}, {upper}]"
            )
        return
    if isinstance(value_type, ir.IndexType):
        if type(value) is not int:
            raise TypeError(
                f"index requires an int literal, got {type(value).__name__}"
            )
        lower, upper = -(1 << 63), (1 << 63) - 1
        if value < lower or value > upper:
            raise ValueError(
                f"integer literal {_render_literal(value)} is outside index "
                f"range [{lower}, {upper}]"
            )
        return
    if is_float_type(value_type):
        if type(value) not in {int, float}:
            raise TypeError(
                f"floating type {value_type} requires an int or float literal, "
                f"got {type(value).__name__}"
            )
        try:
            converted = float(value)
        except (OverflowError, ValueError) as exc:
            raise ValueError(
                f"floating literal {_render_literal(value)} is not representable as "
                f"{value_type}"
            ) from exc
        if not math.isfinite(converted) or abs(converted) > _float_maximum(value_type):
            raise ValueError(
                f"floating literal {_render_literal(value)} is not finite and representable as "
                f"{value_type}"
            )
        return
    raise TypeError(f"cannot materialize a Python scalar as MLIR type {value_type}")


def materialize_literal(
    value: object,
    value_type: ir.Type,
    *,
    semantic_unsigned: bool | None = None,
    loc=None,
    ip=None,
) -> ir.Value:
    validate_literal(
        value, value_type, semantic_unsigned=semantic_unsigned
    )
    if isinstance(value_type, ir.IndexType):
        return arith.ConstantOp(
            value_type,
            ir.IntegerAttr.get(value_type, int(value)),
            loc=loc,
            ip=ip,
        ).result
    if isinstance(value_type, ir.IntegerType):
        integer_value = int(value)
        # Python's MLIR binding transports IntegerAttr values through a signed
        # 64-bit C++ carrier. Preserve the upper half of a semantic uint64 as
        # its equal-width two's-complement bit pattern in canonical i64.
        if (
            value_type.width == 64
            and value_type.is_signless
            and semantic_unsigned
            and integer_value > (1 << 63) - 1
        ):
            integer_value -= 1 << 64
        return arith.ConstantOp(
            value_type, integer_value, loc=loc, ip=ip
        ).result
    return arith.ConstantOp(value_type, float(value), loc=loc, ip=ip).result


def coerce_scalar_value(
    value: object,
    target_type: ir.Type,
    *,
    source_unsigned: bool | None = None,
    target_unsigned: bool | None = None,
    loc=None,
    ip=None,
) -> ir.Value:
    """Materialize a literal or emit the explicit cast to ``target_type``.

    Low-level APIs with a fixed operand type use this boundary instead of
    open-coding constant, index-cast, extension, and truncation policies.
    """

    if type(value) in {bool, int, float}:
        return materialize_literal(
            value,
            target_type,
            semantic_unsigned=target_unsigned,
            loc=loc,
            ip=ip,
        )
    if not isinstance(value, ir.Value):
        candidate = getattr(value, "value", None)
        if isinstance(candidate, ir.Value):
            value = candidate
    if not isinstance(value, ir.Value):
        raise TypeError(
            f"expected a Python numeric literal or scalar SSA value, got "
            f"{type(value).__name__}"
        )
    if source_unsigned is None:
        source_unsigned = bool(getattr(value, "unsigned", False))
    return cast_value(
        value,
        target_type,
        source_unsigned=source_unsigned,
        target_unsigned=target_unsigned,
        loc=loc,
        ip=ip,
    )


def _scalar_cast(value: object, dtype: object):
    """Implement the private conversion behind ``dtypes.<name>(value)``.

    Public dtype calls deliberately accept less than the implementation
    wrapper constructors.  A signless integer carrier does not encode whether
    its arithmetic semantics are signed or unsigned, so only a registered
    concrete wrapper may supply that meaning.  Floating carriers, i1,
    canonical unsigned storage carriers, and index are intrinsically
    unambiguous.  MLIR ``siN`` is not a CANNBotDSL storage or scalar carrier.
    """

    from cannbotdsl.core.contracts.elements import (
        element_for_dsl_type,
        element_for_integer,
        trace_scalar_for_dtype,
    )

    target = trace_scalar_for_dtype(dtype)
    target_wrapper = target.dsl_type
    assert target_wrapper is not None  # Established by trace_scalar_for_dtype.

    is_literal = type(value) in {bool, int, float}
    if not is_literal and not isinstance(value, ir.Value):
        raise TypeError(
            f"dtypes.{target.dtype.name}(value) expects a Python numeric "
            "literal or a DSL scalar value, got "
            f"{type(value).__name__}"
        )
    if not _has_current_context() or not _has_current_insertion_point():
        raise RuntimeError(
            f"dtypes.{target.dtype.name}(value) is a traced scalar operation "
            "and requires an active @jit/@kernel trace or MLIR Context and "
            "InsertionPoint"
        )

    if is_literal:
        target_type = target.scalar_mlir_type()
        carrier = materialize_literal(
            value,
            target_type,
            semantic_unsigned=target.dtype.signed is False,
        )
        return target_wrapper(carrier)

    assert isinstance(value, ir.Value)

    try:
        source = element_for_dsl_type(type(value))
    except TypeError:
        source = None
    if source is not None:
        expected_type = source.scalar_mlir_type()
        if value.type != expected_type:
            raise TypeError(
                f"{type(value).__name__} carries {value.type}, expected "
                f"{expected_type} for dtypes.{source.dtype.name}"
            )
        if source is target:
            return value
        return target_wrapper(value)

    source_type = value.type
    if isinstance(source_type, ir.IndexType):
        return target_wrapper(value)
    if is_float_type(source_type):
        return target_wrapper(value)
    if isinstance(source_type, ir.IntegerType):
        if source_type.width == 1:
            return target_wrapper(value)
        if source_type.is_signed:
            raise TypeError(
                f"cannot convert non-canonical signed MLIR carrier "
                f"{source_type} to dtypes.{target.dtype.name}; use a "
                "DSL-produced typed scalar"
            )
        if source_type.is_unsigned:
            from cannbotdsl._mlir.dialects import cannir

            source_info = element_for_integer(
                source_type.width, signed=False
            )
            source_wrapper = source_info.dsl_type
            assert source_wrapper is not None
            scalar_type = source_info.scalar_mlir_type()
            normalized = cannir.scalar_storage_cast(scalar_type, value)
            source_value = source_wrapper(normalized)
            if source_info is target:
                return source_value
            return target_wrapper(source_value)
        raise TypeError(
            f"cannot convert bare signless {source_type} to "
            f"dtypes.{target.dtype.name}: signedness is not recoverable; "
            "use a DSL-produced typed scalar"
        )
    raise TypeError(
        f"cannot convert DSL scalar carrier {source_type} to "
        f"dtypes.{target.dtype.name}"
    )


def cast_value(
    value: ir.Value,
    target_type: ir.Type,
    *,
    source_unsigned: bool | None = None,
    target_unsigned: bool | None = None,
    loc=None,
    ip=None,
) -> ir.Value:
    """Emit a real numeric cast or reject an unsupported conversion."""

    if not isinstance(value, ir.Value):
        raise TypeError(
            f"explicit cast expects an MLIR value, got {type(value).__name__}"
        )
    source_type = value.type
    if source_unsigned is None:
        source_unsigned = bool(
            isinstance(source_type, ir.IntegerType) and source_type.is_unsigned
        )
    if target_unsigned is None:
        target_unsigned = bool(
            isinstance(target_type, ir.IntegerType) and target_type.is_unsigned
        )
    if source_type == target_type:
        return value

    if isinstance(source_type, ir.IndexType) and isinstance(
        target_type, ir.IntegerType
    ):
        operation = arith.index_castui if target_unsigned else arith.index_cast
        return operation(target_type, value, loc=loc, ip=ip)

    if isinstance(source_type, ir.IntegerType) and isinstance(
        target_type, ir.IndexType
    ):
        operation = arith.index_castui if source_unsigned else arith.index_cast
        return operation(target_type, value, loc=loc, ip=ip)

    if isinstance(source_type, ir.IntegerType) and isinstance(
        target_type, ir.IntegerType
    ):
        source_width = source_type.width
        target_width = target_type.width
        if source_width == target_width:
            # arith.bitcast accepts signless integers, not MLIR's signed/ui
            # integer spellings.  Returning the original value would create a
            # wrapper whose advertised dtype disagrees with its SSA type.
            raise TypeError(
                f"numeric conversion from {source_type} to {target_type} is "
                "not available for equal-width integer types"
            )
        if source_width > target_width:
            return arith.trunci(target_type, value, loc=loc, ip=ip)
        extension = arith.extui if source_unsigned or source_width == 1 else arith.extsi
        return extension(target_type, value, loc=loc, ip=ip)

    if isinstance(source_type, ir.IntegerType) and is_float_type(target_type):
        conversion = (
            arith.uitofp
            if source_unsigned or source_type.width == 1
            else arith.sitofp
        )
        return conversion(target_type, value, loc=loc, ip=ip)

    if is_float_type(source_type) and isinstance(target_type, ir.IntegerType):
        operation = (
            arith.FPToUIOp(target_type, value, loc=loc, ip=ip)
            if target_unsigned
            else arith.FPToSIOp(target_type, value, loc=loc, ip=ip)
        )
        return operation.result

    if is_float_type(source_type) and is_float_type(target_type):
        source_width = source_type.width
        target_width = target_type.width
        if source_width < target_width:
            return arith.extf(target_type, value, loc=loc, ip=ip)
        if source_width > target_width:
            return arith.truncf(target_type, value, loc=loc, ip=ip)
        # f16 and bf16 have equal width but different formats.  A bitcast would
        # silently reinterpret payload bits, not numerically convert them.
        raise TypeError(
            f"numeric conversion from {source_type} to {target_type} is not "
            "available; use an explicit tensor/vector cast operation"
        )

    raise TypeError(
        f"cannot explicitly cast MLIR scalar from {source_type} to {target_type}"
    )


def require_same_dynamic_type(
    lhs: ir.Value,
    rhs: ir.Value,
    *,
    operation: str,
) -> None:
    if lhs.type != rhs.type:
        raise TypeError(
            f"{operation} operands have different resolved types: "
            f"{lhs.type} versus {rhs.type}; cast one operand explicitly"
        )


def _integer_element(value):
    """Recover integer semantics only from a registered concrete producer."""
    from cannbotdsl.core.contracts.elements import element_for_dsl_type

    try:
        element = element_for_dsl_type(type(value))
    except TypeError:
        return None
    if element.dtype.signed is None or element.dtype.name == "bool":
        return None
    if not isinstance(value, ir.Value) or value.type != element.scalar_mlir_type():
        return None
    return element


def _common_integer_element(elements, *, operation):
    """Same signedness selects the widest dtype; literals never widen it."""
    elements = tuple(elements)
    if not elements or any(element is None for element in elements):
        raise TypeError(f"{operation} requires typed DSL integers; bare signless signedness is ambiguous")
    if any(element.dtype.signed != elements[0].dtype.signed for element in elements):
        raise TypeError(f"{operation} operands have different resolved signedness; cast one operand explicitly")
    return max(elements, key=lambda element: element.dtype.bits)


def _can_widen_integer(source, target):
    return (
        source is not None
        and target is not None
        and source.dtype.signed is not None
        and source.dtype.signed == target.dtype.signed
        and source.dtype.bits <= target.dtype.bits
    )


def _coerce_lossless_integer(value, target, *, operation, loc=None, ip=None):
    if type(value) is not int and not _can_widen_integer(_integer_element(value), target):
        raise TypeError(f"{operation} requires a lossless same-signedness integer conversion; cast explicitly")
    carrier = coerce_scalar_value(
        value, target.scalar_mlir_type(),
        source_unsigned=target.dtype.signed is False,
        target_unsigned=target.dtype.signed is False,
        loc=loc, ip=ip,
    )
    return target.dsl_type(carrier)


def _promote_integer_operands(lhs, rhs, *, operation, loc=None, ip=None):
    target = _common_integer_element(
        (_integer_element(value) for value in (lhs, rhs) if type(value) is not int),
        operation=operation,
    )
    return tuple(
        _coerce_lossless_integer(value, target, operation=operation, loc=loc, ip=ip)
        for value in (lhs, rhs)
    )


def _validate_index_value(value, *, operation="index"):
    """Keep the established i64/index carrier escape hatch, but never guess
    the signedness of a bare narrow signless integer.
    """
    if type(value) is int:
        return
    if isinstance(value, ir.Value):
        ty = value.type
        if isinstance(ty, ir.IndexType):
            return
        if isinstance(ty, ir.IntegerType) and ty.width in {8, 16, 32, 64}:
            if _integer_element(value) is not None or ty.is_unsigned or (ty.is_signless and ty.width == 64):
                return
    raise TypeError(
        f"{operation} requires a Python int, typed DSL integer, or i64/index carrier; "
        f"bare narrow signless signedness is ambiguous (got {getattr(value, 'type', type(value).__name__)})"
    )


def _index_value(value, *, target_type=None, operation="index", loc=None, ip=None):
    """Adapt address operands while wrapper signedness is still available."""
    _validate_index_value(value, operation=operation)
    target_type = ir.IntegerType.get_signless(64) if target_type is None else target_type
    unsigned = False
    if isinstance(value, ir.Value) and isinstance(value.type, ir.IntegerType):
        unsigned = bool(getattr(value, "unsigned", False)) or value.type.is_unsigned
        if value.type.is_unsigned:
            from cannbotdsl._mlir.dialects import cannir

            value = cannir.scalar_storage_cast(ir.IntegerType.get_signless(value.type.width), value)
    return coerce_scalar_value(value, target_type, source_unsigned=unsigned, loc=loc, ip=ip)


def _int64_result(value):
    """Attach the canonical semantic dtype to a producer-owned i64 result."""

    from cannbotdsl.types._numeric import Int64

    return Int64(value)


def _integer_attribute(operation, name: str) -> int | None:
    try:
        return int(ir.IntegerAttr(operation.attributes[name]).value)
    except (KeyError, TypeError, ValueError):
        return None


def _constant_i64(value) -> int | None:
    if type(value) is int:
        return value
    if not isinstance(value, ir.Value):
        return None
    owner = getattr(value, "owner", None)
    # Block arguments report their owning Block here, while OpResults report
    # the defining Operation.  Only the latter has an operation name and
    # attributes to inspect.
    if owner is None or str(getattr(owner, "name", "")) != "arith.constant":
        return None
    return _integer_attribute(owner, "value")


__all__ = [
    "cast_value",
    "coerce_scalar_value",
    "integer_bounds",
    "is_float_type",
    "is_integer_type",
    "materialize_literal",
    "require_same_dynamic_type",
    "validate_literal",
]
