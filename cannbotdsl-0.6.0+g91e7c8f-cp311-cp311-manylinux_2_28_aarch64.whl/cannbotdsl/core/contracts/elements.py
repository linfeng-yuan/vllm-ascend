# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Canonical backend mappings for CANNBotDSL scalar elements."""

from __future__ import annotations

import ctypes
import math
from dataclasses import dataclass
from typing import Callable

from cannbotdsl.types import dtypes
from cannbotdsl.types.dtypes import DType, DTypeKind, _DTYPES, _resolve_dtype
from cannbotdsl.types._numeric import BFloat16, Float16, Float32, Float64
from cannbotdsl.types._numeric import (
    Boolean,
    Int8,
    Int16,
    Int32,
    Int64,
    UInt8,
    UInt16,
    UInt32,
    UInt64,
)
from cannbotdsl.core.diag.diagnostics import (
    ABI101_RUNTIME_ARGUMENT_REJECTED,
    CANNBotTypeError,
    CANNBotValueError,
    CT101_INVALID_RUNTIME_DEFAULT,
)


@dataclass(frozen=True, slots=True)
class ElementInfo:
    dtype: DType
    tag: str
    dsl_type: type | None
    # Historical field names: internal Host ABI semantic codes, including
    # restored FP8 codes. Native validates DLPack 1.0 transport separately.
    dlpack_code: int
    dlpack_bits: int
    torch_name: str | None
    ascendc_name: str
    scalar_ctype: type | None = None
    aggregate_ctype: type | None = None
    storage_factory: Callable[[], object] | None = None

    def __post_init__(self) -> None:
        if self.dsl_type is not None:
            assert getattr(self.dsl_type, "_dtype", None) is self.dtype

    @property
    def cpp_name(self) -> str:
        """AscendC spelling retained under the lowering-facing name."""

        return self.ascendc_name

    @property
    def mlir_element_name(self) -> str:
        """Canonical tensor/vector element spelling."""

        if self.dtype.format == "int4x2":
            return "!cannir.int4x2"
        if self.dtype.kind is DTypeKind.BOOLEAN:
            return "i1"
        if self.dtype.kind is DTypeKind.INTEGER:
            prefix = "i" if self.dtype.signed else "ui"
            return f"{prefix}{self.dtype.bits}"
        return {
            "ieee-f16": "f16",
            "ieee-f32": "f32",
            "ieee-f64": "f64",
            "bfloat16": "bf16",
            "float8-e4m3fn": "f8E4M3FN",
            "float8-e5m2": "f8E5M2",
            "float8-e8m0": "!cannir.fp8_e8m0",
            "hifloat8": "!cannir.hifloat8",
            "fp4x2-e2m1": "!cannir.fp4x2_e2m1",
            "fp4x2-e1m2": "!cannir.fp4x2_e1m2",
        }[self.dtype.format]

    @property
    def mlir_scalar_name(self) -> str | None:
        """Canonical scalar-arithmetic spelling."""

        if self.dsl_type is None:
            return None
        if self.dtype.kind in {DTypeKind.BOOLEAN, DTypeKind.INTEGER}:
            # MLIR arith integer operations use signless operands.
            return f"i{self.dtype.bits}"
        return self.mlir_element_name

    @property
    def scalar_kind(self) -> str | None:
        if self.scalar_ctype is None:
            return None
        if self.dtype.kind is DTypeKind.BOOLEAN:
            return "bool"
        if self.dtype.kind is DTypeKind.INTEGER:
            return "int"
        if self.dtype.kind is DTypeKind.FLOAT:
            return "float"
        return None

    @property
    def scalar_minimum(self) -> int | None:
        return self.dtype.minimum

    @property
    def scalar_maximum(self) -> int | None:
        return self.dtype.maximum

    @property
    def runtime_annotation(self):
        """Public annotation spelling for a standalone runtime scalar."""

        return {
            "bool": bool,
            "int64": int,
            "float32": float,
        }.get(self.dtype.name, self.dtype)

    def mlir_type(self):
        """Build the tensor/vector storage type."""

        if self.storage_factory is not None:
            return self.storage_factory()
        if self.dsl_type is None:  # pragma: no cover - table invariant
            raise TypeError(f"dtypes.{self.dtype.name} has no storage carrier")
        return self.dsl_type.mlir_type()

    def scalar_mlir_type(self):
        """Build the real scalar ``arith`` type through its SSA wrapper."""

        if self.dsl_type is None:
            raise TypeError(f"dtypes.{self.dtype.name} has no executable scalar wrapper")
        factory = getattr(self.dsl_type, "scalar_mlir_type", self.dsl_type.mlir_type)
        return factory()


def _float8_e4m3fn_storage_type():
    import cannbotdsl._mlir.ir as ir

    return ir.Float8E4M3FNType.get()


def _float8_e5m2_storage_type():
    import cannbotdsl._mlir.ir as ir

    return ir.Float8E5M2Type.get()


def _float8_e8m0_storage_type():
    from cannbotdsl._mlir.dialects import cannir

    return cannir.FP8E8M0Type.get()


def _hifloat8_storage_type():
    from cannbotdsl._mlir.dialects import cannir

    return cannir.HiFloat8Type.get()


def _fp4x2_e2m1_storage_type():
    from cannbotdsl._mlir.dialects import cannir

    return cannir.Fp4x2E2M1Type.get()


def _fp4x2_e1m2_storage_type():
    from cannbotdsl._mlir.dialects import cannir

    return cannir.Fp4x2E1M2Type.get()


def _int4x2_storage_type():
    from cannbotdsl._mlir.dialects import cannir

    return cannir.Int4x2Type.get()


_STORAGE_ELEMENTS = (
    ElementInfo(
        dtypes.float16,
        "f16",
        Float16,
        2,
        16,
        "torch.float16",
        "half",
    ),
    ElementInfo(
        dtypes.float32,
        "f32",
        Float32,
        2,
        32,
        "torch.float32",
        "float",
        ctypes.c_float,
        ctypes.c_float,
    ),
    ElementInfo(
        dtypes.float64,
        "f64",
        Float64,
        2,
        64,
        "torch.float64",
        "double",
        ctypes.c_double,
        ctypes.c_double,
    ),
    ElementInfo(
        dtypes.bfloat16,
        "bf16",
        BFloat16,
        4,
        16,
        "torch.bfloat16",
        "bfloat16_t",
    ),
    ElementInfo(
        dtypes.float8_e4m3fn,
        "f8e4m3",
        None,
        10,
        8,
        "torch.float8_e4m3fn",
        "fp8_e4m3fn_t",
        storage_factory=_float8_e4m3fn_storage_type,
    ),
    ElementInfo(
        dtypes.float8_e5m2,
        "f8e5m2",
        None,
        12,
        8,
        "torch.float8_e5m2",
        "fp8_e5m2_t",
        storage_factory=_float8_e5m2_storage_type,
    ),
    ElementInfo(
        dtypes.float8_e8m0,
        "f8e8m0",
        None,
        14,
        8,
        None,
        "fp8_e8m0_t",
        storage_factory=_float8_e8m0_storage_type,
    ),
    ElementInfo(
        dtypes.hifloat8,
        "hif8",
        None,
        # HiFloat8 is a Huawei-private format: DLPack has no standard code and
        # torch has no dtype for it, so callers smuggle raw bytes through
        # torch.int8 the same way they do for the e8m0 scale.  The code below
        # only has to stay unique in this table and agree with the descriptor
        # emitted by TranslateToAscendC.
        200,
        8,
        None,
        "hifloat8_t",
        storage_factory=_hifloat8_storage_type,
    ),
    ElementInfo(
        dtypes.fp4x2_e2m1,
        "fp4x2e2m1",
        None,
        # DLPack kDLFloat4_e2m1fn; torch has no dtype for it, so callers pass
        # the packed bytes through torch.int8/uint8.
        17,
        4,
        None,
        "fp4x2_e2m1_t",
        storage_factory=_fp4x2_e2m1_storage_type,
    ),
    ElementInfo(
        dtypes.fp4x2_e1m2,
        "fp4x2e1m2",
        None,
        # No standardized DLPack code exists for E1M2; runtime tensors use a
        # byte carrier and the semantic code remains private to this project.
        201,
        4,
        None,
        "fp4x2_e1m2_t",
        storage_factory=_fp4x2_e1m2_storage_type,
    ),
    ElementInfo(
        dtypes.int4x2,
        "int4x2",
        None,
        # DLPack signed integer code with four logical bits. Torch callers use
        # a packed byte carrier because torch has no native int4 scalar dtype.
        0,
        4,
        None,
        "int4x2_t",
        storage_factory=_int4x2_storage_type,
    ),
    ElementInfo(
        dtypes.int8,
        "i8",
        Int8,
        0,
        8,
        "torch.int8",
        "int8_t",
        ctypes.c_int8,
        ctypes.c_int8,
    ),
    ElementInfo(
        dtypes.int16,
        "i16",
        Int16,
        0,
        16,
        "torch.int16",
        "int16_t",
        ctypes.c_int16,
        ctypes.c_int16,
    ),
    ElementInfo(
        dtypes.int32,
        "i32",
        Int32,
        0,
        32,
        "torch.int32",
        "int32_t",
        ctypes.c_int32,
        ctypes.c_int32,
    ),
    ElementInfo(
        dtypes.int64,
        "i64",
        Int64,
        0,
        64,
        "torch.int64",
        "int64_t",
        ctypes.c_int64,
        ctypes.c_int64,
    ),
    ElementInfo(
        dtypes.uint8,
        "u8",
        UInt8,
        1,
        8,
        "torch.uint8",
        "uint8_t",
        ctypes.c_uint8,
        ctypes.c_uint8,
    ),
    ElementInfo(
        dtypes.uint16,
        "u16",
        UInt16,
        1,
        16,
        "torch.uint16",
        "uint16_t",
        ctypes.c_uint16,
        ctypes.c_uint16,
    ),
    ElementInfo(
        dtypes.uint32,
        "u32",
        UInt32,
        1,
        32,
        "torch.uint32",
        "uint32_t",
        ctypes.c_uint32,
        ctypes.c_uint32,
    ),
    ElementInfo(
        dtypes.uint64,
        "u64",
        UInt64,
        1,
        64,
        "torch.uint64",
        "uint64_t",
        ctypes.c_uint64,
        ctypes.c_uint64,
    ),
    # DLPack bool is byte-addressed even though its semantic/SSA type is i1.
    ElementInfo(
        dtypes.bool,
        "bool",
        Boolean,
        6,
        8,
        "torch.bool",
        "int8_t",
        ctypes.c_bool,
        ctypes.c_bool,
    ),
)


def _unique_map(items, key, *, label: str) -> dict:
    result = {key(item): item for item in items}
    if len(result) != len(items):  # pragma: no cover - module invariant
        raise ValueError(f"element table contains duplicate {label}")
    return result


if len(_STORAGE_ELEMENTS) != len(_DTYPES) or {item.dtype for item in _STORAGE_ELEMENTS} != set(
    _DTYPES
):  # pragma: no cover - module invariant
    raise ValueError("storage table must cover every canonical dtype exactly once")

_SCALAR_ELEMENTS = tuple(item for item in _STORAGE_ELEMENTS if item.dsl_type is not None)

_BY_DTYPE = _unique_map(_STORAGE_ELEMENTS, lambda item: item.dtype, label="dtypes")
_BY_NAME = _unique_map(_STORAGE_ELEMENTS, lambda item: item.dtype.name, label="dtype names")
_BY_TAG = _unique_map(_STORAGE_ELEMENTS, lambda item: item.tag, label="ABI tags")
_BY_DSL_TYPE = _unique_map(_SCALAR_ELEMENTS, lambda item: item.dsl_type, label="SSA wrappers")
_BY_DLPACK = _unique_map(
    _STORAGE_ELEMENTS,
    lambda item: (item.dlpack_code, item.dlpack_bits),
    label="DLPack encodings",
)
_TORCH_ELEMENTS = tuple(item for item in _STORAGE_ELEMENTS if item.torch_name is not None)
_BY_TORCH = _unique_map(_TORCH_ELEMENTS, lambda item: item.torch_name, label="Torch spellings")
_INTEGER_ELEMENTS = tuple(item for item in _SCALAR_ELEMENTS if item.dtype.kind is DTypeKind.INTEGER)
_BY_INTEGER = _unique_map(
    _INTEGER_ELEMENTS,
    lambda item: (item.dtype.bits, item.dtype.signed),
    label="integer width/signedness pairs",
)


def element_for_name(name: str) -> ElementInfo:
    try:
        return _BY_NAME[name]
    except KeyError as exc:
        raise ValueError(f"unknown CANNBotDSL dtype {name!r}") from exc


def element_for_tag(tag: str) -> ElementInfo:
    try:
        return _BY_TAG[tag]
    except KeyError as exc:
        raise ValueError(f"unknown CANNBotDSL element tag {tag!r}") from exc


def element_for_dtype(dtype: object, *, allow_python: bool = False) -> ElementInfo:
    return _BY_DTYPE[_resolve_dtype(dtype, allow_python=allow_python)]


def element_for_dsl_type(dtype: object) -> ElementInfo:
    """Resolve an exact internal SSA wrapper class to its element info."""

    for item in _SCALAR_ELEMENTS:
        if dtype is item.dsl_type:
            return item
    if isinstance(dtype, type):
        rendered = type.__getattribute__(dtype, "__name__")
    else:
        rendered = type.__getattribute__(type(dtype), "__name__")
    raise TypeError(f"unsupported internal scalar value wrapper {rendered}")


def element_for_integer(bits: int, signed: bool) -> ElementInfo:
    """Resolve the canonical integer descriptor for width and signedness."""

    try:
        return _BY_INTEGER[(bits, signed)]
    except (KeyError, TypeError) as exc:
        raise TypeError(f"unsupported CANNBotDSL integer dtype bits={bits!r}, signed={signed!r}") from exc


def element_for_storage_mlir_type(mlir_type) -> ElementInfo:
    """Resolve a canonical dtype from its tensor/array storage carrier."""

    for item in _STORAGE_ELEMENTS:
        if item.mlir_type() == mlir_type:
            return item
    raise TypeError(f"unsupported scalar storage carrier {mlir_type}")


def dtype_for_storage_mlir_type(mlir_type) -> DType:
    """Resolve the canonical semantic descriptor for tensor storage."""

    return element_for_storage_mlir_type(mlir_type).dtype


def wrap_produced_scalar(value, *, storage_type=None):
    """Attach the canonical semantic wrapper at a scalar producer boundary."""

    import cannbotdsl._mlir.ir as ir
    from cannbotdsl._mlir.dialects import cannir

    if not isinstance(value, ir.Value):
        raise TypeError(f"scalar producer must return an MLIR value, got {type(value).__name__}")
    storage_type = value.type if storage_type is None else storage_type
    info = element_for_storage_mlir_type(storage_type)
    if value.type != storage_type:
        raise TypeError(f"scalar producer returned carrier {value.type}, expected {storage_type}")
    scalar_type = info.scalar_mlir_type()
    if value.type != scalar_type:
        value = cannir.scalar_storage_cast(scalar_type, value)
    return info.dsl_type(value)


def coerce_scalar_to_storage(value, storage_type, *, path: str = "value"):
    """Validate scalar semantics and materialize a storage carrier."""

    import cannbotdsl._mlir.ir as ir
    from cannbotdsl._mlir.dialects import cannir

    info = element_for_storage_mlir_type(storage_type)
    if info.dsl_type is None:
        raise TypeError(
            f"{path} uses dtypes.{info.dtype.name}, which has tensor storage support but no executable scalar wrapper"
        )
    if not isinstance(value, ir.Value):
        try:
            value = info.dsl_type(value)
        except (TypeError, ValueError) as exc:
            raise TypeError(f"{path} is not representable as dtypes.{info.dtype.name}") from exc
    elif not isinstance(value, info.dsl_type):
        raise TypeError(
            f"{path} expects a canonical {info.dsl_type.__name__} value; "
            f"bare carrier {value.type} has no recoverable dtype semantics"
        )

    scalar_type = info.scalar_mlir_type()
    if value.type != scalar_type:
        raise TypeError(f"{path} wrapper {type(value).__name__} has carrier {value.type}, expected {scalar_type}")
    if scalar_type != storage_type:
        value = cannir.scalar_storage_cast(storage_type, value)
    return value


def dsl_type_for_dtype(dtype: object, *, allow_python: bool = False) -> type:
    return trace_scalar_for_dtype(dtype, allow_python=allow_python).dsl_type


def trace_scalar_for_dtype(dtype: object, *, allow_python: bool = False) -> ElementInfo:
    """Require an executable trace-body scalar wrapper for ``dtype``.

    This capability is deliberately independent from the standalone host
    scalar ABI: types such as float16 can participate in traced scalar
    expressions without being accepted as direct host scalar arguments, while
    FP8 descriptors are storage-only and support neither operation.
    """

    info = element_for_dtype(dtype, allow_python=allow_python)
    if info.dsl_type is None:
        raise TypeError(f"dtypes.{info.dtype.name} has tensor storage support but no executable scalar wrapper")
    return info


def trace_scalar_for_value(
    value: object,
    *,
    path: str = "ScalarValue parameter",
) -> ElementInfo:
    """Resolve one trace argument through the closed scalar-wrapper registry.

    Python literals receive the ordinary bool/int64/float32 defaults.  Dynamic
    values must be an exact framework wrapper; a dtype-looking third-party
    object or a bare SSA carrier is never accepted by structural typing.
    """

    if type(value) in {bool, int, float}:
        return trace_scalar_for_dtype(type(value), allow_python=True)

    import cannbotdsl._mlir.ir as ir

    if not isinstance(value, ir.Value):
        raise TypeError(
            f"{path} expects a Python bool/int/float or a registered DSL scalar wrapper, got {type(value).__name__}"
        )

    try:
        info = element_for_dsl_type(type(value))
    except TypeError:
        info = None
    if info is not None:
        expected = info.scalar_mlir_type()
        if value.type != expected:
            raise TypeError(
                f"{path} received {type(value).__name__} with carrier "
                f"{value.type}; dtypes.{info.dtype.name} requires {expected}"
            )
        return info

    carrier = value.type
    if isinstance(carrier, ir.IntegerType) and carrier.width > 1 and not carrier.is_signed and not carrier.is_unsigned:
        raise TypeError(
            f"{path} cannot infer signedness from bare signless integer "
            f"carrier {carrier}; use a DSL-produced typed scalar"
        )
    raise TypeError(
        f"{path} expects a registered DSL scalar wrapper, got {type(value).__name__} with carrier {carrier}"
    )


def mlir_type_for_dtype(dtype: object, *, allow_python: bool = False):
    return element_for_dtype(dtype, allow_python=allow_python).mlir_type()


def scalar_mlir_type_for_dtype(dtype: object, *, allow_python: bool = False):
    return element_for_dtype(dtype, allow_python=allow_python).scalar_mlir_type()


def normalize_storage_dtype(dtype: object):
    """Return the canonical tensor-storage dtype descriptor."""

    try:
        return _resolve_dtype(dtype)
    except TypeError as exc:
        raise TypeError(f"dtype must be a canonical dtypes.* descriptor, got {dtype!r}") from exc


def storage_mlir_type_for_dtype(dtype: object):
    normalized = normalize_storage_dtype(dtype)
    return mlir_type_for_dtype(normalized)


def element_for_dlpack(code: int, bits: int, lanes: int = 1) -> ElementInfo:
    """Resolve validated metadata, including restored internal semantic dtypes."""
    if int(lanes) != 1:
        raise TypeError(f"tensor dtype lanes must be 1, got {lanes}")
    try:
        return _BY_DLPACK[(int(code), int(bits))]
    except KeyError as exc:
        raise TypeError(f"unsupported runtime tensor dtype code={code}, bits={bits}, lanes={lanes}") from exc


def scalar_for_dsl_type(dtype: type) -> ElementInfo:
    return _require_scalar_abi(element_for_dsl_type(dtype))


def scalar_for_dtype(dtype: object, *, allow_python: bool = False) -> ElementInfo:
    return _require_scalar_abi(element_for_dtype(dtype, allow_python=allow_python))


def host_scalar_for_value(
    value: object,
    *,
    path: str = "runtime ScalarValue parameter",
) -> ElementInfo:
    """Resolve an exact host scalar to its default standalone ABI dtype."""

    if type(value) not in {bool, int, float}:
        raise TypeError(f"{path} expects a Python bool/int/float, got {type(value).__name__}")
    return scalar_for_dtype(type(value), allow_python=True)


def validate_host_scalar_value(
    info: ElementInfo,
    value: object,
    *,
    path: str,
    code=ABI101_RUNTIME_ARGUMENT_REJECTED,
    phase: str = "host-abi",
) -> object:
    """Validate one Python value against a standalone scalar ABI slot.

    This is deliberately MLIR-independent and is shared by direct-JIT
    binding, persisted runtime defaults, and loaded ``ProviderCallable``
    invocation.  The original Python value is returned unchanged.
    """

    hint = (
        f"Pass a finite Python value representable as dtypes.{info.dtype.name} "
        "or change the boundary annotation/descriptor to the intended dtype."
    )

    def type_error(message: str):
        error_type = (
            CANNBotValueError
            if code is CT101_INVALID_RUNTIME_DEFAULT
            else CANNBotTypeError
        )
        raise error_type(
            code,
            message,
            phase=phase,
            path=path,
            hint=hint,
        )

    def value_error(message: str):
        raise CANNBotValueError(
            code,
            message,
            phase=phase,
            path=path,
            hint=hint,
        )

    if info.scalar_kind == "bool":
        if type(value) is not bool:
            type_error(
                f"{path} expects bool for dtypes.{info.dtype.name}, got "
                f"{type(value).__name__}"
            )
        return value

    if info.scalar_kind == "int":
        if type(value) is not int:
            type_error(
                f"{path} expects int for dtypes.{info.dtype.name}, got "
                f"{type(value).__name__}"
            )
        assert info.scalar_minimum is not None and info.scalar_maximum is not None
        if value < info.scalar_minimum or value > info.scalar_maximum:
            value_error(
                f"{path}={value} is outside dtypes.{info.dtype.name} range "
                f"[{info.scalar_minimum}, {info.scalar_maximum}]"
            )
        return value

    if info.scalar_kind == "float":
        if type(value) not in {int, float}:
            type_error(
                f"{path} expects int or float for dtypes.{info.dtype.name}, got "
                f"{type(value).__name__}"
            )
        try:
            converted = float(value)
        except (OverflowError, TypeError, ValueError) as exc:
            error = CANNBotValueError(
                code,
                f"{path} is not representable as dtypes.{info.dtype.name}",
                phase=phase,
                path=path,
                hint=hint,
            )
            raise error from exc
        if not math.isfinite(converted):
            value_error(
                f"{path} must be finite for dtypes.{info.dtype.name}, got {converted!r}"
            )
        if info.dtype.bits == 32:
            narrowed = ctypes.c_float(converted).value
            if not math.isfinite(narrowed):
                value_error(
                    f"{path} overflows dtypes.float32 after narrowing"
                )
        return value

    type_error(
        f"dtypes.{info.dtype.name} is not supported by the standalone scalar ABI"
    )


def _require_scalar_abi(info: ElementInfo) -> ElementInfo:
    if info.scalar_ctype is None:
        supported = ", ".join(f"dtypes.{item.dtype.name}" for item in _SCALAR_ELEMENTS if item.scalar_ctype is not None)
        raise TypeError(
            f"dtypes.{info.dtype.name} is not supported by the standalone "
            f"host scalar ABI; supported scalar types: {supported}"
        )
    return info


def element_for_torch_dtype(name: str) -> ElementInfo:
    try:
        return _BY_TORCH[name]
    except KeyError as exc:
        supported = ", ".join(sorted(_BY_TORCH))
        raise TypeError(f"unsupported torch tensor dtype {name!r}; supported: {supported}") from exc


def aggregate_element_infos() -> tuple[ElementInfo, ...]:
    return tuple(item for item in _SCALAR_ELEMENTS if item.aggregate_ctype is not None)


__all__ = [
    "ElementInfo",
    "aggregate_element_infos",
    "coerce_scalar_to_storage",
    "dsl_type_for_dtype",
    "element_for_dlpack",
    "element_for_dsl_type",
    "element_for_dtype",
    "element_for_integer",
    "element_for_name",
    "element_for_storage_mlir_type",
    "dtype_for_storage_mlir_type",
    "element_for_tag",
    "element_for_torch_dtype",
    "host_scalar_for_value",
    "mlir_type_for_dtype",
    "normalize_storage_dtype",
    "scalar_for_dsl_type",
    "scalar_for_dtype",
    "scalar_mlir_type_for_dtype",
    "storage_mlir_type_for_dtype",
    "trace_scalar_for_dtype",
    "trace_scalar_for_value",
    "validate_host_scalar_value",
    "wrap_produced_scalar",
]
