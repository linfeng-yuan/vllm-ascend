# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Python-signature binders for value calls and AOT specification calls."""

from __future__ import annotations

import inspect
from dataclasses import dataclass, replace
from typing import Any, Callable

from cannbotdsl.core.contracts.codec import literal_from_python
from cannbotdsl.core.contracts.elements import (
    element_for_tag,
    host_scalar_for_value,
    scalar_for_dtype,
    validate_host_scalar_value,
)
from cannbotdsl.core.diag.diagnostics import (
    CANNBotTypeError,
    CT101_INVALID_RUNTIME_DEFAULT,
    ST101_UNSUPPORTED_DYNAMIC_ARGUMENT,
)
from cannbotdsl.core.contracts.model import (
    CallContract,
    ConstantExpr,
    ExactLayout,
    ExactLayouts,
    ParameterContract,
    ScalarContract,
    StructContract,
    StructRefContract,
    TensorListContract,
)
from cannbotdsl.core.contracts.normalize import (
    ContractNormalizer,
    static_tensor_contract,
)
from cannbotdsl.core.contracts.surface import (
    ScalarAnnotationSemantics,
    SurfaceSignature,
    _StagedRole,
    classify_scalar_annotation,
    is_tensor_annotation,
    is_tensor_list_annotation,
    surface_annotation_name,
    unwrap_surface_annotation,
)
from cannbotdsl.types.dtypes import DType
from cannbotdsl.lang.spec import StructSpec, TensorListSpec, TensorSpec
from cannbotdsl.types import ScalarValue


@dataclass(frozen=True, slots=True)
class BoundCall:
    contract: CallContract
    trace_arguments: dict[str, Any]
    runtime_values: tuple[Any, ...]
    surface_signature: SurfaceSignature

    @property
    def receiver_parameter(self) -> str | None:
        return self.surface_signature.receiver_parameter


@dataclass(frozen=True, slots=True)
class _DeferredTensorArgument:
    snapshot_index: int
    # Set when the parameter is annotated ``Annotated[Tensor, TensorSpec(...)]``
    # with a sub-byte dtype.  torch cannot name such a dtype, so the caller
    # passes the packed bytes and the declared spec supplies the logical view.
    packed_spec: object = None


@dataclass(frozen=True, slots=True)
class _DeferredStructRefArgument:
    snapshot_index: int
    descriptor: object
    path: str


@dataclass(frozen=True, slots=True)
class _DeferredTensorListArgument:
    snapshot_indices: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class _DeferredRuntimeParameter:
    name: str
    kind: str
    source_parameter: inspect.Parameter
    argument: object


def _unwrap_annotated(annotation):
    return unwrap_surface_annotation(annotation)


def _is_python_scalar_type(value) -> bool:
    return value is bool or value is int or value is float


def _is_tensor_annotation(annotation) -> bool:
    return is_tensor_annotation(annotation)


def _schema_for_class(value):
    if not inspect.isclass(value):
        return None
    from cannbotdsl.types.datastruct import _DataStructSchema

    for owner in type.__getattribute__(value, "__mro__"):
        namespace = type.__getattribute__(owner, "__dict__")
        candidate = namespace.get("__cannbotdsl_datastruct_schema__")
        if type(candidate) is _DataStructSchema:
            return candidate
    return None


def _schema_for_value(value):
    return _schema_for_class(type(value))


def _struct_ref_descriptor(annotation):
    from cannbotdsl.types.datastruct import StructRef

    annotation = _unwrap_annotated(annotation)
    return annotation if type(annotation) is StructRef else None


def _check_annotation_for_tensor(name: str, annotation) -> None:
    if annotation is inspect.Parameter.empty:
        return
    if not _is_tensor_annotation(annotation):
        raise TypeError(
            f"parameter {name!r} is annotated as "
            f"{surface_annotation_name(annotation)}, "
            "but its AOT descriptor is TensorSpec"
        )


def _check_annotation_for_tensor_list(name: str, annotation) -> None:
    if not is_tensor_list_annotation(annotation):
        raise TypeError(
            f"parameter {name!r} must be annotated as TensorList when its "
            "runtime/AOT carrier is a dynamic Tensor list"
        )


def _check_annotation_for_scalar(name: str, annotation, dtype: object) -> None:
    if annotation is inspect.Parameter.empty:
        return
    semantics = classify_scalar_annotation(name, annotation)
    if semantics is not None and semantics.mode is ScalarAnnotationSemantics.Mode.GENERIC:
        return
    if semantics is None:
        raise TypeError(
            f"parameter {name!r} is annotated as "
            f"{surface_annotation_name(annotation)}, which is not a "
            "supported runtime scalar type"
        )
    try:
        assert semantics.dtype is not None
        annotated = scalar_for_dtype(semantics.dtype)
        supplied = scalar_for_dtype(dtype, allow_python=True)
    except TypeError as exc:
        raise TypeError(
            f"parameter {name!r} is annotated as "
            f"{surface_annotation_name(annotation)}, which is not a "
            "supported runtime scalar type"
        ) from exc
    if annotated.dtype != supplied.dtype:
        raise TypeError(
            f"parameter {name!r} is annotated as "
            f"{surface_annotation_name(annotation)}, "
            f"but its AOT descriptor is {supplied.dtype.name}"
        )


def _scalar_descriptor_info(value):
    if type(value) is not DType and not _is_python_scalar_type(value):
        return None
    try:
        return scalar_for_dtype(value, allow_python=True)
    except TypeError:
        return None


def _scalar_annotation_info(name: str, annotation, value):
    semantics = classify_scalar_annotation(name, annotation)
    if semantics is not None and semantics.mode is ScalarAnnotationSemantics.Mode.GENERIC:
        info = host_scalar_for_value(
            value,
            path=f"runtime ScalarValue parameter {name!r}",
        )
    else:
        if annotation is inspect.Parameter.empty:
            candidate = type(value)
            allow_python = True
        elif semantics is not None:
            assert semantics.dtype is not None
            candidate = semantics.dtype
            allow_python = False
        else:
            raise TypeError(
                f"runtime scalar parameter {name!r} requires a supported scalar "
                "annotation (bool/int/float, ScalarValue, or a canonical "
                "DType descriptor)"
            )
        try:
            info = scalar_for_dtype(candidate, allow_python=allow_python)
        except TypeError as exc:
            raise TypeError(
                f"runtime scalar parameter {name!r} requires a supported scalar "
                "annotation (bool/int/float, ScalarValue, or a canonical "
                "DType descriptor)"
            ) from exc

    validate_host_scalar_value(
        info,
        value,
        path=f"runtime scalar parameter {name!r}",
    )
    return info


def _check_annotation_for_struct(name: str, annotation, schema) -> None:
    if annotation is inspect.Parameter.empty:
        return
    annotated_schema = _schema_for_class(_unwrap_annotated(annotation))
    if annotated_schema is None or annotated_schema.fingerprint != schema.fingerprint:
        raise TypeError(
            f"parameter {name!r} annotation does not match datastruct {schema.c_name}/{schema.fingerprint[:12]}"
        )


def _check_annotation_for_struct_ref(name: str, annotation, descriptor) -> None:
    if annotation is inspect.Parameter.empty:
        return
    annotated = _struct_ref_descriptor(annotation)
    if annotated is None or annotated != descriptor:
        raise TypeError(
            f"parameter {name!r} annotation does not match StructRef "
            f"{descriptor.schema.c_name}/{descriptor.schema.fingerprint[:12]}"
        )


def _aot_argument(
    value,
    annotation,
    normalizer,
    *,
    path: str,
):
    from cannbotdsl.core.compiler.runtime_bridge import has_dlpack

    if value is ScalarValue:
        raise TypeError(
            f"AOT parameter {path!r} received ScalarValue as a compile "
            "specification; ScalarValue is an abstract value category, not a "
            "concrete ABI dtype. Use a supported dtypes.* descriptor."
        )
    semantics = classify_scalar_annotation(path, annotation)
    if semantics is not None and semantics.mode is ScalarAnnotationSemantics.Mode.GENERIC:
        if type(value) is not DType:
            raise TypeError(
                f"AOT ScalarValue parameter {path!r} requires a concrete "
                "supported dtypes.* descriptor, got "
                f"{surface_annotation_name(value)}"
            )
        info = _scalar_descriptor_info(value)
        if info is None:
            raise TypeError(
                f"AOT ScalarValue parameter {path!r} requires a concrete "
                "supported dtypes.* descriptor, got "
                f"{type(value).__name__}"
            )
        return ScalarContract(info.tag)

    from cannbotdsl.types.datastruct import StructRef

    if type(value) is StructRef:
        _check_annotation_for_struct_ref(path, annotation, value)
        return StructRefContract(
            value.schema,
            address_space=value.address_space,
            access=value.access,
        )

    if has_dlpack(value):
        if _struct_ref_descriptor(annotation) is not None:
            raise TypeError(
                f"AOT StructRef parameter {path!r} received a provider tensor; "
                "use its StructRef[...] descriptor with .compile()"
            )
        raise TypeError(f"AOT parameter {path!r} received a provider tensor value; use TensorSpec with .compile()")

    if isinstance(value, TensorListSpec):
        _check_annotation_for_tensor_list(path, annotation)
        return normalizer.tensor_list(value)
    if isinstance(value, TensorSpec):
        _check_annotation_for_tensor(path, annotation)
        return normalizer.tensor(value)
    if isinstance(value, StructSpec):
        schema = value._internal_schema
        _check_annotation_for_struct(path, annotation, schema)
        return StructContract(schema)
    if _schema_for_class(value) is not None:
        schema = _schema_for_class(value)
        _check_annotation_for_struct(path, annotation, schema)
        return StructContract(schema)
    info = _scalar_descriptor_info(value)
    if info is not None:
        _check_annotation_for_scalar(path, annotation, value)
        return ScalarContract(info.tag)
    raise _unsupported_host_runtime(path, value)


def _jit_argument(
    value,
    annotation,
    tensor_items: list[tuple[str, object]],
    *,
    path: str,
):
    from cannbotdsl.core.compiler.runtime_bridge import (
        has_dlpack,
    )

    if is_tensor_list_annotation(annotation):
        if type(value) is not tuple:
            raise TypeError(
                f"parameter {path!r} annotated as TensorList requires an "
                f"exact list or tuple, got {type(value).__name__}"
            )
        if not value:
            raise ValueError(
                f"parameter {path!r} TensorList must contain at least one tensor"
            )
        indices = []
        for index, element in enumerate(value):
            element_path = f"{path}[{index}]"
            indices.append(len(tensor_items))
            tensor_items.append((element_path, element))
        return _DeferredTensorListArgument(tuple(indices))

    semantics = classify_scalar_annotation(path, annotation)
    if semantics is not None and semantics.mode is ScalarAnnotationSemantics.Mode.GENERIC:
        info = _scalar_annotation_info(path, annotation, value)
        return ScalarContract(info.tag)
    descriptor = _struct_ref_descriptor(annotation)
    if has_dlpack(value):
        if descriptor is not None:
            index = len(tensor_items)
            tensor_items.append((path, value))
            return _DeferredStructRefArgument(index, descriptor, path)
        _check_annotation_for_tensor(path, annotation)
        index = len(tensor_items)
        tensor_items.append((path, value))
        return _DeferredTensorArgument(index, _packed_tensor_spec(annotation))
    if descriptor is not None:
        raise TypeError(
            f"parameter {path!r} is annotated as {descriptor!r} and requires "
            f"a DLPack NPU provider tensor, got {type(value).__name__}"
        )
    if _is_python_scalar_type(type(value)):
        dtype = _unwrap_annotated(annotation)
        annotated_schema = _schema_for_class(dtype)
        if annotated_schema is not None:
            raise TypeError(
                f"parameter {path!r} is annotated as datastruct {annotated_schema.c_name}, got {type(value).__name__}"
            )
        info = _scalar_annotation_info(path, annotation, value)
        return ScalarContract(info.tag)
    schema = _schema_for_value(value)
    if schema is not None:
        _check_annotation_for_struct(path, annotation, schema)
        return StructContract(schema)
    raise _unsupported_host_runtime(path, value)


def _packed_tensor_spec(annotation):
    """Return an ``Annotated[Tensor, TensorSpec]`` payload for a packed dtype.

    Only sub-byte dtypes get this treatment.  For every other dtype the runtime
    tensor already names itself correctly, and letting a spec override that
    would silently reinterpret a caller's buffer.
    """

    import typing

    if typing.get_origin(annotation) is not typing.Annotated:
        return None
    for item in typing.get_args(annotation)[1:]:
        if type(item) is TensorSpec and item.dtype.bits < 8:
            return item
    return None


def _packed_tensor_contract(spec, snapshot, *, path: str) -> TensorContract:
    """Bind packed bytes to the logical view declared by ``spec``.

    The caller hands over an 8-bit tensor whose innermost extent is the logical
    one divided by the packing factor; every other extent is unchanged.
    """

    from cannbotdsl.core.compiler.physical_abi import host_carrier
    from cannbotdsl.core.contracts.elements import element_for_dlpack, element_for_dtype
    from cannbotdsl.core.contracts.model import TensorContract

    actual = element_for_dlpack(
        snapshot.dtype_code, snapshot.dtype_bits, snapshot.dtype_lanes
    )
    if actual.dtype.bits != 8:
        raise TypeError(
            f"{path} is declared as dtypes.{spec.dtype.name}, whose packed bytes "
            f"must be passed as an 8-bit tensor; got dtypes.{actual.dtype.name}"
        )
    try:
        logical = tuple(int(value) for value in spec.shape)
    except TypeError:
        raise TypeError(
            f"{path} packed TensorSpec requires a fully static shape, "
            f"got {spec.shape!r}"
        ) from None
    info = element_for_dtype(spec.dtype)
    stride = []
    running = 1
    for extent in reversed(logical):
        stride.append(running)
        running *= extent
    contract = TensorContract(
        element=info.tag,
        shape=tuple(ConstantExpr(value) for value in logical),
        stride=tuple(ConstantExpr(value) for value in reversed(stride)),
    )
    # Derive the expected carrier from the same helper the host ABI guards are
    # built from, so a caller can never satisfy one and violate the other.
    expected = tuple(item.value for item in host_carrier(contract).shape)
    got = tuple(int(value) for value in snapshot.shape)
    if got != expected:
        raise ValueError(
            f"{path} is declared as dtypes.{spec.dtype.name} with logical shape "
            f"{logical}, so its packed carrier must have shape {expected}; got {got}"
        )
    return contract


def _materialize_jit_argument(argument, snapshots, tensor_items):
    if isinstance(argument, _DeferredTensorArgument):
        snapshot = snapshots[argument.snapshot_index]
        if argument.packed_spec is not None:
            return _packed_tensor_contract(
                argument.packed_spec,
                snapshot,
                path=tensor_items[argument.snapshot_index][0],
            )
        return static_tensor_contract(snapshot)
    if isinstance(argument, _DeferredStructRefArgument):
        from cannbotdsl.core.contracts.normalize import (
            validate_struct_ref_snapshot,
        )

        descriptor = argument.descriptor
        validate_struct_ref_snapshot(
            snapshots[argument.snapshot_index],
            descriptor.schema,
            path=argument.path,
        )
        from cannbotdsl.core.compiler.runtime_bridge import (
            validate_struct_ref_provider_storage,
        )

        validate_struct_ref_provider_storage(
            tensor_items[argument.snapshot_index][1],
            descriptor.schema,
            name=argument.path,
        )
        return StructRefContract(
            descriptor.schema,
            address_space=descriptor.address_space,
            access=descriptor.access,
        )
    if isinstance(argument, _DeferredTensorListArgument):
        contracts = tuple(
            static_tensor_contract(snapshots[index])
            for index in argument.snapshot_indices
        )
        for offset, contract in enumerate(contracts):
            if contract.storage_encoding is not None:
                path = tensor_items[argument.snapshot_indices[offset]][0]
                raise BufferError(
                    f"{path} uses private FRACTAL_NZ storage; TensorList "
                    "supports only ND elements"
                )
        element = contracts[0]
        for offset, candidate in enumerate(contracts[1:], 1):
            path = tensor_items[argument.snapshot_indices[offset]][0]
            if candidate.element != element.element:
                raise ValueError(
                    f"{path} TensorList element dtype does not match the first element"
                )
            if candidate.rank != element.rank:
                raise ValueError(
                    f"{path} TensorList element rank does not match the first element"
                )
        return TensorListContract(
            element_type=element.element,
            element_rank=element.rank,
            address_space=element.address_space,
            length=ConstantExpr(len(contracts)),
            layout=ExactLayouts(
                tuple(
                    ExactLayout(
                        tuple(item.value for item in contract.shape),
                        tuple(item.value for item in contract.stride),
                    )
                    for contract in contracts
                )
            ),
        )
    return argument


def _reject_variadics(signature: inspect.Signature) -> None:
    for parameter in signature.parameters.values():
        if parameter.kind in {
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        }:
            raise TypeError("@jit staged calls do not support *args or **kwargs parameters")


def _bind_source_call(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    *,
    surface_signature: SurfaceSignature | None,
):
    surface = surface_signature or SurfaceSignature.from_callable(fn)
    signature = surface.signature
    _reject_variadics(signature)
    return surface, surface.bind_staged(args, kwargs)


def _unsupported_runtime_default(name: str, value: object) -> CANNBotTypeError:
    return CANNBotTypeError(
        ST101_UNSUPPORTED_DYNAMIC_ARGUMENT,
        f"Host runtime default {name!r} has unsupported carrier {type(value).__name__}.",
        phase="staging",
        path=name,
        hint=(
            "Use None only for an absent Tensor parameter, make the runtime "
            "argument required, or mark stable configuration explicitly as "
            "Constexpr[...]."
        ),
    )


def _unsupported_host_runtime(path: str, value: object) -> CANNBotTypeError:
    return CANNBotTypeError(
        ST101_UNSUPPORTED_DYNAMIC_ARGUMENT,
        f"Host runtime parameter {path!r} has unsupported carrier {type(value).__name__}.",
        phase="staging",
        path=path,
        hint=(
            "Use a provider Tensor/StructRef carrier, an annotated TensorList, "
            "bool/int/float, or "
            "@datastruct value; "
            "use None for an absent Tensor or Constexpr[...] for stable "
            "specialization."
        ),
    )


def _aot_default_argument(name: str, annotation: object, value: object):
    """Infer one omitted scalar ABI descriptor from its annotation/default."""

    semantics = classify_scalar_annotation(name, annotation)
    try:
        if semantics is None:
            if annotation is not inspect.Parameter.empty:
                raise _unsupported_runtime_default(name, value)
            info = host_scalar_for_value(value, path=f"default {name}")
        elif semantics.mode is ScalarAnnotationSemantics.Mode.GENERIC:
            info = host_scalar_for_value(value, path=f"default {name}")
        else:
            assert semantics.dtype is not None
            info = scalar_for_dtype(semantics.dtype)
    except CANNBotTypeError:
        raise
    except TypeError as exc:
        raise _unsupported_runtime_default(name, value) from exc
    return ScalarContract(info.tag)


def _runtime_default(parameter: inspect.Parameter, argument):
    """Keep only defaults that can themselves cross the current host ABI."""

    if parameter.default is inspect.Parameter.empty or not isinstance(argument, ScalarContract):
        return None, False
    info = element_for_tag(argument.element)
    validate_host_scalar_value(
        info,
        parameter.default,
        path=f"default {parameter.name}",
        code=CT101_INVALID_RUNTIME_DEFAULT,
        phase="contract",
    )
    return (
        literal_from_python(parameter.default, path=f"default {parameter.name}"),
        True,
    )


def _normalize_runtime_defaults(
    parameters: list[ParameterContract],
) -> tuple[ParameterContract, ...]:
    """Keep the staged positional signature valid after static parameters leave it.

    A source-level optional tensor can become a required runtime parameter when
    the caller explicitly supplies a TensorSpec or runtime tensor.  If an
    earlier positional scalar also enters the ABI with its source default, the
    filtered runtime signature would otherwise contain a required parameter
    after a defaulted one.  Such earlier defaults cannot be expressed by
    ``inspect.Signature`` without changing parameter order or kind, so those
    runtime parameters become required for this specialization.
    """

    normalized = list(parameters)
    required_to_right = False
    positional_kinds = {"POSITIONAL_ONLY", "POSITIONAL_OR_KEYWORD"}
    for index in range(len(normalized) - 1, -1, -1):
        parameter = normalized[index]
        if parameter.role != "runtime" or parameter.kind not in positional_kinds:
            continue
        if not parameter.has_runtime_default:
            required_to_right = True
            continue
        if required_to_right:
            normalized[index] = replace(
                parameter,
                runtime_default=None,
                has_runtime_default=False,
            )
    return tuple(normalized)


def bind_aot_call(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    *,
    surface_signature: SurfaceSignature | None = None,
) -> BoundCall:
    """Bind descriptors for ``JitFunction.compile`` using Python call rules."""

    surface, staged = _bind_source_call(
        fn, args, kwargs, surface_signature=surface_signature
    )
    bound = staged.bound
    normalizer = ContractNormalizer()
    parameters = []
    trace_arguments = dict(bound.arguments)

    for item in staged.parameters:
        parameter = item.parameter
        name = parameter.name
        if item.role is _StagedRole.RECEIVER:
            continue
        value = bound.arguments[name]
        if item.role is _StagedRole.CONSTEXPR:
            literal = literal_from_python(value, path=f"constexpr {name}")
            parameters.append(
                ParameterContract(
                    name,
                    parameter.kind.name,
                    "constexpr",
                    static_value=literal,
                )
            )
            continue

        if item.role is _StagedRole.ABSENT:
            parameters.append(
                ParameterContract(
                    name,
                    parameter.kind.name,
                    "captured",
                    static_value=literal_from_python(None),
                )
            )
            continue

        annotation = item.annotation
        if (
            name not in staged.supplied_names
            and parameter.default is not inspect.Parameter.empty
        ):
            argument = _aot_default_argument(name, annotation, value)
        else:
            argument = _aot_argument(value, annotation, normalizer, path=name)

        runtime_default, has_default = _runtime_default(parameter, argument)
        if name not in staged.supplied_names and not has_default:
            raise _unsupported_runtime_default(name, value)
        parameters.append(
            ParameterContract(
                name,
                parameter.kind.name,
                "runtime",
                argument=argument,
                runtime_default=runtime_default,
                has_runtime_default=has_default,
            )
        )

    contract = CallContract(
        _normalize_runtime_defaults(parameters),
        normalizer.dimensions(),
    )
    return BoundCall(
        contract=contract,
        trace_arguments=trace_arguments,
        runtime_values=(),
        surface_signature=surface,
    )


def bind_jit_call(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    *,
    surface_signature: SurfaceSignature | None = None,
) -> BoundCall:
    """Bind concrete values for a direct top-level ``@jit`` invocation."""

    surface, staged = _bind_source_call(
        fn, args, kwargs, surface_signature=surface_signature
    )
    bound = staged.bound
    parameters = []
    runtime_values = []
    tensor_items: list[tuple[str, object]] = []
    has_tensor_list = False

    for item in staged.parameters:
        parameter = item.parameter
        name = parameter.name
        if item.role is _StagedRole.RECEIVER:
            continue
        value = bound.arguments[name]
        if item.role is _StagedRole.CONSTEXPR:
            parameters.append(
                ParameterContract(
                    name,
                    parameter.kind.name,
                    "constexpr",
                    static_value=literal_from_python(value, path=f"constexpr {name}"),
                )
            )
            continue

        if item.role is _StagedRole.ABSENT:
            parameters.append(
                ParameterContract(
                    name,
                    parameter.kind.name,
                    "captured",
                    static_value=literal_from_python(None),
                )
            )
            continue

        annotation = item.annotation
        if isinstance(value, TensorSpec):
            raise TypeError(
                f"direct @jit call parameter {name!r} received TensorSpec; "
                "TensorSpec is accepted only by .compile()"
            )
        if isinstance(value, TensorListSpec):
            raise TypeError(
                f"direct @jit call parameter {name!r} received "
                "TensorListSpec; TensorListSpec is accepted only by "
                ".compile()"
            )

        if is_tensor_list_annotation(annotation):
            if type(value) is not list and type(value) is not tuple:
                raise TypeError(
                    f"parameter {name!r} annotated as TensorList requires an "
                    f"exact list or tuple, got {type(value).__name__}"
                )
            value = tuple(value)
            bound.arguments[name] = value

        omitted_default = (
            name not in staged.supplied_names
            and parameter.default is not inspect.Parameter.empty
        )
        if omitted_default:
            argument = _aot_default_argument(name, annotation, value)
        else:
            argument = _jit_argument(
                value,
                annotation,
                tensor_items,
                path=name,
            )
            if isinstance(argument, _DeferredTensorListArgument):
                has_tensor_list = True
        parameters.append(
            _DeferredRuntimeParameter(
                name,
                parameter.kind.name,
                parameter,
                argument,
            )
        )
        runtime_values.append(value)

    from cannbotdsl.core.compiler.runtime_bridge import inspect_provider_tensors

    snapshots = inspect_provider_tensors(
        tuple(tensor_items),
        require_torch_npu=has_tensor_list,
    )
    materialized_parameters = []
    for item in parameters:
        if isinstance(item, ParameterContract):
            materialized_parameters.append(item)
            continue
        argument = _materialize_jit_argument(
            item.argument,
            snapshots,
            tensor_items,
        )
        runtime_default, has_default = _runtime_default(item.source_parameter, argument)
        materialized_parameters.append(
            ParameterContract(
                item.name,
                item.kind,
                "runtime",
                argument=argument,
                runtime_default=runtime_default,
                has_runtime_default=has_default,
            )
        )

    return BoundCall(
        contract=CallContract(
            _normalize_runtime_defaults(materialized_parameters),
            (),
        ),
        trace_arguments=dict(bound.arguments),
        runtime_values=tuple(runtime_values),
        surface_signature=surface,
    )


__all__ = ["BoundCall", "bind_aot_call", "bind_jit_call"]
