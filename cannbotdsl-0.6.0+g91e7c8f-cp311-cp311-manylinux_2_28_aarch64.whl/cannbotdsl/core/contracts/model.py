# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Immutable, backend-independent representation of one staged call."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class LiteralValue:
    kind: str
    value: Any


@dataclass(frozen=True, slots=True)
class ConstantExpr:
    value: int


@dataclass(frozen=True, slots=True)
class DimensionExpr:
    name: str


@dataclass(frozen=True, slots=True)
class BinaryExpr:
    op: str
    lhs: "ShapeExpr"
    rhs: "ShapeExpr"


ShapeExpr = ConstantExpr | DimensionExpr | BinaryExpr


@dataclass(frozen=True, slots=True)
class DimensionContract:
    name: str
    minimum: int
    maximum: int | None
    multiple_of: int


@dataclass(frozen=True, slots=True)
class StorageEncodingContract:
    """Provider-neutral private-storage encoding for one tensor contract.

    Logical shape and stride already belong to :class:`TensorContract`.
    Physical stride and the CANNIR layout map are canonical consequences of
    the encoding and physical shape, so neither is persisted twice.
    """

    encoding: str
    physical_shape: tuple[ShapeExpr, ...]


@dataclass(frozen=True, slots=True)
class TensorContract:
    element: str
    shape: tuple[ShapeExpr, ...]
    stride: tuple[ShapeExpr, ...]
    address_space: str = "GM"
    storage_encoding: StorageEncodingContract | None = None

    @property
    def rank(self) -> int:
        return len(self.shape)


@dataclass(frozen=True, slots=True)
class TemplateLayout:
    """One AOT element template with a TensorList-local dimension scope."""

    element_dimensions: tuple[DimensionContract, ...]
    shape_expressions: tuple[ShapeExpr, ...]
    stride_expressions: tuple[ShapeExpr, ...]


@dataclass(frozen=True, slots=True)
class ExactLayout:
    """The exact layout of one positional Direct-JIT TensorList element."""

    shape: tuple[int, ...]
    stride: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class ExactLayouts:
    """A fixed-length, position-sensitive Direct-JIT layout sequence."""

    items: tuple[ExactLayout, ...]


TensorListLayout = TemplateLayout | ExactLayouts


@dataclass(frozen=True, slots=True)
class TensorListContract:
    """One non-empty runtime collection of same-dtype, same-rank tensors.

    Shape and stride are deliberately owned by ``layout`` rather than a
    single element ``TensorContract``: AOT uses one independently-bound
    template per element, while Direct JIT records an exact positional layout
    for every element.
    """

    element_type: str
    element_rank: int
    address_space: str
    length: ShapeExpr
    layout: TensorListLayout
    descriptor_version: int = 2

    @property
    def record_words(self) -> int:
        return 1 + 2 * self.element_rank


@dataclass(frozen=True, slots=True)
class ScalarContract:
    element: str


@dataclass(frozen=True, slots=True)
class StructContract:
    # _DataStructSchema is already a recursive, immutable logical schema.
    # Keep the annotation broad here to avoid a dependency from the domain
    # model back into the frontend implementation.
    schema: Any


@dataclass(frozen=True, slots=True)
class StructRefContract:
    """One provider-backed datastruct object resident in device GM."""

    # Keep this broad for the same dependency-direction reason as
    # StructContract above.  Validation/codec code owns the concrete schema
    # invariants.
    schema: Any
    address_space: str = "GM"
    access: str = "readwrite"


ArgumentContract = (
    TensorContract
    | TensorListContract
    | ScalarContract
    | StructContract
    | StructRefContract
)


@dataclass(frozen=True, slots=True)
class ParameterContract:
    name: str
    kind: str
    role: str
    argument: ArgumentContract | None = None
    static_value: LiteralValue | None = None
    runtime_default: LiteralValue | None = None
    has_runtime_default: bool = False


@dataclass(frozen=True, slots=True)
class CallContract:
    parameters: tuple[ParameterContract, ...]
    dimensions: tuple[DimensionContract, ...]
    host_abi_version: int = 9

    @property
    def runtime_parameters(self) -> tuple[ParameterContract, ...]:
        return tuple(p for p in self.parameters if p.role == "runtime")

    @property
    def abi_arguments(self) -> tuple[ArgumentContract, ...]:
        return tuple(
            p.argument
            for p in self.runtime_parameters
            if p.argument is not None
        )


__all__ = [
    "ArgumentContract",
    "BinaryExpr",
    "CallContract",
    "ConstantExpr",
    "DimensionContract",
    "DimensionExpr",
    "ExactLayout",
    "ExactLayouts",
    "LiteralValue",
    "ParameterContract",
    "ScalarContract",
    "ShapeExpr",
    "StructContract",
    "StructRefContract",
    "StorageEncodingContract",
    "TensorContract",
    "TensorListContract",
    "TensorListLayout",
    "TemplateLayout",
]
