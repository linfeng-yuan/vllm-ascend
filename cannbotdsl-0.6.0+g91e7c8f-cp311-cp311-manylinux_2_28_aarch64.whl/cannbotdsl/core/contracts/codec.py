# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Stable logical codec used by cache keys and artifact manifests."""

from __future__ import annotations

import hashlib
import inspect
import json
import math

from cannbotdsl.core.contracts.elements import (
    element_for_tag,
    scalar_for_dsl_type,
    validate_host_scalar_value,
)
from cannbotdsl.core.diag.diagnostics import (
    CANNBotError,
    CANNBotValueError,
    CT101_INVALID_RUNTIME_DEFAULT,
)
from cannbotdsl.core.contracts.model import (
    BinaryExpr,
    CallContract,
    ConstantExpr,
    DimensionContract,
    DimensionExpr,
    ExactLayout,
    ExactLayouts,
    LiteralValue,
    ParameterContract,
    ScalarContract,
    StructContract,
    StructRefContract,
    StorageEncodingContract,
    TensorContract,
    TensorListContract,
    TemplateLayout,
)
from cannbotdsl.types._storage_format import FRACTAL_NZ_ELEMENT_TAGS
from cannbotdsl.core.contracts.storage import (
    compact_stride,
    fractal_nz_storage_encoding,
)


_CONTRACT_SCHEMA_VERSION = 6
_HOST_ABI_VERSION = 9
_I64_MIN = -(1 << 63)
_I64_MAX = (1 << 63) - 1
_PARAMETER_KINDS = {
    "POSITIONAL_ONLY": inspect.Parameter.POSITIONAL_ONLY,
    "POSITIONAL_OR_KEYWORD": inspect.Parameter.POSITIONAL_OR_KEYWORD,
    "KEYWORD_ONLY": inspect.Parameter.KEYWORD_ONLY,
}


def _checked_i64(value, *, path: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{path} must be an int, got {value!r}")
    if value < _I64_MIN or value > _I64_MAX:
        raise ValueError(f"{path}={value} is outside signed int64 range")
    return value


def _checked_string(value, *, path: str, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or (not allow_empty and not value):
        qualifier = "a string" if allow_empty else "a non-empty string"
        raise ValueError(f"{path} must be {qualifier}, got {value!r}")
    return value


def literal_from_python(value, *, path: str = "value") -> LiteralValue:
    if value is None:
        return LiteralValue("none", None)
    if type(value) is bool:
        return LiteralValue("bool", value)
    if type(value) is int:
        return LiteralValue("int", str(value))
    if type(value) is float:
        if math.isnan(value):
            encoded = "nan"
        elif math.isinf(value):
            encoded = "inf" if value > 0 else "-inf"
        else:
            encoded = value.hex()
        return LiteralValue("float", encoded)
    if type(value) is str:
        return LiteralValue("str", value)
    if type(value) is bytes:
        return LiteralValue("bytes", value.hex())
    if type(value) is tuple:
        return LiteralValue(
            "tuple",
            tuple(
                literal_from_python(item, path=f"{path}[{index}]")
                for index, item in enumerate(value)
            ),
        )
    if type(value) is list:
        return LiteralValue(
            "list",
            tuple(
                literal_from_python(item, path=f"{path}[{index}]")
                for index, item in enumerate(value)
            ),
        )
    if type(value) is dict:
        invalid_keys = [key for key in value if type(key) is not str]
        if invalid_keys:
            raise TypeError(
                f"{path} dict keys must be strings, got {invalid_keys[0]!r}"
            )
        entries = []
        for key, item in value.items():
            entries.append((key, literal_from_python(item, path=f"{path}.{key}")))
        return LiteralValue("dict", tuple(entries))
    raise TypeError(
        f"{path} of type {type(value).__name__} is not a stable constexpr/default value"
    )


def literal_to_python(literal: LiteralValue):
    if literal.kind == "none":
        if literal.value is not None:
            raise ValueError("literal kind 'none' must carry null")
        return None
    if literal.kind == "bool":
        if type(literal.value) is not bool:
            raise ValueError("literal kind 'bool' must carry a bool")
        return literal.value
    if literal.kind == "int":
        if not isinstance(literal.value, str):
            raise ValueError("literal kind 'int' must carry a decimal string")
        try:
            value = int(literal.value)
        except ValueError as exc:
            raise ValueError(f"invalid integer literal {literal.value!r}") from exc
        if str(value) != literal.value:
            raise ValueError(f"non-canonical integer literal {literal.value!r}")
        return value
    if literal.kind == "float":
        if not isinstance(literal.value, str):
            raise ValueError("literal kind 'float' must carry a string")
        if literal.value == "nan":
            return float("nan")
        if literal.value == "inf":
            return float("inf")
        if literal.value == "-inf":
            return float("-inf")
        try:
            value = float.fromhex(literal.value)
        except ValueError as exc:
            raise ValueError(f"invalid float literal {literal.value!r}") from exc
        if value.hex() != literal.value:
            raise ValueError(f"non-canonical float literal {literal.value!r}")
        return value
    if literal.kind == "str":
        if not isinstance(literal.value, str):
            raise ValueError("literal kind 'str' must carry a string")
        return literal.value
    if literal.kind == "bytes":
        if not isinstance(literal.value, str):
            raise ValueError("literal kind 'bytes' must carry a hex string")
        try:
            value = bytes.fromhex(literal.value)
        except ValueError as exc:
            raise ValueError(f"invalid bytes literal {literal.value!r}") from exc
        if value.hex() != literal.value:
            raise ValueError(f"non-canonical bytes literal {literal.value!r}")
        return value
    if literal.kind == "tuple":
        if not isinstance(literal.value, tuple):
            raise ValueError("literal kind 'tuple' must carry a tuple")
        return tuple(literal_to_python(item) for item in literal.value)
    if literal.kind == "list":
        if not isinstance(literal.value, tuple):
            raise ValueError("literal kind 'list' must carry a tuple payload")
        return [literal_to_python(item) for item in literal.value]
    if literal.kind == "dict":
        if not isinstance(literal.value, tuple):
            raise ValueError("literal kind 'dict' must carry an entry tuple")
        keys = []
        for entry in literal.value:
            if not isinstance(entry, tuple) or len(entry) != 2:
                raise ValueError("malformed dict literal entry")
            key, _ = entry
            _checked_string(key, path="dict literal key", allow_empty=True)
            keys.append(key)
        if len(keys) != len(set(keys)):
            raise ValueError("dict literal keys must be unique")
        return {key: literal_to_python(item) for key, item in literal.value}
    raise ValueError(f"unknown literal kind {literal.kind!r}")


def _runtime_default_to_python(literal: LiteralValue, *, path: str):
    try:
        return literal_to_python(literal)
    except CANNBotError:
        raise
    except (KeyError, TypeError, ValueError) as exc:
        raise CANNBotValueError(
            CT101_INVALID_RUNTIME_DEFAULT,
            f"Persisted runtime default is invalid: {exc}",
            phase="contract",
            path=path,
            hint=(
                "Regenerate the artifact with a finite, in-range scalar "
                "default matching its runtime ScalarContract."
            ),
        ) from exc


def _runtime_default_from_dict(data: dict, *, path: str) -> LiteralValue:
    try:
        return _literal_from_dict(data)
    except CANNBotError:
        raise
    except (KeyError, TypeError, ValueError) as exc:
        raise CANNBotValueError(
            CT101_INVALID_RUNTIME_DEFAULT,
            f"Persisted runtime default is malformed: {exc}",
            phase="contract",
            path=path,
            hint=(
                "Regenerate the artifact instead of editing its runtime "
                "default metadata."
            ),
        ) from exc


def _literal_to_dict(value: LiteralValue) -> dict:
    if value.kind in {"tuple", "list"}:
        payload = [_literal_to_dict(item) for item in value.value]
    elif value.kind == "dict":
        payload = [
            {"key": key, "value": _literal_to_dict(item)}
            for key, item in value.value
        ]
    else:
        payload = value.value
    return {"kind": value.kind, "value": payload}


def _literal_from_dict(data: dict) -> LiteralValue:
    if not isinstance(data, dict):
        raise ValueError(f"literal must be an object, got {type(data).__name__}")
    kind = data["kind"]
    payload = data.get("value")
    if kind in {"tuple", "list"}:
        if not isinstance(payload, list):
            raise ValueError(f"literal kind {kind!r} must carry an array")
        payload = tuple(_literal_from_dict(item) for item in payload)
    elif kind == "dict":
        if not isinstance(payload, list):
            raise ValueError("literal kind 'dict' must carry an array")
        entries = []
        for entry in payload:
            if not isinstance(entry, dict):
                raise ValueError("malformed dict literal entry")
            entries.append(
                (entry["key"], _literal_from_dict(entry["value"]))
            )
        payload = tuple(entries)
    result = LiteralValue(kind, payload)
    # Decode once so malformed tags/payloads fail while reading the manifest.
    literal_to_python(result)
    return result


def _expr_to_dict(expression) -> dict:
    if isinstance(expression, ConstantExpr):
        return {"kind": "constant", "value": expression.value}
    if isinstance(expression, DimensionExpr):
        return {"kind": "dimension", "name": expression.name}
    if isinstance(expression, BinaryExpr):
        return {
            "kind": "binary",
            "op": expression.op,
            "lhs": _expr_to_dict(expression.lhs),
            "rhs": _expr_to_dict(expression.rhs),
        }
    raise TypeError(f"cannot encode expression {expression!r}")


def _expr_from_dict(data: dict):
    if not isinstance(data, dict):
        raise ValueError(
            f"dimension expression must be an object, got {type(data).__name__}"
        )
    kind = data.get("kind")
    if kind == "constant":
        value = _checked_i64(data["value"], path="constant expression")
        return ConstantExpr(value)
    if kind == "dimension":
        return DimensionExpr(
            _checked_string(data["name"], path="dimension expression name")
        )
    if kind == "binary":
        op = data["op"]
        if op not in {"add", "sub", "mul", "floordiv"}:
            raise ValueError(f"unknown dimension expression op {op!r}")
        expression = BinaryExpr(
            op, _expr_from_dict(data["lhs"]), _expr_from_dict(data["rhs"])
        )
        if op == "floordiv" and (
            not isinstance(expression.rhs, ConstantExpr)
            or expression.rhs.value <= 0
        ):
            raise ValueError(
                "dimension floor-divisor must be a positive integer constant"
            )
        return expression
    raise ValueError(f"unknown dimension expression kind {kind!r}")


def _argument_to_dict(argument) -> dict:
    if isinstance(argument, TensorContract):
        storage_encoding = argument.storage_encoding
        result = {
            "kind": "tensor",
            "element": argument.element,
            "address_space": argument.address_space,
            "shape": [_expr_to_dict(item) for item in argument.shape],
            "stride": [_expr_to_dict(item) for item in argument.stride],
        }
        if storage_encoding is not None:
            result["storage_encoding"] = {
                "encoding": storage_encoding.encoding,
                "physical_shape": [
                    _expr_to_dict(item)
                    for item in storage_encoding.physical_shape
                ],
            }
        return result
    if isinstance(argument, TensorListContract):
        if isinstance(argument.layout, TemplateLayout):
            layout = {
                "kind": "template",
                "element_dimensions": [
                    {
                        "name": item.name,
                        "min": item.minimum,
                        "max": item.maximum,
                        "multiple_of": item.multiple_of,
                    }
                    for item in argument.layout.element_dimensions
                ],
                "shape_expressions": [
                    _expr_to_dict(item)
                    for item in argument.layout.shape_expressions
                ],
                "stride_expressions": [
                    _expr_to_dict(item)
                    for item in argument.layout.stride_expressions
                ],
            }
        elif isinstance(argument.layout, ExactLayouts):
            layout = {
                "kind": "exact",
                "items": [
                    {
                        "shape": list(item.shape),
                        "stride": list(item.stride),
                    }
                    for item in argument.layout.items
                ],
            }
        else:  # pragma: no cover - contract validation reports this first.
            raise TypeError(f"unknown TensorList layout {argument.layout!r}")
        return {
            "kind": "tensor_list",
            "element_type": argument.element_type,
            "element_rank": argument.element_rank,
            "address_space": argument.address_space,
            "length": _expr_to_dict(argument.length),
            "layout": layout,
            "descriptor_version": argument.descriptor_version,
        }
    if isinstance(argument, ScalarContract):
        return {"kind": "scalar", "element": argument.element}
    if isinstance(argument, StructContract):
        from cannbotdsl.types.datastruct import _schema_to_dict

        return {"kind": "datastruct", "schema": _schema_to_dict(argument.schema)}
    if isinstance(argument, StructRefContract):
        from cannbotdsl.types.datastruct import _schema_to_dict

        return {
            "kind": "datastruct_ref",
            "schema": _schema_to_dict(argument.schema),
            "address_space": argument.address_space,
            "access": argument.access,
        }
    raise TypeError(f"cannot encode argument contract {argument!r}")


def _argument_from_dict(data: dict):
    if not isinstance(data, dict):
        raise ValueError(
            f"argument contract must be an object, got {type(data).__name__}"
        )
    kind = data.get("kind")
    if kind == "tensor":
        element = _checked_string(data["element"], path="tensor element tag")
        element_for_tag(element)
        if not isinstance(data["shape"], list) or not isinstance(
            data["stride"], list
        ):
            raise ValueError("tensor contract shape/stride must be arrays")
        shape = tuple(_expr_from_dict(item) for item in data["shape"])
        stride = tuple(_expr_from_dict(item) for item in data["stride"])
        if len(shape) != len(stride):
            raise ValueError("tensor contract shape/stride rank mismatch")
        if data.get("address_space") != "GM":
            raise ValueError("host tensor contracts must use GM address space")
        raw_storage = data.get("storage_encoding")
        storage_encoding = None
        if raw_storage is not None:
            if not isinstance(raw_storage, dict):
                raise ValueError(
                    "tensor storage_encoding must be null or an object"
                )
            raw_physical_shape = raw_storage.get("physical_shape")
            if not isinstance(raw_physical_shape, list):
                raise ValueError(
                    "tensor storage_encoding.physical_shape must be an array"
                )
            storage_encoding = StorageEncodingContract(
                encoding=_checked_string(
                    raw_storage.get("encoding"),
                    path="tensor storage_encoding.encoding",
                ),
                physical_shape=tuple(
                    _expr_from_dict(item) for item in raw_physical_shape
                ),
            )
        return TensorContract(
            element,
            shape,
            stride,
            storage_encoding=storage_encoding,
        )
    if kind == "tensor_list":
        version = data.get("descriptor_version")
        if isinstance(version, bool) or version != 2:
            raise ValueError(
                "unsupported tensor_list descriptor_version; expected the "
                "integer 2. Recompile the artifact with the current "
                "CANNBotDSL runtime."
            )
        element_type = _checked_string(
            data["element_type"], path="tensor_list element_type"
        )
        element_for_tag(element_type)
        element_rank = _checked_i64(
            data["element_rank"], path="tensor_list element_rank"
        )
        address_space = _checked_string(
            data["address_space"], path="tensor_list address_space"
        )
        raw_layout = data["layout"]
        if not isinstance(raw_layout, dict):
            raise ValueError("tensor_list layout must be an object")
        layout_kind = raw_layout.get("kind")
        if layout_kind == "template":
            raw_dimensions = raw_layout["element_dimensions"]
            raw_shape = raw_layout["shape_expressions"]
            raw_stride = raw_layout["stride_expressions"]
            if not isinstance(raw_dimensions, list):
                raise ValueError(
                    "tensor_list template element_dimensions must be an array"
                )
            if not isinstance(raw_shape, list) or not isinstance(
                raw_stride, list
            ):
                raise ValueError(
                    "tensor_list template shape/stride expressions must be arrays"
                )
            dimensions = []
            for index, item in enumerate(raw_dimensions):
                if not isinstance(item, dict):
                    raise ValueError(
                        f"tensor_list element_dimensions[{index}] must be an object"
                    )
                dimensions.append(
                    DimensionContract(
                        _checked_string(
                            item["name"],
                            path=f"tensor_list element_dimensions[{index}].name",
                        ),
                        _checked_i64(
                            item["min"],
                            path=f"tensor_list element_dimensions[{index}].min",
                        ),
                        (
                            None
                            if item.get("max") is None
                            else _checked_i64(
                                item["max"],
                                path=(
                                    "tensor_list element_dimensions"
                                    f"[{index}].max"
                                ),
                            )
                        ),
                        _checked_i64(
                            item["multiple_of"],
                            path=(
                                "tensor_list element_dimensions"
                                f"[{index}].multiple_of"
                            ),
                        ),
                    )
                )
            layout = TemplateLayout(
                tuple(dimensions),
                tuple(_expr_from_dict(item) for item in raw_shape),
                tuple(_expr_from_dict(item) for item in raw_stride),
            )
        elif layout_kind == "exact":
            raw_items = raw_layout["items"]
            if not isinstance(raw_items, list):
                raise ValueError("tensor_list exact items must be an array")
            items = []
            for index, item in enumerate(raw_items):
                if not isinstance(item, dict):
                    raise ValueError(
                        f"tensor_list exact items[{index}] must be an object"
                    )
                raw_shape = item["shape"]
                raw_stride = item["stride"]
                if not isinstance(raw_shape, list) or not isinstance(
                    raw_stride, list
                ):
                    raise ValueError(
                        f"tensor_list exact items[{index}] shape/stride must be arrays"
                    )
                items.append(
                    ExactLayout(
                        tuple(
                            _checked_i64(
                                value,
                                path=(
                                    f"tensor_list exact items[{index}].shape"
                                    f"[{axis}]"
                                ),
                            )
                            for axis, value in enumerate(raw_shape)
                        ),
                        tuple(
                            _checked_i64(
                                value,
                                path=(
                                    f"tensor_list exact items[{index}].stride"
                                    f"[{axis}]"
                                ),
                            )
                            for axis, value in enumerate(raw_stride)
                        ),
                    )
                )
            layout = ExactLayouts(tuple(items))
        else:
            raise ValueError(
                f"unknown tensor_list layout kind {layout_kind!r}"
            )
        return TensorListContract(
            element_type=element_type,
            element_rank=element_rank,
            address_space=address_space,
            length=_expr_from_dict(data["length"]),
            layout=layout,
            descriptor_version=version,
        )
    if kind == "scalar":
        element = _checked_string(data["element"], path="scalar element tag")
        info = element_for_tag(element)
        scalar_for_dsl_type(info.dsl_type)
        return ScalarContract(element)
    if kind == "datastruct":
        from cannbotdsl.types.datastruct import _schema_from_dict

        return StructContract(_schema_from_dict(data["schema"]))
    if kind == "datastruct_ref":
        from cannbotdsl.types.datastruct import _schema_from_dict

        address_space = _checked_string(
            data["address_space"], path="datastruct_ref address_space"
        )
        access = _checked_string(data["access"], path="datastruct_ref access")
        return StructRefContract(
            _schema_from_dict(data["schema"]),
            address_space=address_space,
            access=access,
        )
    raise ValueError(f"unknown argument contract kind {kind!r}")


def _validate_expression(
    expression,
    *,
    dimensions: dict[str, DimensionContract],
    referenced: set[str],
    path: str,
) -> None:
    if isinstance(expression, ConstantExpr):
        _checked_i64(expression.value, path=path)
        return
    if isinstance(expression, DimensionExpr):
        name = _checked_string(expression.name, path=f"{path} dimension")
        if name not in dimensions:
            raise ValueError(f"{path} references undeclared Dim {name!r}")
        referenced.add(name)
        return
    if not isinstance(expression, BinaryExpr):
        raise ValueError(f"{path} contains unknown expression {expression!r}")
    if expression.op not in {"add", "sub", "mul", "floordiv"}:
        raise ValueError(f"{path} has unknown expression op {expression.op!r}")
    _validate_expression(
        expression.lhs,
        dimensions=dimensions,
        referenced=referenced,
        path=f"{path}.lhs",
    )
    _validate_expression(
        expression.rhs,
        dimensions=dimensions,
        referenced=referenced,
        path=f"{path}.rhs",
    )
    if expression.op == "floordiv" and (
        not isinstance(expression.rhs, ConstantExpr)
        or expression.rhs.value <= 0
    ):
        raise ValueError(
            f"{path} floor-divisor must be a positive integer constant"
        )


def _validate_dimension_scope(
    declarations,
    *,
    path: str,
) -> dict[str, DimensionContract]:
    if not isinstance(declarations, tuple):
        raise ValueError(f"{path} must be a tuple")
    names = []
    result = {}
    for index, dimension in enumerate(declarations):
        item_path = f"{path}[{index}]"
        if not isinstance(dimension, DimensionContract):
            raise ValueError(f"{item_path} is not a DimensionContract")
        name = _checked_string(dimension.name, path=f"{item_path}.name")
        if name in result:
            raise ValueError(f"duplicate Dim declaration {name!r} in {path}")
        minimum = _checked_i64(
            dimension.minimum, path=f"Dim {name!r}.minimum"
        )
        if minimum < 0:
            raise ValueError(f"Dim {name!r}.minimum must be >= 0")
        if dimension.maximum is not None:
            maximum = _checked_i64(
                dimension.maximum, path=f"Dim {name!r}.maximum"
            )
            if maximum < minimum:
                raise ValueError(f"Dim {name!r}.maximum must be >= minimum")
        multiple = _checked_i64(
            dimension.multiple_of, path=f"Dim {name!r}.multiple_of"
        )
        if multiple < 1:
            raise ValueError(f"Dim {name!r}.multiple_of must be >= 1")
        names.append(name)
        result[name] = dimension
    if names != sorted(names):
        raise ValueError(f"{path} must be sorted by name")
    return result


def _validate_argument(
    argument,
    *,
    dimensions: dict[str, DimensionContract],
    referenced: set[str],
    directly_bound: set[str],
    path: str,
) -> None:
    if isinstance(argument, TensorContract):
        info = element_for_tag(argument.element)
        if argument.address_space != "GM":
            raise ValueError(f"{path} host tensor address space must be GM")
        if not isinstance(argument.shape, tuple) or not isinstance(
            argument.stride, tuple
        ):
            raise ValueError(f"{path} tensor shape/stride must be tuples")
        if len(argument.shape) != len(argument.stride):
            raise ValueError(f"{path} tensor shape/stride rank mismatch")
        for field, slots in (("shape", argument.shape), ("stride", argument.stride)):
            for index, expression in enumerate(slots):
                slot_path = f"{path}.{field}[{index}]"
                _validate_expression(
                    expression,
                    dimensions=dimensions,
                    referenced=referenced,
                    path=slot_path,
                )
                if isinstance(expression, ConstantExpr) and expression.value < 0:
                    raise ValueError(
                        f"{slot_path} must be non-negative, got {expression.value}"
                    )
                if isinstance(expression, DimensionExpr):
                    directly_bound.add(expression.name)
        storage = argument.storage_encoding
        if storage is None:
            return
        if not isinstance(storage, StorageEncodingContract):
            raise ValueError(
                f"{path}.storage_encoding must be a StorageEncodingContract or None"
            )
        if argument.element not in FRACTAL_NZ_ELEMENT_TAGS:
            raise ValueError(
                f"{path} FRACTAL_NZ storage does not support element "
                f"{argument.element!r}"
            )
        if storage.encoding != "fractal_nz":
            raise ValueError(
                f"{path}.storage_encoding.encoding must be 'fractal_nz', got "
                f"{storage.encoding!r}"
            )
        if argument.stride != compact_stride(argument.shape):
            raise ValueError(
                f"{path}.storage_encoding requires compact logical stride"
            )
        expected = fractal_nz_storage_encoding(
            argument.shape,
            element=argument.element,
        )
        if storage.physical_shape != expected.physical_shape:
            raise ValueError(
                f"{path}.storage_encoding physical shape is not canonical FRACTAL_NZ"
            )
        if not isinstance(storage.physical_shape, tuple):
            raise ValueError(
                f"{path}.storage_encoding.physical_shape must be a tuple"
            )
        for index, expression in enumerate(storage.physical_shape):
            _validate_expression(
                expression,
                dimensions=dimensions,
                referenced=referenced,
                path=f"{path}.storage_encoding.physical_shape[{index}]",
            )
        return
    if isinstance(argument, TensorListContract):
        if argument.descriptor_version != 2 or isinstance(
            argument.descriptor_version, bool
        ):
            raise ValueError(
                f"{path} tensor_list descriptor_version must be 2. "
                "Recompile the artifact with the current CANNBotDSL runtime."
            )
        element_for_tag(argument.element_type)
        rank = _checked_i64(
            argument.element_rank, path=f"{path}.element_rank"
        )
        if rank < 0:
            raise ValueError(f"{path}.element_rank must be >= 0")
        if rank > (1 << 31) - 1:
            raise ValueError(f"{path}.element_rank exceeds signed int32")
        if argument.address_space != "GM":
            raise ValueError(f"{path} tensor_list address space must be GM")
        _validate_expression(
            argument.length,
            dimensions=dimensions,
            referenced=referenced,
            path=f"{path}.length",
        )
        if isinstance(argument.length, ConstantExpr):
            if argument.length.value < 1:
                raise ValueError(
                    f"{path}.length must be >= 1, got {argument.length.value}"
                )
        elif isinstance(argument.length, DimensionExpr):
            directly_bound.add(argument.length.name)
            rule = dimensions[argument.length.name]
            if rule.minimum < 1:
                raise ValueError(
                    f"{path}.length Dim {rule.name!r} must have minimum >= 1"
                )
        else:
            raise ValueError(
                f"{path}.length must be a constant or direct Dim expression"
            )

        if isinstance(argument.layout, TemplateLayout):
            local_dimensions = _validate_dimension_scope(
                argument.layout.element_dimensions,
                path=f"{path}.layout.element_dimensions",
            )
            if not isinstance(argument.layout.shape_expressions, tuple) or not isinstance(
                argument.layout.stride_expressions, tuple
            ):
                raise ValueError(
                    f"{path} template shape/stride expressions must be tuples"
                )
            if len(argument.layout.shape_expressions) != rank or len(
                argument.layout.stride_expressions
            ) != rank:
                raise ValueError(
                    f"{path} template shape/stride rank must equal element_rank"
                )
            local_referenced: set[str] = set()
            local_directly_bound: set[str] = set()
            for field, slots in (
                ("shape", argument.layout.shape_expressions),
                ("stride", argument.layout.stride_expressions),
            ):
                for index, expression in enumerate(slots):
                    slot_path = f"{path}.layout.{field}[{index}]"
                    _validate_expression(
                        expression,
                        dimensions=local_dimensions,
                        referenced=local_referenced,
                        path=slot_path,
                    )
                    if (
                        isinstance(expression, ConstantExpr)
                        and expression.value < 0
                    ):
                        raise ValueError(
                            f"{slot_path} must be non-negative, got "
                            f"{expression.value}"
                        )
                    if isinstance(expression, DimensionExpr):
                        local_directly_bound.add(expression.name)
            local_names = set(local_dimensions)
            unused = local_names - local_referenced
            if unused:
                raise ValueError(
                    f"unused TensorList element Dim declarations: {sorted(unused)}"
                )
            unbound = local_referenced - local_directly_bound
            if unbound:
                raise ValueError(
                    "every TensorList element Dim must appear directly in at "
                    "least one complete shape/stride slot; only derived "
                    f"occurrences were found for {sorted(unbound)}"
                )
        elif isinstance(argument.layout, ExactLayouts):
            if not isinstance(argument.length, ConstantExpr):
                raise ValueError(
                    f"{path} exact TensorList layout requires a constant length"
                )
            if not isinstance(argument.layout.items, tuple):
                raise ValueError(f"{path} exact layout items must be a tuple")
            if len(argument.layout.items) != argument.length.value:
                raise ValueError(
                    f"{path} exact layout item count must match length"
                )
            for item_index, item in enumerate(argument.layout.items):
                item_path = f"{path}.layout.items[{item_index}]"
                if not isinstance(item, ExactLayout):
                    raise ValueError(f"{item_path} is not an ExactLayout")
                if not isinstance(item.shape, tuple) or not isinstance(
                    item.stride, tuple
                ):
                    raise ValueError(
                        f"{item_path} shape/stride must be tuples"
                    )
                if len(item.shape) != rank or len(item.stride) != rank:
                    raise ValueError(
                        f"{item_path} shape/stride rank must equal element_rank"
                    )
                for field, values in (("shape", item.shape), ("stride", item.stride)):
                    for axis, value in enumerate(values):
                        checked = _checked_i64(
                            value, path=f"{item_path}.{field}[{axis}]"
                        )
                        if checked < 0:
                            raise ValueError(
                                f"{item_path}.{field}[{axis}] must be "
                                f"non-negative, got {checked}"
                            )
        else:
            raise ValueError(
                f"{path} has unknown TensorList layout {argument.layout!r}"
            )
        return
    if isinstance(argument, ScalarContract):
        info = element_for_tag(argument.element)
        scalar_for_dsl_type(info.dsl_type)
        return
    if isinstance(argument, StructContract):
        from cannbotdsl.types.datastruct import _schema_to_dict

        _schema_to_dict(argument.schema)
        return
    if isinstance(argument, StructRefContract):
        from cannbotdsl.types.datastruct import _schema_to_dict

        _schema_to_dict(argument.schema)
        if argument.address_space != "GM":
            raise ValueError(f"{path} datastruct_ref address space must be GM")
        if argument.access != "readwrite":
            raise ValueError(f"{path} datastruct_ref access must be readwrite")
        return
    raise ValueError(f"{path} has unknown argument contract {argument!r}")


def validate_call_contract(contract: CallContract) -> CallContract:
    """Validate all persisted/domain invariants without creating MLIR state."""

    if not isinstance(contract, CallContract):
        raise TypeError(f"expected CallContract, got {type(contract).__name__}")
    if contract.host_abi_version != _HOST_ABI_VERSION:
        raise ValueError(
            f"unsupported call contract host ABI {contract.host_abi_version!r}; "
            f"expected {_HOST_ABI_VERSION}"
        )
    if not isinstance(contract.dimensions, tuple):
        raise ValueError("call contract dimensions must be a tuple")
    dimension_names = []
    dimensions = {}
    for index, dimension in enumerate(contract.dimensions):
        if not isinstance(dimension, DimensionContract):
            raise ValueError(f"dimensions[{index}] is not a DimensionContract")
        name = _checked_string(dimension.name, path=f"dimensions[{index}].name")
        if name in dimensions:
            raise ValueError(f"duplicate Dim declaration {name!r}")
        minimum = _checked_i64(
            dimension.minimum, path=f"Dim {name!r}.minimum"
        )
        if minimum < 0:
            raise ValueError(f"Dim {name!r}.minimum must be >= 0")
        if dimension.maximum is not None:
            maximum = _checked_i64(
                dimension.maximum, path=f"Dim {name!r}.maximum"
            )
            if maximum < minimum:
                raise ValueError(f"Dim {name!r}.maximum must be >= minimum")
        multiple = _checked_i64(
            dimension.multiple_of, path=f"Dim {name!r}.multiple_of"
        )
        if multiple < 1:
            raise ValueError(f"Dim {name!r}.multiple_of must be >= 1")
        dimension_names.append(name)
        dimensions[name] = dimension
    if dimension_names != sorted(dimension_names):
        raise ValueError("call contract dimensions must be sorted by name")

    if not isinstance(contract.parameters, tuple):
        raise ValueError("call contract parameters must be a tuple")
    parameter_names = set()
    runtime_signature_parameters = []
    referenced: set[str] = set()
    directly_bound: set[str] = set()
    for index, parameter in enumerate(contract.parameters):
        path = f"parameters[{index}]"
        if not isinstance(parameter, ParameterContract):
            raise ValueError(f"{path} is not a ParameterContract")
        name = _checked_string(parameter.name, path=f"{path}.name")
        if name in parameter_names:
            raise ValueError(f"duplicate parameter name {name!r}")
        parameter_names.add(name)
        kind = _PARAMETER_KINDS.get(parameter.kind)
        if kind is None:
            raise ValueError(f"{path} has unsupported parameter kind {parameter.kind!r}")
        if parameter.role not in {"runtime", "constexpr", "captured"}:
            raise ValueError(f"{path} has unknown role {parameter.role!r}")
        if type(parameter.has_runtime_default) is not bool:
            raise ValueError(f"{path}.has_runtime_default must be a bool")

        if parameter.role == "runtime":
            if parameter.argument is None:
                raise ValueError(f"runtime {path} is missing its argument contract")
            if parameter.static_value is not None:
                raise ValueError(f"runtime {path} cannot carry a static value")
            if parameter.has_runtime_default != (parameter.runtime_default is not None):
                raise ValueError(f"runtime {path} has inconsistent default metadata")
            default = inspect.Parameter.empty
            if parameter.runtime_default is not None:
                default = _runtime_default_to_python(
                    parameter.runtime_default,
                    path=f"{path}.runtime_default",
                )
            _validate_argument(
                parameter.argument,
                dimensions=dimensions,
                referenced=referenced,
                directly_bound=directly_bound,
                path=f"parameter {name!r}",
            )
            if parameter.runtime_default is not None and isinstance(
                parameter.argument, ScalarContract
            ):
                validate_host_scalar_value(
                    element_for_tag(parameter.argument.element),
                    default,
                    path=f"{path}.runtime_default",
                    code=CT101_INVALID_RUNTIME_DEFAULT,
                    phase="contract",
                )
            try:
                runtime_signature_parameters.append(
                    inspect.Parameter(name, kind, default=default)
                )
            except (TypeError, ValueError) as exc:
                raise ValueError(f"invalid runtime parameter {name!r}: {exc}") from exc
        else:
            if parameter.argument is not None:
                raise ValueError(f"static {path} cannot carry an ABI argument")
            if parameter.static_value is None:
                raise ValueError(f"static {path} is missing its value")
            if parameter.has_runtime_default or parameter.runtime_default is not None:
                raise ValueError(f"static {path} cannot carry a runtime default")
            literal_to_python(parameter.static_value)

    try:
        inspect.Signature(runtime_signature_parameters)
    except ValueError as exc:
        raise ValueError(f"invalid runtime parameter ordering: {exc}") from exc

    undeclared_use = referenced - set(dimensions)
    if undeclared_use:  # defensive; _validate_expression reports this first
        raise ValueError(f"undeclared dimensions referenced: {sorted(undeclared_use)}")
    unused = set(dimensions) - referenced
    if unused:
        raise ValueError(f"unused Dim declarations: {sorted(unused)}")
    unbound = referenced - directly_bound
    if unbound:
        raise ValueError(
            "every Dim must appear directly in at least one "
            "shape/stride/TensorList-length slot; "
            f"only derived occurrences were found for {sorted(unbound)}"
        )
    return contract


def contract_to_dict(contract: CallContract) -> dict:
    validate_call_contract(contract)
    return {
        "schema_version": _CONTRACT_SCHEMA_VERSION,
        "host_abi_version": contract.host_abi_version,
        "dimensions": [
            {
                "name": item.name,
                "min": item.minimum,
                "max": item.maximum,
                "multiple_of": item.multiple_of,
            }
            for item in contract.dimensions
        ],
        "parameters": [
            {
                "name": parameter.name,
                "parameter_kind": parameter.kind,
                "role": parameter.role,
                "argument": (
                    None
                    if parameter.argument is None
                    else _argument_to_dict(parameter.argument)
                ),
                "static_value": (
                    None
                    if parameter.static_value is None
                    else _literal_to_dict(parameter.static_value)
                ),
                "has_runtime_default": parameter.has_runtime_default,
                "runtime_default": (
                    None
                    if parameter.runtime_default is None
                    else _literal_to_dict(parameter.runtime_default)
                ),
            }
            for parameter in contract.parameters
        ],
    }


def contract_from_dict(data: dict) -> CallContract:
    if not isinstance(data, dict):
        raise ValueError(
            f"call contract must be an object, got {type(data).__name__}"
        )
    if data.get("schema_version") != _CONTRACT_SCHEMA_VERSION:
        raise ValueError(
            f"unsupported call contract schema {data.get('schema_version')!r}; "
            f"expected {_CONTRACT_SCHEMA_VERSION}. Recompile the artifact "
            "with the current CANNBotDSL runtime."
        )
    raw_dimensions = data["dimensions"]
    raw_parameters = data["parameters"]
    if not isinstance(raw_dimensions, list):
        raise ValueError("call contract dimensions must be an array")
    if not isinstance(raw_parameters, list):
        raise ValueError("call contract parameters must be an array")
    dimensions = []
    for index, item in enumerate(raw_dimensions):
        if not isinstance(item, dict):
            raise ValueError(f"dimensions[{index}] must be an object")
        dimensions.append(
            DimensionContract(
                _checked_string(item["name"], path=f"dimensions[{index}].name"),
                _checked_i64(item["min"], path=f"dimensions[{index}].min"),
                (
                    None
                    if item.get("max") is None
                    else _checked_i64(
                        item["max"], path=f"dimensions[{index}].max"
                    )
                ),
                _checked_i64(
                    item["multiple_of"],
                    path=f"dimensions[{index}].multiple_of",
                ),
            )
        )
    parameters = []
    for index, item in enumerate(raw_parameters):
        if not isinstance(item, dict):
            raise ValueError(f"parameters[{index}] must be an object")
        role = item["role"]
        if role not in {"runtime", "constexpr", "captured"}:
            raise ValueError(f"unknown parameter role {role!r}")
        argument_data = item.get("argument")
        static_data = item.get("static_value")
        default_data = item.get("runtime_default")
        has_runtime_default = item.get("has_runtime_default", False)
        if type(has_runtime_default) is not bool:
            raise ValueError(
                f"parameters[{index}].has_runtime_default must be a bool"
            )
        parameters.append(
            ParameterContract(
                name=_checked_string(
                    item["name"], path=f"parameters[{index}].name"
                ),
                kind=_checked_string(
                    item["parameter_kind"],
                    path=f"parameters[{index}].parameter_kind",
                ),
                role=role,
                argument=(
                    None
                    if argument_data is None
                    else _argument_from_dict(argument_data)
                ),
                static_value=(
                    None if static_data is None else _literal_from_dict(static_data)
                ),
                runtime_default=(
                    None
                    if default_data is None
                    else _runtime_default_from_dict(
                        default_data,
                        path=f"parameters[{index}].runtime_default",
                    )
                ),
                has_runtime_default=has_runtime_default,
            )
        )
    host_abi_version = _checked_i64(
        data["host_abi_version"], path="host_abi_version"
    )
    return validate_call_contract(
        CallContract(
            tuple(parameters),
            tuple(dimensions),
            host_abi_version=host_abi_version,
        )
    )


def canonical_contract_bytes(contract: CallContract) -> bytes:
    return json.dumps(
        contract_to_dict(contract),
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def contract_digest(contract: CallContract) -> str:
    return hashlib.sha256(canonical_contract_bytes(contract)).hexdigest()


__all__ = [
    "canonical_contract_bytes",
    "contract_digest",
    "contract_from_dict",
    "contract_to_dict",
    "literal_from_python",
    "literal_to_python",
    "validate_call_contract",
]
