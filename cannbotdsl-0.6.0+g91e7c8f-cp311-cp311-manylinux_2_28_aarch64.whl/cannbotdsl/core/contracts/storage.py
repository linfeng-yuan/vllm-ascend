# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Canonical storage-layout expressions shared by JIT, AOT, and codecs."""

from __future__ import annotations

from typing import cast

from cannbotdsl.core.contracts.model import (
    BinaryExpr,
    ConstantExpr,
    DimensionExpr,
    ShapeExpr,
    StorageEncodingContract,
)
from cannbotdsl.types._storage_format import fractal_nz_c0


def _constant(value: int) -> ConstantExpr:
    return ConstantExpr(int(value))


def _expression_sort_key(value: ShapeExpr) -> tuple:
    if isinstance(value, ConstantExpr):
        return (0, value.value)
    if isinstance(value, DimensionExpr):
        return (1, value.name)
    return (
        2,
        value.op,
        _expression_sort_key(value.lhs),
        _expression_sort_key(value.rhs),
    )


def _add(lhs: ShapeExpr, rhs: ShapeExpr) -> ShapeExpr:
    if isinstance(lhs, ConstantExpr) and isinstance(rhs, ConstantExpr):
        return _constant(lhs.value + rhs.value)
    if isinstance(rhs, ConstantExpr) and rhs.value == 0:
        return lhs
    if isinstance(lhs, ConstantExpr) and lhs.value == 0:
        return rhs
    if _expression_sort_key(rhs) < _expression_sort_key(lhs):
        lhs, rhs = rhs, lhs
    return BinaryExpr("add", lhs, rhs)


def _mul(lhs: ShapeExpr, rhs: ShapeExpr) -> ShapeExpr:
    if isinstance(lhs, ConstantExpr) and isinstance(rhs, ConstantExpr):
        return _constant(lhs.value * rhs.value)
    if isinstance(lhs, ConstantExpr):
        if lhs.value == 0:
            return lhs
        if lhs.value == 1:
            return rhs
    if isinstance(rhs, ConstantExpr):
        if rhs.value == 0:
            return rhs
        if rhs.value == 1:
            return lhs
    if _expression_sort_key(rhs) < _expression_sort_key(lhs):
        lhs, rhs = rhs, lhs
    return BinaryExpr("mul", lhs, rhs)


def _ceil_div(value: ShapeExpr, divisor: int) -> ShapeExpr:
    if isinstance(value, ConstantExpr):
        return _constant((value.value + divisor - 1) // divisor)
    return BinaryExpr(
        "floordiv",
        _add(value, _constant(divisor - 1)),
        _constant(divisor),
    )


def compact_stride(shape: tuple[ShapeExpr, ...]) -> tuple[ShapeExpr, ...]:
    if not shape:
        return ()
    stride: list[ShapeExpr] = [_constant(1) for _ in shape]
    for index in range(len(shape) - 2, -1, -1):
        stride[index] = _mul(shape[index + 1], stride[index + 1])
    return tuple(stride)


def fractal_nz_storage_encoding(
    logical_shape: tuple[ShapeExpr, ...],
    *,
    element: str,
) -> StorageEncodingContract:
    if len(logical_shape) not in (2, 3):
        raise ValueError(
            "FRACTAL_NZ storage requires logical rank 2 or 3, got "
            f"{len(logical_shape)}"
        )
    c0 = fractal_nz_c0(element)
    m, n = logical_shape[-2:]
    physical_shape = logical_shape[:-2] + (
        _ceil_div(n, c0),
        _ceil_div(m, 16),
        _constant(16),
        _constant(c0),
    )
    return StorageEncodingContract(
        encoding="fractal_nz",
        physical_shape=physical_shape,
    )


def constant_values(
    expressions: tuple[ShapeExpr, ...],
) -> tuple[int, ...] | None:
    if not all(isinstance(item, ConstantExpr) for item in expressions):
        return None
    return tuple(cast(ConstantExpr, item).value for item in expressions)


__all__ = [
    "compact_stride",
    "constant_values",
    "fractal_nz_storage_encoding",
]
