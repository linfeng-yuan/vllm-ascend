# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# Licensed under the CANN Open Software License Agreement Version 2.0.
"""Metadata reporting to CANN profiling tools; this module does not collect traces."""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ProfileSpec:
    """Describe a kernel's profiling identity and Tensor parameter roles.

    Parameter groups are tuples of parameter names. ``inouts`` are reported
    once as inputs and once as outputs. Undeclared arguments are omitted.
    Shapes, storage formats, and dtypes come from the actual kernel launch.
    """

    name: str | None = None
    op_type: str | None = None
    inputs: tuple[str, ...] = ()
    outputs: tuple[str, ...] = ()
    inouts: tuple[str, ...] = ()

    def __post_init__(self):
        for field in ("name", "op_type"):
            value = getattr(self, field)
            if value is not None and (
                not isinstance(value, str) or not value or "\0" in value
            ):
                raise ValueError(f"ProfileSpec.{field} must be a nonempty string without NUL")
        seen = set()
        for field in ("inputs", "outputs", "inouts"):
            names = getattr(self, field)
            if not isinstance(names, tuple):
                raise TypeError(f"ProfileSpec.{field} must be a tuple of parameter names")
            for name in names:
                if not isinstance(name, str) or not name.isidentifier():
                    raise ValueError(f"ProfileSpec.{field} contains an invalid parameter name")
                if name in seen:
                    raise ValueError(f"ProfileSpec repeats parameter {name!r}; use inouts for read/write tensors")
                seen.add(name)

    def _validate_signature(self, signature):
        for name in (*self.inputs, *self.outputs, *self.inouts):
            if name not in signature.parameters:
                raise ValueError(f"ProfileSpec names unknown kernel parameter {name!r}")


__all__ = ["ProfileSpec"]
