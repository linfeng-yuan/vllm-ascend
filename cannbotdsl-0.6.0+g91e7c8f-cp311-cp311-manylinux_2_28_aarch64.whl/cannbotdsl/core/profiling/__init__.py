# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# Licensed under the CANN Open Software License Agreement Version 2.0.
"""Kernel profiling metadata declarations, independent of compiler IR."""

from .spec import ProfileSpec

__all__ = ["ProfileSpec"]
