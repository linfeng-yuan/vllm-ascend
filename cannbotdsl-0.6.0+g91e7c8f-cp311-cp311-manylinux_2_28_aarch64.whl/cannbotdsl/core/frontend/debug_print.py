# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Debug-print plumbing for ``cannbotdsl.print_tensor``.

Owns the per-kernel ``DebugPrintPlan`` / ``DebugPrintRecord`` data classes,
the MLIR memref types that carry payload + counter buffers, and the
post-launch ``_capture_debug_prints`` routine that reads the device-side
ring buffers back to host and renders them.

Decoupled from :mod:`cannbotdsl.lang.jit` so the staged JIT function is
limited to decorator glue and the AOT compiler
(``cannbotdsl.core.compiler.function``) can reuse the same capture path without
reaching into the JIT module.
"""

from dataclasses import dataclass, field
from typing import Any, List, Optional, Tuple

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir


@dataclass
class DebugPrintRecord:
    printer_id: int
    label: str
    source_location: str
    dtype: str
    shape: Tuple[int, ...]
    memloc: str
    max_bytes: int
    mode: str = "ring"
    op: Optional[Any] = None
    view_offset_in_bytes: int = 0
    physical_copy_bytes: Optional[int] = None
    visible_payload_bytes: Optional[int] = None
    physical_shape: Optional[Tuple[int, ...]] = None
    layout_kind: str = "identity"
    physical_format: str = "nd"
    is_scalar: bool = False


@dataclass
class DebugPrintPlan:
    kernel_name: str
    block_dim: int = 1
    subblock_dim: int = 2
    payload_arg: Optional[ir.Value] = None
    counter_arg: Optional[ir.Value] = None
    host_payload_arg: Optional[ir.Value] = None
    host_counter_arg: Optional[ir.Value] = None
    payload_type: Optional[ir.Type] = None
    counter_type: Optional[ir.Type] = None
    records: List[DebugPrintRecord] = field(default_factory=list)
    native_dump_count: int = 0

    @property
    def has_prints(self) -> bool:
        return bool(self.records)

    @property
    def payload_bytes(self) -> int:
        triples = max(1, len(self.records)) * max(1, self.block_dim) * max(1, self.subblock_dim)
        return triples * 64 * 1024

    @property
    def counter_bytes(self) -> int:
        triples = max(1, len(self.records)) * max(1, self.block_dim) * max(1, self.subblock_dim)
        return triples * 64


def _debug_memref_type(num_bytes: int, *, ctx: ir.Context) -> ir.Type:
    from cannbotdsl.tensor import MemLoc

    layout_ty = cannir.LayoutType.get((num_bytes,), (1,), context=ctx)
    ptr_ty = cannir.PointerType.get(
        MemLoc.GM,
        ir.IntegerType.get_signless(8, context=ctx),
        context=ctx,
    )
    return cannir.TensorType.get(ptr_ty, layout_ty, layout_ty, 0)


def _debug_counter_memref_type(num_bytes: int, *, ctx: ir.Context) -> ir.Type:
    from cannbotdsl.tensor import MemLoc

    if num_bytes % 8 != 0:
        raise ValueError("debug counter byte size must be a multiple of 8")
    num_elems = num_bytes // 8
    layout_ty = cannir.LayoutType.get((num_elems,), (1,), context=ctx)
    ptr_ty = cannir.PointerType.get(
        MemLoc.GM,
        ir.IntegerType.get_signless(64, context=ctx),
        context=ctx,
    )
    return cannir.TensorType.get(ptr_ty, layout_ty, layout_ty, 0)


def _torch_dtype_for_debug_record(record: "DebugPrintRecord", torch_module):
    dtype = record.dtype
    if dtype in ("i1", "bool"):
        return torch_module.bool
    if dtype == "f32":
        return torch_module.float32
    if dtype == "f64":
        return torch_module.float64
    if dtype == "f16":
        return torch_module.float16
    if dtype == "bf16":
        return torch_module.bfloat16
    if dtype.startswith("i") and dtype[1:].isdigit():
        bits = int(dtype[1:])
        if bits == 8:
            return torch_module.int8
        if bits == 16:
            return torch_module.int16
        if bits == 32:
            return torch_module.int32
        if bits == 64:
            return torch_module.int64
    if dtype.startswith("ui") and dtype[2:].isdigit():
        bits = int(dtype[2:])
        if bits == 8:
            return torch_module.uint8
    return None


def _debug_record_numel(record: "DebugPrintRecord") -> int:
    numel = 1
    shape = record.physical_shape or record.shape
    for dim in shape:
        if dim < 0:
            return 0
        numel *= int(dim)
    return numel


def _debug_record_view_shape(record: "DebugPrintRecord", view_elems: int) -> Optional[Tuple[int, ...]]:
    shape = record.physical_shape or record.shape
    expected = 1
    for dim in shape:
        if dim < 0:
            return None
        expected *= int(dim)
    return tuple(shape) if expected == view_elems else None


def _debug_record_elem_size(record: "DebugPrintRecord", torch_module) -> int:
    dtype = _torch_dtype_for_debug_record(record, torch_module)
    if dtype is None:
        return 1
    return torch_module.empty((), dtype=dtype).element_size()


def _debug_visible_bytes(record: "DebugPrintRecord", logical_bytes: int) -> int:
    if record.visible_payload_bytes is not None:
        return max(0, min(int(record.visible_payload_bytes), logical_bytes))
    physical = record.physical_copy_bytes if record.physical_copy_bytes is not None else record.max_bytes
    return max(0, min(logical_bytes, int(physical) - int(record.view_offset_in_bytes)))


def _debug_slot_offset(plan: "DebugPrintPlan", record: "DebugPrintRecord", block_id: int, subblock_id: int) -> int:
    triple = (record.printer_id * max(1, plan.block_dim) + block_id) * max(1, plan.subblock_dim) + subblock_id
    return triple * 64 * 1024


def _debug_counter_offset(plan: "DebugPrintPlan", record: "DebugPrintRecord", block_id: int, subblock_id: int) -> int:
    triple = (record.printer_id * max(1, plan.block_dim) + block_id) * max(1, plan.subblock_dim) + subblock_id
    return triple * 8


def _render_debug_record(
    record: "DebugPrintRecord",
    data,
    counter: int,
    *,
    block_id: int = 0,
    subblock_id: int = 0,
    total_counter: Optional[int] = None,
) -> dict:
    rendered = {
        "label": record.label,
        "source_location": record.source_location,
        "printer_id": record.printer_id,
        "dtype": record.dtype,
        "shape": record.shape,
        "physical_shape": record.physical_shape,
        "layout_kind": record.layout_kind,
        "physical_format": record.physical_format,
        "memloc": record.memloc,
        "mode": record.mode,
        "counter": int(counter),
        "block_id": int(block_id),
        "subblock_id": int(subblock_id),
        "total_counter": int(total_counter if total_counter is not None else counter),
        "view_offset_in_bytes": int(record.view_offset_in_bytes),
        "physical_copy_bytes": record.physical_copy_bytes,
        "visible_payload_bytes": record.visible_payload_bytes,
        "data": data,
    }
    if record.is_scalar and data is not None:
        rendered["value"] = data.item()
    total_suffix = "" if total_counter is None else f" total={int(total_counter)}"
    print(
        f'[cannbotdsl.core.diag.debug] printer {record.printer_id} "{record.label}" '
        f"{record.memloc} {record.dtype} shape={record.shape} "
        f"layout={record.layout_kind}/{record.physical_format} "
        f"counter={rendered['counter']}{total_suffix} block={block_id} subblock={subblock_id} "
        f"@ {record.source_location}"
    )
    if data is not None:
        print(data)
    return rendered


def _capture_debug_prints(
    debug_tensors, existing_records: Optional[List[dict[str, Any]]] = None
) -> List[dict[str, Any]]:
    try:
        import torch
        from cannbotdsl.core.diag.debug import _set_debug_prints, get_debug_prints
    except ImportError:
        return existing_records or []

    records = list(existing_records if existing_records is not None else get_debug_prints())
    for plan, payload, counter in debug_tensors:
        payload_cpu = payload.cpu()
        counter_cpu = counter.cpu()
        for record in plan.records:
            dtype = _torch_dtype_for_debug_record(record, torch)
            numel = _debug_record_numel(record)
            elem_size = _debug_record_elem_size(record, torch)
            logical_bytes = numel * elem_size
            visible_bytes = _debug_visible_bytes(record, logical_bytes)
            total_counter = 0
            pending = []
            for block_id in range(max(1, plan.block_dim)):
                for subblock_id in range(max(1, plan.subblock_dim)):
                    counter_offset = _debug_counter_offset(plan, record, block_id, subblock_id)
                    slot_counter = (
                        int(counter_cpu[counter_offset].item()) if counter_offset < counter_cpu.numel() else 0
                    )
                    total_counter += slot_counter
                    pending.append((block_id, subblock_id, slot_counter))
            for block_id, subblock_id, slot_counter in pending:
                if slot_counter <= 0:
                    continue
                slot_offset = _debug_slot_offset(plan, record, block_id, subblock_id)
                records_to_read = min(slot_counter, 64)
                first_old = 0 if record.mode == "stop" else max(0, slot_counter - records_to_read)
                for old_idx in range(first_old, slot_counter):
                    if record.mode == "stop" and old_idx >= records_to_read:
                        break
                    record_slot = old_idx if record.mode == "stop" else (old_idx & 63)
                    start = slot_offset + record_slot * 1024 + int(record.view_offset_in_bytes)
                    nbytes = min(visible_bytes, max(0, payload_cpu.numel() - start))
                    data = None
                    if dtype is not None and numel > 0 and nbytes > 0:
                        view_elems = min(numel, nbytes // elem_size)
                        raw = payload_cpu[start : start + view_elems * elem_size].contiguous()
                        data = raw.view(dtype)[:view_elems].clone()
                        view_shape = _debug_record_view_shape(record, view_elems)
                        if view_shape is not None:
                            data = data.reshape(view_shape)
                    records.append(
                        _render_debug_record(
                            record,
                            data,
                            old_idx + 1,
                            block_id=block_id,
                            subblock_id=subblock_id,
                            total_counter=total_counter,
                        )
                    )
    _set_debug_prints(records)
    return records


def _capture_debug_results(
    debug_results, existing_records: Optional[List[dict[str, Any]]] = None
) -> List[dict[str, Any]]:
    """Decode synchronized provider-neutral debug bytes on the host."""

    try:
        import torch
    except ImportError:
        return existing_records or []
    debug_tensors = []
    for plan, result in debug_results:
        if result.payload:
            payload = torch.frombuffer(
                bytearray(result.payload), dtype=torch.int8
            )
        else:
            payload = torch.empty((0,), dtype=torch.int8)
        counter = torch.tensor(result.counters, dtype=torch.int64)
        debug_tensors.append((plan, payload, counter))
    return _capture_debug_prints(debug_tensors, existing_records)
