# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Stable, MLIR-independent contracts for the Python AST frontend."""

from __future__ import annotations

import ast
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cannbotdsl.core.frontend.analysis import FrontendPlan


class FrontendDumpKind(str, Enum):
    """Debug artifacts that can be retained for one frontend compilation."""

    SOURCE = "source"
    PLAN = "plan"
    LOWERED = "lowered"

    @classmethod
    def parse_many(cls, value: str | None) -> frozenset["FrontendDumpKind"]:
        if value is None or not value.strip():
            return frozenset()
        result: set[FrontendDumpKind] = set()
        for raw_token in value.split(","):
            token = raw_token.strip().lower()
            try:
                result.add(cls(token))
            except ValueError as exc:
                choices = ", ".join(item.value for item in cls)
                raise ValueError(
                    "CANNBOTDSL_DUMP_FRONTEND contains unknown token "
                    f"{raw_token!r}; expected a comma-separated subset of: {choices}"
                ) from exc
        return frozenset(result)


@dataclass(frozen=True, slots=True)
class FrontendOptions:
    """Immutable options captured at the start of one compilation."""

    emit_line_info: bool = False
    dumps: frozenset[FrontendDumpKind] = frozenset()

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "dumps",
            frozenset(FrontendDumpKind(kind) for kind in self.dumps),
        )


@dataclass(frozen=True, slots=True)
class SourceSpan:
    """A half-open source range using Python AST coordinates.

    Lines are one-based. Columns are zero-based UTF-8 byte offsets, matching
    :mod:`ast`. User-facing formatting converts columns to one-based character
    positions.
    """

    filename: str
    start_line: int
    start_col: int
    end_line: int
    end_col: int

    @classmethod
    def from_node(cls, node: ast.AST, filename: str) -> "SourceSpan":
        start_line = int(getattr(node, "lineno", 1))
        start_col = int(getattr(node, "col_offset", 0))
        end_line = int(getattr(node, "end_lineno", start_line))
        end_col = int(getattr(node, "end_col_offset", start_col + 1))
        return cls(
            filename=filename,
            start_line=start_line,
            start_col=start_col,
            end_line=end_line,
            end_col=end_col,
        )

    @property
    def display_start_col(self) -> int:
        """One-based column for diagnostics without a source line."""

        return self.start_col + 1

    def sort_key(self) -> tuple[int, int, int, int]:
        return (
            self.start_line,
            self.start_col,
            self.end_line,
            self.end_col,
        )


@dataclass(frozen=True, slots=True)
class FrontendDebugArtifacts:
    """Requested textual snapshots from a frontend compilation."""

    source: str | None = None
    plan: str | None = None
    lowered: str | None = None

    @property
    def normalized_source(self) -> str | None:
        return self.source

    @property
    def formatted_plan(self) -> str | None:
        return self.plan

    @property
    def lowered_source(self) -> str | None:
        return self.lowered


@dataclass(frozen=True, slots=True)
class FrontendArtifact:
    """The lowered callable and analysis/debug products of the frontend."""

    function: Callable[..., object]
    plan: "FrontendPlan"
    source_digest: str
    debug: FrontendDebugArtifacts | None


__all__ = [
    "FrontendArtifact",
    "FrontendDebugArtifacts",
    "FrontendDumpKind",
    "FrontendOptions",
    "SourceSpan",
]
