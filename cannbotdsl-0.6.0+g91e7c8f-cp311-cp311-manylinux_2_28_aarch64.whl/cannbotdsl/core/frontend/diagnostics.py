# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Deterministic diagnostics for the AST frontend.

This module intentionally has no dependency on the MLIR Python bindings.
"""

from __future__ import annotations

from enum import Enum

from cannbotdsl.core.diag.diagnostics import CANNBotError
from cannbotdsl.core.frontend.api import SourceSpan


class FrontendErrorCode(str, Enum):
    FE001_SOURCE_UNAVAILABLE = "FE001_SOURCE_UNAVAILABLE"
    FE002_TARGET_NOT_FOUND = "FE002_TARGET_NOT_FOUND"
    FE101_UNSUPPORTED_SYNTAX = "FE101_UNSUPPORTED_SYNTAX"
    FE102_UNSAFE_EARLY_EXIT = "FE102_UNSAFE_EARLY_EXIT"
    FE103_STRUCT_REF_REBIND = "FE103_STRUCT_REF_REBIND"
    FE201_UNBOUND_REGION_STATE = "FE201_UNBOUND_REGION_STATE"
    FE202_REGION_VALUE_ESCAPE = "FE202_REGION_VALUE_ESCAPE"
    FE301_INVALID_RANGE = "FE301_INVALID_RANGE"
    FE302_RANGE_TYPE_MISMATCH = "FE302_RANGE_TYPE_MISMATCH"
    FE303_NON_POSITIVE_STEP = "FE303_NON_POSITIVE_STEP"
    FE401_STATE_STRUCTURE_MISMATCH = "FE401_STATE_STRUCTURE_MISMATCH"
    FE402_STATE_TYPE_MISMATCH = "FE402_STATE_TYPE_MISMATCH"
    FE404_AMBIGUOUS_CARRIER_TYPE = "FE404_AMBIGUOUS_CARRIER_TYPE"
    FE501_MATERIALIZATION_FAILED = "FE501_MATERIALIZATION_FAILED"


# Module-level aliases make diagnostic codes convenient to import while the
# enum remains the canonical iterable registry.
FE001_SOURCE_UNAVAILABLE = FrontendErrorCode.FE001_SOURCE_UNAVAILABLE
FE002_TARGET_NOT_FOUND = FrontendErrorCode.FE002_TARGET_NOT_FOUND
FE101_UNSUPPORTED_SYNTAX = FrontendErrorCode.FE101_UNSUPPORTED_SYNTAX
FE102_UNSAFE_EARLY_EXIT = FrontendErrorCode.FE102_UNSAFE_EARLY_EXIT
FE103_STRUCT_REF_REBIND = FrontendErrorCode.FE103_STRUCT_REF_REBIND
FE201_UNBOUND_REGION_STATE = FrontendErrorCode.FE201_UNBOUND_REGION_STATE
FE202_REGION_VALUE_ESCAPE = FrontendErrorCode.FE202_REGION_VALUE_ESCAPE
FE301_INVALID_RANGE = FrontendErrorCode.FE301_INVALID_RANGE
FE302_RANGE_TYPE_MISMATCH = FrontendErrorCode.FE302_RANGE_TYPE_MISMATCH
FE303_NON_POSITIVE_STEP = FrontendErrorCode.FE303_NON_POSITIVE_STEP
FE401_STATE_STRUCTURE_MISMATCH = FrontendErrorCode.FE401_STATE_STRUCTURE_MISMATCH
FE402_STATE_TYPE_MISMATCH = FrontendErrorCode.FE402_STATE_TYPE_MISMATCH
FE404_AMBIGUOUS_CARRIER_TYPE = FrontendErrorCode.FE404_AMBIGUOUS_CARRIER_TYPE
FE501_MATERIALIZATION_FAILED = FrontendErrorCode.FE501_MATERIALIZATION_FAILED


def _byte_col_to_character_col(line: str, byte_col: int) -> int:
    """Convert an AST UTF-8 byte offset to a zero-based character offset."""

    encoded = line.encode("utf-8")
    prefix = encoded[: max(0, min(byte_col, len(encoded)))]
    return len(prefix.decode("utf-8", errors="ignore"))


def format_source_excerpt(
    source: str | None,
    span: SourceSpan | None,
    *,
    source_first_line: int = 1,
) -> str | None:
    """Render a compact multi-line excerpt with Unicode-correct carets."""

    if source is None or span is None:
        return None
    lines = source.splitlines()
    if not lines:
        return None
    first_index = span.start_line - source_first_line
    last_index = span.end_line - source_first_line
    if first_index < 0 or first_index >= len(lines):
        return None
    last_index = max(first_index, min(last_index, len(lines) - 1))
    number_width = len(str(source_first_line + last_index))
    rendered: list[str] = []
    for index in range(first_index, last_index + 1):
        line = lines[index]
        line_number = source_first_line + index
        if index == first_index:
            caret_start = _byte_col_to_character_col(line, span.start_col)
        else:
            caret_start = 0
        if index == last_index:
            caret_end = _byte_col_to_character_col(line, span.end_col)
        else:
            caret_end = len(line)
        caret_end = max(caret_start + 1, caret_end)
        rendered.append(f"{line_number:>{number_width}} | {line}")
        rendered.append(
            f"{'':>{number_width}} | "
            f"{' ' * caret_start}{'^' * (caret_end - caret_start)}"
        )
    return "\n".join(rendered)


class FrontendError(CANNBotError):
    """A stable frontend failure with source location and remediation hint."""

    def __init__(
        self,
        code: FrontendErrorCode,
        message: str,
        *,
        span: SourceSpan | None = None,
        hint: str | None = None,
        source: str | None = None,
        source_first_line: int = 1,
    ) -> None:
        self.code = FrontendErrorCode(code)
        self.span = span
        self.message = message
        self.hint = hint
        self.phase = "type-system"
        self.path = (
            f"{span.filename}:{span.start_line}:{span.display_start_col}"
            if span is not None
            else "frontend"
        )
        self.excerpt = format_source_excerpt(
            source, span, source_first_line=source_first_line
        )
        Exception.__init__(self, self._format())

    def _format(self) -> str:
        location = ""
        if self.span is not None:
            location = (
                f"{self.span.filename}:{self.span.start_line}:"
                f"{self.span.display_start_col}: "
            )
        parts = [f"{location}{self.code.value}: {self.message}"]
        if self.excerpt:
            parts.append(self.excerpt)
        if self.hint:
            parts.append(f"hint: {self.hint}")
        return "\n".join(parts)

    def __str__(self) -> str:
        return self._format()


__all__ = [
    "FE001_SOURCE_UNAVAILABLE",
    "FE002_TARGET_NOT_FOUND",
    "FE101_UNSUPPORTED_SYNTAX",
    "FE102_UNSAFE_EARLY_EXIT",
    "FE103_STRUCT_REF_REBIND",
    "FE201_UNBOUND_REGION_STATE",
    "FE202_REGION_VALUE_ESCAPE",
    "FE301_INVALID_RANGE",
    "FE302_RANGE_TYPE_MISMATCH",
    "FE303_NON_POSITIVE_STEP",
    "FE401_STATE_STRUCTURE_MISMATCH",
    "FE402_STATE_TYPE_MISMATCH",
    "FE404_AMBIGUOUS_CARRIER_TYPE",
    "FE501_MATERIALIZATION_FAILED",
    "FrontendError",
    "FrontendErrorCode",
    "format_source_excerpt",
]
