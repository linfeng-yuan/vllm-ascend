# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Typed SCF builders used by hygienically lowered functions."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from enum import Enum, auto
from typing import Callable, Iterator

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import arith, scf
from cannbotdsl.core.ir_transport import unwrap_operand

from cannbotdsl.core.frontend.diagnostics import (
    FE301_INVALID_RANGE,
    FE302_RANGE_TYPE_MISMATCH,
    FE303_NON_POSITIVE_STEP,
    FE404_AMBIGUOUS_CARRIER_TYPE,
)
from cannbotdsl.core.frontend.runtime.hooks import (
    _detach_on_failure,
    RegionInfo,
    region_child_scope,
    region_hook_scope,
)
from cannbotdsl.core.frontend.runtime.value_tree_layout import ValueTreeLayout
from cannbotdsl.core.frontend.runtime.trace_value import is_trace_value
from cannbotdsl.core.scalar_conversion import (
    _common_integer_element,
    _coerce_lossless_integer,
    materialize_literal,
)
from cannbotdsl.types.dtypes import DTypeKind


def to_mlir_value(value: object, *, context: str) -> ir.Value:
    """Return an SSA value or fail with a boundary-specific diagnostic."""

    try:
        value = unwrap_operand(value)
    except TypeError as exc:
        raise TypeError(
            f"{context} must be a framework semantic value or ir.Value, "
            f"got {type(value).__name__}"
        ) from exc
    if isinstance(value, ir.Value):
        return value
    raise TypeError(f"{context} must be an ir.Value, got {type(value).__name__}")


def to_i1(value: object, *, context: str = "predicate") -> ir.Value:
    if not is_trace_value(value):
        i1 = ir.IntegerType.get_signless(1)
        return arith.ConstantOp(i1, int(bool(value))).result
    predicate = to_mlir_value(value, context=context)
    if isinstance(predicate.type, ir.IntegerType):
        if predicate.type.width == 1:
            return predicate
        zero = arith.ConstantOp(predicate.type, 0).result
        return arith.CmpIOp(arith.CmpIPredicate.ne, predicate, zero).result
    if isinstance(predicate.type, (ir.F16Type, ir.F32Type, ir.F64Type, ir.BF16Type)):
        zero = arith.ConstantOp(predicate.type, 0.0).result
        return arith.CmpFOp(arith.CmpFPredicate.ONE, predicate, zero).result
    raise TypeError(f"{context} must lower to an integer or float scalar, got {predicate.type}")


class _RangeBoundKind(Enum):
    LITERAL = auto()
    DSL_INTEGER = auto()
    INDEX = auto()


@dataclass(frozen=True, slots=True)
class _RangeBound:
    original: object
    kind: _RangeBoundKind
    value: ir.Value | None = None
    element: object | None = None


def _region_error(region_info: RegionInfo, code, message: str, hint: str):
    return region_info.error(code, message, hint=hint)


def _classify_range_bound(bound: object, region_info: RegionInfo) -> _RangeBound:
    """Classify a range operand without erasing DSL signedness."""

    if type(bound) is int:
        return _RangeBound(bound, _RangeBoundKind.LITERAL)
    if type(bound) is bool:
        raise _region_error(
            region_info,
            FE302_RANGE_TYPE_MISMATCH,
            "Boolean values are not valid dynamic range bounds.",
            "Use integer literals or non-Boolean DSL integer values.",
        )

    from cannbotdsl.core.contracts.elements import element_for_dsl_type

    try:
        element = element_for_dsl_type(type(bound))
    except TypeError:
        element = None
    if element is not None:
        if element.dtype.kind is not DTypeKind.INTEGER:
            raise _region_error(
                region_info,
                FE302_RANGE_TYPE_MISMATCH,
                f"Dynamic range bounds must be DSL integers, got dtypes.{element.dtype.name}.",
                "Use an integer literal or cast every bound to one common DSL integer dtype.",
            )
        value = to_mlir_value(bound, context="range bound")
        expected = element.scalar_mlir_type()
        if value.type != expected:
            raise _region_error(
                region_info,
                FE302_RANGE_TYPE_MISMATCH,
                f"DSL range bound dtypes.{element.dtype.name} carries {value.type}, expected {expected}.",
                "Pass a value produced by the registered DSL integer wrapper.",
            )
        return _RangeBound(bound, _RangeBoundKind.DSL_INTEGER, value, element)

    try:
        value = to_mlir_value(bound, context="range bound")
    except TypeError as exc:
        raise _region_error(
            region_info,
            FE302_RANGE_TYPE_MISMATCH,
            f"Dynamic range bounds must be integer or index DSL values, got {type(bound).__name__}.",
            "Use an integer literal or cast every bound to a common DSL integer type.",
        ) from exc
    if isinstance(value.type, ir.IndexType):
        return _RangeBound(bound, _RangeBoundKind.INDEX, value)
    if (
        isinstance(value.type, ir.IntegerType)
        and not value.type.is_signed
        and not value.type.is_unsigned
    ):
        raise _region_error(
            region_info,
            FE404_AMBIGUOUS_CARRIER_TYPE,
            f"Bare signless range carrier {value.type} has no recoverable signedness.",
            "Wrap the value in a concrete DSL integer type before using it as a range bound.",
        )
    raise _region_error(
        region_info,
        FE302_RANGE_TYPE_MISMATCH,
        f"Dynamic range bounds must use a registered DSL integer or index carrier, got {value.type}.",
        "Cast every range bound to one common DSL integer type.",
    )


def _constant_integer_value(bound: _RangeBound) -> int | None:
    assert bound.value is not None
    value = bound.value
    owner = getattr(value, "owner", None)
    operation = getattr(owner, "operation", owner)
    if operation is None or str(getattr(operation, "name", "")) != "arith.constant":
        return None
    try:
        raw = int(ir.IntegerAttr(operation.attributes["value"]).value)
    except (KeyError, TypeError, ValueError):
        return None
    if (
        bound.kind is _RangeBoundKind.DSL_INTEGER
        and bound.element.dtype.signed is False
    ):
        return raw % (1 << bound.element.dtype.bits)
    return raw


def _is_trusted_positive_step(value: ir.Value) -> bool:
    owner = getattr(value, "owner", None)
    operation = getattr(owner, "operation", owner)
    return (
        operation is not None
        and str(getattr(operation, "name", "")) == "cannir.get_block_num"
    )


def _validate_unroll(
    unroll: object,
    unroll_full: object,
    region_info: RegionInfo,
) -> None:
    if not isinstance(unroll_full, bool):
        raise _region_error(
            region_info,
            FE301_INVALID_RANGE,
            "cannbotdsl.range() unroll_full must be a compile-time bool.",
            "Pass unroll_full=True or unroll_full=False directly.",
        )
    if unroll is not None:
        if isinstance(unroll, bool) or not isinstance(unroll, int):
            raise _region_error(
                region_info,
                FE301_INVALID_RANGE,
                "cannbotdsl.range() unroll must be a compile-time int or None.",
                "Pass a positive integer literal to unroll=.",
            )
        if unroll <= 0:
            raise _region_error(
                region_info,
                FE301_INVALID_RANGE,
                f"cannbotdsl.range() unroll must be positive, got {unroll}.",
                "Use unroll=1 to explicitly disable multi-iteration unrolling.",
            )
        if unroll_full:
            raise _region_error(
                region_info,
                FE301_INVALID_RANGE,
                "cannbotdsl.range() unroll and unroll_full=True are mutually exclusive.",
                "Choose either a fixed unroll factor or full unrolling.",
            )


def _state_arguments(state: object) -> tuple[object, ...]:
    if type(state) is tuple:
        return state
    return (state,)


def _invoke_state(callback: Callable[..., object], state: object) -> object:
    return callback(*_state_arguments(state))


@contextmanager
def _source_location(region_info: RegionInfo) -> Iterator[None]:
    if not region_info.emit_line_info:
        yield
        return
    with ir.Location.file(
        region_info.span.filename,
        region_info.span.start_line,
        region_info.span.display_start_col,
    ):
        yield


def _wrap_induction_variable(iv: ir.Value, element: object | None) -> object:
    if element is None:
        return iv
    wrapper = element.dsl_type
    assert wrapper is not None
    return wrapper(iv)


def for_region(
    start: object,
    stop: object,
    step: object,
    state: object,
    body_fn: Callable[..., object],
    region_info: RegionInfo,
    *,
    unroll: int | None = None,
    unroll_full: bool = False,
) -> object:
    """Build one ``scf.for`` and return state with its original ValueTree."""

    _validate_unroll(unroll, unroll_full, region_info)
    bounds = (start, stop, step)
    classified = tuple(
        _classify_range_bound(bound, region_info) for bound in bounds
    )
    dynamic = tuple(
        bound
        for bound in classified
        if bound.kind is not _RangeBoundKind.LITERAL
    )
    induction_element = None
    if not dynamic:
        from cannbotdsl.types import dtypes
        from cannbotdsl.core.contracts.elements import element_for_dtype

        induction_element = element_for_dtype(dtypes.int64)
        bound_type = induction_element.scalar_mlir_type()
    elif all(bound.kind is _RangeBoundKind.INDEX for bound in dynamic):
        bound_type = ir.IndexType.get()
    elif all(bound.kind is _RangeBoundKind.DSL_INTEGER for bound in dynamic):
        try:
            induction_element = _common_integer_element(
                (bound.element for bound in dynamic), operation="range"
            )
        except TypeError as exc:
            raise _region_error(
                region_info, FE302_RANGE_TYPE_MISMATCH,
                f"Dynamic range bounds have different canonical dtypes: {exc}.",
                "Use bounds with the same integer signedness or cast explicitly.",
            ) from exc
        bound_type = induction_element.scalar_mlir_type()
    else:
        raise _region_error(
            region_info,
            FE302_RANGE_TYPE_MISMATCH,
            "Dynamic range bounds mix index and DSL integer carriers.",
            "Use index for every dynamic bound, or one common DSL integer dtype for all of them.",
        )

    if type(step) is int and step <= 0:
        raise _region_error(
            region_info,
            FE303_NON_POSITIVE_STEP,
            f"Dynamic DSL range step must be strictly positive, got {step}.",
            "Use a positive step and express reverse traversal explicitly.",
        )
    step_bound = classified[2]
    if (
        step_bound.value is not None
        and not _is_trusted_positive_step(step_bound.value)
    ):
        constant_step = _constant_integer_value(step_bound)
        if constant_step is not None and constant_step <= 0:
            raise _region_error(
                region_info,
                FE303_NON_POSITIVE_STEP,
                f"Dynamic DSL range step must be strictly positive, got constant {constant_step}.",
                "Use a positive step and express reverse traversal explicitly.",
            )

    state_layout, initial_values = ValueTreeLayout.capture_with_values(state, region_info)
    with _source_location(region_info):
        normalized_bounds: list[ir.Value] = []
        semantic_unsigned = (
            induction_element is not None
            and induction_element.dtype.signed is False
        )
        for bound in classified:
            if bound.kind is _RangeBoundKind.LITERAL:
                try:
                    normalized = materialize_literal(
                        bound.original,
                        bound_type,
                        semantic_unsigned=semantic_unsigned,
                    )
                except (TypeError, ValueError) as exc:
                    raise _region_error(
                        region_info,
                        FE302_RANGE_TYPE_MISMATCH,
                        f"Range literal {bound.original!r} is not representable by the selected bound type.",
                        "Use a literal within the selected signed or unsigned dtype range.",
                    ) from exc
                normalized_bounds.append(normalized)
            else:
                assert bound.value is not None
                normalized_bounds.append(
                    _coerce_lossless_integer(bound.original, induction_element, operation="range")
                    if induction_element is not None else bound.value
                )
        lower, upper, stride = normalized_bounds
        operation = scf.ForOp(
            lower,
            upper,
            stride,
            list(initial_values) if initial_values else None,
        )
        if unroll is not None:
            i64 = ir.IntegerType.get_signless(64)
            operation.operation.attributes["cannir.loop_unroll"] = ir.IntegerAttr.get(i64, unroll)
        elif unroll_full:
            operation.operation.attributes["cannir.loop_unroll_full"] = ir.UnitAttr.get()

    with _detach_on_failure(operation):
        with region_hook_scope("for", operation, region_info):
            with region_child_scope("for", "body", operation, region_info):
                with ir.InsertionPoint(operation.body):
                    iv = _wrap_induction_variable(
                        operation.body.arguments[0], induction_element
                    )
                    body_state = state_layout.rebuild(tuple(operation.body.arguments[1:]))
                    result = body_fn(iv, *_state_arguments(body_state))
                    yielded = state_layout.flatten(
                        result,
                        allow_integer_widening=True,
                        context="scf.for body",
                        region_info=region_info,
                    )
                    scf.YieldOp(list(yielded))
        return state_layout.rebuild(tuple(operation.results))


def if_region(
    predicate: object,
    state: object,
    then_fn: Callable[..., object],
    else_fn: Callable[..., object] | None,
    region_info: RegionInfo,
) -> object:
    """Build one ``scf.if`` with fixed state types and lossless integer yields."""

    if not is_trace_value(predicate):
        callback = then_fn if bool(predicate) else else_fn
        if callback is None:
            return state
        return _invoke_state(callback, state)

    state_layout, initial_values = ValueTreeLayout.capture_with_values(state, region_info)
    pred = to_i1(predicate, context="if predicate")
    emit_else = else_fn is not None or bool(initial_values)
    with _source_location(region_info):
        operation = scf.IfOp(pred, list(state_layout.mlir_types), hasElse=emit_else)

    def emit_branch(
        block,
        callback: Callable[..., object] | None,
        child: str,
        context: str,
    ) -> None:
        with region_child_scope("if", child, operation, region_info):
            with ir.InsertionPoint(block):
                branch_state = state_layout.rebuild(initial_values)
                result = (
                    _invoke_state(callback, branch_state)
                    if callback is not None
                    else branch_state
                )
                yielded = state_layout.flatten(
                    result, allow_integer_widening=True,
                    context=context, region_info=region_info,
                )
                scf.YieldOp(list(yielded))

    with _detach_on_failure(operation):
        with region_hook_scope("if", operation, region_info):
            emit_branch(
                operation.then_block, then_fn, "then", "scf.if then branch"
            )
            if emit_else:
                emit_branch(
                    operation.else_block, else_fn, "else", "scf.if else branch"
                )
        return state_layout.rebuild(tuple(operation.results))


def while_region(
    state: object,
    condition_fn: Callable[..., object],
    body_fn: Callable[..., object],
    region_info: RegionInfo,
) -> object:
    """Build ``scf.while`` without evaluating its predicate outside before."""

    state_layout, initial_values = ValueTreeLayout.capture_with_values(state, region_info)
    with _source_location(region_info):
        operation = scf.WhileOp(list(state_layout.mlir_types), list(initial_values))
        operation.before.blocks.append(*state_layout.mlir_types)
        operation.after.blocks.append(*state_layout.mlir_types)

    with _detach_on_failure(operation):
        with region_hook_scope("while", operation, region_info):
            before = operation.before.blocks[0]
            with region_child_scope("while", "before", operation, region_info):
                with ir.InsertionPoint(before):
                    before_values = tuple(before.arguments)
                    before_state = state_layout.rebuild(before_values)
                    predicate = _invoke_state(condition_fn, before_state)
                    condition = to_i1(predicate, context="while predicate")
                    # The condition region forwards state unchanged. No predicate
                    # IR is emitted before this block.
                    scf.ConditionOp(
                        condition,
                        [unwrap_operand(value) for value in before_values],
                    )

            after = operation.after.blocks[0]
            with region_child_scope("while", "after", operation, region_info):
                with ir.InsertionPoint(after):
                    after_state = state_layout.rebuild(tuple(after.arguments))
                    result = _invoke_state(body_fn, after_state)
                    yielded = state_layout.flatten(
                        result,
                        allow_integer_widening=True,
                        context="scf.while body",
                        region_info=region_info,
                    )
                    scf.YieldOp(list(yielded))
        return state_layout.rebuild(tuple(operation.results))


__all__ = [
    "for_region",
    "if_region",
    "to_i1",
    "to_mlir_value",
    "while_region",
]
