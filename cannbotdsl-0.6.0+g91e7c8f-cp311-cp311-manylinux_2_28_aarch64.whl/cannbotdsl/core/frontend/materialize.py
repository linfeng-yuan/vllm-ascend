# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Side-effect-free code extraction and function reconstruction."""

from __future__ import annotations

import ast
from dataclasses import dataclass
import importlib
import types
from types import MappingProxyType
from typing import Any

from cannbotdsl.core.frontend.analysis import FrontendPlan
from cannbotdsl.core.frontend.api import FrontendOptions
from cannbotdsl.core.frontend.lowering import LoweringResult
from cannbotdsl.core.frontend.runtime.hooks import RegionInfo
from cannbotdsl.core.frontend.source import SourceUnit


_RUNTIME_TARGETS = MappingProxyType({
    "for_region": ("control_flow", "for_region"),
    "if_region": ("control_flow", "if_region"),
    "while_region": ("control_flow", "while_region"),
    "boolop": ("expressions", "boolop"),
    "comparison": ("expressions", "comparison"),
    "logical_not": ("expressions", "logical_not"),
    "if_expression": ("expressions", "if_expression"),
    "any_all": ("expressions", "any_all"),
    "minmax": ("expressions", "minmax"),
    "dynamic_getitem": ("expressions", "dynamic_getitem"),
})


@dataclass(frozen=True, slots=True)
class RuntimeBindings:
    """The single synthetic freevar exposed to lowered source."""

    plan: FrontendPlan
    source: str
    source_first_line: int
    emit_line_info: bool

    def region_info(self, region_id: int) -> RegionInfo:
        region = self.plan.regions[region_id]
        if region.id != region_id:
            raise RuntimeError(
                f"Frontend plan region index mismatch for id {region_id}"
            )
        return RegionInfo(
            id=region.id,
            kind=region.kind.value,
            span=region.span,
            source=self.source,
            source_first_line=self.source_first_line,
            emit_line_info=self.emit_line_info,
        )

    def expression_info(self, expression_id: int) -> RegionInfo:
        expression = self.plan.expressions[expression_id]
        if expression.id != expression_id:
            raise RuntimeError(
                "Frontend plan expression index mismatch for id "
                f"{expression_id}"
            )
        return RegionInfo(
            id=expression.id,
            kind=expression.kind,
            span=expression.span,
            source=self.source,
            source_first_line=self.source_first_line,
            emit_line_info=self.emit_line_info,
        )

    def __getattr__(self, name: str):
        try:
            module_name, target_name = _RUNTIME_TARGETS[name]
        except KeyError as exc:
            raise AttributeError(name) from exc
        module = importlib.import_module(
            f"cannbotdsl.core.frontend.runtime.{module_name}"
        )
        return getattr(module, target_name)


def _strip_signature(
    target: ast.FunctionDef | ast.AsyncFunctionDef,
) -> None:
    target.decorator_list = []
    target.returns = None
    target.type_comment = None
    target.args.defaults = []
    target.args.kw_defaults = [None] * len(target.args.kwonlyargs)
    for argument in (
        *target.args.posonlyargs,
        *target.args.args,
        *target.args.kwonlyargs,
    ):
        argument.annotation = None
        argument.type_comment = None
    if target.args.vararg is not None:
        target.args.vararg.annotation = None
        target.args.vararg.type_comment = None
    if target.args.kwarg is not None:
        target.args.kwarg.annotation = None
        target.args.kwarg.type_comment = None
    if hasattr(target, "type_params"):
        target.type_params = []


def _factory_definition(
    target: ast.FunctionDef | ast.AsyncFunctionDef,
    closure_names: tuple[str, ...],
) -> ast.FunctionDef:
    closure_arguments: list[ast.arg] = []
    for name in closure_names:
        argument = ast.arg(arg=name, annotation=None)
        argument.lineno = 1
        argument.col_offset = 0
        argument.end_lineno = 1
        argument.end_col_offset = len(name)
        closure_arguments.append(argument)
    arguments = ast.arguments(
        posonlyargs=[],
        args=closure_arguments,
        vararg=None,
        kwonlyargs=[],
        kw_defaults=[],
        kwarg=None,
        defaults=[],
    )
    kwargs = {
        "name": "__cannbotdsl_frontend_factory",
        "args": arguments,
        "body": [target],
        "decorator_list": [],
        "returns": None,
        "type_comment": None,
    }
    if "type_params" in ast.FunctionDef._fields:
        kwargs["type_params"] = []
    factory = ast.FunctionDef(**kwargs)
    factory.lineno = 1
    factory.col_offset = 0
    factory.end_lineno = max(1, int(getattr(target, "end_lineno", 1)))
    factory.end_col_offset = int(getattr(target, "end_col_offset", 0))
    return factory


def _find_code(
    code: types.CodeType,
    *,
    name: str,
) -> types.CodeType:
    matches = [
        constant
        for constant in code.co_consts
        if isinstance(constant, types.CodeType) and constant.co_name == name
    ]
    if len(matches) != 1:
        raise RuntimeError(
            f"Expected exactly one code object named {name!r}, got {len(matches)}"
        )
    return matches[0]


def _make_cell(value: object):
    def capture():
        return value

    assert capture.__closure__ is not None
    return capture.__closure__[0]


def materialize(
    source: SourceUnit,
    plan: FrontendPlan,
    lowered: LoweringResult,
    options: FrontendOptions,
) -> types.FunctionType:
    """Compile code objects only, then bind original globals/defaults/cells."""

    target = lowered.target
    _strip_signature(target)
    outer_names = (lowered.runtime_name, *source.function.__code__.co_freevars)
    factory = _factory_definition(target, outer_names)
    module = ast.Module(body=[factory], type_ignores=[])
    module_code = compile(module, source.filename, "exec")
    factory_code = _find_code(
        module_code, name="__cannbotdsl_frontend_factory"
    )
    target_code = _find_code(factory_code, name=target.name)

    runtime = RuntimeBindings(
        plan=plan,
        source=source.source,
        source_first_line=source.first_line,
        emit_line_info=options.emit_line_info,
    )
    cells: list[Any] = []
    for freevar in target_code.co_freevars:
        if freevar == lowered.runtime_name:
            cells.append(_make_cell(runtime))
            continue
        try:
            cells.append(source.closure_cells[freevar])
        except KeyError as exc:
            raise RuntimeError(
                f"Lowered function introduced unknown freevar {freevar!r}"
            ) from exc

    original = source.function
    rebuilt = types.FunctionType(
        target_code,
        original.__globals__,
        original.__name__,
        original.__defaults__,
        tuple(cells) if cells else None,
    )
    rebuilt.__kwdefaults__ = original.__kwdefaults__
    rebuilt.__annotations__ = original.__annotations__
    rebuilt.__qualname__ = original.__qualname__
    rebuilt.__module__ = original.__module__
    rebuilt.__doc__ = original.__doc__
    rebuilt.__dict__.update(original.__dict__)
    if hasattr(original, "__type_params__"):
        rebuilt.__type_params__ = original.__type_params__
    return rebuilt
