# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Identity-based marker resolution that never executes user attributes."""

from __future__ import annotations

import ast
import builtins
import importlib.util
import sys
from dataclasses import dataclass
from enum import Enum
import types
from typing import Any

from cannbotdsl.core.frontend.source import SourceUnit


class MarkerKind(str, Enum):
    BUILTIN_RANGE = "builtin_range"
    DSL_RANGE = "dsl_range"
    RANGE_CONSTEXPR = "range_constexpr"
    CONST_EXPR = "const_expr"
    TARGET_VERSION = "target_version"
    ANY = "any"
    ALL = "all"
    MIN = "min"
    MAX = "max"


@dataclass(frozen=True, slots=True)
class Marker:
    kind: MarkerKind
    value: object


@dataclass(frozen=True, slots=True)
class MarkerRegistry:
    """An immutable ordered registry of marker identities."""

    markers: tuple[Marker, ...]

    @classmethod
    def default(cls) -> "MarkerRegistry":
        # Imported lazily: the ``entry`` and ``lang`` package ``__init__``
        # modules import back into ``cannbotdsl.core.frontend``, so a
        # module-level import here would close that cycle at import time.
        from cannbotdsl.lang.constexpr import (
            const_expr,
            range_constexpr,
            target_version,
        )
        from cannbotdsl.lang.control_flow import range as dsl_range

        return cls(
            (
                Marker(MarkerKind.BUILTIN_RANGE, builtins.range),
                Marker(MarkerKind.DSL_RANGE, dsl_range),
                Marker(MarkerKind.RANGE_CONSTEXPR, range_constexpr),
                Marker(MarkerKind.CONST_EXPR, const_expr),
                Marker(MarkerKind.TARGET_VERSION, target_version),
                Marker(MarkerKind.ANY, builtins.any),
                Marker(MarkerKind.ALL, builtins.all),
                Marker(MarkerKind.MIN, builtins.min),
                Marker(MarkerKind.MAX, builtins.max),
            )
        )

    def identify(self, value: object) -> MarkerKind | None:
        for marker in self.markers:
            if value is marker.value:
                return marker.kind
        return None


class _Unresolved:
    __slots__ = ()

    def __repr__(self) -> str:
        return "UNRESOLVED"


UNRESOLVED = _Unresolved()


def _module_dict(module: types.ModuleType) -> dict[str, Any]:
    """Read a module namespace without dispatching subclass attributes."""

    return types.ModuleType.__getattribute__(module, "__dict__")


class SafeSymbolResolver:
    """Resolve root-scope symbols without invoking descriptors or user code."""

    __slots__ = (
        "_source",
        "_registry",
        "_builtins",
        "_local_imports",
        "_name_cache",
        "_resolve_cache",
    )

    def __init__(
        self,
        source: SourceUnit,
        registry: MarkerRegistry | None = None,
    ) -> None:
        self._source = source
        self._registry = registry or MarkerRegistry.default()
        builtins_value = source.globals.get("__builtins__", builtins)
        if isinstance(builtins_value, types.ModuleType):
            self._builtins = _module_dict(builtins_value)
        elif isinstance(builtins_value, dict):
            self._builtins = builtins_value
        else:
            self._builtins = _module_dict(builtins)
        self._local_imports = self._source_local_imports(source)
        self._name_cache: dict[str, object] = {}
        self._resolve_cache: dict[int, object] = {}

    @staticmethod
    def _source_local_imports(source: SourceUnit) -> dict[str, object]:
        """Index unconditional local imports from already-loaded modules.

        This never imports a module or performs attribute lookup.  Imports
        nested in control flow are intentionally excluded because their
        binding depends on reachability.
        """

        result: dict[str, object] = {}
        package = source.globals.get("__package__")
        for statement in source.target.body:
            if isinstance(statement, ast.Import):
                for alias in statement.names:
                    module = sys.modules.get(alias.name)
                    if module is None:
                        continue
                    binding = alias.asname or alias.name.split(".", 1)[0]
                    if alias.asname is None:
                        module = sys.modules.get(binding, module)
                    result[binding] = module
            elif isinstance(statement, ast.ImportFrom):
                spelling = "." * statement.level + (statement.module or "")
                try:
                    module_name = (
                        importlib.util.resolve_name(spelling, package)
                        if statement.level
                        else spelling
                    )
                except (ImportError, ValueError, TypeError):
                    continue
                module = sys.modules.get(module_name)
                if not isinstance(module, types.ModuleType):
                    continue
                namespace = _module_dict(module)
                for alias in statement.names:
                    if alias.name == "*":
                        continue
                    value = namespace.get(alias.name, UNRESOLVED)
                    if value is not UNRESOLVED:
                        result[alias.asname or alias.name] = value
        return result

    def _symbol(self, name: str):
        try:
            return self._source.symbol_table.lookup(name)
        except KeyError:
            return None

    def is_local(self, name: str) -> bool:
        symbol = self._symbol(name)
        if symbol is None:
            return False
        return bool(
            symbol.is_local()
            or symbol.is_parameter()
            or symbol.is_imported()
            or symbol.is_assigned()
        ) and not symbol.is_global() and not symbol.is_free()

    def resolve_name(self, name: str) -> object:
        if name in self._name_cache:
            return self._name_cache[name]
        symbol = self._symbol(name)
        if symbol is not None:
            if symbol.is_free():
                cell = self._source.closure_cells.get(name)
                if cell is None:
                    result = UNRESOLVED
                    self._name_cache[name] = result
                    return result
                try:
                    result = cell.cell_contents
                except ValueError:
                    result = UNRESOLVED
                self._name_cache[name] = result
                return result
            if self.is_local(name):
                if symbol.is_imported() and name in self._local_imports:
                    result = self._local_imports[name]
                    self._name_cache[name] = result
                    return result
                self._name_cache[name] = UNRESOLVED
                return UNRESOLVED

        if name in self._source.globals:
            result = self._source.globals[name]
        elif name in self._builtins:
            result = self._builtins[name]
        else:
            result = UNRESOLVED
        self._name_cache[name] = result
        return result

    def resolve(self, node: ast.AST) -> object:
        key = id(node)
        if key in self._resolve_cache:
            return self._resolve_cache[key]
        if isinstance(node, ast.Name):
            result = self.resolve_name(node.id)
        elif isinstance(node, ast.Attribute):
            base = self.resolve(node.value)
            if isinstance(base, types.ModuleType):
                result = _module_dict(base).get(node.attr, UNRESOLVED)
            else:
                result = UNRESOLVED
        else:
            result = UNRESOLVED
        self._resolve_cache[key] = result
        return result

    resolve_callee = resolve

    def marker_kind(self, node: ast.AST) -> MarkerKind | None:
        value = self.resolve(node)
        if value is UNRESOLVED:
            return None
        return self._registry.identify(value)


__all__ = [
    "Marker",
    "MarkerKind",
    "MarkerRegistry",
    "SafeSymbolResolver",
    "UNRESOLVED",
]
