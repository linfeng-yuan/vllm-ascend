# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Source capture for one frontend compilation."""

from __future__ import annotations

import ast
from collections.abc import Callable, Mapping
from dataclasses import dataclass
import hashlib
import inspect
import symtable
import textwrap
from types import MappingProxyType
from typing import Any

from cannbotdsl.core.frontend.api import SourceSpan
from cannbotdsl.core.frontend.diagnostics import (
    FE001_SOURCE_UNAVAILABLE,
    FE002_TARGET_NOT_FOUND,
    FrontendError,
)


def _definition_first_line(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
) -> int:
    if not node.decorator_list:
        return node.lineno
    return min(node.lineno, *(decorator.lineno for decorator in node.decorator_list))


def _find_target(
    module: ast.Module,
    fn: Callable[..., object],
    *,
    first_line: int,
) -> ast.FunctionDef | ast.AsyncFunctionDef | None:
    target_name = fn.__code__.co_name
    top_level = [
        node
        for node in module.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == target_name
    ]
    if len(top_level) == 1:
        return top_level[0]

    expected_line = fn.__code__.co_firstlineno
    candidates = [
        node
        for node in ast.walk(module)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == target_name
    ]
    if not candidates:
        return None

    def score(node: ast.FunctionDef | ast.AsyncFunctionDef) -> tuple[int, int, int]:
        definition_line = node.lineno + first_line - 1
        decorated_line = _definition_first_line(node) + first_line - 1
        contains_expected = int(
            not (decorated_line <= expected_line <= definition_line)
        )
        return (
            contains_expected,
            abs(definition_line - expected_line),
            definition_line,
        )

    return min(candidates, key=score)


def _find_symbol_table(
    root: symtable.SymbolTable,
    target_name: str,
    target_line: int,
    *,
    line_offset: int = 0,
) -> symtable.SymbolTable:
    descendants: list[symtable.SymbolTable] = []
    pending = list(root.get_children())
    while pending:
        child = pending.pop()
        descendants.append(child)
        pending.extend(child.get_children())
    candidates = [
        child
        for child in descendants
        if child.get_type() == "function" and child.get_name() == target_name
    ]
    if not candidates:
        return root
    expected_line = target_line + line_offset
    return min(
        candidates,
        key=lambda child: abs(child.get_lineno() - expected_line),
    )


def _build_symbol_table(
    source: str,
    filename: str,
    target_name: str,
    target_line: int,
    freevars: tuple[str, ...],
) -> symtable.SymbolTable:
    """Build the target table, restoring an inspect-elided outer scope."""

    if not freevars:
        root = symtable.symtable(source, filename, "exec")
        return _find_symbol_table(root, target_name, target_line)

    prefix = ["def __cannbotdsl_symbol_scope():"]
    prefix.extend(f"    {name} = None" for name in freevars)
    line_offset = len(prefix)
    wrapped_source = (
        "\n".join(prefix) + "\n" + textwrap.indent(source, "    ")
    )
    root = symtable.symtable(wrapped_source, filename, "exec")
    return _find_symbol_table(
        root,
        target_name,
        target_line,
        line_offset=line_offset,
    )


@dataclass(frozen=True, slots=True)
class SourceUnit:
    """Normalized source and immutable lookup inputs for a Python function."""

    function: Callable[..., object]
    source: str
    source_lines: tuple[bytes, ...]
    filename: str
    first_line: int
    module: ast.Module
    target: ast.FunctionDef | ast.AsyncFunctionDef
    globals: dict[str, Any]
    closure_cells: Mapping[str, Any]
    symbol_table: symtable.SymbolTable
    source_digest: str

    @classmethod
    def capture(cls, fn: Callable[..., object]) -> "SourceUnit":
        code = getattr(fn, "__code__", None)
        filename = getattr(code, "co_filename", "<unknown>")
        try:
            filename = inspect.getsourcefile(fn) or inspect.getfile(fn) or filename
            lines, first_line = inspect.getsourcelines(fn)
        except (OSError, IOError, TypeError) as exc:
            span = SourceSpan(
                filename=filename,
                start_line=getattr(code, "co_firstlineno", 1),
                start_col=0,
                end_line=getattr(code, "co_firstlineno", 1),
                end_col=1,
            )
            raise FrontendError(
                FE001_SOURCE_UNAVAILABLE,
                f"Source is unavailable for function {getattr(fn, '__qualname__', fn)!r}.",
                span=span,
                hint="Define the function in a saved Python source file before compiling it.",
            ) from exc

        source = textwrap.dedent("".join(lines))
        try:
            parse_source = "\n" * (first_line - 1) + source
            local_module = ast.parse(
                parse_source,
                filename=filename,
                type_comments=True,
            )
        except SyntaxError as exc:
            span = SourceSpan(
                filename=filename,
                start_line=exc.lineno or first_line,
                start_col=max(0, (exc.offset or 1) - 1),
                end_line=exc.end_lineno or exc.lineno or first_line,
                end_col=max(1, (exc.end_offset or exc.offset or 1) - 1),
            )
            raise FrontendError(
                FE002_TARGET_NOT_FOUND,
                f"Captured source for {fn.__qualname__!r} cannot be parsed.",
                span=span,
                hint="Check that the decorated definition is complete and syntactically valid.",
                source=source,
                source_first_line=first_line,
            ) from exc

        target = _find_target(local_module, fn, first_line=1)
        if target is None:
            span = SourceSpan(
                filename=filename,
                start_line=first_line,
                start_col=0,
                end_line=first_line,
                end_col=1,
            )
            raise FrontendError(
                FE002_TARGET_NOT_FOUND,
                f"Could not find the exact definition of {fn.__qualname__!r} in captured source.",
                span=span,
                hint="Avoid dynamically replacing a function's code object before compilation.",
                source=source,
                source_first_line=first_line,
            )

        freevars = fn.__code__.co_freevars
        function_symbols = _build_symbol_table(
            source,
            filename,
            target.name,
            target.lineno - first_line + 1,
            freevars,
        )

        closure = fn.__closure__ or ()
        closure_cells = MappingProxyType(
            dict(zip(freevars, closure, strict=True))
        )
        digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
        return cls(
            function=fn,
            source=source,
            source_lines=tuple(
                line.encode("utf-8")
                for line in source.splitlines(keepends=True)
            ),
            filename=filename,
            first_line=first_line,
            module=local_module,
            target=target,
            globals=fn.__globals__,
            closure_cells=closure_cells,
            symbol_table=function_symbols,
            source_digest=digest,
        )

    def text(self, node: ast.AST) -> str:
        """Return the exact normalized source for a captured AST node."""

        start_line = getattr(node, "lineno", None)
        end_line = getattr(node, "end_lineno", None)
        start_col = getattr(node, "col_offset", None)
        end_col = getattr(node, "end_col_offset", None)
        if None in (start_line, end_line, start_col, end_col):
            return ast.unparse(node)

        start_index = int(start_line) - self.first_line
        end_index = int(end_line) - self.first_line
        if not (
            0 <= start_index <= end_index < len(self.source_lines)
        ):
            return ast.unparse(node)
        if start_index == end_index:
            data = self.source_lines[start_index][
                int(start_col) : int(end_col)
            ]
        else:
            parts = [self.source_lines[start_index][int(start_col) :]]
            parts.extend(self.source_lines[start_index + 1 : end_index])
            parts.append(self.source_lines[end_index][: int(end_col)])
            data = b"".join(parts)
        return data.decode("utf-8")

    def span(self, node: ast.AST) -> SourceSpan:
        return SourceSpan.from_node(node, self.filename)

    def fresh_target(self) -> ast.FunctionDef | ast.AsyncFunctionDef:
        """Parse a fresh target tree with the captured absolute locations."""

        module = ast.parse(
            "\n" * (self.first_line - 1) + self.source,
            filename=self.filename,
            type_comments=True,
        )
        target = _find_target(
            module,
            self.function,
            first_line=1,
        )
        if target is None:
            raise RuntimeError(
                f"Fresh parse lost target function {self.target.name!r}"
            )
        return target

    def error(
        self,
        code,
        message: str,
        *,
        node: ast.AST | None = None,
        hint: str | None = None,
    ) -> FrontendError:
        return FrontendError(
            code,
            message,
            span=self.span(node or self.target),
            hint=hint,
            source=self.source,
            source_first_line=self.first_line,
        )


__all__ = ["SourceUnit"]
