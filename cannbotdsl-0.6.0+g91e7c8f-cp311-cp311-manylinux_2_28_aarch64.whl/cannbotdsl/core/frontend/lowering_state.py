# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Trace-time lowering state shared by JIT, AOT and @kernel paths.

Owns the per-frame ``JitLoweringState`` dataclass and the ``ContextVar``
that exposes the currently-active state to nested helpers (debug-print,
kernel materialise, etc.).
"""

from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

import cannbotdsl._mlir.ir as ir

from cannbotdsl.core.frontend.debug_print import DebugPrintPlan


@dataclass
class JitLoweringState:
    module: ir.Module
    host_func: Optional[Any] = None
    # Content digest -> compiler-private materialized-function record.  The
    # record type lives in kernel_materialize to keep this state module free of
    # compiler-layer import cycles.
    kernel_registry: Dict[str, Any] = field(default_factory=dict)
    kernel_counter: int = 0
    debug_prints: Dict[str, DebugPrintPlan] = field(default_factory=dict)
    # Monotonic counter used by :mod:`cannbotdsl.lang.vf` to tag ops emitted
    # inside a ``with cannbotdsl.lang.vf(...)`` block with a unique
    # ``cannir.vf_group`` id. Per-state (not module-level) so each
    # trace gets its own counter automatically — previously this was
    # a module-level ``[0]`` list whose state leaked across compiles
    # and broke IR-hash determinism.
    vf_group_counter: int = 0


_CURRENT_LOWERING_STATE: ContextVar[Optional[JitLoweringState]] = ContextVar(
    "cannbotdsl_current_lowering_state", default=None
)


def _current_lowering_state() -> Optional[JitLoweringState]:
    return _CURRENT_LOWERING_STATE.get()
