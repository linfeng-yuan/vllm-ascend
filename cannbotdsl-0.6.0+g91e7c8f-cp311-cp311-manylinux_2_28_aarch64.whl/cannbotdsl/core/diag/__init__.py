# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""cannbotdsl.core.diag -- diagnostic codes, error types and debug printing."""

from cannbotdsl.core.diag.debug import (
    cannir,
    DebugPrintRecord,
    MemLoc,
    Tensor,
    clear_debug_prints,
    get_debug_prints,
    print_tensor,
    print_scalar,
)
from cannbotdsl.core.diag.diagnostics import (
    DiagnosticCode,
    TS101_INVALID_SCALAR_LITERAL,
    CT101_INVALID_RUNTIME_DEFAULT,
    ST101_UNSUPPORTED_DYNAMIC_ARGUMENT,
    ST102_NON_VOID_ENTRY_RETURN,
    KM101_INVALID_BLOCK_DIM,
    ABI101_RUNTIME_ARGUMENT_REJECTED,
    IN001_COMPILER_INVARIANT,
    CANNBotError,
    CANNBotTypeError,
    CANNBotValueError,
    CANNBotRuntimeError,
    CANNBotInternalError,
)

__all__ = [
    "ABI101_RUNTIME_ARGUMENT_REJECTED",
    "CANNBotError",
    "CANNBotInternalError",
    "CANNBotRuntimeError",
    "CANNBotTypeError",
    "CANNBotValueError",
    "CT101_INVALID_RUNTIME_DEFAULT",
    "DebugPrintRecord",
    "DiagnosticCode",
    "IN001_COMPILER_INVARIANT",
    "KM101_INVALID_BLOCK_DIM",
    "MemLoc",
    "ST101_UNSUPPORTED_DYNAMIC_ARGUMENT",
    "ST102_NON_VOID_ENTRY_RETURN",
    "TS101_INVALID_SCALAR_LITERAL",
    "Tensor",
    "cannir",
    "clear_debug_prints",
    "get_debug_prints",
    "print_scalar",
    "print_tensor",
]
