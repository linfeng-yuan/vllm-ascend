# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Public, stable diagnostics shared by every CANNBotDSL boundary.

The classes in this module intentionally have no MLIR dependency.  A caller
may therefore classify a bad value before creating compiler state and can
reliably catch either the CANNBotDSL category or the corresponding Python
``TypeError``/``ValueError``/``RuntimeError`` category.
"""

from __future__ import annotations

from enum import Enum


class DiagnosticCode(str, Enum):
    TS101_INVALID_SCALAR_LITERAL = "TS101_INVALID_SCALAR_LITERAL"
    CT101_INVALID_RUNTIME_DEFAULT = "CT101_INVALID_RUNTIME_DEFAULT"
    ST101_UNSUPPORTED_DYNAMIC_ARGUMENT = "ST101_UNSUPPORTED_DYNAMIC_ARGUMENT"
    ST102_NON_VOID_ENTRY_RETURN = "ST102_NON_VOID_ENTRY_RETURN"
    KM101_INVALID_BLOCK_DIM = "KM101_INVALID_BLOCK_DIM"
    ABI101_RUNTIME_ARGUMENT_REJECTED = "ABI101_RUNTIME_ARGUMENT_REJECTED"
    IN001_COMPILER_INVARIANT = "IN001_COMPILER_INVARIANT"


TS101_INVALID_SCALAR_LITERAL = DiagnosticCode.TS101_INVALID_SCALAR_LITERAL
CT101_INVALID_RUNTIME_DEFAULT = DiagnosticCode.CT101_INVALID_RUNTIME_DEFAULT
ST101_UNSUPPORTED_DYNAMIC_ARGUMENT = DiagnosticCode.ST101_UNSUPPORTED_DYNAMIC_ARGUMENT
ST102_NON_VOID_ENTRY_RETURN = DiagnosticCode.ST102_NON_VOID_ENTRY_RETURN
KM101_INVALID_BLOCK_DIM = DiagnosticCode.KM101_INVALID_BLOCK_DIM
ABI101_RUNTIME_ARGUMENT_REJECTED = DiagnosticCode.ABI101_RUNTIME_ARGUMENT_REJECTED
IN001_COMPILER_INVARIANT = DiagnosticCode.IN001_COMPILER_INVARIANT


class CANNBotError(Exception):
    """Base class for a classified CANNBotDSL failure."""

    def __init__(
        self,
        code: DiagnosticCode,
        message: str,
        *,
        phase: str,
        path: str,
        hint: str,
    ) -> None:
        self.code = DiagnosticCode(code)
        self.phase = str(phase)
        self.path = str(path)
        self.message = str(message)
        self.hint = str(hint)
        if not self.phase:
            raise ValueError("diagnostic phase must be non-empty")
        if not self.path:
            raise ValueError("diagnostic path must be non-empty")
        if not self.hint:
            raise ValueError("diagnostic hint must be non-empty")
        super().__init__(self._format())

    def _format(self) -> str:
        return (
            f"{self.code.value}: {self.message}\n"
            f"phase: {self.phase}\n"
            f"path: {self.path}\n"
            f"hint: {self.hint}"
        )

    def __str__(self) -> str:
        return self._format()


class CANNBotTypeError(CANNBotError, TypeError):
    """A classified type mismatch."""


class CANNBotValueError(CANNBotError, ValueError):
    """A classified value-domain failure."""


class CANNBotRuntimeError(CANNBotError, RuntimeError):
    """A classified runtime/compiler-boundary failure."""


class CANNBotInternalError(CANNBotRuntimeError):
    """An invariant violation that indicates a compiler defect."""


__all__ = [
    "ABI101_RUNTIME_ARGUMENT_REJECTED",
    "CANNBotError",
    "CANNBotInternalError",
    "CANNBotRuntimeError",
    "CANNBotTypeError",
    "CANNBotValueError",
    "CT101_INVALID_RUNTIME_DEFAULT",
    "DiagnosticCode",
    "IN001_COMPILER_INVARIANT",
    "KM101_INVALID_BLOCK_DIM",
    "ST101_UNSUPPORTED_DYNAMIC_ARGUMENT",
    "ST102_NON_VOID_ENTRY_RETURN",
    "TS101_INVALID_SCALAR_LITERAL",
]
