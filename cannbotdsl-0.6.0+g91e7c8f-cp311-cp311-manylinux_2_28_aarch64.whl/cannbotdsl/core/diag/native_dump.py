# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Thin bindings to CANN native tensor and vector-register diagnostics."""

import math

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import ascvec, cannir
from cannbotdsl.core.diag import debug as _debug
from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.tensor import MemLoc
from cannbotdsl.tensor import Tensor


def _native_dump_uint32(value, name, *, positive=False, dynamic=False):
    """Validate constants before emission and accept integer SSA parameters."""
    raw = value if isinstance(value, ir.Value) else getattr(value, "value", value)
    if dynamic and isinstance(raw, ir.Value):
        if isinstance(raw.type, ir.IndexType) or (
            isinstance(raw.type, ir.IntegerType) and raw.type.width > 1
        ):
            return raw
        raise TypeError(f"{name} must be an integer SSA value")
    minimum = 1 if positive else 0
    if type(value) is not int or not minimum <= value < 2**32:
        qualifier = "positive " if positive else ""
        raise ValueError(f"{name} must be a {qualifier}uint32 integer")
    return value


def _native_dump_type(source_dtype, dtype):
    """Resolve CANN's printed type; bool occupies one byte in native memory."""
    from cannbotdsl.core.contracts.elements import (
        dtype_for_storage_mlir_type, storage_mlir_type_for_dtype,
    )

    result = source_dtype if dtype is None else storage_mlir_type_for_dtype(dtype)
    if isinstance(result, ir.F64Type):
        raise TypeError("native dump does not support float64")
    bits = dtype_for_storage_mlir_type(result).bits
    if isinstance(result, ir.IntegerType) and result.width == 1:
        bits = 8
    if bits < 8 or bits % 8:
        raise TypeError("native dump requires a whole-byte element dtype")
    return result, bits


def dump_tensor(
    tensor, *, desc=None, dump_size=None, offset=0, shape=None, dtype=None,
):
    """Dump a contiguous physical span to the native CANN diagnostic stream.

    Accepts a Tensor or an automatically managed Channel in GM, UB, L1,
    L0C, BIAS or FIXBUF. ``dump_size`` and ``offset`` use element units.
    The default size is the static physical extent, capped at 1 KiB; an explicit
    size may be larger. Runtime view offsets are preserved. The caller must
    guarantee bounds for dynamic views, offsets and sizes. ``desc`` and
    ``dump_size`` accept integer SSA values. ``dtype`` may reinterpret elements
    of the same byte width, including byte storage as CANN bool.

    ``shape`` optionally supplies up to eight dimensions of display metadata,
    independently of the printed element count. Inside a raw VF only
    UB is supported, without shape metadata. Native records do not appear in
    ``get_debug_prints()``. FIXBUF can be inspected through an explicit typed
    ``make_pointer``/``make_tensor`` view of an existing allocation.

    Scalar UB/L1 addresses require 32-byte alignment. L0C addresses require
    1024-byte alignment; CANN may read a complete tile for a partial dump.
    Each raw VF record must fit its payload and 72-byte header in the 2024-byte native FIFO. Cumulative
    output and repeated calls are handled by CANN, including in dynamic loops.
    Output is asynchronous, as with CANN; synchronize before collecting it.
    """
    from cannbotdsl.channel import Channel
    from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type
    from cannbotdsl.core.scalar_conversion import coerce_scalar_value
    from cannbotdsl.ops.reg._common import _tag_raw_op
    from cannbotdsl.lang.vf import _CURRENT_VF, _current_vf_mode

    if not isinstance(tensor, (Tensor, Channel)):
        raise TypeError("dump_tensor expects a Tensor or Channel")
    carrier = unwrap_operand(tensor)
    tensor_type = (
        cannir.ChannelType(carrier.type).element
        if cannir.ChannelType.isinstance(carrier.type)
        else carrier.type
    )
    tensor_type = cannir.TensorType(tensor_type)
    memloc = MemLoc(tensor_type.pointer.memloc)
    supported = (
        MemLoc.GM, MemLoc.UB, MemLoc.L1, MemLoc.L0C, MemLoc.BIAS, MemLoc.FBUF,
    )
    if memloc not in supported:
        raise NotImplementedError(
            f"dump_tensor does not support memory location {memloc.name}"
        )
    source_dtype = tensor_type.pointer.dtype
    source_bits = dtype_for_storage_mlir_type(source_dtype).bits
    if isinstance(source_dtype, ir.IntegerType) and source_dtype.width == 1:
        source_bits = 8
    dump_dtype, bits = _native_dump_type(source_dtype, dtype)
    if source_bits != bits:
        raise TypeError("dump_tensor dtype must preserve element byte width")
    physical_shape = _debug._type_shape_tuple(tensor_type.physical_layout)
    extent = (
        math.prod(physical_shape)
        if physical_shape and all(dim > 0 for dim in physical_shape)
        else None
    )
    if type(offset) is int and offset < 0:
        raise ValueError("dump_tensor offset must be non-negative")
    offset_value = (
        offset if isinstance(offset, ir.Value) else getattr(offset, "value", offset)
    )
    if type(offset_value) is not int:
        valid_ssa = isinstance(offset_value, ir.Value) and (
            isinstance(offset_value.type, ir.IndexType)
            or (isinstance(offset_value.type, ir.IntegerType)
                and offset_value.type.width > 1)
        )
        if not valid_ssa:
            raise TypeError(
                "dump_tensor offset must be an integer or integer SSA value"
            )
    if dump_size is None:
        if extent is None or type(offset) is not int:
            raise ValueError("dynamic views or offsets require dump_size")
        dump_size = min(extent - offset, 1024 // (bits // 8))
    count = _native_dump_uint32(
        dump_size, "dump_size", dynamic=True,
    )
    static_count = type(count) is int
    if static_count and count * (bits // 8) >= 2**32:
        raise ValueError("dump_tensor byte count must fit in uint32")
    if (static_count and extent is not None and type(offset) is int
            and offset + count > extent):
        raise ValueError("dump_tensor span exceeds the tensor's physical extent")
    display_shape = () if shape is None else shape
    if not isinstance(display_shape, (tuple, list)) or len(display_shape) > 8:
        raise ValueError("dump_tensor shape must contain at most eight dimensions")
    for dim in display_shape:
        _native_dump_uint32(dim, "shape dimension", positive=True)
    vf_mode = _current_vf_mode()
    if _CURRENT_VF.get() is not None and (
        vf_mode != "raw" or memloc != MemLoc.UB or display_shape
    ):
        raise ValueError("VF dump_tensor requires raw mode, UB, and no shape")
    # CANN 9.2 reserves 2024 bytes after the VF FIFO header. A tensor TLV
    # consumes 72 bytes, leaving 1952 bytes of aligned payload per record.
    if vf_mode == "raw" and static_count and count * (bits // 8) > 1952:
        raise ValueError("raw VF dump_tensor payload must not exceed 1952 bytes")
    plan = _debug._find_current_plan("dump_tensor")
    desc = plan.native_dump_count if desc is None else desc
    desc = _native_dump_uint32(desc, "desc", dynamic=True)
    integer_type = ir.IntegerType.get_signless(64)
    op = cannir.DumpTensorOp(
        carrier, coerce_scalar_value(offset, ir.IndexType.get()),
        coerce_scalar_value(desc, integer_type),
        coerce_scalar_value(count, integer_type),
        ir.DenseI64ArrayAttr.get(display_shape), ir.TypeAttr.get(dump_dtype),
    )
    _tag_raw_op(op)
    plan.native_dump_count += 1


def dump_reg(register, *, desc=None, dump_size=None, dtype=None):
    """Dump raw vector-register lanes to CANN inside ``vf(mode='raw')``.

    ``dump_size`` defaults to all lanes in one 256-byte register. It must not
    exceed that register's capacity. The source register is preserved.
    ``dtype`` selects CANN's template element type independently of the carrier
    register, for example bool over an int8 register. Integer SSA values are
    accepted for ``desc`` and ``dump_size``; dynamic sizes must fit the register.
    """
    from cannbotdsl.core.scalar_conversion import coerce_scalar_value
    from cannbotdsl.ops.reg import RawVReg
    from cannbotdsl.ops.reg._common import _tag_raw_op
    from cannbotdsl.lang.vf import _require_raw_mode

    _require_raw_mode("dump_reg")
    if not isinstance(register, RawVReg):
        raise TypeError("dump_reg expects a RawVReg")
    dump_dtype, bits = _native_dump_type(register.dtype, dtype)
    capacity = 2048 // bits
    count = capacity if dump_size is None else dump_size
    count = _native_dump_uint32(count, "dump_size", dynamic=True)
    if type(count) is int and count > capacity:
        raise ValueError("dump_reg size exceeds one vector register")
    plan = _debug._find_current_plan("dump_reg")
    desc = plan.native_dump_count if desc is None else desc
    desc = _native_dump_uint32(desc, "desc", dynamic=True)
    integer_type = ir.IntegerType.get_signless(64)
    op = ascvec.DumpRegOp(
        register, coerce_scalar_value(desc, integer_type),
        coerce_scalar_value(count, integer_type), ir.TypeAttr.get(dump_dtype),
    )
    _tag_raw_op(op)
    plan.native_dump_count += 1
