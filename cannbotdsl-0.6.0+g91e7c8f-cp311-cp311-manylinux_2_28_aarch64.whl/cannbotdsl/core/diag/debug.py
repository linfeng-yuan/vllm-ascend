# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Debug dump frontend APIs."""

import inspect
from typing import Any, Optional, Tuple

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.core.frontend.debug_print import DebugPrintRecord
from cannbotdsl.core.frontend.lowering_state import _current_lowering_state
from cannbotdsl.tensor import MemLoc
from cannbotdsl.tensor import Tensor


_LAST_PRINTS: list[dict[str, Any]] = []


def clear_debug_prints() -> None:
    """Clear host-captured debug print records from the last execution."""
    _LAST_PRINTS.clear()


def get_debug_prints() -> list[dict[str, Any]]:
    """Return host-captured debug print records from the last execution."""
    return list(_LAST_PRINTS)


def _set_debug_prints(records: list[dict[str, Any]]) -> None:
    _LAST_PRINTS[:] = records


def _static_shape_tuple(tensor: Any) -> Tuple[int, ...]:
    try:
        shape = tensor.shape()
    except TypeError:
        shape = tensor.shape
    if isinstance(shape, int):
        return (int(shape),)
    result = []
    for dim in shape:
        if isinstance(dim, int):
            result.append(dim)
        else:
            result.append(-1)
    return tuple(result)


def _type_shape_tuple(layout: Any) -> Tuple[int, ...]:
    try:
        shape = layout.shape
    except Exception:
        return ()
    result = []
    for dim in shape:
        try:
            result.append(int(dim))
        except Exception:
            result.append(-1)
    return tuple(result)


def _layout_kind_name(memref_ty: Any) -> str:
    try:
        from cannbotdsl.tensor import LayoutMapKind

        return LayoutMapKind(memref_ty.layout_map_kind).name.lower()
    except Exception:
        return "identity"


def _physical_format_name(layout_kind: str) -> str:
    if layout_kind == "nd2nz":
        return "nz"
    if layout_kind == "dn2nz":
        return "zn"
    return "nd"


def _source_location() -> str:
    frame = inspect.currentframe()
    caller = frame.f_back.f_back if frame and frame.f_back else None
    if caller is None:
        return "<unknown>"
    info = inspect.getframeinfo(caller)
    return f"{info.filename}:{info.lineno}"


def _find_current_plan(api_name: str):
    state = _current_lowering_state()
    if state is None:
        raise RuntimeError(f"{api_name} must be called while lowering a @kernel")
    active = [plan for plan in state.debug_prints.values() if plan.payload_arg is None]
    if not active:
        raise RuntimeError(f"{api_name} must be called from inside a @kernel body")
    return active[-1]


def _view_offset_in_bytes(tensor: Tensor) -> Optional[int]:
    """Static local_slice byte offset, or None when it is not statically known.

    A ``local_slice`` may carry a runtime offset operand instead of the static
    ``offset_bytes`` attribute. Its value is not knowable here, and reporting
    only the static part would silently under-report the offset -- which the
    caller turns into a trimmed print range. Return None so the caller can
    fall back to the conservative full range instead.
    """
    offset = 0
    cur = unwrap_operand(tensor)
    while isinstance(cur, ir.Value):
        owner = getattr(cur, "owner", None)
        if getattr(getattr(owner, "operation", None), "name", None) not in {
            "cannir.local_slice", "cannir.reinterpret_view", "cannir.storage_cast",
        }:
            break
        operation = getattr(owner, "operation", None)
        # operands: (buf, tile, [offset], [user_stride])
        if len(owner.operands) > 2:
            return None
        try:
            offset += int(str(operation.attributes["offset_bytes"]).split()[0])
            cur = owner.operands[0]
        except Exception:
            break
    return offset


def _is_supported_scalar_type(typ: ir.Type) -> bool:
    if ir.IntegerType.isinstance(typ):
        return ir.IntegerType(typ).width in (1, 8, 16, 32, 64)
    return (
        ir.F16Type.isinstance(typ)
        or ir.BF16Type.isinstance(typ)
        or ir.F32Type.isinstance(typ)
    )


def _scalar_dtype_name(typ: ir.Type) -> str:
    if ir.IntegerType.isinstance(typ):
        return f"i{ir.IntegerType(typ).width}"
    return str(typ)


def _scalar_memref_source(value: ir.Value) -> ir.Value | None:
    owner = getattr(value, "owner", None)
    # Pybind may expose an OpResult owner either as an Operation directly or
    # through an OpView.  Normalize both forms before inspecting the load.
    operation = getattr(owner, "operation", owner)
    if getattr(operation, "name", None) != "cannir.memref_load":
        return None
    try:
        # MemRef operands are value-cast back to the public Tensor facade by
        # MLIR's Python binding, so cross the private boundary explicitly.
        source = unwrap_operand(operation.operands[0])
    except Exception:
        return None
    if isinstance(source, ir.Value) and cannir.TensorType.isinstance(source.type):
        return source
    return None


def _scalar_source_memloc(value: ir.Value) -> tuple[str, ir.Value]:
    source = _scalar_memref_source(value)
    if source is None:
        return "LOCAL", value
    memref_ty = cannir.TensorType(source.type)
    return MemLoc(memref_ty.pointer.memloc).name, source


def print_tensor(tensor: Any, *, label: str | None = None, max_bytes: int = 1024,
                 mode: str = "ring") -> None:
    """Emit a device-side debug print for an on-chip tensor.

    The debug payload and counter buffers are hidden kernel arguments managed by
    the JIT. ``mode="ring"`` keeps the last 64 records; ``mode="stop"`` keeps
    the first 64 records and continues counting hits.
    """
    if max_bytes != 1024:
        raise ValueError("print_tensor requires max_bytes=1024")
    if mode not in ("ring", "stop"):
        raise ValueError('print_tensor only supports mode="ring" or mode="stop"')
    if not isinstance(tensor, Tensor):
        raise TypeError("print_tensor expects a CANNIR tensor")

    carrier = unwrap_operand(tensor)
    memref_ty = cannir.TensorType(carrier.type)
    memloc = MemLoc(memref_ty.pointer.memloc)
    plan = _find_current_plan("print_tensor")
    printer_id = len(plan.records)
    source = _source_location()
    shape = _static_shape_tuple(tensor)
    physical_shape = _type_shape_tuple(memref_ty.physical_layout)
    layout_kind = _layout_kind_name(memref_ty)
    physical_format = _physical_format_name(layout_kind)
    dtype = str(memref_ty.pointer.dtype)
    storage_shape = physical_shape or shape
    storage_bytes = 0
    try:
        from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type

        elem_bits = dtype_for_storage_mlir_type(memref_ty.pointer.dtype).bits
    except TypeError:
        elem_bits = 0
    if elem_bits > 0 and all(dim >= 0 for dim in storage_shape):
        numel = 1
        for dim in storage_shape:
            numel *= dim
        storage_bytes = numel * (elem_bits // 8)

    if memloc not in (MemLoc.UB, MemLoc.L1, MemLoc.L0C):
        raise NotImplementedError("print_tensor only supports UB, L1, and L0C tensors")

    raw_offset = _view_offset_in_bytes(tensor)
    # An unknown (runtime) offset cannot be turned into a byte-aligned view
    # offset. Fall back to 0, which yields the conservative full print range
    # rather than a silently trimmed one.
    view_offset = raw_offset % 32 if (memloc == MemLoc.UB and raw_offset is not None) else 0
    if storage_bytes:
        physical_copy_bytes = max(32, min(max_bytes, ((view_offset + storage_bytes + 31) // 32) * 32))
        visible_payload_bytes = max(0, min(storage_bytes, physical_copy_bytes - view_offset))
    else:
        physical_copy_bytes = max_bytes
        visible_payload_bytes = max_bytes
    placeholder = carrier
    op = cannir.debug_print(
        carrier,
        placeholder,
        placeholder,
        printer_id=printer_id,
        max_bytes=max_bytes,
        mode=mode,
    )
    record = DebugPrintRecord(
        printer_id=printer_id,
        label=label or f"printer_{printer_id}",
        source_location=source,
        dtype=dtype,
        shape=shape,
        memloc=memloc.name,
        max_bytes=max_bytes,
        mode=mode,
        op=op,
        view_offset_in_bytes=view_offset,
        physical_copy_bytes=physical_copy_bytes,
        visible_payload_bytes=visible_payload_bytes,
        physical_shape=physical_shape,
        layout_kind=layout_kind,
        physical_format=physical_format,
    )
    plan.records.append(record)


def print_scalar(value: Any, *, label: str | None = None, mode: str = "ring") -> None:
    """Emit a device-side debug print for one scalar SSA value.

    Tensor-backed scalar values should be loaded first, e.g.
    ``print_scalar(tensor[(0, 0)])``.
    """
    if mode not in ("ring", "stop"):
        raise ValueError('print_scalar only supports mode="ring" or mode="stop"')
    if not isinstance(value, ir.Value):
        raise TypeError("print_scalar expects a CANNIR scalar value")
    if cannir.TensorType.isinstance(value.type):
        raise TypeError("print_scalar expects a scalar value, not a CANNIR tensor")
    if not _is_supported_scalar_type(value.type):
        raise TypeError(f"print_scalar only supports numeric scalar values, got {value.type}")

    plan = _find_current_plan("print_scalar")
    printer_id = len(plan.records)
    source = _source_location()
    dtype = _scalar_dtype_name(value.type)
    memloc, source_operand = _scalar_source_memloc(value)
    if memloc not in ("LOCAL", "GM", "UB"):
        raise NotImplementedError("print_scalar only supports local, GM, and UB scalar values")
    placeholder = source_operand
    op = cannir.debug_print_scalar(
        value,
        source_operand,
        placeholder,
        placeholder,
        printer_id=printer_id,
        max_bytes=1024,
        mode=mode,
    )
    record = DebugPrintRecord(
        printer_id=printer_id,
        label=label or f"scalar_{printer_id}",
        source_location=source,
        dtype=dtype,
        shape=(),
        memloc=memloc,
        max_bytes=1024,
        mode=mode,
        op=op,
        physical_copy_bytes=None,
        visible_payload_bytes=None,
        physical_shape=(),
        layout_kind="scalar",
        physical_format="scalar",
        is_scalar=True,
    )
    plan.records.append(record)
