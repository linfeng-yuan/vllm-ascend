# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Shared compile-segment extraction for AOT and top-level ``@jit`` calls.

This module owns the IR-build → passes → translate → bisheng pipeline,
returning a :class:`_CompileArtifact` that downstream code wraps in
either:
  - a reusable :class:`ProviderCallable` handle (AOT), or
  - a one-call :class:`ProviderCallable` wrapper that is closed after
    execution (JIT).

Closing the JIT wrapper only removes a fresh, cache-bypassed artifact.
Normal cache entries are borrowed by both callers and remain cache-owned.

It does not own argument marshalling, debug-print runtime allocation,
or execution. JIT execution lives in ``jit_executor.py``; AOT execution
lives on ``ProviderCallable`` itself.
"""

import logging
import os
from contextvars import Token
from dataclasses import dataclass
from typing import Any, Callable, List, Optional, Tuple

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir, func

from cannbotdsl.core.compiler.abi import (
    HOST_ABI_VERSION,
    validate_ascendc_host_abi,
)
from cannbotdsl.core.toolchain.ascendc import resolve_bisheng
from cannbotdsl.core.utils.timer import time_block
from cannbotdsl.package.native import runtime as native_binary

_LOG = logging.getLogger(__name__)


@dataclass(frozen=True)
class _CompileArtifact:
    """Output of :func:`compile_to_artifact`.

    :param so_path: Absolute path to the compiled .so on disk, or the
        empty string if compilation was short-circuited by
        ``CANNBOTDSL_PIPE_STAGE`` before the bisheng step.
    :param symbol_name: Exported ``extern "C"`` symbol name in the .so.
    :param contract: The current request's immutable call contract.  It is
        never borrowed from the cache.
    :param debug_plans: ``DebugPrintPlan`` instances collected from the
        IR build. Non-empty only when the source function uses
        ``cannbotdsl.print_tensor`` or ``cannbotdsl.print_scalar``. They bypass both cache tiers and are
        consumed either by ``ProviderCallable.__call__`` (AOT) or by
        :func:`cannbotdsl.core.compiler.jit_executor._execute_bound_call`
        (JIT).
    :param owns_so: True iff the consumer is expected to unlink the .so.
        This includes cache-bypassed ``cannbotdsl_aot_*`` artifacts and
        transient process-local artifacts produced while L1 is disabled.
    :param host_abi_version: Internal generated-symbol calling convention
        propagated through cache, save/load, and runtime construction.
    """

    so_path: str
    symbol_name: str
    contract: Any
    debug_plans: List[Any]
    owns_so: bool
    host_abi_version: int
    content_key: str = ""
    format_version_tag: str = ""
    binary_key: str = ""
    binary_key_schema: int = 1
    binary_key_inputs: Any = None


def _cache_format_version() -> str:
    from cannbotdsl.core.compiler.cache_key import _FORMAT_VERSION_TAG

    return _FORMAT_VERSION_TAG


def collect_runtime_abi_args(fn: Callable, call_args: Tuple[Any, ...], call_kwargs: dict) -> List[Any]:
    """Collect direct-JIT runtime values in canonical ABI order."""
    from cannbotdsl.core.contracts.binding import bind_jit_call

    return list(bind_jit_call(fn, call_args, call_kwargs).runtime_values)


@native_binary.observe
def compile_to_artifact(
    fn: Callable,
    call_args: Tuple[Any, ...],
    call_kwargs: dict,
    *,
    aot: bool = False,
    bound_call=None,
) -> _CompileArtifact:
    """Run the compile half of the ``@jit`` pipeline and return an artifact.

    The artifact is the only thing the caller needs to either construct
    a :class:`ProviderCallable` or run a one-shot ``@jit`` call. This
    function does NOT execute the kernel.

    Honors ``CANNBOTDSL_PIPE_STAGE`` for early-exit:

    - ``transform`` / ``translate``: returns artifact with empty
      ``so_path``; bisheng never runs.
    - ``compile``: bisheng runs, .so is written, but no execution; the
      caller is expected to either save the .so or unlink it.
    """
    from cannbotdsl.core.toolchain.ascendc import AscendCCompiler
    from cannbotdsl.core.utils.env import env
    from cannbotdsl.core.frontend.lowering_state import (
        JitLoweringState,
        _CURRENT_LOWERING_STATE,
    )
    from cannbotdsl.core.frontend.compiler import (
        FrontendCompiler,
        frontend_options_scope,
        options_from_snapshot,
    )
    from cannbotdsl.core.compiler.call_lowering import CallLoweringPlan
    from cannbotdsl.core.compiler.passes import _run_cannir_passes
    from cannbotdsl.core.utils.dump import dump_text, safe_basename

    _env = env()
    frontend_options = options_from_snapshot(_env)
    if bound_call is None:
        from cannbotdsl.core.contracts.binding import bind_aot_call, bind_jit_call

        binder = bind_aot_call if aot else bind_jit_call
        bound_call = binder(fn, call_args, call_kwargs)
    contract = bound_call.contract
    from cannbotdsl.core.contracts.model import (
        StructRefContract,
        TensorContract,
        TensorListContract,
    )

    struct_ref_parameters = frozenset(
        parameter.name
        for parameter in contract.runtime_parameters
        if isinstance(parameter.argument, StructRefContract)
    )

    has_canonical_tensor = any(
        isinstance(
            argument,
            (TensorContract, TensorListContract, StructRefContract),
        )
        for argument in contract.abi_arguments
    )
    # Pipeline-stage exits are compiler-inspection modes: they never construct
    # or invoke a ProviderCallable, and a transient compile-stage DSO is retired
    # by JitFunction.  Keeping tensorless probes available there lets frontend,
    # lowering, and toolchain suites exercise scalar/buffer-only fragments
    # without creating a second production calling convention.  Every AOT
    # request and every path that could execute or publish a program is rejected
    # before entering the toolchain.
    if not has_canonical_tensor and (
        aot or _env.pipe_stage not in {"transform", "translate", "compile"}
    ):
        raise TypeError(
            "staged provider calls require at least one canonical "
            "TensorContract, TensorListContract, or StructRefContract leaf"
        )
    from cannbotdsl.core.compiler.parameter_lowering import ParameterLoweringPlan

    parameter_lowering = ParameterLoweringPlan(contract)
    from cannbotdsl.core.contracts.codec import contract_digest

    symbol_name = f"{fn.__name__}_{contract_digest(contract)[:32]}"
    with time_block("trace:ast_preprocess"):
        from cannbotdsl.core.frontend.analysis import (
            _struct_ref_parameters_scope,
        )

        with _struct_ref_parameters_scope(struct_ref_parameters):
            frontend_artifact = FrontendCompiler().compile(fn, frontend_options)
        ir_builder = frontend_artifact.function

    ascendc_source = None
    debug_plans: List[Any] = []
    cache_key: Optional[str] = None
    binary_key = ""
    binary_key_inputs = None
    from cannbotdsl.core.compiler import cache as _cache

    # Cache switches are dynamic between compilations, but immutable
    # within this one. Passing this snapshot through lookup,
    # singleflight, and store prevents a concurrent os.environ mutation
    # from mixing policies halfway through the pipeline.
    cache_policy = _cache.resolve_policy()
    stage = _env.pipe_stage
    if _env.reuse_ascendc and _env.dump_ascendc:
        raise ValueError("CANNBOTDSL_REUSE_ASCENDC and CANNBOTDSL_DUMP_ASCENDC cannot be enabled together")

    dump_basename = safe_basename(getattr(fn, "__name__", "jit"))
    if frontend_artifact.debug is not None:
        frontend_debug = frontend_artifact.debug
        if frontend_debug.source is not None:
            dump_text(
                f"{dump_basename}.frontend.py",
                frontend_debug.source,
                dump_dir=_env.dump_dir,
            )
        if frontend_debug.plan is not None:
            dump_text(
                f"{dump_basename}.frontend.plan",
                frontend_debug.plan,
                dump_dir=_env.dump_dir,
            )
        if frontend_debug.lowered is not None:
            dump_text(
                f"{dump_basename}.frontend.lowered.py",
                frontend_debug.lowered,
                dump_dir=_env.dump_dir,
            )

    with ir.Context() as ctx:
        with time_block("trace:ir_build"):
            with ir.Location.unknown(ctx):
                call_plan = CallLoweringPlan.from_bound_call(fn, bound_call)
                func_types = list(call_plan.mlir_types)
                if len(func_types) != parameter_lowering.slot_count:
                    raise RuntimeError(
                        "internal host ABI mismatch: "
                        f"{len(func_types)} MLIR arguments but "
                        f"{parameter_lowering.slot_count} contract ABI arguments"
                    )

                module = ir.Module.create()
                with ir.InsertionPoint(module.body):
                    func_op = func.FuncOp(symbol_name, (func_types, []))
                    func_op.attributes["cannir.host"] = ir.UnitAttr.get()
                    entry_block = func_op.add_entry_block()
                    from cannbotdsl.core.compiler.host_schema import (
                        apply_physical_shape_upper_bound_attributes,
                    )

                    apply_physical_shape_upper_bound_attributes(
                        func_op, contract
                    )
                    with ir.InsertionPoint(entry_block):
                        from cannbotdsl._onchip import _OnChipTraceState, _reset_current_onchip_trace, _set_current_onchip_trace

                        state = JitLoweringState(
                            module=module,
                            host_func=func_op,
                        )
                        token: Token = _CURRENT_LOWERING_STATE.set(state)
                        onchip_trace_token = _set_current_onchip_trace(_OnChipTraceState())
                        from cannbotdsl.ops.cube import (
                            _finish_cube_trace,
                            _start_cube_trace,
                        )

                        cube_trace, cube_trace_token = _start_cube_trace(func_op)
                        try:
                            func_op_args = list(func_op.regions[0].blocks[0].arguments)
                            ir_args, ir_kwargs = call_plan.rebuild(func_op_args)
                            with frontend_options_scope(frontend_options):
                                result = ir_builder(*ir_args, **ir_kwargs)
                            if result is not None:
                                from cannbotdsl.core.diag.diagnostics import (
                                    CANNBotTypeError,
                                    ST102_NON_VOID_ENTRY_RETURN,
                                )

                                raise CANNBotTypeError(
                                    ST102_NON_VOID_ENTRY_RETURN,
                                    f"Top-level @jit entry {fn.__qualname__!r} returned {type(result).__name__}; entries must return None.",
                                    phase="staging",
                                    path=fn.__qualname__,
                                    hint="Remove the returned value; only nested @jit and inline kernels may return values.",
                                )
                            func.ReturnOp([])
                        except BaseException:
                            _finish_cube_trace(
                                cube_trace, cube_trace_token, finalize=False
                            )
                            raise
                        else:
                            _finish_cube_trace(
                                cube_trace, cube_trace_token, finalize=True
                            )
                        finally:
                            _reset_current_onchip_trace(onchip_trace_token)
                            _CURRENT_LOWERING_STATE.reset(token)

        debug_plans = [
            plan for plan in state.debug_prints.values() if plan.has_prints
        ]
        from cannbotdsl.core.compiler.host_schema import (
            build_host_program_spec,
        )

        host_program_spec = build_host_program_spec(
            contract,
            parameter_lowering.ctypes_types(),
            debug_plans,
        )
        if len(host_program_spec.schema_slots) != len(
            func_op.regions[0].blocks[0].arguments
        ):
            raise RuntimeError(
                "HostProgramSpec slot count does not match generated host "
                "function arguments"
            )
        host_program_spec.apply_mlir_attributes(func_op)

        with time_block("trace:verify"):
            try:
                module.operation.verify()
            except Exception:
                _LOG.error("Module verification failed. Module:\n%s", str(module))
                raise

        # Cache lookup happens after IR build + verify but before passes
        # / translate / bisheng. The verified MLIR module subsumes every
        # input represented in the IR (source body, helper edits,
        # closure values, bound-instance attributes read at trace time,
        # dynamic shape types) — see cache_key._compute_key.  Relationships
        # and constraints that lower to the same ``-1`` IR live in the
        # independent CallContract key section.
        #
        # debug_plans skip the cache entirely: they hold live ir.Value
        # references that don't survive a cache roundtrip, and the
        # workflow is debug mode where the bisheng cost isn't critical.
        cache_bypass = _cache.bypass_reason(
            _env,
            policy=cache_policy,
            has_debug_plans=bool(debug_plans),
        )
        if cache_bypass in (None, "all_tiers_disabled") and (cache_bypass is None or native_binary.enabled()):
            from cannbotdsl.core.compiler.cache_key import (
                _compute_key,
                _runtime_identity,
            )

            if native_binary.enabled():
                from cannbotdsl.core.compiler.binary_key import compute_binary_key
                try:
                    binary_key, binary_key_inputs = compute_binary_key(
                        module, contract=contract, target=_env.npu_arch,
                        pipeline=_env.cannir_pipeline, barall=_env.barall)
                except Exception:
                    _LOG.warning("Native key computation failed", exc_info=True)
                    binary_key = ""
                installed = native_binary.lookup(binary_key or None, contract, _env.npu_arch)
                if installed is not None:
                    return _CompileArtifact(
                        so_path=installed.so_path, symbol_name=installed.symbol_name,
                        contract=contract, debug_plans=[], owns_so=False,
                        host_abi_version=installed.host_abi_version,
                        content_key=installed.content_key,
                        format_version_tag=installed.format_version_tag,
                        binary_key=binary_key, binary_key_inputs=binary_key_inputs)
            cached = None
            with time_block("cache:compute_key_and_lookup"):
                try:
                    cache_key = _compute_key(
                        module,
                        runtime_identity=_runtime_identity(),
                        contract=contract,
                        compile_options={
                            "frontend": {
                                "emit_line_info": frontend_options.emit_line_info,
                            },
                            "backend": {
                                "pipeline": _env.cannir_pipeline,
                            },
                        },
                        target=_env.npu_arch,
                    )
                except Exception:
                    # The cache is an optimization, so it must never be able
                    # to fail a compilation that would otherwise succeed —
                    # Malformed build metadata degrades to "compile without
                    # caching".
                    cache_key = None
                    _LOG.warning(
                        "compile cache disabled for this compilation: cache key computation failed",
                        exc_info=True,
                    )
                    _cache.trace_bypass("key_error")
            if cache_key is not None:
                try:
                    cached = _cache.lookup(cache_key, cache_policy)
                except Exception:
                    # Keep ordinary cache failures nonfatal; installed package
                    # validation above deliberately does not fail open.
                    _LOG.debug("Compilation cache lookup failed", exc_info=True)
            if cached is not None:
                native_binary.event('compile_cache_hit', key=cache_key)
                return _CompileArtifact(
                    so_path=cached.so_path,
                    symbol_name=cached.symbol_name,
                    contract=contract,
                    debug_plans=[],
                    owns_so=cached.owns_so,
                    host_abi_version=cached.host_abi_version,
                    content_key=cache_key,
                    binary_key=binary_key, binary_key_inputs=binary_key_inputs,
                    format_version_tag=_cache_format_version(),
                )
        else:
            native_binary.lookup(None, contract, _env.npu_arch, bypass=cache_bypass)
            _cache.trace_bypass(cache_bypass)

        # Dump file names keep the original Python identifier so today's
        # debug workflow (.dump/<fn_name>.mlir / .asc) keeps working —
        # only the in-binary symbol gets mangled.
        ###### Transform stage ######
        native_binary.event("backend_pipeline", key=cache_key)
        _run_cannir_passes(module)
        if _env.dump_mlir:
            dump_text(
                f"{dump_basename}.mlir",
                str(module),
                dump_dir=_env.dump_dir,
            )
        if stage == "transform":
            return _CompileArtifact(
                so_path="",
                symbol_name=symbol_name,
                contract=contract,
                debug_plans=debug_plans,
                owns_so=False,
                host_abi_version=HOST_ABI_VERSION,
            )

        ###### Translate stage ######
        with time_block("translate:codegen_asc"):
            ascendc_source = cannir.translate_to_ascendc(module.operation)
        if ascendc_source is None:
            _LOG.error("Failed to translate to AscendC.")
            return _CompileArtifact(
                so_path="",
                symbol_name=symbol_name,
                contract=contract,
                debug_plans=debug_plans,
                owns_so=False,
                host_abi_version=HOST_ABI_VERSION,
            )
        if _env.dump_ascendc:
            dump_text(
                f"{dump_basename}.asc",
                ascendc_source,
                dump_dir=_env.dump_dir,
            )
        if stage == "translate":
            if _env.print_ascendc:
                _LOG.debug("AscendC source for '%s':\n%s", dump_basename, ascendc_source)
            return _CompileArtifact(
                so_path="",
                symbol_name=symbol_name,
                contract=contract,
                debug_plans=debug_plans,
                owns_so=False,
                host_abi_version=HOST_ABI_VERSION,
            )

    ###### Compile stage (outside ir.Context) ######
    if _env.reuse_ascendc:
        candidate_path = os.path.join(_env.dump_dir, f"{dump_basename}.asc")
        if not os.path.isfile(candidate_path):
            raise FileNotFoundError(f"CANNBOTDSL_REUSE_ASCENDC requires an existing dump: {candidate_path}")
        with open(candidate_path, "r", encoding="utf-8") as f:
            ascendc_source = f.read()
        validate_ascendc_host_abi(
            ascendc_source,
            source_path=candidate_path,
        )

    if _env.print_ascendc:
        _LOG.debug("AscendC source for '%s':\n%s", dump_basename, ascendc_source)

    compiler = AscendCCompiler(barall=_env.barall)
    if cache_key is None:
        native_binary.event("backend_compile", key=cache_key)
        so_path = compiler.compile_ascendc_to_so(ascendc_source)
        _LOG.debug("Compiled kernel: %s", so_path)
        return _CompileArtifact(
            so_path=so_path,
            symbol_name=symbol_name,
            contract=contract,
            debug_plans=debug_plans,
            owns_so=True,
            host_abi_version=HOST_ABI_VERSION,
        )

    # Serialize on the key so a cold-start fan-out (parallel pytest, one
    # rank per device) runs bisheng once rather than once per worker. The
    # context manager hands back an entry when someone else won the race.
    with _cache.singleflight(cache_key, cache_policy) as published:
        if published is not None:
            return _CompileArtifact(
                so_path=published.so_path,
                symbol_name=published.symbol_name,
                contract=contract,
                debug_plans=[],
                owns_so=published.owns_so,
                host_abi_version=published.host_abi_version,
                content_key=cache_key,
                binary_key=binary_key, binary_key_inputs=binary_key_inputs,
                format_version_tag=_cache_format_version(),
            )
        # Link straight into the directory the cache keeps the artifact
        # in, so no ``cannbotdsl_aot_*`` tempdir is created for anyone to
        # leak. Cache-bypassed compilations above keep the private
        # tempdir their owning handle knows how to clean up.
        native_binary.event("backend_compile", key=cache_key)
        so_path = compiler.compile_ascendc_to_so(
            ascendc_source,
            output_path=_cache.staging_path(cache_key),
        )
        _LOG.debug("Compiled kernel: %s", so_path)
        # L1 takes ownership when enabled. With L1 disabled the store
        # result transfers this staging file to the caller instead.
        entry = _cache.store(
            cache_key,
            so_path,
            symbol_name,
            contract,
            host_abi_version=HOST_ABI_VERSION,
            fn_body=fn,
            policy=cache_policy,
        )

    return _CompileArtifact(
        so_path=entry.so_path,
        symbol_name=symbol_name,
        contract=contract,
        debug_plans=debug_plans,
        owns_so=entry.owns_so,
        host_abi_version=HOST_ABI_VERSION,
        content_key=cache_key,
        binary_key=binary_key, binary_key_inputs=binary_key_inputs,
        format_version_tag=_cache_format_version(),
    )
