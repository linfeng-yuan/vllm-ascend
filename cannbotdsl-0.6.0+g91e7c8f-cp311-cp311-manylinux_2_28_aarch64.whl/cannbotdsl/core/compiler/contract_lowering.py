# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""MLIR type lowering and trace-value construction for call contracts."""

from __future__ import annotations

from cannbotdsl.core.contracts.elements import element_for_tag
from cannbotdsl.core.compiler.physical_abi import physical_argument
from cannbotdsl.core.contracts.model import (
    ConstantExpr,
    ScalarContract,
    StructContract,
    StructRefContract,
    TensorContract,
    TensorListContract,
)
from cannbotdsl.core.contracts.storage import compact_stride


class ContractTypeLowerer:
    @staticmethod
    def _tensor_type(contract: TensorContract):
        import cannbotdsl._mlir.ir as ir
        from cannbotdsl._mlir.dialects import cannir
        from cannbotdsl.tensor import LayoutMapKind
        from cannbotdsl.tensor import MemLoc

        ctx = ir.Context.current
        if ctx is None:
            raise RuntimeError("contract lowering requires an active MLIR context")
        info = element_for_tag(contract.element)
        shape = tuple(
            item.value if isinstance(item, ConstantExpr) else cannir.ShapeType.DYNAMIC for item in contract.shape
        )
        stride = tuple(
            item.value if isinstance(item, ConstantExpr) else cannir.StrideType.DYNAMIC for item in contract.stride
        )
        logical_layout = cannir.LayoutType.get(shape, stride, context=ctx)
        storage = contract.storage_encoding
        if storage is None:
            physical_layout = logical_layout
            layout_map_kind = LayoutMapKind.Identity
        else:
            physical_shape = tuple(
                item.value
                if isinstance(item, ConstantExpr)
                else cannir.ShapeType.DYNAMIC
                for item in storage.physical_shape
            )
            physical_stride = tuple(
                item.value
                if isinstance(item, ConstantExpr)
                else cannir.StrideType.DYNAMIC
                for item in compact_stride(storage.physical_shape)
            )
            physical_layout = cannir.LayoutType.get(
                physical_shape,
                physical_stride,
                context=ctx,
            )
            if storage.encoding != "fractal_nz":  # validated contract.
                raise ValueError(
                    f"unsupported tensor storage encoding {storage.encoding!r}"
                )
            layout_map_kind = LayoutMapKind.ND2NZ
        pointer = cannir.PointerType.get(
            MemLoc.GM, info.mlir_type(), context=ctx
        )
        return cannir.TensorType.get(
            pointer,
            logical_layout,
            physical_layout,
            int(layout_map_kind),
            context=ctx,
        )

    @classmethod
    def mlir_type(cls, argument):
        physical = physical_argument(argument)
        if isinstance(physical, TensorContract):
            return cls._tensor_type(physical)
        if isinstance(argument, ScalarContract):
            return element_for_tag(argument.element).scalar_mlir_type()
        if isinstance(argument, StructContract):
            from cannbotdsl.types.datastruct import _schema_mlir_type

            return _schema_mlir_type(argument.schema)
        if isinstance(argument, StructRefContract):
            from cannbotdsl.types.datastruct import _schema_ref_mlir_type

            return _schema_ref_mlir_type(
                argument.schema,
                address_space=argument.address_space,
                access=argument.access,
            )
        raise TypeError(f"cannot lower argument contract {argument!r}")


class TraceValueFactory:
    @classmethod
    def create(cls, argument, value):
        if isinstance(argument, TensorListContract):
            from cannbotdsl.types.tensor_list import TensorList

            return TensorList._from_ir(value, contract=argument)
        if isinstance(argument, TensorContract):
            from cannbotdsl.tensor import Tensor

            return Tensor._from_ir(value)
        if isinstance(argument, ScalarContract):
            info = element_for_tag(argument.element)
            if info.dsl_type is None:  # pragma: no cover - validated contract
                raise TypeError(
                    f"dtypes.{info.dtype.name} has no scalar trace wrapper"
                )
            return info.dsl_type(value)
        if isinstance(argument, StructContract):
            from cannbotdsl.types.datastruct import _DataStructValue

            return _DataStructValue(value)
        if isinstance(argument, StructRefContract):
            from cannbotdsl.types.datastruct import _DataStructRefValue

            return _DataStructRefValue(value)
        raise TypeError(f"cannot create trace value for {argument!r}")


__all__ = ["ContractTypeLowerer", "TraceValueFactory"]
