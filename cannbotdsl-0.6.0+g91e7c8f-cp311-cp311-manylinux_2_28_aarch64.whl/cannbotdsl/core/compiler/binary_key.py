# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# Licensed under the CANN Open Software License Agreement Version 2.0.
"""Explicit Native matching identity; independent of compilation cache identity."""
import hashlib
import io
import json
import platform
import struct
import subprocess

BINARY_KEY_SCHEMA = 1


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def normalized_ir(module):
    """Strip all debug locations on a clone using MLIR's recursive pass."""
    from cannbotdsl._mlir.passmanager import PassManager
    clone = module.operation.clone()
    PassManager.parse('builtin.module(strip-debuginfo)').run(clone)
    buffer = io.BytesIO()
    clone.operation.write_bytecode(buffer)
    return buffer.getvalue()


def compute_binary_key(module, *, contract, target, pipeline, barall):
    from cannbotdsl.core.contracts.codec import canonical_contract_bytes
    # Reject invalid pipelines rather than claiming the requested pipeline ran.
    from cannbotdsl._mlir.passmanager import PassManager
    PassManager.parse(pipeline)
    ir_bytes = normalized_ir(module)
    contract_bytes = canonical_contract_bytes(contract)
    options = {'barall': bool(barall)}
    parts = (
        ('schema', b'cannbotdsl-native-binary-v1'),
        ('verified-ir', ir_bytes), ('call-contract', contract_bytes),
        ('target', target.encode()), ('backend-pipeline', pipeline.encode()),
        ('codegen-options', _json(options)),
    )
    digest = hashlib.sha256()
    for name, payload in parts:
        name = name.encode()
        digest.update(struct.pack('>I', len(name)) + name)
        digest.update(struct.pack('>Q', len(payload)) + payload)
    return digest.hexdigest(), {
        'verified_ir_sha256': hashlib.sha256(ir_bytes).hexdigest(),
        'call_contract_sha256': hashlib.sha256(contract_bytes).hexdigest(),
        'backend_pipeline': pipeline, 'codegen_options': options,
    }


def host_platform():
    return {'os': platform.system().lower(), 'arch': platform.machine()}


def build_provenance():
    from importlib.resources import files
    from cannbotdsl.core.compiler.cache_key import _toolchain_version
    path = files('cannbotdsl').joinpath('_build_info.json')
    from cannbotdsl.core.toolchain.ascendc import resolve_bisheng
    from cannbotdsl.core.compiler.cache_key import _cann_release_identity
    resolution = resolve_bisheng(required=False)
    details = {'cann': _cann_release_identity(resolution.ascend_home)}
    if resolution.path:
        try:
            result = subprocess.run([resolution.path, '--version'], capture_output=True,
                                    text=True, timeout=60, check=False)
            details['bisheng'] = (result.stdout or result.stderr).strip()
        except (OSError, subprocess.SubprocessError) as exc:
            details['bisheng_probe_error'] = type(exc).__name__
    return {'build_info': json.loads(path.read_text()) if path.is_file() else {},
            'toolchain_identity': _toolchain_version(), 'toolchain_details': details}
