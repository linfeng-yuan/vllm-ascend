# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Versioned v14 artifact manifests for cache entries and saved binaries."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
from dataclasses import dataclass

from cannbotdsl.core.compiler.abi import HOST_ABI_VERSION
from cannbotdsl.core.contracts.codec import (
    contract_digest,
    contract_from_dict,
    contract_to_dict,
)


SIDECAR_VERSION = 14
SIDECAR_SUFFIX = ".meta.json"
_SYMBOL_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _validate_digest(value, *, field: str, allow_empty: bool = False) -> str:
    if allow_empty and value == "":
        return value
    if (
        not isinstance(value, str)
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        suffix = " or empty" if allow_empty else ""
        raise ValueError(
            f"{field} must be a lowercase 64-hex SHA-256 digest{suffix}, "
            f"got {value!r}"
        )
    return value


def _validate_provenance(content_key, format_version_tag) -> tuple[str, str]:
    content_key = _validate_digest(
        content_key, field="content_key", allow_empty=True
    )
    if not isinstance(format_version_tag, str):
        raise ValueError("format_version_tag must be a string")
    if bool(content_key) != bool(format_version_tag):
        raise ValueError(
            "content_key and format_version_tag must either both be present "
            "or both be empty"
        )
    return content_key, format_version_tag


@dataclass(frozen=True, slots=True)
class SidecarRecord:
    symbol_name: str
    contract: object
    host_abi_version: int
    content_key: str
    format_version_tag: str


def sidecar_path(so_path: str) -> str:
    return so_path + SIDECAR_SUFFIX


def sha256_file(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for chunk in iter(lambda: source.read(1 << 16), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_metadata(
    symbol_name: str,
    contract,
    binary_sha256: str,
    *,
    host_abi_version: int,
    content_key: str,
    format_version_tag: str,
) -> dict:
    if host_abi_version != HOST_ABI_VERSION:
        raise ValueError(
            f"cannot write host ABI {host_abi_version}; current ABI is {HOST_ABI_VERSION}"
        )
    if not isinstance(symbol_name, str) or not _SYMBOL_RE.fullmatch(symbol_name):
        raise ValueError(f"invalid exported symbol name {symbol_name!r}")
    binary_sha256 = _validate_digest(binary_sha256, field="binary_sha256")
    content_key, format_version_tag = _validate_provenance(
        content_key, format_version_tag
    )
    return {
        "version": SIDECAR_VERSION,
        "host_abi_version": int(host_abi_version),
        "symbol_name": symbol_name,
        "binary_sha256": binary_sha256,
        "contract_digest": contract_digest(contract),
        "call_contract": contract_to_dict(contract),
        "content_key": content_key,
        "format_version_tag": format_version_tag,
    }


def parse_metadata(data: dict):
    if not isinstance(data, dict):
        raise ValueError("sidecar metadata must be a JSON object")
    host_abi_version = data.get("host_abi_version")
    # Diagnose an old ABI artifact consistently even when its sidecar version
    # is also obsolete. There is no dual-ABI loader or signature guessing.
    if host_abi_version != HOST_ABI_VERSION:
        raise ValueError(
            f"artifact uses host ABI {host_abi_version}; runtime requires "
            f"ABI {HOST_ABI_VERSION}. Recompile the artifact."
        )
    version = data.get("version")
    if version != SIDECAR_VERSION:
        hint = " Recompile the artifact with the current CANNBotDSL runtime."
        raise ValueError(
            f"unsupported sidecar version {version!r}; this runtime understands "
            f"version {SIDECAR_VERSION}.{hint}"
        )
    contract = contract_from_dict(data["call_contract"])
    actual_digest = contract_digest(contract)
    claimed_digest = data.get("contract_digest")
    if claimed_digest != actual_digest:
        raise ValueError(
            f"call contract digest mismatch: expected {claimed_digest!r}, "
            f"decoded {actual_digest!r}"
        )
    symbol_name = data["symbol_name"]
    if not isinstance(symbol_name, str) or not _SYMBOL_RE.fullmatch(symbol_name):
        raise ValueError(f"invalid exported symbol name {symbol_name!r}")
    binary_sha256 = _validate_digest(
        data["binary_sha256"], field="binary_sha256"
    )
    content_key, format_version_tag = _validate_provenance(
        data.get("content_key", ""), data.get("format_version_tag", "")
    )
    return (
        symbol_name,
        contract,
        int(host_abi_version),
        binary_sha256,
        content_key,
        format_version_tag,
    )


def _write_json_fsynced(path: str, payload: dict) -> None:
    with open(path, "w", encoding="utf-8") as output:
        json.dump(payload, output, indent=2, sort_keys=True)
        output.flush()
        os.fsync(output.fileno())


def _fsync_directory(path: str) -> None:
    try:
        descriptor = os.open(path or ".", os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write_sidecar(
    so_path: str,
    symbol_name: str,
    contract,
    *,
    host_abi_version: int,
    content_key: str,
    format_version_tag: str,
) -> str:
    """Atomically replace the manifest for an already-published binary."""

    payload = build_metadata(
        symbol_name,
        contract,
        sha256_file(so_path),
        host_abi_version=host_abi_version,
        content_key=content_key,
        format_version_tag=format_version_tag,
    )
    final_path = sidecar_path(so_path)
    directory = os.path.dirname(os.path.abspath(final_path))
    descriptor, temporary = tempfile.mkstemp(dir=directory, suffix=".meta.tmp")
    os.close(descriptor)
    try:
        _write_json_fsynced(temporary, payload)
        os.replace(temporary, final_path)
        _fsync_directory(directory)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return final_path


def publish_artifact(
    source_so: str,
    destination_so: str,
    symbol_name: str,
    contract,
    *,
    host_abi_version: int,
    content_key: str,
    format_version_tag: str,
) -> str:
    """Commit binary first and its manifest last as the publication marker."""

    destination_so = os.path.abspath(destination_so)
    directory = os.path.dirname(destination_so)
    os.makedirs(directory, exist_ok=True)
    so_fd, temporary_so = tempfile.mkstemp(dir=directory, suffix=".so.tmp")
    meta_fd, temporary_meta = tempfile.mkstemp(dir=directory, suffix=".meta.tmp")
    os.close(meta_fd)
    try:
        with os.fdopen(so_fd, "wb") as output, open(source_so, "rb") as source:
            shutil.copyfileobj(source, output, length=1 << 16)
            output.flush()
            os.fsync(output.fileno())
        payload = build_metadata(
            symbol_name,
            contract,
            sha256_file(temporary_so),
            host_abi_version=host_abi_version,
            content_key=content_key,
            format_version_tag=format_version_tag,
        )
        _write_json_fsynced(temporary_meta, payload)
        os.replace(temporary_so, destination_so)
        _fsync_directory(directory)
        os.replace(temporary_meta, sidecar_path(destination_so))
        _fsync_directory(directory)
        return destination_so
    finally:
        for path in (temporary_so, temporary_meta):
            if os.path.exists(path):
                os.unlink(path)


def read_sidecar(so_path: str):
    path = sidecar_path(so_path)
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"sidecar metadata not found at {path!r}; ProviderCallable.save() "
            f"writes a '{SIDECAR_SUFFIX}' file next to the binary"
        )
    with open(path, "r", encoding="utf-8") as source:
        payload = json.load(source)
    symbol, contract, host_abi, claimed, content_key, fmt = parse_metadata(
        payload
    )
    actual = sha256_file(so_path)
    if actual != claimed:
        raise ValueError(
            f"sidecar integrity check failed for {so_path!r}: expected sha256 "
            f"{claimed!r}, got {actual!r}. The binary was modified or replaced."
        )
    return SidecarRecord(
        symbol,
        contract,
        host_abi,
        content_key,
        fmt,
    )


__all__ = [
    "SIDECAR_SUFFIX",
    "SIDECAR_VERSION",
    "SidecarRecord",
    "build_metadata",
    "parse_metadata",
    "publish_artifact",
    "read_sidecar",
    "sha256_file",
    "sidecar_path",
    "write_sidecar",
]
