# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""One physical lowering plan for a concrete Python call.

The plan captures parameter layouts once.  Its stored MLIR types build the
callee signature, the same structural arities rebuild block arguments, and
trace calls retain the exact operands and layout identity used by a kernel
launch.
"""

from __future__ import annotations

import inspect
import typing
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field

import cannbotdsl._mlir.ir as ir

from cannbotdsl.core.contracts.surface import (
    ScalarAnnotationSemantics,
    SurfaceSignature,
    _StagedBinding,
    _StagedRole,
    classify_scalar_annotation,
    surface_union_members,
    unwrap_surface_annotation,
)
from cannbotdsl.core.frontend.runtime.value_tree_layout import (
    BoundaryPolicy,
    ValueTreeLayout,
)
from cannbotdsl.tensor import Tensor
from cannbotdsl.core.diag.diagnostics import (
    CANNBotTypeError,
    ST101_UNSUPPORTED_DYNAMIC_ARGUMENT,
)


def get_fullargspec(fn: Callable[..., object]):
    """Resolve supported parameter annotations without executing expressions."""

    spec = inspect.getfullargspec(fn)
    surface = SurfaceSignature.from_callable(fn)
    annotations = dict(spec.annotations)
    for parameter in surface.signature.parameters.values():
        result = surface.resolver.resolve(parameter.name)
        if result.is_resolved:
            annotations[parameter.name] = result.value
    return spec._replace(annotations=annotations)


def _unwrap_annotated(annotation):
    return unwrap_surface_annotation(annotation)


def _normalize_trace_scalar_parameter(
    name: str,
    annotation: object,
    value: object,
) -> object:
    """Apply one resolved scalar-annotation strategy at a trace boundary."""

    semantics = classify_scalar_annotation(name, annotation)
    if semantics is None:
        return value
    if semantics.mode is ScalarAnnotationSemantics.Mode.GENERIC:
        from cannbotdsl.core.contracts.elements import trace_scalar_for_value

        info = trace_scalar_for_value(
            value,
            path=f"ScalarValue parameter {name!r}",
        )
        if type(value) in {bool, int, float}:
            assert info.dsl_type is not None
            return info.dsl_type(value)
        return value

    from cannbotdsl.core.contracts.elements import trace_scalar_for_dtype

    assert semantics.dtype is not None
    scalar_info = trace_scalar_for_dtype(semantics.dtype)
    assert scalar_info.dsl_type is not None
    return scalar_info.dsl_type(value)


def _is_tensor_annotation(annotation) -> bool:
    annotation = _unwrap_annotated(annotation)
    variants = surface_union_members(annotation)
    if variants is not None:
        variants = [item for item in variants if item is not type(None)]
        return bool(variants) and all(_is_tensor_annotation(item) for item in variants)
    return annotation is Tensor


def _dynamic_path(path: str, key: object) -> str:
    if type(key) is str:
        escaped = key.replace("\\", "\\\\").replace('"', '\\"')
        return f'{path}["{escaped}"]'
    return f"{path}[{key!r}]"


def _unsupported_dynamic(path: str, value: object, *, channel: bool = False):
    if channel:
        message = (
            f"{path} is a Channel, which is a trace-local transactional resource "
            "and cannot be transported into a materialized kernel."
        )
        hint = "Construct the Channel in the kernel/receiver or keep the helper inline."
    else:
        message = (
            f"{path} has unsupported dynamic carrier {type(value).__name__} at a "
            "materialized kernel boundary."
        )
        hint = (
            "Use a supported scalar/Tensor/Layout/Buffer/datastruct carrier, "
            "or mark stable configuration as Constexpr[...]."
        )
    return CANNBotTypeError(
        ST101_UNSUPPORTED_DYNAMIC_ARGUMENT,
        message,
        phase="staging",
        path=path,
        hint=hint,
    )


def _validate_dynamic_tree(value: object, *, path: str) -> None:
    from cannbotdsl.channel import Channel

    if type(value) is Channel:
        raise _unsupported_dynamic(path, value, channel=True)
    if type(value) is tuple or type(value) is list:
        for index, item in enumerate(value):
            _validate_dynamic_tree(item, path=f"{path}[{index}]")
        return
    if type(value) is dict:
        for key, item in value.items():
            _validate_dynamic_tree(item, path=_dynamic_path(path, key))
        return
    if type(value) in {bool, int, float}:
        return
    try:
        from cannbotdsl.core.ir_transport import extract_ir_values

        extract_ir_values(value)
    except TypeError as exc:
        raise _unsupported_dynamic(path, value) from exc


@dataclass(frozen=True, slots=True)
class _ParameterEntry:
    name: str
    kind: inspect._ParameterKind
    template: object
    _types: tuple[ir.Type, ...] = ()
    _layout: ValueTreeLayout | None = field(default=None, repr=False, compare=False)
    _contract_argument: object | None = field(default=None, repr=False, compare=False)

    def _rebuild(self, values: tuple[ir.Value, ...]) -> object:
        if self._layout is not None:
            return self._layout.rebuild(values)
        if self._contract_argument is not None:
            from cannbotdsl.core.compiler.contract_lowering import TraceValueFactory

            if len(values) != 1:
                raise AssertionError(f"contract parameter {self.name!r} must have one MLIR value")
            return TraceValueFactory.create(
                self._contract_argument,
                values[0],
            )
        if self._types:
            raise AssertionError(f"parameter {self.name!r} lost its rebuild strategy")
        return self.template


@dataclass(frozen=True, slots=True)
class CallLoweringPlan:
    """Captured signature/rebuild plan shared by host and kernel lowering."""

    _entries: tuple[_ParameterEntry, ...] = field(repr=False)
    _mlir_types: tuple[ir.Type, ...] = field(repr=False)
    _operands: tuple[ir.Value, ...] = field(repr=False, compare=False)

    @classmethod
    def from_bound_call(
        cls,
        fn: Callable[..., object],
        bound_call,
        args_spec=None,
    ) -> "CallLoweringPlan":
        runtime_names = frozenset(parameter.name for parameter in bound_call.contract.runtime_parameters)
        return _build_plan(
            fn,
            bound_call.trace_arguments,
            args_spec=args_spec,
            runtime_param_names=runtime_names,
            call_contract=bound_call.contract,
            surface_signature=bound_call.surface_signature,
            capture_operands=False,
        )

    @property
    def mlir_types(self) -> tuple[ir.Type, ...]:
        return self._mlir_types

    @property
    def _struct_ref_parameter_names(self) -> frozenset[str]:
        """Names whose concrete lowering is one DataStructRefType value."""

        from cannbotdsl._mlir.dialects import cannir
        from cannbotdsl.core.contracts.model import StructRefContract

        return frozenset(
            entry.name
            for entry in self._entries
            if isinstance(entry._contract_argument, StructRefContract)
            or any(
                cannir.DataStructRefType.isinstance(type_)
                for type_ in entry._types
            )
        )

    @property
    def _logical_signature(self) -> tuple[tuple[str, str], ...]:
        """Return the deterministic staged type/structure of runtime inputs."""

        signature = []
        for entry in self._entries:
            if entry._layout is not None:
                identity = entry._layout._content_identity()
            elif entry._contract_argument is not None:
                identity = ("contract", repr(entry._contract_argument))
            elif entry._types:
                identity = ("carrier", tuple(str(item) for item in entry._types))
            else:
                continue
            signature.append((entry.name, repr(identity)))
        return tuple(signature)

    def rebuild(self, block_args: Sequence[ir.Value]) -> tuple[list[object], dict[str, object]]:
        if len(block_args) != len(self._mlir_types):
            raise RuntimeError(f"call lowering expected {len(self._mlir_types)} block arguments, got {len(block_args)}")
        positional: list[object] = []
        keywords: dict[str, object] = {}
        offset = 0
        for entry in self._entries:
            count = len(entry._types)
            value = entry._rebuild(
                tuple(block_args[offset : offset + count]),
            )
            offset += count
            if entry.kind is inspect.Parameter.KEYWORD_ONLY:
                keywords[entry.name] = value
            else:
                positional.append(value)
        if offset != len(block_args):
            raise AssertionError("call lowering arity accounting is inconsistent")
        return positional, keywords


def _trace_call_plan(
    fn: Callable[..., object],
    bound_arguments: Mapping[str, object],
    *,
    args_spec=None,
    surface_signature: SurfaceSignature | None = None,
    staged_binding: _StagedBinding | None = None,
) -> CallLoweringPlan:
    """Compiler-private factory for an already-bound nested trace call."""

    surface = surface_signature or SurfaceSignature.from_callable(fn)
    if staged_binding is None:
        bound = inspect.BoundArguments(surface.signature, dict(bound_arguments))
        staged_binding = surface.classify_bound(bound)
    return _build_plan(
        fn,
        staged_binding.bound.arguments,
        args_spec=args_spec,
        surface_signature=surface,
        staged_binding=staged_binding,
        capture_operands=True,
    )


def _build_plan(
    fn: Callable[..., object],
    bound_arguments: Mapping[str, object],
    *,
    args_spec=None,
    runtime_param_names: typing.AbstractSet[str] | None = None,
    call_contract=None,
    surface_signature: SurfaceSignature | None = None,
    staged_binding: _StagedBinding | None = None,
    capture_operands: bool,
) -> CallLoweringPlan:
    surface = surface_signature or SurfaceSignature.from_callable(fn)
    annotations: dict[str, object] = {}
    if args_spec is not None:
        annotations = {**args_spec.annotations, **annotations}
    contracts = (
        {
            parameter.name: parameter.argument
            for parameter in call_contract.runtime_parameters
            if parameter.argument is not None
        }
        if call_contract is not None
        else {}
    )
    entries: list[_ParameterEntry] = []
    operands: list[ir.Value] = []
    staged_parameters = (
        {item.parameter.name: item for item in staged_binding.parameters}
        if staged_binding is not None
        else {}
    )

    for index, parameter in enumerate(surface.signature.parameters.values()):
        if parameter.kind in {
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        }:
            raise TypeError("dynamic trace parameters do not support *args/**kwargs")
        value = bound_arguments.get(parameter.name, parameter.default)
        if value is inspect.Parameter.empty:
            raise TypeError(f"trace argument {parameter.name!r} is not bound")
        staged_parameter = staged_parameters.get(parameter.name)
        reserved = (
            staged_parameter is not None
            and staged_parameter.role is _StagedRole.RECEIVER
        ) or surface.is_receiver(index, parameter)
        annotation = annotations.get(parameter.name, inspect.Parameter.empty)
        if runtime_param_names is None and staged_parameter is not None:
            if not reserved:
                annotation = staged_parameter.annotation
                if annotation is not inspect.Parameter.empty:
                    annotations[parameter.name] = annotation
            omitted = staged_parameter.role is _StagedRole.ABSENT
            runtime = staged_parameter.role is _StagedRole.RUNTIME
        elif runtime_param_names is None and not reserved:
            if annotation is inspect.Parameter.empty:
                annotation = surface.resolver.runtime_annotation(parameter.name)
                if annotation is not inspect.Parameter.empty:
                    annotations[parameter.name] = annotation
            omitted = value is None and _is_tensor_annotation(annotation)
            runtime = not omitted
        else:
            omitted = False
            runtime = not reserved and parameter.name in (runtime_param_names or ())
        if not runtime:
            template = None if omitted else value
            entries.append(
                _ParameterEntry(
                    parameter.name,
                    parameter.kind,
                    template,
                )
            )
            continue

        contract_argument = contracts.get(parameter.name)
        if contract_argument is not None:
            from cannbotdsl.core.compiler.contract_lowering import ContractTypeLowerer

            type_ = ContractTypeLowerer.mlir_type(contract_argument)
            entries.append(
                _ParameterEntry(
                    parameter.name,
                    parameter.kind,
                    value,
                    _types=(type_,),
                    _contract_argument=contract_argument,
                )
            )
            continue

        if annotation is inspect.Parameter.empty:
            annotation = surface.resolver.runtime_annotation(parameter.name)
            if annotation is not inspect.Parameter.empty:
                annotations[parameter.name] = annotation
        _validate_dynamic_tree(value, path=parameter.name)
        normalized = _normalize_trace_scalar_parameter(
            parameter.name,
            annotation,
            value,
        )

        layout, captured = ValueTreeLayout.capture_with_values(normalized, policy=BoundaryPolicy.PARAMETER)
        types_ = layout.mlir_types
        if len(types_) != len(captured):
            raise AssertionError("value-tree layout type/operand arity mismatch")
        for expected, operand in zip(types_, captured):
            if expected != operand.type:
                raise AssertionError(f"value-tree layout captured {operand.type}, expected {expected}")
        entries.append(
            _ParameterEntry(
                parameter.name,
                parameter.kind,
                normalized,
                _types=types_,
                _layout=layout,
            )
        )
        if capture_operands:
            operands.extend(captured)

    mlir_types = tuple(value_type for entry in entries for value_type in entry._types)
    if capture_operands and len(operands) != len(mlir_types):
        raise AssertionError("trace call operand/signature arity mismatch")
    return CallLoweringPlan(
        tuple(entries),
        mlir_types,
        tuple(operands),
    )


__all__ = ["CallLoweringPlan"]
