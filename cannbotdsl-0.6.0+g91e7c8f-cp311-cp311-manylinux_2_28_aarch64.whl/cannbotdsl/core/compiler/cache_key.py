# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Cache key computation shared by JIT and AOT compile paths.

The post-trace IR bytecode is the primary cache-key input.
The orchestration lives in ``builder.compile_to_artifact``; this file
exposes only the key-composition pieces so the lookup point can be a
single ``_cache.lookup(_compute_key(module))`` call from the builder.

Key composition uses length-prefixed named sections for verified IR, the
canonical call contract, a canonical environment snapshot, frontend/backend
options, target, runtime identity, toolchain identity, and cache
format tags.

The IR bytecode subsumes source body, helper edits, closure values, and
bound-instance attribute reads. The independent call-contract section
retains dynamic dimension identity, constraints, and expression relations
that all lower to the same dynamic IR slots. The env snapshot catches backend-affecting
inputs that don't transit through IR (for example, an explicit pipeline
override). The toolchain section is an additional
best-effort invalidation input; its current coverage is documented in
``docs/design/compile_cache.md``.

Both the runtime and toolchain sections are **content-derived, not
path-derived**, so a disk cache stays shareable across machines that
install the same CANN release and the same wheel at different prefixes
or at different times. Reading them is memoized on each input file's
``(mtime_ns, size)`` — see :func:`_stamped_digest`.

Observability and source-reuse flags are omitted from the key because
those modes bypass both cache tiers entirely.
"""

import hashlib
import io
import json
import logging
import os
import struct
import subprocess
from enum import Enum
from importlib import resources as importlib_resources
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple

import cannbotdsl._mlir.ir as ir

_LOG = logging.getLogger(__name__)


# Bump (via env var or this constant) when the cache layout or hash
# composition changes such that any existing entry must be considered
# stale. Users hit ``CANNBOTDSL_CACHE_FORMAT_TAG`` for ad-hoc invalidation
# without redeploying; developers bump ``_FORMAT_VERSION_TAG`` for a
# global one-shot bust.
#
# v17: contract schema v3 and sidecar v11 retain only the standard call
# contract paths while preserving the physical Host ABI v9 layout.
# v18: contract schema v4 and sidecar v12 add provider-backed StructRef
# schemas while preserving the physical Host ABI v9 layout.
# v19: contract schema v5 and sidecar v13 add runtime-dynamic TensorList
# contracts and their asynchronous descriptor-staging ABI projection.
# v20: contract schema v6, sidecar v14, and TensorList descriptor v2 add
# per-element AOT template binding and positional heterogeneous JIT layouts
# while preserving the physical Host ABI v9 layout.
# v21: lossless integer promotion and index normalization change generated IR;
# Host ABI v9, contract schema v6, and sidecar v14 remain unchanged.
# v22: reinterpret access-window normalization and internal storage casts.
# v23: integrate aligned tilers, DualParam access metadata, and slot pitch.
# v24: static copy descriptors, runtime controls, unified scale and block mapping.
# v25: preserve parent L1 pitches for formatted subwindows and FIXPIPE tails.
# v26: propagate UB copy access extents; keep page offsets independent of pitch.
# v27: explicit Channel cursor SSA, Tensor slot identities and automatic
# same-core Buffer synchronization replace implicit same-core transactions.
_FORMAT_VERSION_TAG = "cannbotdsl-cache-v27"


# Env fields that do NOT affect the .so contents. Observability /
# pipeline-staging / source-reuse flags only — everything else in the
# env snapshot is folded into the key. Black-list (rather than
# white-list) so new env fields default to "affects key", which is the
# safe direction: a stale cache miss is harmless, a stale cache hit is
# a correctness bug.
#
# ``debug_asc_sync`` is the one entry here that is NOT a
# doesn't-affect-the-artifact flag. It is the raw spelling of
# ``CANNBOTDSL_DEBUG_ASC_SYNC``, which the same snapshot already carries
# fully decoded as ``debug_asc_pipe_sync`` / ``debug_asc_vf_sync`` — and
# those two ARE keyed. Keying the raw string as well only splits the
# cache across spellings of one setting: "all", "pipe,vf" and "vf,pipe"
# are the same request and used to produce three keys for one artifact.
# Nothing outside the key ever reads it (env.py only stores and passes
# it through). Do not read this as licence to add flags here: the test
# is "some other keyed field already determines this one", not "I don't
# think it matters".
_KEY_IGNORED_ENV = frozenset(
    {
        "dump_dir",
        "dump_mlir",
        "dump_ascendc",
        "reuse_ascendc",
        "print_mlir",
        "print_ascendc",
        "pipe_stage",
        "jit_time_profiling",
        "debug_asc_sync",
    }
)


def _canonical_json_bytes(payload: bytes) -> bytes:
    """Canonicalize JSON so harmless formatting changes do not bust caches."""

    parsed = json.loads(payload.decode("utf-8"))
    return json.dumps(parsed, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


# ---------------------------------------------------------------------------
# Stat-stamped memoization
# ---------------------------------------------------------------------------

# ``(path, producer) -> ((mtime_ns, size), digest)``. Every key input that
# lives in a file goes through :func:`_stamped_digest`, so a steady-state
# compile pays one ``os.stat`` per input instead of re-reading and
# re-hashing the whole install tree. A changed stamp re-reads exactly that
# one file, so content fidelity is preserved for anything a caller can
# observe; the blind spot is a rewrite to the same size inside one mtime
# tick, which is the same trade the Bisheng probe below already makes.
_STAMPED_DIGESTS: Dict[Tuple[str, str], Tuple[Tuple[int, int], str]] = {}


def _file_stamp(path: str) -> Optional[Tuple[int, int]]:
    """``(mtime_ns, size)`` for ``path``, or ``None`` if it can't be stat-ed."""
    try:
        st = os.stat(path)
    except OSError:
        return None
    return (st.st_mtime_ns, st.st_size)


def _stamped_digest(path: str, produce: Callable[[str], bytes]) -> str:
    """Digest of ``produce(path)``, memoized on the file's ``(mtime_ns, size)``.

    Falls back to computing without memoizing when the path cannot be
    stat-ed, so a caller that hands over a virtual/packaged resource
    still gets a correct (just uncached) answer. ``produce`` is part of
    the memo key so two readings of the same file don't alias.
    """
    memo_key = (path, produce.__name__)
    stamp = _file_stamp(path)
    if stamp is not None:
        cached = _STAMPED_DIGESTS.get(memo_key)
        if cached is not None and cached[0] == stamp:
            return cached[1]
    digest = hashlib.blake2b(produce(path), digest_size=16).hexdigest()
    if stamp is not None:
        _STAMPED_DIGESTS[memo_key] = (stamp, digest)
    return digest


def _raw_bytes(path: str) -> bytes:
    return Path(path).read_bytes()


def _canonical_bytes(path: str) -> bytes:
    return _canonical_json_bytes(Path(path).read_bytes())


# ---------------------------------------------------------------------------
# Toolchain identity
# ---------------------------------------------------------------------------


def _info_file_fields(path: str, keys: Tuple[str, ...]) -> Optional[str]:
    """Extract ``key=value`` lines from a CANN ``*.info`` file, in order."""
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    found: Dict[str, str] = {}
    for line in text.splitlines():
        name, sep, value = line.partition("=")
        if sep and name.strip() in keys:
            found[name.strip()] = value.strip()
    if not found:
        return None
    return ",".join(f"{k}={found[k]}" for k in keys if k in found)


def _cann_release_identity(ascend_home: Optional[str]) -> str:
    """Content-derived CANN release identity, or a machine-local fallback.

    ``ascend_toolkit_install.info`` carries ``version`` (e.g. ``9.2.0``)
    and ``innerversion`` (e.g. ``V100R001C11B104``) — the pair identifies
    one CANN build, independent of where it was unpacked. That matters
    because the AscendC headers under ``ASCEND_HOME_PATH`` feed every
    compile: the old key used the absolute install path, which made a
    shared disk cache miss on every machine.
    """
    if not ascend_home:
        return "<unset>"

    from cannbotdsl.core.toolchain.ascendc import _host_sdk_directory

    candidates = []
    host_dir = _host_sdk_directory()
    if host_dir:
        candidates.append(
            (os.path.join(ascend_home, host_dir, "ascend_toolkit_install.info"), ("version", "innerversion"))
        )
    candidates.append((os.path.join(ascend_home, "compiler", "version.info"), ("Version",)))

    for path, keys in candidates:
        fields = _info_file_fields(path, keys)
        if fields:
            return fields

    # No release marker: degrade to a machine-local identity rather than
    # pretending two unidentified installs are the same one.
    return f"local-only:{ascend_home}"


def _bisheng_identity(path: str) -> str:
    """First line of ``bisheng --version``, memoized on ``(mtime_ns, size)``.

    That line carries the compiler build timestamp and the clang/flang
    commit ids, so it identifies the binary without hashing 150 MB (a
    full content hash measured ~1.75 s). Later lines are dropped because
    ``InstalledDir:`` leaks the absolute prefix.

    Any failure degrades to a machine-local stamp so a shared cache
    partitions per machine instead of colliding across compilers.
    """

    def produce(p: str) -> bytes:
        try:
            proc = subprocess.run(
                [p, "--version"],
                capture_output=True,
                text=True,
                timeout=60,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            _LOG.debug("bisheng --version failed (%s); using a machine-local stamp", exc)
            return f"local-only:{_file_stamp(p)}".encode("utf-8")
        first = (proc.stdout or proc.stderr or "").strip().splitlines()
        if proc.returncode != 0 or not first:
            _LOG.debug("bisheng --version returned no usable output; using a machine-local stamp")
            return f"local-only:{_file_stamp(p)}".encode("utf-8")
        return first[0].strip().encode("utf-8")

    return _stamped_digest(path, produce)


def _toolchain_version() -> str:
    """Lazy-probed toolchain identity string.

    Uses the same resolver as compilation. The resolver itself is
    intentionally not cached — tests and long-running build processes may
    change toolchain environment variables between compilations — but the
    per-binary probes behind it are memoized on ``(mtime_ns, size)``.
    """
    from cannbotdsl.core.toolchain.ascendc import resolve_bisheng

    resolution = resolve_bisheng(required=False)
    parts = [f"cann={_cann_release_identity(resolution.ascend_home)}"]
    if resolution.path:
        stamp = _file_stamp(resolution.path)
        parts.append(f"bisheng_size={stamp[1] if stamp else '<stat-error>'}")
        parts.append(f"bisheng={_bisheng_identity(resolution.path)}")
    else:
        parts.append("bisheng=<not-found>")
    return "|".join(parts)


def _runtime_identity() -> str:
    """Identify the wheel native runtime.

    ``_build_info.json`` is generated for wheel and editable builds and may
    grow additional native artifact hashes without requiring another cache
    key schema change.
    """

    hasher = hashlib.blake2b(digest_size=16)
    build_info = importlib_resources.files("cannbotdsl").joinpath("_build_info.json")
    if build_info.is_file():
        hasher.update(b"build-info=")
        try:
            digest = _stamped_digest(str(build_info), _canonical_bytes)
        except (UnicodeError, json.JSONDecodeError):
            # Preserve deterministic invalidation even for malformed metadata;
            # packaging validation reports the malformed file separately.
            digest = _stamped_digest(str(build_info), _raw_bytes)
        hasher.update(digest.encode("utf-8"))
    else:
        hasher.update(b"build-info=<source-tree-unversioned>")

    return hasher.hexdigest()


def _env_snapshot() -> Dict[str, Any]:
    """Extract key-affecting fields from a fresh cannbotdsl env snapshot.

    Walks ``vars(env())`` and skips anything in ``_KEY_IGNORED_ENV``.
    """
    from cannbotdsl.core.utils.env import env

    snap: Dict[str, Any] = {}
    for k, v in vars(env()).items():
        if k in _KEY_IGNORED_ENV:
            continue
        snap[k] = v
    return snap


class _KeyComposer:
    """Length-prefix named byte sections into one fixed-size digest."""

    def __init__(self) -> None:
        self._digest = hashlib.sha256()

    def add(self, name: str, payload: bytes) -> None:
        encoded_name = name.encode("utf-8")
        self._digest.update(struct.pack(">I", len(encoded_name)))
        self._digest.update(encoded_name)
        self._digest.update(struct.pack(">Q", len(payload)))
        self._digest.update(payload)

    def hexdigest(self) -> str:
        return self._digest.hexdigest()


def _stable_json_value(value: Any, *, path: str) -> Any:
    """Convert option-domain values to a path- and repr-free JSON tree."""

    if value is None or type(value) in {bool, int, float, str}:
        return value
    if isinstance(value, Enum):
        value_type = type(value)
        return {
            "enum": f"{value_type.__module__}.{value_type.__qualname__}",
            "name": value.name,
        }
    if isinstance(value, (tuple, list)):
        return [_stable_json_value(item, path=f"{path}[{index}]") for index, item in enumerate(value)]
    if isinstance(value, (set, frozenset)):
        items = [_stable_json_value(item, path=f"{path}[]") for item in value]
        return sorted(
            items,
            key=lambda item: json.dumps(
                item,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ),
        )
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            if type(key) is not str:
                raise TypeError(f"{path} option keys must be strings, got {key!r}")
            result[key] = _stable_json_value(item, path=f"{path}.{key}")
        return result
    raise TypeError(f"{path} contains unsupported option value {type(value).__name__}")


def _encode_options(snapshot: Dict[str, Any], *, path: str) -> bytes:
    if not isinstance(snapshot, dict):
        raise TypeError(f"{path} must be a dict")
    tree = _stable_json_value(snapshot, path=path)
    return json.dumps(
        tree,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _encode_env_snapshot(snapshot: Dict[str, Any]) -> bytes:
    """Encode an environment snapshot as canonical logical JSON."""

    return _encode_options(snapshot, path="environment")


def _compute_key(
    module: ir.Module,
    *,
    runtime_identity: str,
    contract=None,
    env_snapshot: Optional[Dict[str, Any]] = None,
    compile_options: Optional[Dict[str, Any]] = None,
    target: Optional[str] = None,
    toolchain: Optional[str] = None,
) -> str:
    """Compose the SHA-256 cache key for verified IR plus its call contract.

    Caller is responsible for passing a module that has already been
    ``operation.verify()``-ed — invalid IR will still produce a stable
    bytecode but storing such an entry is meaningless.
    """
    composer = _KeyComposer()

    buf = io.BytesIO()
    module.operation.write_bytecode(buf)
    composer.add("verified-ir", buf.getvalue())

    if contract is None:
        contract_payload = b""
    else:
        from cannbotdsl.core.contracts.codec import canonical_contract_bytes

        contract_payload = canonical_contract_bytes(contract)
    composer.add("call-contract", contract_payload)

    snap = env_snapshot if env_snapshot is not None else _env_snapshot()
    composer.add("environment", _encode_env_snapshot(snap))
    options = compile_options if compile_options is not None else {}
    composer.add(
        "compile-options",
        _encode_options(options, path="compile-options"),
    )
    target_identity = target if target is not None else str(snap.get("npu_arch", "<unspecified>"))
    composer.add("target", target_identity.encode("utf-8"))

    composer.add("runtime", runtime_identity.encode("utf-8"))

    tc = toolchain if toolchain is not None else _toolchain_version()
    composer.add("toolchain", tc.encode("utf-8"))

    composer.add("format", _FORMAT_VERSION_TAG.encode("utf-8"))
    user_tag = os.environ.get("CANNBOTDSL_CACHE_FORMAT_TAG", "")
    composer.add("user-format", user_tag.encode("utf-8"))

    return composer.hexdigest()
