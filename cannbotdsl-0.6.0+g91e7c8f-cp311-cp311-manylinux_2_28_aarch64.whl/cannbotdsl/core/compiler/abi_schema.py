# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Host ABI derivation and marshalling from logical argument contracts."""

from __future__ import annotations

from cannbotdsl.core.compiler.marshalling import make_kernel_arg_struct
from cannbotdsl.core.compiler.physical_abi import physical_argument
from cannbotdsl.core.contracts.elements import element_for_tag
from cannbotdsl.core.contracts.model import (
    ScalarContract,
    StructContract,
    StructRefContract,
    TensorContract,
)


def ctypes_type(argument):
    argument = physical_argument(argument)
    if isinstance(argument, TensorContract):
        info = element_for_tag(argument.element)
        storage = argument.storage_encoding
        return make_kernel_arg_struct(
            info.cpp_name,
            argument.rank,
            encoding=(
                "identity" if storage is None else storage.encoding
            ),
            physical_rank=(
                argument.rank
                if storage is None
                else len(storage.physical_shape)
            ),
        )
    if isinstance(argument, ScalarContract):
        info = element_for_tag(argument.element)
        if info.scalar_ctype is None:
            raise TypeError(
                f"dtypes.{info.dtype.name} has no supported standalone scalar ABI"
            )
        return info.scalar_ctype
    if isinstance(argument, StructContract):
        from cannbotdsl.types.datastruct import _make_ctypes_struct

        return _make_ctypes_struct(argument.schema)
    if isinstance(argument, StructRefContract):
        return make_kernel_arg_struct("uint8_t", 1)
    raise TypeError(f"unknown ABI argument contract {argument!r}")


__all__ = ["ctypes_type"]
