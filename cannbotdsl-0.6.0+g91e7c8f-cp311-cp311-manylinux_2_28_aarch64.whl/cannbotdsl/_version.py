# Generated from the distribution metadata; do not edit.
__version__ = "0.6.0+g91e7c8f"
