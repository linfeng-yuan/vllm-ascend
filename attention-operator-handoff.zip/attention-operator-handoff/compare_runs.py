import argparse
import csv
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("baseline", type=Path)
p.add_argument("candidates", type=Path, nargs="+")
p.add_argument("--output", type=Path, default=Path("comparison.csv"))
p.add_argument(
    "--check-outputs",
    action="store_true",
    help="Optional cross-version comparison; not an independent golden",
)
a = p.parse_args()
rows = []
for candidate in a.candidates:
    for case in ["c2", "c1", "swa", "dspark_swa"]:
        old_path, new_path = a.baseline / (case + ".json"), candidate / (case + ".json")
        if not old_path.exists() or not new_path.exists():
            print("SKIP missing case", case, a.baseline, candidate)
            continue
        old, new = json.loads(old_path.read_text()), json.loads(new_path.read_text())
        old_hashes = [b["input_sha256"] for b in old["banks"]]
        new_hashes = [b["input_sha256"] for b in new["banks"]]
        if old_hashes != new_hashes:
            raise RuntimeError(
                f"{case}: input fingerprints differ; refusing a performance ratio"
            )
        row = {
            "case": case,
            "baseline": old["label"],
            "candidate": new["label"],
            "baseline_median_us": old["median_us"],
            "candidate_median_us": new["median_us"],
            "duration_change_pct": (new["median_us"] / old["median_us"] - 1) * 100,
            "baseline_fd": str([b["fd_used_vec_num"] for b in old["banks"]]),
            "candidate_fd": str([b["fd_used_vec_num"] for b in new["banks"]]),
            "same_inputs": True,
            "output_check": "not requested",
        }
        if a.check_outputs:
            import torch

            x = torch.load(
                a.baseline / (case + ".outputs.pt"),
                map_location="cpu",
                weights_only=True,
            )
            y = torch.load(
                candidate / (case + ".outputs.pt"),
                map_location="cpu",
                weights_only=True,
            )
            assert len(x) == len(y)
            maximum = max(
                (s.float() - t.float()).abs().max().item() for s, t in zip(x, y)
            )
            close = all(
                torch.allclose(s.float(), t.float(), rtol=0.02, atol=0.002)
                for s, t in zip(x, y)
            )
            row["output_check"] = (
                f"allclose={close}, max_abs={maximum}, rtol=.02, atol=.002; cross-version only"
            )
        rows.append(row)
        print(json.dumps(row))
if not rows:
    raise RuntimeError("No matching result files")
with a.output.open("w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)
