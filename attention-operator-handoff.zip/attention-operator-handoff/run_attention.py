"""Single-device attention isolation; no vLLM, QLI, QSLI or MoE in timing."""

import argparse
import gc
import hashlib
import importlib
import importlib.metadata
import json
import math
import os
import random
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "cases.json").read_text())


def plan(case, length, seed, batch=8, q_per_request=None):
    qn = q_per_request or case["queries_per_request"]
    ratio = case["compression_ratio"]
    draft = case["name"] == "dspark_swa"
    assert length >= 1024 and length >= qn + 128
    assert not draft or qn == 5, "DSpark reproducer requires five draft rows/request"
    rng = random.Random(seed)
    original, compressed, positions = [], [], []
    for request in range(batch):
        for row in range(qn):
            pos = length - qn + row
            positions.append(pos)
            ids = (
                list(range(length - qn - 128, length))
                if draft
                else list(range(pos - 127, pos + 1))
            )
            original.append(ids + [-1] * (case["original_index_width"] - len(ids)))
            if ratio:
                compressed.append(rng.sample(range((pos + 1) // ratio), 512))
    return {
        "q_shape": [batch * qn, 64, 512],
        "batch": batch,
        "q_per_request": qn,
        "cu_seqlens_q": list(range(0, batch * qn + 1, qn)),
        "seq_ori": [length] * batch,
        "seq_cmp": [length // ratio] * batch if ratio else None,
        "positions": positions,
        "original_indices": original,
        "compressed_indices": compressed or None,
        "original_visible": 133 if draft else 128,
        "original_index_width": case["original_index_width"],
        "compressed_visible": 512 if ratio else 0,
        "compressed_page_size": case["compressed_page_size"],
    }


def check_plan(p):
    for row, ids in enumerate(p["original_indices"]):
        valid = [x for x in ids if x >= 0]
        assert len(valid) == p["original_visible"] and len(set(valid)) == len(valid)
        assert min(valid) >= 0 and max(valid) < p["seq_ori"][0]
        if p["original_visible"] == 128:
            assert valid[-1] == p["positions"][row]
        else:
            assert valid[-1] == p["seq_ori"][0] - 1
    if p["compressed_indices"]:
        ratio = 128 // p["compressed_page_size"]
        for row, ids in enumerate(p["compressed_indices"]):
            assert len(ids) == len(set(ids)) == 512
            assert max(ids) < (p["positions"][row] + 1) // ratio


def module(name):
    for suffix in ("", "_dsl"):
        full = "ops." + name + suffix
        try:
            return importlib.import_module(full)
        except ModuleNotFoundError as error:
            if error.name not in (full, "ops"):
                raise
    raise ImportError("Cannot find packaged operator ops." + name)


def fingerprint(tensor, digest):
    digest.update(str((list(tensor.shape), str(tensor.dtype))).encode())
    digest.update(memoryview(tensor.contiguous().view(torch.uint8).numpy()).cast("B"))


def packed_cache(
    batch,
    tokens,
    page,
    fp4,
    generator,
    padding,
    digest,
    page_stride_bytes=0,
    table_width=0,
):
    pages = math.ceil(tokens / page)
    row_bytes, code_bytes = (320, 256) if fp4 else (544, 512)
    stride = page_stride_bytes or (page * row_bytes + padding)
    assert stride >= page * row_bytes, "Page stride is smaller than logical page bytes"
    storage = torch.zeros((batch * pages, stride), dtype=torch.uint8)
    view = storage.as_strided(
        (batch * pages, page, 1, row_bytes), (stride, row_bytes, row_bytes, 1)
    )
    for first in range(0, batch * pages, 64):
        target = view[first : first + 64]
        shape = (*target.shape[:-1], code_bytes)
        if fp4:
            codes = torch.randint(0, 256, shape, generator=generator, dtype=torch.uint8)
        else:
            codes = (
                (torch.randn(shape, generator=generator) * 0.25)
                .to(torch.float8_e4m3fn)
                .view(torch.uint8)
            )
        target[..., :code_bytes].copy_(codes)
        scales = torch.full(
            (*target.shape[:-1], 32 if fp4 else 16), 0.25, dtype=torch.bfloat16
        )
        target[..., code_bytes:].copy_(scales.view(torch.uint8))
    # Random physical page assignment, shared across versions through the seed.
    table = (
        torch.randperm(batch * pages, generator=generator).reshape(batch, pages).int()
    )
    if table_width:
        assert table_width >= pages
        wide = torch.zeros((batch, table_width), dtype=torch.int32)
        wide[:, :pages].copy_(table)
        table = wide
    fingerprint(storage, digest)
    fingerprint(table, digest)
    device_storage = storage.to("npu")
    device_view = device_storage.as_strided(view.shape, view.stride())
    return device_view, table.to("npu")


def make_inputs(case, args, bank):
    seed = args.seed + bank
    p = plan(
        case, args.kv_len + args.decode_offset, seed, args.batch, args.q_per_request
    )
    check_plan(p)
    network_layout = getattr(args, "layout", "compact") == "network"
    stride_override = getattr(args, "page_stride_bytes", None)
    original_stride = (
        stride_override
        if stride_override is not None
        else (case["original_page_stride_bytes"] if network_layout else 0)
    )
    compressed_stride = (
        stride_override
        if stride_override is not None
        else ((case["compressed_page_stride_bytes"] or 0) if network_layout else 0)
    )
    table_width = getattr(args, "block_table_width", None)
    if table_width is None:
        table_width = case["block_table_width"] if network_layout else 0
    g = torch.Generator().manual_seed(seed)
    digest = hashlib.sha256(json.dumps(p, sort_keys=True).encode())
    q = (torch.randn(p["q_shape"], generator=g) * 0.25).bfloat16()
    sinks = torch.randn(64, generator=g)
    fingerprint(q, digest)
    fingerprint(sinks, digest)
    ori, ori_table = packed_cache(
        p["batch"],
        p["seq_ori"][0],
        128,
        False,
        g,
        args.page_padding,
        digest,
        original_stride,
        table_width,
    )
    if case["compression_ratio"]:
        cmp, cmp_table = packed_cache(
            p["batch"],
            p["seq_cmp"][0],
            p["compressed_page_size"],
            True,
            g,
            args.page_padding,
            digest,
            compressed_stride,
            table_width,
        )
    else:
        cmp, cmp_table = None, None

    def ints(value):
        return (
            torch.tensor(value, dtype=torch.int32, device="npu")
            if value is not None
            else None
        )

    q = q.to("npu")
    ol = torch.full(
        (q.shape[0], 1), p["original_visible"], dtype=torch.int32, device="npu"
    )
    cl = torch.full_like(ol, p["compressed_visible"])
    cu = ints(p["cu_seqlens_q"])
    # This is the ONLY metadata build. Its execution completes before warmup.
    metadata = md.mixed_quant_sparse_flash_mla_metadata(
        ol,
        cl,
        cu_seqlens_q=cu,
        num_heads_q=64,
        num_heads_kv=1,
        head_dim=512,
        quant_mode=1,
        layout_q="TND",
        layout_kv="PA_BBND",
        has_ori_kv=True,
        has_cmp_kv=case["compression_ratio"] != 0,
    )
    torch.npu.synchronize()
    metadata_cpu = metadata.cpu()
    fd_index = getattr(md, "FD_USED_VEC_NUM_WORD", None)
    fd_used = int(metadata_cpu.flatten()[fd_index]) if fd_index is not None else None
    kwargs = {
        "q": q,
        "ori_kv": ori,
        "cmp_kv": cmp,
        "ori_sparse_indices": ints(p["original_indices"]).unsqueeze(1),
        "cmp_sparse_indices": ints(p["compressed_indices"]).unsqueeze(1)
        if cmp is not None
        else None,
        "ori_block_table": ori_table,
        "cmp_block_table": cmp_table,
        "cu_seqlens_q": cu,
        "seqused_ori_kv": ints(p["seq_ori"]),
        "seqused_cmp_kv": ints(p["seq_cmp"]),
        "ori_topk_length": ol,
        "cmp_topk_length": cl if cmp is not None else None,
        "sinks": sinks.to("npu"),
        "metadata": metadata,
        "quant_mode": 1,
        "softmax_scale": 512**-0.5,
        "layout_q": "TND",
        "layout_kv": "PA_BBND",
        "return_softmax_lse": False,
        "out": torch.empty_like(q),
        "lse": torch.empty((0,), dtype=torch.float32, device="npu"),
    }
    info = {
        k: v
        for k, v in p.items()
        if k not in ("original_indices", "compressed_indices", "positions")
    }
    info.update(
        input_sha256=digest.hexdigest(),
        fd_used_vec_num=fd_used,
        metadata_words=metadata_cpu.flatten().tolist(),
        tensors={
            k: {
                "shape": list(v.shape),
                "stride": list(v.stride()),
                "dtype": str(v.dtype),
            }
            for k, v in kwargs.items()
            if isinstance(v, torch.Tensor)
        },
    )
    return kwargs, info


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--case", choices=["all", "c2", "c1", "swa", "dspark_swa"], default="all"
    )
    parser.add_argument("--label", default="unlabelled")
    parser.add_argument("--output", type=Path, default=Path("results/run"))
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--kv-len", type=int, default=131072)
    parser.add_argument("--decode-offset", type=int, default=0)
    parser.add_argument("--batch", type=int, default=8)
    parser.add_argument("--q-per-request", type=int)
    parser.add_argument("--page-padding", type=int, choices=[0, 64], default=0)
    parser.add_argument("--layout", choices=["network", "compact"], default="network")
    parser.add_argument(
        "--page-stride-bytes",
        type=int,
        default=None,
        help="Physical page stride from PD runtime; 0 selects compact pages",
    )
    parser.add_argument(
        "--block-table-width",
        type=int,
        default=None,
        help="Physical table width from PD runtime; 0 uses logical required width",
    )
    parser.add_argument("--seed", type=int, default=20261102)
    parser.add_argument("--banks", type=int, default=1)
    parser.add_argument("--warmup", type=int, default=20)
    parser.add_argument("--calls-per-graph", type=int, default=40)
    parser.add_argument("--repeats", type=int, default=20)
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--describe", action="store_true")
    args = parser.parse_args()
    assert args.page_stride_bytes is None or args.page_stride_bytes >= 0
    assert args.block_table_width is None or args.block_table_width >= 0
    assert not (
        args.page_padding and (args.layout == "network" or args.page_stride_bytes)
    )
    assert args.batch > 0 and args.banks > 0 and args.repeats >= 3 and args.warmup >= 1
    assert args.q_per_request is None or args.q_per_request > 0
    assert args.decode_offset >= 0 and args.calls_per_graph >= args.banks
    assert args.calls_per_graph % args.banks == 0
    cases = [c for c in CONFIG["cases"] if args.case in ("all", c["name"])]
    if args.describe:
        for case in cases:
            p = plan(
                case,
                args.kv_len + args.decode_offset,
                args.seed,
                args.batch,
                args.q_per_request,
            )
            check_plan(p)
            print(
                json.dumps(
                    {
                        "case": case["name"],
                        **{
                            k: v
                            for k, v in p.items()
                            if not k.endswith("indices") and k != "positions"
                        },
                    },
                    indent=2,
                )
            )
        return
    args.output.mkdir(parents=True, exist_ok=False)
    os.environ["CANNBOTDSL_NATIVE_BINARY_REPORT"] = str(
        args.output.resolve() / "native-dispatch.json"
    )
    global torch, md
    import torch
    import torch_npu

    torch.set_num_threads(4)
    torch.npu.set_device(args.device)
    op_module = module("mixed_quant_sparse_flash_mla")
    md = module("mixed_quant_sparse_flash_mla_metadata")
    device = torch.npu.get_device_properties(args.device)
    provenance = {
        "label": args.label,
        "arguments": {
            k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()
        },
        "packages": {
            d.metadata["Name"]: d.version
            for d in importlib.metadata.distributions()
            if "cannbot" in d.metadata["Name"].lower()
            or d.metadata["Name"].lower() in ("torch", "torch_npu")
        },
        "operator_file": op_module.__file__,
        "metadata_file": md.__file__,
        "device": str(device),
        "cube_core_num": getattr(device, "cube_core_num", None),
        "native_binary_mode_env": os.environ.get("CANNBOTDSL_NATIVE_BINARY_MODE"),
        "fd_policy": {
            k: getattr(md, k, None) for k in ("SUPPORT_FD", "SELECTIVE_FD_72")
        },
    }
    (args.output / "provenance.json").write_text(json.dumps(provenance, indent=2))
    for case in cases:
        banks = [make_inputs(case, args, bank) for bank in range(args.banks)]
        for bank_kwargs, bank_info in banks:
            address_args = [
                bank_kwargs[k]
                for k in (
                    "ori_kv",
                    "ori_block_table",
                    "ori_sparse_indices",
                    "cmp_kv",
                    "cmp_block_table",
                    "cmp_sparse_indices",
                )
            ]
            if hasattr(op_module, "_select_addr_mode"):
                bank_info["address_mode"] = op_module._select_addr_mode(*address_args)
            elif hasattr(op_module, "_addr_vec_eligible"):
                bank_info["address_mode"] = (
                    "pre" if op_module._addr_vec_eligible(*address_args) else "off"
                )
            else:
                bank_info["address_mode"] = "unknown"

        def call(i, case_banks=banks):
            op_module.mixed_quant_sparse_flash_mla(**case_banks[i % args.banks][0])

        for i in range(args.warmup * args.banks):
            call(i)
        torch.npu.synchronize()
        for kwargs, _ in banks:
            assert torch.isfinite(kwargs["out"]).all().item(), "Nonfinite output"
        torch.save(
            [kwargs["out"].cpu() for kwargs, _ in banks],
            args.output / (case["name"] + ".outputs.pt"),
        )
        graph = torch.npu.NPUGraph()
        with torch.npu.graph(graph):
            for i in range(args.calls_per_graph):
                call(i)
        for _ in range(3):
            graph.replay()
        torch.npu.synchronize()
        samples = []
        for _ in range(args.repeats):
            start, end = (
                torch.npu.Event(enable_timing=True),
                torch.npu.Event(enable_timing=True),
            )
            start.record()
            graph.replay()
            end.record()
            end.synchronize()
            samples.append(start.elapsed_time(end) * 1000 / args.calls_per_graph)
        result = {
            "case": case["name"],
            "label": args.label,
            "metadata_in_timing": False,
            "method": "NPU event time per graph replay / calls; kernel_details.csv is the kernel-only authority",
            "median_us": statistics.median(samples),
            "samples_us": samples,
            "banks": [info for _, info in banks],
        }
        (args.output / (case["name"] + ".json")).write_text(
            json.dumps(result, indent=2)
        )
        print(json.dumps({k: v for k, v in result.items() if k != "banks"}), flush=True)
        if args.profile:
            with torch_npu.profiler.profile(
                activities=[
                    torch_npu.profiler.ProfilerActivity.CPU,
                    torch_npu.profiler.ProfilerActivity.NPU,
                ],
                schedule=torch_npu.profiler.schedule(
                    wait=0, warmup=1, active=1, repeat=1
                ),
                with_stack=False,
                record_shapes=True,
                experimental_config=torch_npu.profiler._ExperimentalConfig(
                    profiler_level=torch_npu.profiler.ProfilerLevel.Level1
                ),
                on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(
                    str(args.output / ("profile-" + case["name"]))
                ),
            ) as profiler:
                for _ in range(2):
                    for _ in range(10):
                        graph.replay()
                    torch.npu.synchronize()
                    profiler.step()
        del graph, banks, call, kwargs, bank_kwargs, bank_info
        gc.collect()
        torch.npu.empty_cache()


if __name__ == "__main__":
    main()
