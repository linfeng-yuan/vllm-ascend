from pathlib import Path

_native = Path(__file__).with_name('_native')
if _native.is_dir() and not (_native / 'mqsmla_standalone.json').is_file():
    from cannbotdsl.package.native import register_resources

    register_resources(__package__, '_native')
