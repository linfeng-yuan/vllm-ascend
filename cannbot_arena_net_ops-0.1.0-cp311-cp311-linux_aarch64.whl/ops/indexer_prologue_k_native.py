"""Native AOT signatures for :mod:`ops.indexer_prologue_k`.

The exported binaries keep the deployment model shape (H, D, Dr) and the
storage layout static, while the token count and the whole cache geometry
are dynamic ``Dim`` axes. One variant per storage configuration therefore
covers every ``T``/cache size at runtime. Model shapes or layouts not
listed here continue through CANNBotDSL's normal Native ``prefer`` fallback
and are JIT-compiled on first use.
"""

from cannbotdsl.package.native import register

from .indexer_prologue_k import (
    _AOT_CALLABLE_CACHE,
    _FUSED_AOT_CALLABLE_CACHE,
    _get_fused_pipeline_callable,
)


def _close_aot_callables():
    """Release Provider callables retained by the Python JIT caches."""
    for cache in (_FUSED_AOT_CALLABLE_CACHE, _AOT_CALLABLE_CACHE):
        for compiled in cache.values():
            close = getattr(compiled, "close", None)
            if callable(close):
                close()
        cache.clear()


@register("indexer_prologue_k")
def export_indexer_prologue_k():
    """Export the four storage layouts used by the ACLGraph validation suite.

    Each variant is compiled against dynamic token/cache axes, so the four
    binaries serve every deployment ``T``, block count, slot count, and
    axis-0/1 cache stride for the exported model shape.
    """
    variants = (
        # storage_mode, combined_block_size, write_scale_cache
        (0, -1, True),
        (0, -1, False),
        (1, 4, False),
        (1, 8, False),
    )
    try:
        for storage_mode, group_size, write_scale_cache in variants:
            _get_fused_pipeline_callable(
                head_dim=512,
                index_head_dim=128,
                rope_head_dim=64,
                storage_mode=storage_mode,
                combined_block_size=group_size,
                write_scale_cache=write_scale_cache,
            )
    finally:
        _close_aot_callables()
