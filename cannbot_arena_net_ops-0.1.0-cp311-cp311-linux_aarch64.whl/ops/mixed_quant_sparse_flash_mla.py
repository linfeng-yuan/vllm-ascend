import math
import os
import threading
import cannbotdsl
import torch

from cannbotdsl.channel import Channel
from cannbotdsl.lang.constexpr import const_expr, range_constexpr
from cannbotdsl.types.delay_line import DelayLineGroup
from cannbotdsl.ops.arch import get_subblock_id, get_block_idx, get_subblock_dim
from cannbotdsl import select as dyn_select
from cannbotdsl.types._integer import Int32, Int64
from cannbotdsl import dtypes
from cannbotdsl import ProfileSpec
from cannbotdsl.lang.jit import jit
from cannbotdsl.lang.kernel import kernel
from cannbotdsl.ops.matmul import matmul
from cannbotdsl.ops.memcpy import make_copy_engine, mem_copy
from cannbotdsl import ChannelKind, MemLoc, PIPE, Tensor
from cannbotdsl.tensor import (
    ceil_div,
    tile_slice,
    reinterpret,
)
from cannbotdsl.buffer import Buffer
from cannbotdsl.lang.vf import vf
from cannbotdsl.ops.sync import (
    cube_raw_l1_to_l0a,
    cube_sync_block_arrive,
    cube_sync_notify,
    cube_sync_wait,
    cube_sync_intra_wait,
    global_sync_all,
    vec_sync_block_wait,
    vec_sync_all,
    vec_busy_wait,
    vec_sync_intra_arrive,
    vec_sync_notify,
    vec_sync_wait,
)
from cannbotdsl.ops.sync import channel_rewind
from cannbotdsl.ops.scalar import vec_store_bypass
from cannbotdsl.ops import reg as rr

# Metadata constants and public host entry are re-exported from the metadata module.
if __package__:
    from .mixed_quant_sparse_flash_mla_metadata import (
        AIC_CORE_MAX_NUM, MQSMLA_METADATA_TOTAL_SIZE, FA_METADATA_SIZE,
        FA_BN2_START_INDEX, FA_M_START_INDEX, FA_S2_START_INDEX,
        FA_BN2_END_INDEX, FA_M_END_INDEX, FA_S2_END_INDEX,
        FA_FIRST_FD_DATA_WORKSPACE_IDX_INDEX, FD_METADATA_BASE, FD_METADATA_SIZE,
        FD_CORE_ENABLE_INDEX, FD_BN2_IDX_INDEX, FD_M_IDX_INDEX, FD_WORKSPACE_IDX_INDEX,
        FD_WORKSPACE_NUM_INDEX, FD_M_START_INDEX, FD_USED_VEC_NUM_WORD,
        _get_cube_core_num, mixed_quant_sparse_flash_mla_metadata,
    )
else:
    from mixed_quant_sparse_flash_mla_metadata import (
        AIC_CORE_MAX_NUM, MQSMLA_METADATA_TOTAL_SIZE, FA_METADATA_SIZE,
        FA_BN2_START_INDEX, FA_M_START_INDEX, FA_S2_START_INDEX,
        FA_BN2_END_INDEX, FA_M_END_INDEX, FA_S2_END_INDEX,
        FA_FIRST_FD_DATA_WORKSPACE_IDX_INDEX, FD_METADATA_BASE, FD_METADATA_SIZE,
        FD_CORE_ENABLE_INDEX, FD_BN2_IDX_INDEX, FD_M_IDX_INDEX, FD_WORKSPACE_IDX_INDEX,
        FD_WORKSPACE_NUM_INDEX, FD_M_START_INDEX, FD_USED_VEC_NUM_WORD,
        _get_cube_core_num, mixed_quant_sparse_flash_mla_metadata,
    )

# Address precomputation uses fixed-capacity UB and runtime K/page-table widths.
# Dense power-of-two pages use vector addressing; other layouts use scalar addressing.
# The page128 template fixes its stride; other eligible page sizes remain symbolic.
_ADDR_VEC_OVERRIDE = None


def _addr_vec_mode():
    return _ADDR_VEC_OVERRIDE or "pre"


def _addr_vec_eligible(ori_kv, ori_bt, ori_idx, cmp_kv, cmp_bt, cmp_idx):
    """Select a bounded vector algorithm, independently of exact S2/K values.

    Power-of-two pages and dense page strides make the row-number mapping exact.
    Fixed UB capacities bound staging; all remaining layouts share scalar AOT.
    """
    def pool_ok(kv, row_bytes):
        bs = kv.shape[1]
        return (isinstance(bs, int) and bs >= 16 and bs & (bs - 1) == 0
                and kv.stride(0) == bs * row_bytes)

    if not isinstance(ori_bt.shape[1], int) or not isinstance(ori_idx.shape[2], int):
        return False
    ok = pool_ok(ori_kv, KV_ROW_BYTES_ORI)
    btp_c, k2 = None, None
    if cmp_kv is not None:
        if not isinstance(cmp_bt.shape[1], int) or not isinstance(cmp_idx.shape[2], int):
            return False
        ok_c = pool_ok(cmp_kv, KV_ROW_BYTES_CMP)
        ok = ok and ok_c
        btp_c, k2 = cmp_bt.shape[1], cmp_idx.shape[2]
    btp = ori_bt.shape[1] if cmp_kv is None else max(ori_bt.shape[1], btp_c)
    sp_w = ori_idx.shape[2] if cmp_kv is None else max(ori_idx.shape[2], k2)
    ok = ok and btp <= _ADDR_BT_CAPACITY and sp_w <= _ADDR_K_CAPACITY
    return ok


# _NZ_CHUNK 是 face 间距（BF16 元素数）；padding 只存在于 UB，copy-out 时跳过。
_NZ_ROW = 16
_NZ_PAD_ROWS = 17
_NZ_CHUNK = _NZ_PAD_ROWS * _NZ_ROW
# 输出落地手动同步的 HardEvent id（与 sync_intra id / sync_block flag id 空间相互独立）：
# finalize 的 cast(V) → out 拷贝(MTE3) 只需这一对「MTE3 等 V」；空行路径（drain 段连续
# 写零、无 AIC 生产链门控）在覆写前额外补一对「V 等 MTE3」排空上一笔出拷贝。
_OUT_V_TO_MTE3_EVENT_ID = 0
_OUT_MTE3_TO_V_EVENT_ID = 1
_FD_READY_BASE = FD_USED_VEC_NUM_WORD + 1
_FD_ASYNC_MODE_WORD = FD_USED_VEC_NUM_WORD + 50

# Address-prepass buffers are reclaimed after the block handshake.
# Main-loop and FD reduction buffers reuse UB at separate phases.
# Ascend950 exposes 248 KiB usable UB. The address phase has exactly three
# int32 buffers: BT + K + round16(K); none survives the synchronized rewind.
# BT=16384 keeps every logical index below 2**24 for all supported BS<=1024,
# so the generic template's int32 -> FP32 -> page-number conversion is exact.
# With that BT capacity, K=23552 is the largest 16-aligned capacity fitting UB:
# 4*16384 + 2*4*23552 = 253952 bytes (64 + 92 + 92 KiB).
_ADDR_BT_CAPACITY = 16384
_ADDR_K_CAPACITY = 23552

# Compile-time shape contract.
D = 512                  # 逻辑 head dim：nope 448 + rope 64（计算序 nope 在前）
N1 = 64                  # Q heads
N2 = 1                   # KV 头数（G=N1/N2=64）
TILE_N = 128             # n-tile：一个 s2 任务的 KV token 数

# ---- per-token-group 物理布局 ----
# 物理字节序 = nope[448] ‖ rope[64]；ori 每 32 元素、cmp 每 16 元素共享 1 个 BF16 scale。
# scale 内联在数据段尾、无 pad 字段，均以 uint8 字节视图传入：
#   ori_kv (FP8 E4M3)    544 B/token = 512B fp8 数据 + 32B scale
#   cmp_kv (FP4 E2M1 x2) 320 B/token = 256B fp4x2 数据（偶元素低 nibble）+ 64B scale
KV_ROW_BYTES_ORI = 544
KV_ROW_BYTES_CMP = 320
ROW_BF16_ORI = KV_ROW_BYTES_ORI // 2      # ori 池 bf16 视图行宽 272
SCALE_BF16_OFF_ORI = 256                  # scale 段在 ori 行内的 bf16 偏移（512B/2）
SCALE_BF16_OFF_CMP = 128                  # scale 段在 cmp 行内的 bf16 偏移（256B/2）

# FD workspace: normalized O slots followed by per-slot max/sum.
# Each core stages at most two partial rows: a leading continuation and a trailing split.
FD_SLOTS_PER_CORE = 2
FD_O_ELEMS = N1 * D                       # 每 slot O 区：64×512 fp32
FD_MS_ELEMS = 2 * N1                      # 每 slot max[64] + sum[64] fp32
FD_SLOT_ELEMS = FD_O_ELEMS + FD_MS_ELEMS  # 32896 fp32 = 131584 B
FD_BYTES_PER_CORE = FD_SLOTS_PER_CORE * FD_SLOT_ELEMS * 4  # 263168
WS_BYTES_PER_CORE = FD_BYTES_PER_CORE                    # 263168

# FD is selected solely by runtime metadata. Partial O is written directly
# from res_o; reduction storage reuses UB after the global barrier.
_FD_NEG_INF = -1.0e38
_FD_MP_SLOTS = AIC_CORE_MAX_NUM  # One row may span every launched Cube core.

# Dequantized KV is written directly from UB to the shared L1 ring.

# ori 侧派生偏移（kernel 侧缺省口径；cmp 侧在 `_vec0_body` 内按池分派）：
_ROW_BF16 = ROW_BF16_ORI          # ch_batch 槽行距 272 bf16（两池统一按 ori 的 544B 槽行距）
_SCALE_BF16_OFF = SCALE_BF16_OFF_ORI  # scale 段在 ori 槽行内的 bf16 偏移

_VL = 128                  # vec0 反量化的单笔向量宽度（bf16 lanes）
_TILE_ROWS = 16            # vec0 子块行数：一个 128-token tile 切 8 个 16 行子块（分形 face 高）
_ADDR_HALF = 64            # 地址向量化：VF 每批算的行号宽度（列宽 64 lane）
# Sentinel beyond every valid query index; prevents reads past the final cu_q span.
_ADDR_M_INF = 1 << 40


def _addr_tab_w(k):
    """Round K up to 16 columns; the prepass clamps padded columns to the last valid index."""
    return ((k + _TILE_ROWS - 1) // _TILE_ROWS) * _TILE_ROWS


def _copy_addr_to_gm(gm, ch, elem_off, n_elems):
    mem_copy(gm.view(gm.shape[0] * gm.shape[1])[elem_off:elem_off + n_elems,].view(1, n_elems),
             reinterpret(ch, shape=(1, n_elems)))


def _copy_addr_from_gm(ch, gm, elem_off, burst_bytes):
    count = burst_bytes // 4
    mem_copy(reinterpret(ch, shape=(1, count)),
             gm.view(gm.shape[0] * gm.shape[1])[elem_off:elem_off + count,].view(1, count))


def _i64(gm, *idx):
    raw = gm[idx] if len(idx) > 1 else gm[idx[0]]
    # GM 索引为 int32；在物理地址乘法前显式扩展到 int64。
    return dtypes.int64(raw)

class Kvcache:
    """PA_BBND 两级寻址（blockTable 值是全局物理块号，batch 只在下标上）：
    blk = s2_idx // blockSize; off = s2_idx % blockSize;
    phys_row = blockTable[bo][blk] * blockSize + off
    两侧均按运行时 blockSize 寻址，不要求页大小是 2 的幂。
    """

    @jit
    def _pa_blk_off(self, gm_block_table, s2_idx, bo_idx, bs):
        # Common page size avoids runtime division; all other sizes remain valid.
        blk = dtypes.int64(0)
        off = dtypes.int64(0)
        if bs == 128:
            blk = s2_idx // 128
            off = s2_idx % 128
        else:
            blk = s2_idx // bs
            off = s2_idx % bs
        return _i64(gm_block_table, bo_idx, blk), off

TILE = 128
D_TILES = D // TILE          # D=512 切 4 个 128 列 chunk（bmm1 的 K 轴 / bmm2 的 N 轴）

# ---- 每 AIC 的 L1 预算：K̃ 384 KiB + Q 96 KiB + p_l1 32 KiB = 512 KiB ----
# L1 K̃ 按 tick%3 轮转，消费范围覆盖 QK 和 PV。Q 按半 D 装载，在一个 M 内常驻，以事件保护代际轮转。
_KV_RING = 3                 # K̃ 环深度；一槽保存一份供 QK/PV 共读的 KV tile

_Q_RING = 3                  # Q Buffer 的 3 个 [64,256] BF16 半槽，共 96 KiB
_Q_SLOT_ELEMS = N1 * (D // 2)
_Q_CHUNK_ELEMS = N1 * TILE
_Q_EVENT_BASE = 3            # KV 使用 0..2；Q 三个物理半槽使用 3..5

_P_L1_DEPTH = 2              # p_l1 跨核 Channel 深度（AIV store_p → AIC bmm2）

# Eight cross-core Channel slots occupy sync ids 0..7. The address-table
# publication barrier uses id 9; AIV1's intra-core token is offset by 16.
_AIV1_ID_OFFSET = 16

_KV_NUM_PER_LOOP = 128
_TILE_SIZE = 64
_COMBINE_DIM = _ROW_BF16 * 2

class Matmul:
    """AIC 侧：把 Q/K̃ 装入 L1，完成 QK、PV 两次矩阵乘并经 fixpipe 送 AIV。

    q_wide 是包含 3 个 [64,256] BF16 半槽的 Buffer（96 KiB）。
    Q 每个 M 只加载一次，两个 K chunk 共读半槽；事件管理 MTE2/MTE1 同步。
    kv_ring 保存 3 份 [128,512] BF16 K̃（384 KiB），同一份数据依次用于 QK 和 PV，
    Channel 保护槽复用：PV 的 L1→L0B 装载结束后才允许 vec0 覆写。
    K̃ 由 vec0 反量化后经 strided mem_copy 直写 L1 的 NZ 槽。QK/PV 共用两个 [64,512] FP32 L0C 槽；
    同一个 Channel 管理写入、FIXPIPE 消费和跨迭代轮转，QK 只使用槽的前 128 列。
    """

    def __init__(self, tile_cube_m, tile_vec_m, tile_n):
        self.tile_cube_m = tile_cube_m
        self.tile_vec_m = tile_vec_m
        self.tile_n = tile_n
        self.tile_d = D

        self.nd2nz = make_copy_engine(format_transform="nd2nz")
        self.fixpipe = make_copy_engine(split_axis=0)

        # Q 按 M 常驻 L1：一代占连续两个半 D 槽，槽基 (2*m)%3。
        # 三槽 credit 保护下一 M 的 MTE2 覆写与上一 M 末 tile 的 MTE1 读取。
        self.q_wide = Buffer(MemLoc.L1, (tile_cube_m, _Q_RING * (D // 2)),
                             dtypes.bfloat16)
        self.kv_ring = Channel(MemLoc.L1, (tile_n, D), dtypes.bfloat16,
                               depth=_KV_RING, kind=ChannelKind.CrossCore)
        self.l0a = Channel(MemLoc.L0A, shape=(tile_cube_m, TILE), dtype=dtypes.bfloat16, depth=2)
        self.l0a_p = Channel(MemLoc.L0A, shape=(tile_cube_m, tile_n), dtype=dtypes.bfloat16, depth=2)
        self.l0b = Channel(MemLoc.L0B, shape=(TILE, TILE), dtype=dtypes.bfloat16, depth=2)
        # Shared two-slot L0C ring; matmul produces and FIXPIPE consumes.
        self.l0c = Channel(MemLoc.L0C, shape=(tile_cube_m, D), dtype=dtypes.float32,
                           depth=2, kind=ChannelKind.SameCore)

    @jit
    def _q_slot(self, m_seq, half):
        return (m_seq * 2 + half) % _Q_RING

    @jit
    def q_event(self, m_seq, half, src_pipe, dst_pipe, notify):
        # One hard event per physical Q half-slot; event IDs must be compile-time constants.
        q_slot = self._q_slot(m_seq, half)
        for slot in range_constexpr(_Q_RING):
            if q_slot == slot:
                if const_expr(notify):
                    cube_sync_notify(src_pipe, dst_pipe,
                                     _Q_EVENT_BASE + slot)
                else:
                    cube_sync_wait(src_pipe, dst_pipe,
                                   _Q_EVENT_BASE + slot)

    @jit
    def q_events_init(self):
        for slot in range_constexpr(_Q_RING):
            cube_sync_notify(PIPE.MTE1, PIPE.MTE2, _Q_EVENT_BASE + slot)

    @jit
    def q_events_drain(self):
        for slot in range_constexpr(_Q_RING):
            cube_sync_wait(PIPE.MTE1, PIPE.MTE2, _Q_EVENT_BASE + slot)

    @jit
    def load_q(self, q_tile_gm, m_seq):
        # Each Q half uses wait-copy-notify independently so half 0 can be consumed first.
        for h in range_constexpr(2):
            self.q_event(m_seq, h, PIPE.MTE1, PIPE.MTE2, False)
            dst = tile_slice(self.q_wide, (self.tile_cube_m, D // 2),
                            (0, self._q_slot(m_seq, h)))
            src = tile_slice(q_tile_gm, (self.tile_cube_m, D // 2), (0, h))
            mem_copy(dst, src, engine=self.nd2nz)
            self.q_event(m_seq, h, PIPE.MTE2, PIPE.MTE1, True)

    @jit
    def _bmm1_chunk_fanout(self, qk_slot, kv_slot, j, m_seq, init):
        q_off = (self._q_slot(m_seq, j // 2) * _Q_SLOT_ELEMS
                 + (j % 2) * _Q_CHUNK_ELEMS)
        a_slot = self.l0a.produce()
        b_slot = self.l0b.produce()
        cube_raw_l1_to_l0a(a_slot, self.q_wide, l1_offset_elems=q_off,
                           m_start=0, k_start=0, m_step=self.tile_cube_m // 16,
                           k_step=TILE // 16, src_stride=self.tile_cube_m // 16,
                           dst_stride=self.tile_cube_m // 16)
        mem_copy(b_slot, tile_slice(kv_slot, (self.tile_n, TILE), (0, j)))
        matmul(qk_slot, a_slot, b_slot, init=init)

    @jit
    def load_qk(self, q_tile_gm, m_seq, tick):
        # Load Q for the first nonempty row; subsequent rows are prefetched by bmm1.
        # KV is already in L1 and remains live through QK and PV.
        if tick == dtypes.int64(0):
            self.load_q(q_tile_gm, m_seq)

    @jit
    def bmm1_fanout_q(self, kv_slot, m_seq, is_first, is_last):
        # lag2：S[64,128] = Q[64,512] @ K̃[128,512]^T，FP32 L0C 累加。
        # 每个 M 的本核首个 tile 取得 Q 读 credit，本核末 tile 归还；中间 tile 直接复用 L1。
        # FD 切分行的分部起点/终点即 credit 边界（is_first/is_last 由 metadata 范围派生）。
        # QK 等待 K̃ 装载就绪，PV 读完后通知槽可复用。
        qk_dst = tile_slice(self.l0c.produce(), (self.tile_cube_m, TILE), (0, 0))
        for j in range_constexpr(D_TILES):
            if const_expr(j % 2 == 0):
                if is_first == dtypes.int64(1):
                    self.q_event(m_seq, j // 2, PIPE.MTE2, PIPE.MTE1, False)
            self._bmm1_chunk_fanout(qk_dst, kv_slot, j, m_seq, init=(j == 0))
        if is_last == dtypes.int64(1):
            for h in range_constexpr(2):
                self.q_event(m_seq, h, PIPE.MTE1, PIPE.MTE2, True)

    def store_s(self, qk_ub_ch):
        # S 从 L0C 经 fixpipe（dual_dst、split-M partition）跨核送到 AIV 的 qk_ub。
        # split-M 将 [64,128] 的 64 个头对半分给两个 AIV。
        # AIV0 处理 head[0:32]，AIV1 处理 head[32:64]，store_p/finalize 保持同一划分。
        mem_copy(qk_ub_ch.produce(), reinterpret(self.l0c.consume(), shape=(self.tile_cube_m, TILE)),
                 engine=self.fixpipe)

    def compute_pv_fanout(self, p_l1_ch, pv_ub_ch, kv_slot, actual_n):
        # lag3：PV[64,512] = P[64,128] @ K̃[128,512]；此时 P 是 exp(score−running_max)，
        # 尚未除以分母。D 切为 4 个独立的 128 列输出 chunk，各自 init=True。
        # K̃ 复用 QK 的 L1 slot，通过 L0B 的 transpose=True 改变矩阵乘的读取方向。
        # P 只装入 L0A 一次并供 4 个 chunk 共读；各列块先写入完整 L0C。
        # 一次 FIXPIPE 写出完整 PV，Channel 自动管理跨核生产和消费。
        p_slot = p_l1_ch.consume()
        a_slot = self.l0a_p.produce()
        mem_copy(a_slot, p_slot)

        # Only reduce initialized 16-row subblocks; masked P=0 cannot suppress NaN V.
        pv_k = ceil_div(actual_n, _TILE_ROWS) * _TILE_ROWS
        a_view = reinterpret(a_slot, shape=(self.tile_cube_m, pv_k),
                             stride=(self.tile_n, 1))
        acc = self.l0c.produce()
        for n in range(D_TILES):
            b_slot = self.l0b.produce()
            mem_copy(b_slot, tile_slice(kv_slot, (self.tile_n, TILE), (0, n)),
                     transpose=True)
            b_view = reinterpret(b_slot, shape=(pv_k, TILE), stride=(TILE, 1))
            col = tile_slice(acc, (self.tile_cube_m, TILE), (0, n))
            matmul(col, a_view, b_view, init=True)
        mem_copy(pv_ub_ch.produce(), self.l0c.consume(), engine=self.fixpipe)

class Vector:
    """AIV 侧：每核负责同一 query 的 32 个头，完成 online softmax 与输出累加。

    对一个头，设旧状态为 (m,l,o)，当前 tile 的缩放后 score 为 s：
      m' = max(m, tile_max)，alpha = exp(m−m')，p_j = exp(s_j−m')；
      l' = alpha*l + Σ_j p_j，o' = alpha*o + BF16(p) @ K̃。
    仅有效前缀参与指数与求和；残块的 tile_max 还可能包含 masked score 的零占位。
    sink 播种 (m=sink,l=1,o=0)，末 tile 才输出 BF16(o/l) 与 log(l)+m。
    sink 是未乘 softmax_scale 的 logit；传 0 仍贡献 exp(0)=1 的分母项。

    max/sum 按非空 query 序号轮转，alpha 属于 KV tile（tick%2）。两套双槽分别防止
    下一 query 的 softmax 覆盖上一 query 收尾所需的分母，以及相邻 tile 覆盖 alpha。
    res_o 只用一块 UB：lag3 按任务顺序消费，上一 query finalize 完才开始下一 query。
    """

    def __init__(self, tile_vec_m, tile_n, tile_d, subblock_idx, sinks_span):
        self.sinks_span = sinks_span
        self.tile_vec_m = tile_vec_m
        self.tile_n = tile_n
        self.tile_d = tile_d
        self.subblock_idx = subblock_idx

        # max/sum 按 query、exp 按任务轮转；索引均为 %2，各分配两槽。
        self.sm_max_tb = [Buffer(MemLoc.UB, (tile_vec_m, 1), dtypes.float32) for _ in range(2)]
        self.sm_sum_tb = [Buffer(MemLoc.UB, (tile_vec_m, 1), dtypes.float32) for _ in range(2)]
        self.sm_exp_tb = [Buffer(MemLoc.UB, (tile_vec_m, 1), dtypes.float32) for _ in range(2)]
        # Partial weights are needed only after the main-loop rewind.
        self.fd_mp_tb = []

        self.tmp_new_max = Buffer(MemLoc.UB, (tile_vec_m, 1), dtypes.float32)
        self.tmp_sum = Buffer(MemLoc.UB, (tile_vec_m, 1), dtypes.float32)
        self.lse_ub = Buffer(MemLoc.UB, shape=(tile_vec_m, 1), dtype=dtypes.float32)
        self.res_o = Buffer(MemLoc.UB, (tile_vec_m, tile_d), dtypes.float32)
        # BF16 output aliases the first 32 KiB of the 64 KiB FP32 res_o buffer.
        self.out_view = reinterpret(self.res_o, dtypes.bfloat16,
                                    (tile_vec_m, tile_d))

        p_n1_pad = 32 // 2
        self.p_ub = Channel(
            MemLoc.UB, shape=(tile_vec_m, tile_n), dtype=dtypes.bfloat16, depth=2,
            data_format="nz", n1_pad=p_n1_pad,
        )
        self.sinks_ub = Buffer(MemLoc.UB, shape=(1, self.sinks_span), dtype=dtypes.float32)

    def _nz_params(self, p_slot):
        # 从 p_ub 的真实物理 stride 推导落点，包含 Channel 的 NZ padding；
        # 此布局与 vec0 的 NZ17 由不同对象管理，不能直接套用 _NZ_CHUNK。
        s = p_slot.physical_stride
        s_n1, s_m1, s_m0, s_n0 = s[0], s[1], s[2], s[3]
        m0 = s_m1 // s_m0
        n0 = s_m0 // s_n0
        return m0, s_m1, s_m0, s_n1 // n0

    def _softmax_fold_row(self, p_slot, qk_ch, base, nz_off, max_brc_buf, row,
                          ve_mask, vo_mask, b16, b16_full, block_stride):
        # softmax 第二遍（行内）：exp(s−max) 后把 f32 偶/奇 lane 各 cast bf16（RegLayout
        # ZERO/ONE 分别落偶/奇 b16 lanes），vbitwise_or 合并成 128 连续 bf16 = P，
        # 按 NZ 分形 vstore_strided 存 p_ub。返回 (ve, vo) 供行求和。
        # 指数掩码按偶/奇列数 ceil(actual_n/2)、floor(actual_n/2) 分开，兼容奇数尾。
        # 最后用 b16_full 写满 128 列，将尾部 P=0 一并写入，避免复用槽里的旧 P 残留。
        mx = rr.vload_broadcast(max_brc_buf, row)
        ve, vo = rr.vload_deinterleave(qk_ch, base, width="b32")
        ve = rr.vexp_sub(ve, mx, mask=ve_mask)
        vo = rr.vexp_sub(vo, mx, mask=vo_mask)
        he = rr.vcast(ve, dtypes.bfloat16, mask=ve_mask, reg_layout=rr.RegLayout.ZERO)
        ho = rr.vcast(vo, dtypes.bfloat16, mask=vo_mask, reg_layout=rr.RegLayout.ONE)
        merged = rr.vbitwise_or(he, ho, mask=b16)
        rr.vstore_strided(p_slot, nz_off, merged, b16_full, block_stride=block_stride, repeat_stride=0)
        return ve, vo

    def _pass_a_row(self, qk_ch, scale, sm_max_dst, row, row_stride, VL_T,
                    half0_mask, half1_mask, full_mask, half_only=False):
        # 第一遍：有效 score 乘 scale 并原位回写，同时求用于稳定指数的行 max。
        # 每行分成前/后各 64 列；vmuls 的非活跃 lane 置零，而 max 用 full_mask 归约，
        # 因此残块的零也可能抬高 max（不等价于用 −inf 填尾）。后续指数和 P 仍按
        # actual_n 屏蔽尾列。half_only 只在 actual_n 为编译期整数且 ≤64 时裁掉后半。
        base = row * row_stride
        if const_expr(half_only):
            v0 = rr.vmuls(rr.vload(qk_ch, base), scale, mask=half0_mask)
            rr.vstore(qk_ch, base, v0, half0_mask)
            rmax = rr.vreduce_max(v0, mask=full_mask)
        else:
            v0 = rr.vmuls(rr.vload(qk_ch, base), scale, mask=half0_mask)
            v1 = rr.vmuls(rr.vload(qk_ch, base + VL_T), scale, mask=half1_mask)
            rr.vstore(qk_ch, base, v0, half0_mask)
            rr.vstore(qk_ch, base + VL_T, v1, half1_mask)
            rmax = rr.vreduce_max(rr.vmax(v0, v1, mask=full_mask), mask=full_mask)
        rr.vstore_first(sm_max_dst, row, rmax)

    @staticmethod
    def _half_only(actual_n, VL_T):
        return isinstance(actual_n, int) and actual_n <= VL_T

    def _softmax_rest_tail(self, sm_max, sm_sum, sm_exp, rowmask):
        # 用本 tile 的新 max 合并归一化分母：alpha = exp(old_max−new_max)，
        # new_sum = alpha * old_sum + Σ_j exp(score_j−new_max)。
        # alpha 存入本任务的 sm_exp 槽，供 lag3 将旧的 O 分子缩放到同一个指数基准。
        old_max = rr.vload(sm_max, 0)
        new_max = rr.vload(self.tmp_new_max, 0)
        se = rr.vexp_sub(old_max, new_max, mask=rowmask)
        rr.vstore(sm_exp, 0, se, rowmask)
        rr.vstore(sm_max, 0, new_max, rowmask)
        old_sum = rr.vload(sm_sum, 0)
        new_sum = rr.vload(self.tmp_sum, 0)
        ss = rr.vmadd(old_sum, se, new_sum, mask=rowmask)
        rr.vstore(sm_sum, 0, ss, rowmask)

    @jit
    def softmax_rest(self, qk_ch, scale, m_axis_triple: int, tile_triple: int, actual_n):
        # 合并当前 tile 与已保存的 running 状态；有 sinks 时首 tile 也走此函数。
        # ori→cmp 时 m_seq 不变、n 不归零，继续使用同一 max/sum 槽，不做分池 softmax。
        sm_max = self.sm_max_tb[m_axis_triple]
        sm_sum = self.sm_sum_tb[m_axis_triple]
        sm_exp = self.sm_exp_tb[tile_triple]
        VL_T = 2048 // 32
        N = self.tile_n
        p_slot = self.p_ub.produce()
        m0, s_m1, s_m0, block_stride = self._nz_params(p_slot)
        half_only = self._half_only(actual_n, VL_T)
        with vf(mode="raw"):
            rows = qk_ch.shape[0]
            src_row_stride = qk_ch.stride[0]
            rowmask, _ = rr.update_mask(rows, elem_bits=32)
            for row in range(rows):
                full, _ = rr.update_mask(VL_T, elem_bits=32)
                half0_mask, _ = rr.update_mask(actual_n, elem_bits=32)
                if const_expr(half_only):
                    half1_mask = None
                else:
                    half1_mask, _ = rr.update_mask(max(0, actual_n - VL_T), elem_bits=32)
                self._pass_a_row(qk_ch, scale, self.tmp_new_max, row, src_row_stride, VL_T,
                                 half0_mask, half1_mask, full, half_only=half_only)
            rr.vmem_bar("vst_vld")
            nm = rr.vmax(rr.vload(sm_max, 0), rr.vload(self.tmp_new_max, 0), mask=rowmask)
            rr.vstore(self.tmp_new_max, 0, nm, rowmask)
            rr.vmem_bar("vst_vld")
            for row in range(rows):
                full, _ = rr.update_mask(VL_T, elem_bits=32)
                b16_full, _ = rr.update_mask(N, elem_bits=16)
                ve_mask, _ = rr.update_mask((actual_n + 1) // 2, elem_bits=32)
                vo_mask, _ = rr.update_mask(actual_n // 2, elem_bits=32)
                b16, _ = rr.update_mask(actual_n, elem_bits=16)
                base = row * src_row_stride
                nz_off = (row // m0) * s_m1 + (row % m0) * s_m0
                ve, vo = self._softmax_fold_row(
                    p_slot, qk_ch, base, nz_off, self.tmp_new_max, row,
                    ve_mask, vo_mask, b16, b16_full, block_stride
                )
                rsum = rr.vreduce_sum(rr.vadd(ve, vo, mask=full), mask=ve_mask)
                rr.vstore_first(self.tmp_sum, row, rsum)
            rr.vmem_bar("vst_vld")
            self._softmax_rest_tail(sm_max, sm_sum, sm_exp, rowmask)

    @jit
    def seed_from_sinks(self, sinks_view, m_axis_triple: int):
        # sinks 播种（仅第一个 n-tile）：max ← sink[head]、sum ← 1.0（exp(sink−sink)=1），
        # 此后每 tile 走 softmax_rest 的 update 路径 —— sink 只吸收分母质量、无 value 贡献。
        sm_max = self.sm_max_tb[m_axis_triple]
        sm_sum = self.sm_sum_tb[m_axis_triple]
        span = self.sinks_span
        with vf(mode="raw"):
            full, _ = rr.update_mask(2048 // 32, elem_bits=32)
            one = rr.vdups(1.0, dtypes.float32, mask=full)
            for row in tuple(range(self.tile_vec_m)):
                rr.vstore_first(sm_max, row, rr.vload_broadcast(sinks_view, row % span))
                rr.vstore_first(sm_sum, row, one)
            rr.vmem_bar("vst_vld")

    @jit
    def seed_empty(self, m_axis_triple: int):
        # FD 非首分部播种（对齐 AscendC 跨核切分行续算语义）：max ← FP32 下界、
        # sum ← 0；sinks 只属于行的首个分部。alpha=exp(下界−new_max) 下溢为 0，
        # 首 tile 后状态等价于从零开始的在线 softmax。
        sm_max = self.sm_max_tb[m_axis_triple]
        sm_sum = self.sm_sum_tb[m_axis_triple]
        with vf(mode="raw"):
            rowmask, _ = rr.update_mask(self.tile_vec_m, elem_bits=32)
            neg = rr.vdups(_FD_NEG_INF, dtypes.float32, mask=rowmask)
            zero = rr.vdups(0.0, dtypes.float32, mask=rowmask)
            rr.vstore(sm_max, 0, neg, rowmask)
            rr.vstore(sm_sum, 0, zero, rowmask)
            rr.vmem_bar("vst_vld")

    def store_p(self, p_l1_ch):
        # P 从 p_ub 跨核送 p_l1：每 AIV 填自己的 32 头半块，L1 两槽合计 32 KiB。
        piece = tile_slice(p_l1_ch.produce(), (self.tile_vec_m, self.tile_n), (self.subblock_idx, 0))
        mem_copy(piece, self.p_ub.consume())

    @jit
    def init_o(self, pv_ch):
        # 首 tile 的旧分子为 0（sink 无 Value），直接复制 PV，无需读未初始化的 res_o。
        mem_copy(reinterpret(self.res_o, shape=(pv_ch.shape[0], self.tile_d)), pv_ch)

    @jit
    def update_o(self, pv_ch, exp_idx: int):
        # res_o 保存尚未除分母的 FP32 分子：new_o = alpha * old_o + PV。
        # alpha 由同一 tick 的 softmax 产生；PV 中的 P 已转 BF16，矩阵乘累加为 FP32。
        # full_mask 复用于 D=512 的八个 64-lane chunk，D 的整除约束在构造时检查。
        sm_exp_buf = self.sm_exp_tb[exp_idx]
        VL_T = 2048 // 32
        with vf(mode="raw"):
            full = rr.full_mask()
            for row in range(self.tile_vec_m):
                exp_b = rr.vload_broadcast(sm_exp_buf, row)
                base = row * self.tile_d
                for col in tuple(range(0, self.tile_d, VL_T)):
                    off = base + col
                    pre = rr.vload(self.res_o, off)
                    cur = rr.vload(pv_ch, off)
                    o = rr.vmadd(pre, exp_b, cur, mask=full)
                    rr.vstore(self.res_o, off, o, full)

    @jit
    def update_o_last(self, pv_ch, exp_idx: int, sum_idx: int):
        # 末 tile：累加后在 FP32 域除 sum，随后 finalize 才转 BF16，避免先舍入再归一化。
        sm_exp_buf = self.sm_exp_tb[exp_idx]
        sm_sum_buf = self.sm_sum_tb[sum_idx]
        VL_T = 2048 // 32
        with vf(mode="raw"):
            full = rr.full_mask()
            one = rr.vdups(1.0, dtypes.float32)
            for row in range(self.tile_vec_m):
                exp_b = rr.vload_broadcast(sm_exp_buf, row)
                sum_b = rr.vload_broadcast(sm_sum_buf, row)
                inv_sum = rr.vdiv(one, sum_b, mask=full)
                base = row * self.tile_d
                for col in tuple(range(0, self.tile_d, VL_T)):
                    off = base + col
                    pre = rr.vload(self.res_o, off)
                    cur = rr.vload(pv_ch, off)
                    o = rr.vmadd(pre, exp_b, cur, mask=full)
                    o = rr.vmul(o, inv_sum, mask=full)
                    rr.vstore(self.res_o, off, o, full)

    @jit
    def init_o_last(self, pv_ch, sum_idx: int):
        # 整个 query 只有一个 KV tile：没有跨 tile 累加，直接用 PV/最终分母初始化 O。
        sm_sum_buf = self.sm_sum_tb[sum_idx]
        VL_T = 2048 // 32
        with vf(mode="raw"):
            full = rr.full_mask()
            one = rr.vdups(1.0, dtypes.float32)
            for row in range(self.tile_vec_m):
                sum_b = rr.vload_broadcast(sm_sum_buf, row)
                inv_sum = rr.vdiv(one, sum_b, mask=full)
                base = row * self.tile_d
                for col in tuple(range(0, self.tile_d, VL_T)):
                    off = base + col
                    cur = rr.vload(pv_ch, off)
                    rr.vstore(self.res_o, off, rr.vmul(cur, inv_sum, mask=full), full)

    @jit
    def _finalize_lse_vf(self, lse_gm, lse_base, sum_idx: int):
        # lse = log(sum) + max；单槽 Buffer 的 V→MTE3 依赖由框架管理。
        sm_max_buf = self.sm_max_tb[sum_idx]
        sm_sum_buf = self.sm_sum_tb[sum_idx]
        with vf(mode="raw"):
            mask, _ = rr.update_mask(self.tile_vec_m, elem_bits=32)
            total = rr.vload(sm_sum_buf, 0)
            maximum = rr.vload(sm_max_buf, 0)
            rr.vstore(self.lse_ub, 0, rr.vadd(rr.vlog(total, mask=mask), maximum, mask=mask), mask)
        mem_copy(tile_slice(lse_gm, (self.tile_vec_m,), (lse_base,)),
                 reinterpret(self.lse_ub, shape=(self.tile_vec_m,)))

    @jit
    def _cast_output(self):
        # 原地 cast：res_o(32,512) FP32 → out_view 前 32 KiB BF16。B32_TO_B16 以相同
        # 元素 offset 落位：第 o 块写 BF16 字节 [2o, 2o+128) ⊂ 读 FP32 字节 [4o, 4o+256)，
        # 且下一块读起点 4(o+64) = 4o+256 > 2o+128，块间无交叉；V 核内按序执行，覆写安全。
        with vf(mode="raw"):
            full = rr.full_mask()
            for offset in range(0, self.tile_vec_m * self.tile_d, 64):
                value = rr.vload(self.res_o, offset)
                result = rr.vcast(value, dtypes.bfloat16, mask=full)
                rr.vstore_pack(self.out_view, offset, result, full, pack_mode=rr.PackMode.B32_TO_B16)

    def finalize_o(self, o_tile_gm, sum_idx: int,
                   lse_gm=None, lse_base=None):
        # Output aliases res_o: wait for this MTE3 copy before the next query overwrites res_o.
        # LSE and output copies run in order after the cast completes.
        half = tile_slice(o_tile_gm, (self.tile_vec_m, self.tile_d), (self.subblock_idx, 0))

        if const_expr(lse_gm is not None):
            self._finalize_lse_vf(lse_gm, lse_base, sum_idx)

        self._cast_output()
        vec_sync_notify(PIPE.V, PIPE.MTE3, _OUT_V_TO_MTE3_EVENT_ID)
        vec_sync_wait(PIPE.V, PIPE.MTE3, _OUT_V_TO_MTE3_EVENT_ID)
        mem_copy(half, self.out_view)
        # 信号紧随出拷贝入队（早于后续 vec0 的 L1 写），等待只覆盖拷贝本身；
        # 末 query 的信号无人消费，悬置无害（sync id 每次发射独立）。
        vec_sync_notify(PIPE.MTE3, PIPE.V, _OUT_MTE3_TO_V_EVENT_ID)

    @jit
    def wait_prev_out_copy(self):
        # Wait only when a preceding task published the output-copy completion event.
        vec_sync_wait(PIPE.MTE3, PIPE.V, _OUT_MTE3_TO_V_EVENT_ID)

    @jit
    def finalize_empty(self, o_tile_gm, sinks_gm, lse_gm=None, lse_base=None):
        # Empty rows produce O=0 and LSE=sink. Drain the previous output copy
        # before overwriting the shared output buffer.
        vec_sync_notify(PIPE.MTE3, PIPE.V, _OUT_MTE3_TO_V_EVENT_ID)
        vec_sync_wait(PIPE.MTE3, PIPE.V, _OUT_MTE3_TO_V_EVENT_ID)
        half = tile_slice(o_tile_gm, (self.tile_vec_m, self.tile_d), (self.subblock_idx, 0))
        with vf(mode="raw"):
            full, _ = rr.update_mask(128, elem_bits=16)
            zero = rr.vdups(0.0, dtypes.bfloat16, mask=full)
            for offset in range(0, self.tile_vec_m * self.tile_d, 128):
                rr.vstore(self.out_view, offset, zero, full)
        vec_sync_notify(PIPE.V, PIPE.MTE3, _OUT_V_TO_MTE3_EVENT_ID)
        vec_sync_wait(PIPE.V, PIPE.MTE3, _OUT_V_TO_MTE3_EVENT_ID)
        mem_copy(half, self.out_view)
        if const_expr(lse_gm is not None):
            # Keep lse_ub's producer on V, as in _finalize_lse_vf; using
            # MTE2 here would change the shared buffer's event protocol.
            mem_copy(self.sinks_ub, tile_slice(sinks_gm, (1, self.sinks_span),
                                            (0, self.subblock_idx)))
            with vf(mode="raw"):
                mask, _ = rr.update_mask(self.tile_vec_m, elem_bits=32)
                rr.vstore(self.lse_ub, 0, rr.vload(self.sinks_ub, 0), mask)
            mem_copy(tile_slice(lse_gm, (self.tile_vec_m,), (lse_base,)),
                     reinterpret(self.lse_ub, shape=(self.tile_vec_m,)))

    # ---- FD 辅助（每个 VF 块独立成 @jit 方法：runtime for 循环体内不得绑定
    # VF 寄存器/mask 局部量，否则会被提升为 scf.for 迭代状态导致类型错乱）----

    @jit
    def _fd_ms_to_ub(self, which: int, sum_idx: int):
        # lse_ub ← sm_max（which=0）/ sm_sum（which=1）槽
        if const_expr(which == 0):
            buf = self.sm_max_tb[sum_idx]
        else:
            buf = self.sm_sum_tb[sum_idx]
        with vf(mode="raw"):
            rowmask, _ = rr.update_mask(self.tile_vec_m, elem_bits=32)
            rr.vstore(self.lse_ub, 0, rr.vload(buf, 0), rowmask)

    @jit
    def _fd_init_acc(self):
        with vf(mode="raw"):
            rowmask, _ = rr.update_mask(self.tile_vec_m, elem_bits=32)
            rr.vstore(self.sm_max_tb[0], 0,
                      rr.vdups(_FD_NEG_INF, dtypes.float32, mask=rowmask), rowmask)
            rr.vstore(self.sm_sum_tb[0], 0,
                      rr.vdups(0.0, dtypes.float32, mask=rowmask), rowmask)
            rr.vmem_bar("vst_vld")

    @jit
    def _fd_acc_max_save(self, p: int, lse_buf):
        # Cache m_p and accumulate the global maximum; the next pass reuses
        # the same weight slot for t_p = s_p * exp(m_p - M).
        mp_buf = tile_slice(self.fd_mp_tb, (self.tile_vec_m, 1), (p, 0))
        with vf(mode="raw"):
            rowmask, _ = rr.update_mask(self.tile_vec_m, elem_bits=32)
            mp = rr.vload(lse_buf, p * FD_MS_ELEMS + self.subblock_idx * self.tile_vec_m + 0)
            nm = rr.vmax(rr.vload(self.sm_max_tb[0], 0), mp, mask=rowmask)
            rr.vstore(self.sm_max_tb[0], 0, nm, rowmask)
            rr.vstore(mp_buf, 0, mp, rowmask)
            rr.vmem_bar("vst_vld")

    @jit
    def _fd_acc_sum(self, p: int, lse_buf):
        # Bulk max/sum landing: t_p = s_p·exp(m_p−M); G += t_p. Cache t_p.
        # （复用第 1 遍的 m_p 槽，第 4 遍以 t_p/G 求权重，= AscendC ComputeScaleValue_8_VF）
        mp_buf = tile_slice(self.fd_mp_tb, (self.tile_vec_m, 1), (p, 0))
        with vf(mode="raw"):
            rowmask, _ = rr.update_mask(self.tile_vec_m, elem_bits=32)
            e = rr.vexp_sub(rr.vload(mp_buf, 0),
                            rr.vload(self.sm_max_tb[0], 0), mask=rowmask)
            t = rr.vmul(rr.vload(lse_buf, p * FD_MS_ELEMS + self.subblock_idx * self.tile_vec_m + 64), e, mask=rowmask)
            acc = rr.vadd(rr.vload(self.sm_sum_tb[0], 0), t, mask=rowmask)
            rr.vstore(self.sm_sum_tb[0], 0, acc, rowmask)
            rr.vstore(mp_buf, 0, t, rowmask)
            rr.vmem_bar("vst_vld")

    @jit
    def _fd_lse_to_ub(self, lse_buf):
        # lse_ub ← M + log(G)
        with vf(mode="raw"):
            rowmask, _ = rr.update_mask(self.tile_vec_m, elem_bits=32)
            lse = rr.vadd(rr.vlog(rr.vload(self.sm_sum_tb[0], 0), mask=rowmask),
                          rr.vload(self.sm_max_tb[0], 0), mask=rowmask)
            rr.vstore(lse_buf, 0, lse, rowmask)

    @jit
    def _fd_acc_full(self, fd_ub, p: int, first: cannbotdsl.Constexpr[bool]):
        # Compute each head weight in registers while consuming partial O.
        # Part zero initializes the accumulator; later parts retain slot order.
        mp_buf = tile_slice(self.fd_mp_tb, (self.tile_vec_m, 1), (p, 0))
        with vf(mode="raw"):
            full = rr.full_mask()
            for r in range(self.tile_vec_m):
                wb = rr.vdiv(rr.vload_broadcast(mp_buf, r),
                             rr.vload_broadcast(self.sm_sum_tb[0], r), mask=full)
                for col in range(0, self.tile_d, 2048 // 32):
                    off = r * self.tile_d + col
                    cur = rr.vload(fd_ub, off)
                    if const_expr(first):
                        value = rr.vmul(cur, wb, mask=full)
                    else:
                        pre = rr.vload(self.res_o, off)
                        value = rr.vmadd(cur, wb, pre, mask=full)
                    rr.vstore(self.res_o, off, value, full)
            rr.vmem_bar("vst_vld")

    @jit
    def _fd_scale_local_first(self):
        # The first partial O is still in res_o: weight it in place.
        mp_buf = tile_slice(self.fd_mp_tb, (self.tile_vec_m, 1), (0, 0))
        with vf(mode="raw"):
            full = rr.full_mask()
            for r in range(self.tile_vec_m):
                wb = rr.vdiv(rr.vload_broadcast(mp_buf, r),
                             rr.vload_broadcast(self.sm_sum_tb[0], r), mask=full)
                for col in range(0, self.tile_d, 2048 // 32):
                    off = r * self.tile_d + col
                    cur = rr.vload(self.res_o, off)
                    rr.vstore(self.res_o, off, rr.vmul(cur, wb, mask=full), full)
            rr.vmem_bar("vst_vld")

    def _setup_fd_reduce_buffers(self):
        # After the global barrier, reuse main-loop UB for one full partial O,
        # an FP32 accumulator, all max/sum rows and up to 36 partial weights.
        # Main-loop allocations and reduction allocations are not simultaneous.
        self.fd_ms_ub = Channel(MemLoc.UB, shape=(_FD_MP_SLOTS, FD_MS_ELEMS),
                                dtype=dtypes.float32, depth=1)
        self.fd_ub = Channel(MemLoc.UB, shape=(self.tile_vec_m, self.tile_d),
                             dtype=dtypes.float32, depth=1)
        # Keep the main-loop res_o alive across rewind for local-first FD.
        # All other main-loop users are drained before this setup is called.
        self.out_view = reinterpret(self.res_o, dtypes.bfloat16,
                                    (self.tile_vec_m, self.tile_d))
        self.lse_ub = Channel(MemLoc.UB, shape=(self.tile_vec_m, 1),
                              dtype=dtypes.float32, depth=1)
        self.sm_max_tb[0] = Buffer(MemLoc.UB, (self.tile_vec_m, 1), dtypes.float32)
        self.sm_sum_tb[0] = Buffer(MemLoc.UB, (self.tile_vec_m, 1), dtypes.float32)
        self.tmp_new_max = Buffer(MemLoc.UB, (self.tile_vec_m, 1), dtypes.float32)
        self.fd_mp_tb = Buffer(MemLoc.UB, (_FD_MP_SLOTS * self.tile_vec_m, 1),
                               dtypes.float32)

    @jit
    def stage_partial(self, fd_o, fd_ms, slot, sum_idx: int, skip_o: int = 0):
        # FD 暂存（= AscendC StageVec1Lse/StageVec2PartialO 的常规 FD 路径）：
        # 跨核切分行在本核的分部结束时，把已归一化 O（FP32，res_o 已除以分母
        # sum，由调用方 init_o_last/update_o_last 完成）与本 AIV 32 个 head 的
        # max/sum 写入 workspace slot。
        # O is one 64 KiB V→MTE3 copy; max/sum reuse the 32-FP32 lse buffer.
        # slot 布局：O 区 (slots*64, 512) fp32；max/sum 区 (slots*128,) fp32，
        # 每 slot 128 元素 = max[0:64] ‖ sum[64:128]。
        sub = self.subblock_idx
        vec_sync_notify(PIPE.V, PIPE.MTE3, _OUT_V_TO_MTE3_EVENT_ID)
        vec_sync_wait(PIPE.V, PIPE.MTE3, _OUT_V_TO_MTE3_EVENT_ID)
        if skip_o == 0:
            mem_copy(tile_slice(fd_o, (self.tile_vec_m, self.tile_d),
                                (slot * (N1 // self.tile_vec_m) + sub, 0)),
                     self.res_o)
        self._fd_ms_to_ub(0, sum_idx)
        mem_copy(tile_slice(fd_ms, (self.tile_vec_m,),
                           (slot * (FD_MS_ELEMS // self.tile_vec_m) + sub,)),
                 reinterpret(self.lse_ub, shape=(self.tile_vec_m,)))
        self._fd_ms_to_ub(1, sum_idx)
        mem_copy(tile_slice(fd_ms, (self.tile_vec_m,),
                           (slot * (FD_MS_ELEMS // self.tile_vec_m) + (N1 // self.tile_vec_m) + sub,)),
                 reinterpret(self.lse_ub, shape=(self.tile_vec_m,)))
        vec_sync_notify(PIPE.MTE3, PIPE.V, _OUT_MTE3_TO_V_EVENT_ID)

    @jit
    def fd_reduce(self, fd_o, fd_ms, fd_ub, out_gm, lse_gm,
                  row, slot0, k, h0):
        # FD 归约（= AscendC ProcessFlashDecode/ReduceWithLse）：本 AIV 负责行 row
        # 的 32 个 head（h0 ∈ {0,32}），合并 k 份分部：
        #   M = max_p(m_p)；e_p = exp(m_p−M)；t_p = s_p·e_p；G = Σ_p t_p；
        #   out = Σ_p t_p/G · O_p（O_p 已归一化）；lse = M + log(G)。
        # 分部按 slot 序号从左到右累加，顺序由 metadata 确定 ⇒ 结果确定。
        # 全部 UB 复用主循环既有对象（barrier 后主循环已结束）：
        # acc_max→sm_max_tb[0]、acc_sum→sm_sum_tb[0]、m_p/t_p→fd_mp_tb[p]、
        # weights remain in registers; res_o accumulates, fd_ub receives O parts.
        sub = h0 // self.tile_vec_m
        self._fd_init_acc()
        ms_offset = slot0 * FD_MS_ELEMS
        ms_count = k * FD_MS_ELEMS
        ms_source = fd_ms[ms_offset:ms_offset + ms_count,].view(k, FD_MS_ELEMS)
        mem_copy(self.fd_ms_ub.produce(),
                 tile_slice(ms_source, (_FD_MP_SLOTS, FD_MS_ELEMS), (0, 0)))
        ms_buf = self.fd_ms_ub.consume()
        for p in range(k):
            self._fd_acc_max_save(p, ms_buf)
        for p in range(k):
            self._fd_acc_sum(p, ms_buf)
        # 3) 可选 LSE = M + log(G)
        if const_expr(lse_gm is not None):
            self._fd_lse_to_ub(self.lse_ub.produce())
            mem_copy(tile_slice(lse_gm, (self.tile_vec_m,), (row * 2 + sub,)),
                     reinterpret(self.lse_ub.consume(), shape=(self.tile_vec_m,)))
        # 4) res_o = Σ_p t_p/G ⊙ O_p（O_p 已归一化；t_p 复用第 2 遍已存值）
        mem_copy(fd_ub.produce(),
                 tile_slice(fd_o, (self.tile_vec_m, self.tile_d),
                            (slot0 * (N1 // self.tile_vec_m) + sub, 0)))
        self._fd_acc_full(fd_ub.consume(), 0, True)
        for p in range(1, k):
            mem_copy(fd_ub.produce(),
                     tile_slice(fd_o, (self.tile_vec_m, self.tile_d),
                                ((slot0 + p) * (N1 // self.tile_vec_m) + sub, 0)))
            self._fd_acc_full(fd_ub.consume(), p, False)
        # 5) 输出：res_o 已归一化，整块原地转 BF16 写出（与 finalize_o 同路径）。
        # out 行号 = row*64 + h0 + [0,32)，(32,512) tile 坐标 = row*(N1/tile_vec_m) + sub；
        # barrier（global_sync_all 的 vec_sync_all）已排空主循环的全部 MTE3，无反向等待。
        self._cast_output()
        vec_sync_notify(PIPE.V, PIPE.MTE3, _OUT_V_TO_MTE3_EVENT_ID)
        vec_sync_wait(PIPE.V, PIPE.MTE3, _OUT_V_TO_MTE3_EVENT_ID)
        mem_copy(tile_slice(out_gm, (self.tile_vec_m, self.tile_d),
                           (row * (N1 // self.tile_vec_m) + sub, 0)),
                 self.out_view)

    @jit
    def fd_reduce_local_first(self, fd_o, fd_ms, fd_ub, out_gm, lse_gm,
                              row, slot0, h0):
        # The first normalized partial remains in this AIV's res_o. Only the
        # second partial crosses GM; readiness is polled before this call.
        sub = h0 // self.tile_vec_m
        self._fd_init_acc()
        ms_offset = slot0 * FD_MS_ELEMS
        ms_source = fd_ms[ms_offset:ms_offset + 2 * FD_MS_ELEMS,].view(2, FD_MS_ELEMS)
        mem_copy(self.fd_ms_ub.produce(),
                 tile_slice(ms_source, (_FD_MP_SLOTS, FD_MS_ELEMS), (0, 0)))
        ms_buf = self.fd_ms_ub.consume()
        for p in range_constexpr(2):
            self._fd_acc_max_save(p, ms_buf)
        for p in range_constexpr(2):
            self._fd_acc_sum(p, ms_buf)
        if const_expr(lse_gm is not None):
            self._fd_lse_to_ub(self.lse_ub.produce())
            mem_copy(tile_slice(lse_gm, (self.tile_vec_m,), (row * 2 + sub,)),
                     reinterpret(self.lse_ub.consume(), shape=(self.tile_vec_m,)))
        self._fd_scale_local_first()
        mem_copy(fd_ub.produce(),
                 tile_slice(fd_o, (self.tile_vec_m, self.tile_d),
                            ((slot0 + 1) * (N1 // self.tile_vec_m) + sub, 0)))
        self._fd_acc_full(fd_ub.consume(), 1, False)
        self._cast_output()
        vec_sync_notify(PIPE.V, PIPE.MTE3, _OUT_V_TO_MTE3_EVENT_ID)
        vec_sync_wait(PIPE.V, PIPE.MTE3, _OUT_V_TO_MTE3_EVENT_ID)
        mem_copy(tile_slice(out_gm, (self.tile_vec_m, self.tile_d),
                           (row * (N1 // self.tile_vec_m) + sub, 0)),
                 self.out_view)

@kernel(profile=ProfileSpec(name="mixed_quant_sparse_flash_mla"))
class MqsmlaKernel:
    """Device attention pipeline; tensor views and launch live in _run_mqsmla."""

    def __init__(self, tile_cube_m, tile_vec_m, tile_n,
                 has_cmp=False):
        self.tile_cube_m = tile_cube_m
        self.tile_vec_m = tile_vec_m
        self.tile_n = tile_n
        self.tile_d = D
        self.has_cmp = has_cmp
        self.p_l1 = Channel(MemLoc.L1, shape=(tile_cube_m, tile_n), dtype=dtypes.bfloat16,
                            depth=_P_L1_DEPTH, kind=ChannelKind.CrossCore)

        # 三条跨核数据链：QK(AIC→AIV，depth=2)、P(AIV→AIC，depth=2)、PV(AIC→AIV，depth=1)。
        # qk_ub/pv_ub 的 shape 是每 AIV 半块，p_l1 的 shape 是 AIC 接收的完整 64 头块。

        self.block_idx = get_block_idx()
        self.subblock_idx = get_subblock_id()

        self.sinks_span = tile_vec_m

        self.matmul = Matmul(tile_cube_m, tile_vec_m, tile_n)
        self.kvcache = Kvcache()
        self.n_sub = tile_n // _TILE_ROWS

    @jit
    def _setup_main_ub(self):
        # Allocate only after address-prepass storage is dead. L1/L0 and their
        # cross-core protocols remain live across rewind; do not reset IDs.
        tile_vec_m, tile_n = self.tile_vec_m, self.tile_n
        self.qk_ub = Channel(MemLoc.UB, shape=(tile_vec_m, tile_n), dtype=dtypes.float32,
                             depth=2, kind=ChannelKind.CrossCore)
        # FIX(AIC) → V(AIV)：必须使用 CrossCore；kind 不代替整块 PV 的事务边界。
        self.pv_ub = Channel(MemLoc.UB, shape=(tile_vec_m, self.tile_d), dtype=dtypes.float32,
                             depth=1, kind=ChannelKind.CrossCore)
        self.vector = Vector(tile_vec_m, tile_n, self.tile_d, self.subblock_idx,
                             sinks_span=self.sinks_span)

        # The existing scalar PA path accepts runtime page sizes and does not
        # allocate an on-chip buffer proportional to the block-table capacity.
        ch_rows = _TILE_ROWS
        # FP8/FP4 共用四槽输入环；SameCore 自动管理 MTE2 → V 及槽复用同步。
        self.ch_batch_bytes = Channel(MemLoc.UB,
                                      shape=(ch_rows, _COMBINE_DIM),
                                      dtype=dtypes.uint8, depth=4, kind=ChannelKind.SameCore)
        # DMA 和 VF 共用一个字节 Channel；scale 在寄存器中按 BF16 位解释，
        # 避免同一槽的两个 Channel dtype 别名生成重复消费事务。
        self._v0_out = Channel(MemLoc.UB, shape=(D // 16, _NZ_PAD_ROWS, 16),
                               dtype=dtypes.bfloat16, depth=2)

    # ---- 坐标与有效宽度：m_seq 是核内 query 序号，m_idx 是全局 query token 序号 ----
    # n 是同一 query 上 ori→cmp 串接的 tile 序号；tick 则跨 query 连续编号。
    # 每侧 w = topk_length（None 时为 K），tiles = ceil(w/128)，actual_n = min(128,w−128*n)。
    # gather 的有效前缀与 softmax 的有效列数必须同源；切到 cmp 后须先减去 ori tile 数。
    # *_s2_start 是稀疏索引表列偏移，不是逻辑 token 值。

    def _m_idx(self, m_seq: int):
        # metadata 连续区间映射：m_start 在 __call__ 里读一次存 SSA，这里只做单次加法。
        return self._m_start + m_seq

    @jit
    def _batch_of(self, m_idx: int):
        # Dynamic upper-bound search over the B query spans.
        lo, hi = 0, self._b_rt
        while lo < hi:
            mid = (lo + hi) // 2
            take = _i64(self._cu_q, 0, mid + 1) <= m_idx
            lo = dyn_select(take, mid + 1, lo)
            hi = dyn_select(take, hi, mid)
        return lo

    @jit
    def _bound_after(self, batch: int, b_last: int):
        # cu_q[batch+1]（= 下一个 batch 的起始 query 序号）。batch 已在最后一个
        # span 上时返回 +INF 哨兵，既不越界读 cu_q，也让增量推进自然停在 b_rt，
        # 与 _batch_of 的 hi=b_rt 钳位逐位一致。单次 GM 标量读。
        nxt = dyn_select(batch < b_last, batch + 1, b_last)
        v = _i64(self._cu_q, 0, nxt)
        return dyn_select(batch < b_last, v, dtypes.int64(_ADDR_M_INF))

    def _cmp_tiles_rt(self, m_idx: int):
        w = self._csa_valid_w(m_idx)
        return (w + self.tile_n - 1) // self.tile_n

    @jit
    def _ori_valid_w(self, m_idx: int):
        # ori 侧有效宽度：min(K1, ori_topk_length[m_idx])。
        # 无 topk_length 时也强制 Int64 提升为 SSA：FD 主循环的 t0/t1/split
        # dyn_select 脚手架要求 tiles 是运行时值（否则 select 谓词退化为 Python bool）。
        if const_expr(self._ori_topk_length is not None):
            return min(self._ori_idx.shape[1], _i64(self._ori_topk_length, m_idx))
        return Int64(self._ori_idx.shape[1])

    @jit
    def _cmp_topk_len(self, m_idx: int):
        if const_expr(self._cmp_topk_length is not None):
            return min(self._cmp_idx.shape[1], _i64(self._cmp_topk_length, m_idx))
        return Int64(self._cmp_idx.shape[1])

    def _ori_tiles_rt(self, m_idx: int):
        w = self._ori_valid_w(m_idx)
        return (w + self.tile_n - 1) // self.tile_n

    def _n_end_rt(self, m_idx: int):
        # 本 query 的 n-tile 趟数（运行时）：ori_tiles + cmp_tiles。
        ori_tiles = self._ori_tiles_rt(m_idx)
        if const_expr(not self.has_cmp):
            return ori_tiles
        return ori_tiles + self._cmp_tiles_rt(m_idx)

    def _actual_n(self, m_idx: int, n):
        # 根据 n 所在的池返回当前 tile 的有效 KV 列数，供 softmax 的指数/P 掩码使用。
        # 只有被选中的池内坐标有效；dyn_select 未选中的候选宽度不代表实际任务。
        ori_w = self._ori_width(m_idx, n)
        if const_expr(not self.has_cmp):
            return ori_w
        ori_tiles = self._ori_tiles_rt(m_idx)
        c = n - ori_tiles
        cmp_w = self._cmp_valid(m_idx, c)
        return dyn_select(n >= ori_tiles, cmp_w, ori_w)

    @jit
    def _ori_width(self, m_idx: int, n):
        w = self._ori_valid_w(m_idx)
        return min(self.tile_n, w - n * self.tile_n)

    def _csa_valid_w(self, m_idx: int):
        return self._cmp_topk_len(m_idx)

    @jit
    def _cmp_valid(self, m_idx: int, c):
        return min(self.tile_n, self._csa_valid_w(m_idx) - c * self.tile_n)

    @staticmethod
    def _scale_idx(grp_lane, base: int, m16):
        # Scale gather uses uint16 indices, so its arithmetic requires a 16-bit mask.
        return rr.vadd(grp_lane, rr.vdups(base, dtypes.uint16), mask=m16)

    @jit
    def _antiquant_vf_fp8_g32(self, kv_fp8, out):
        # ori：nope448|rope64|scale16，数据顺序与计算顺序一致。
        # 四段各128维：FP8→FP32→BF16，deinterleave压紧偶lane，乘group32 BF16 scale。
        # 每段scale基号为4*j，字节偏移为128*j；写入同列的BF16 NZ Channel。
        SUB = _TILE_ROWS
        with vf(mode="raw"):
            m32, _ = rr.update_mask(_TILE_SIZE, elem_bits=32)
            m16, _ = rr.update_mask(_VL, elem_bits=16)
            m8, _ = rr.update_mask(256, elem_bits=8)
            grp_lane = rr.vshr(rr.varange(0, dtypes.uint16), 5, mask=m16)
            row_bf16, row_fp8 = _ROW_BF16, _COMBINE_DIM

            # j遍历四段连续128维，i遍历子块内token。
            for j in tuple(range(D // _KV_NUM_PER_LOOP)):
                src_j = j * _KV_NUM_PER_LOOP
                dst_j = j * _KV_NUM_PER_LOOP
                idx_j = self._scale_idx(grp_lane, 4 * j, m16)
                for i in range(SUB):
                    s = i * row_fp8 + src_j
                    u0 = rr.vload_unpack(kv_fp8, s, unpack_mode="b8_to_b32")
                    u1 = rr.vload_unpack(kv_fp8, s + _TILE_SIZE,
                                         unpack_mode="b8_to_b32")
                    e0 = rr.vreinterpret_lanes(u0, dtypes.float8_e4m3fn)
                    e1 = rr.vreinterpret_lanes(u1, dtypes.float8_e4m3fn)
                    f0 = rr.vcast(e0, dtypes.float32, mask=m8, reg_layout=rr.RegLayout.ZERO)
                    f1 = rr.vcast(e1, dtypes.float32, mask=m8, reg_layout=rr.RegLayout.ZERO)
                    b0 = rr.vcast(f0, dtypes.bfloat16, mask=m32)
                    b1 = rr.vcast(f1, dtypes.bfloat16, mask=m32)
                    raw, _ = rr.vdeinterleave(b0, b1)
                    srow = rr.vreinterpret_lanes(
                        rr.vload(kv_fp8, 2 * (_SCALE_BF16_OFF + i * row_bf16)), dtypes.bfloat16)
                    svec = rr.vgather_reg(srow, idx_j)
                    packed = rr.vmul(raw, svec, mask=m16)
                    self._v0_store(out, i, dst_j, packed, m16)

    @jit
    def _antiquant_vf_fp4_g16(self, kv_fp8, out):
        # cmp：nope224B|rope32B|scale64B，四段各128维连续反量化。
        # UNPACK4 + packed FP4 reinterpret + quarter-0 cast.
        # Packed FP4 consumes an 8-bit mask; each byte expands to two BF16 values.
        # Scales load via E2B broadcast (vload_broadcast mode="elem2datablock"):
        # one instruction fetches 8 g16 scales into 8 x 32B DataBlocks, which is
        # exactly one 128-lane g16 scale vector; the 16-bit broadcast result is
        # bit-pattern u16 and reinterprets back to BF16. This replaces the
        # vload(256B) + vgather_reg pair (board-probe verified bit-identical,
        # single-block cycle 309 -> 183, i.e. the historical opsnn_nz tier).
        SUB = _TILE_ROWS
        kv_bf16 = reinterpret(kv_fp8, dtypes.bfloat16,
                              shape=(SUB, _ROW_BF16))
        with vf(mode="raw"):
            m16, _ = rr.update_mask(_VL, elem_bits=16)
            row_fp8 = _COMBINE_DIM
            scale_off = SCALE_BF16_OFF_CMP

            for p in tuple(range(D // _KV_NUM_PER_LOOP)):
                src_p = p * _TILE_SIZE
                dst_p = p * _KV_NUM_PER_LOOP
                for i in range(SUB):
                    u = rr.vload_unpack(kv_fp8, src_p + i * row_fp8,
                                        unpack_mode=rr.UnpackMode.UNPACK4)
                    f4 = rr.vreinterpret_lanes(u, dtypes.fp4x2_e2m1)
                    fm = rr.full_mask()
                    fm.elem_bits = 8
                    vals = rr.vcast(f4, dtypes.bfloat16, mask=fm,
                                    reg_layout=rr.RegLayout.ZERO)
                    brc = rr.vload_broadcast(
                        kv_bf16, scale_off + i * _ROW_BF16 + 8 * p,
                        mode="elem2datablock")
                    svec = rr.vreinterpret_lanes(brc, dtypes.bfloat16)
                    packed = rr.vmul(vals, svec, mask=m16)
                    self._v0_store(out, i, dst_p, packed, m16)
    def _v0_store(self, out, i, col, val, mask):
        # i 为子块内 token 行，col 为逻辑 D 列，所有偏移均以 BF16 元素计。
        # NZ17 的 UB 地址 = (col//16)*(17*16) + i*16 + col%16；vstore_strided
        # 每写 16 列跨到下一 face，间距 17 个 32B block。第 17 行是 padding。
        rr.vstore_strided(out, (col // 16) * _NZ_CHUNK + i * _NZ_ROW,
                          val, mask, block_stride=_NZ_PAD_ROWS,
                          repeat_stride=0)

    @jit
    def _vec0_body(self, kv_dsts, kv_slot, kv_pool, blk_table, blk_size, s2_start: int,
                   n_real, idx_tab=None, idx_row=None, batch=None,
                   is_cmp=False):
        # Each AIV handles four 16-token subblocks of a 128-token tile.
        # Pair DMA sorts KV and inline scales together; otherwise copy rows individually.
        # Tail rows repeat the last valid index. Uninitialized subblocks are excluded from PV.
        # Both pools use 544-byte UB rows; cmp reads only its 320-byte payload.
        SUB = _TILE_ROWS
        if const_expr(is_cmp):
            _ROW_BYTES = KV_ROW_BYTES_CMP
            page_stride = self._cmp_page_stride
        else:
            _ROW_BYTES = KV_ROW_BYTES_ORI
            page_stride = self._ori_page_stride
        n_rt = n_real
        # 显式覆盖从首字节到末页末字节的物理 storage（含页间空洞），不是 token 折叠。
        # mem_copy 保留 Channel 可识别的生产者。
        storage_bytes = ((kv_pool.shape[0] - 1) * page_stride + blk_size * _ROW_BYTES)
        kv_bytes = kv_pool.view(storage_bytes)

        part = self.n_sub // 2
        t0 = self.subblock_idx * part
        _mode = _addr_vec_mode()
        _consumer_vec = _mode == "pre"
        tab = None
        col_base = 0
        if const_expr(_mode == "pre"):
            # 行号已在主循环前的 pass 里写进 GM 表；col_base 选池区列基址。
            tab = self._addr_tab
            col_base = self._avec_k1_tab if const_expr(is_cmp) else 0
        for lt in range_constexpr(part):
            sub_b = t0 + lt
            sub_row = sub_b * SUB
            v0_out = self._v0_out.produce()
            if sub_row < n_rt:
                buf = self.ch_batch_bytes.produce()
                bo_sp = 0 if batch is None else batch
                # 寻址前钳位到有效前缀；残块尾行重读最后一个有效 token。
                last_off = n_rt - 1 - sub_row
                addresses = []
                pair_first = []
                pair_gap = []
                all_pairs_ok = Int32(1)
                if const_expr(_consumer_vec):
                    # Dense page strides make row_number * row_bytes the physical offset.
                    # The prepass has already clamped each column to the valid prefix.
                    for pair in range_constexpr(SUB // 2):
                        ii = pair * 2
                        c0 = col_base + s2_start + sub_row + ii
                        c1 = c0 + 1
                        r0 = _i64(tab, idx_row, c0)
                        r1 = _i64(tab, idx_row, c1)
                        addr0 = r0 * _ROW_BYTES
                        addr1 = r1 * _ROW_BYTES
                        first = min(addr0, addr1)
                        gap = max(addr0, addr1) - first
                        addresses.append(addr0)
                        addresses.append(addr1)
                        pair_first.append(first)
                        pair_gap.append(gap)
                        all_pairs_ok = dyn_select(gap >= _ROW_BYTES,
                            dyn_select(gap - _ROW_BYTES <= 549755813887,
                                       all_pairs_ok, Int32(0)), Int32(0))
                else:
                    for pair in range_constexpr(SUB // 2):
                        ii = pair * 2
                        pos0 = s2_start + sub_row + min(ii, last_off)
                        pos1 = s2_start + sub_row + min(ii + 1, last_off)
                        tok0 = _i64(idx_tab, idx_row, pos0)
                        tok1 = _i64(idx_tab, idx_row, pos1)
                        blk0, off0 = self.kvcache._pa_blk_off(
                            blk_table, tok0, bo_sp, blk_size)
                        blk1, off1 = self.kvcache._pa_blk_off(
                            blk_table, tok1, bo_sp, blk_size)
                        addr0 = blk0 * page_stride + off0 * _ROW_BYTES
                        addr1 = blk1 * page_stride + off1 * _ROW_BYTES
                        first = min(addr0, addr1)
                        gap = max(addr0, addr1) - first
                        addresses.append(addr0)
                        addresses.append(addr1)
                        pair_first.append(first)
                        pair_gap.append(gap)
                        all_pairs_ok = dyn_select(gap >= _ROW_BYTES,
                            dyn_select(gap - _ROW_BYTES <= 549755813887,
                                       all_pairs_ok, Int32(0)), Int32(0))
                # Deterministic level 3 requires sparse-index order, so disable pair sorting.
                all_pairs_ok = dyn_select(self._batch_consistency != 0, Int32(0), all_pairs_ok)
                # 每个分支填满16行再提交同一Channel槽。排序同时移动KV和内联scale，
                # QK与PV读取同一排列；尾部重复地址触发逐行回退，保留有效前缀。
                if all_pairs_ok != 0:
                    for pair in range_constexpr(SUB // 2):
                        first = pair_first[pair]
                        second = first + pair_gap[pair]
                        dst = tile_slice(buf, (2, _ROW_BYTES), (pair, 0))
                        mem_copy(dst, (kv_bytes[first:first + _ROW_BYTES,],
                                       kv_bytes[second:second + _ROW_BYTES,]))
                else:
                    for ii in range_constexpr(SUB):
                        addr = addresses[ii]
                        row = kv_bytes[addr:addr + _ROW_BYTES,].view(1, _ROW_BYTES)
                        mem_copy(tile_slice(buf, (1, _ROW_BYTES), (ii, 0)), row)
                # 只消费一次字节槽，VF 内的 scale 位解释不引入第二个 Channel。
                rslot_bytes = self.ch_batch_bytes.consume()

                if const_expr(is_cmp):
                    self._antiquant_vf_fp4_g16(rslot_bytes, v0_out)
                else:
                    self._antiquant_vf_fp8_g32(rslot_bytes, v0_out)
                # NZ17 faces become one regular strided UB-to-L1 copy.
                src = reinterpret(v0_out, shape=(D // 16, SUB * 16),
                                  stride=(_NZ_CHUNK, 1))
                dst = kv_dsts[lt]
                mem_copy(dst, src)
            if const_expr(lt == 0 and self._ori_topk_length is not None):
                # Complete the conditional producer transaction, including empty halves.
                empty_src = reinterpret(v0_out, shape=(SUB, D), data_format="nz", n1_pad=16)
                mem_copy(reinterpret(kv_slot, shape=(2 * SUB, D), data_format="nz"),
                         empty_src, engine=make_copy_engine(split_axis=0, split_alignment=16),
                         part_id=self.subblock_idx, actual=(0,D))

    @jit
    def _addr_vector_chunk(self, chunk, ktab, w, bs, inv_bs):
        lanes = min(_ADDR_HALF, ktab - chunk * _ADDR_HALF)
        mk, _ = rr.update_mask(lanes, elem_bits=32)
        lane = rr.varange(0, dtypes.int32)
        col = rr.vadds(lane, chunk * _ADDR_HALF, mask=mk)
        col = rr.vmins(col, w - Int64(1), mask=mk)
        idx = rr.vgather(self._ch_addr_sp,
                         rr.vreinterpret(col, dtypes.uint32), mask=mk)
        if const_expr(isinstance(bs, int)):
            blk = rr.vshr(idx, bs.bit_length() - 1, mask=mk)
        else:
            idx_f = rr.vcast(idx, dtypes.float32, mask=mk)
            blk = rr.vcast(rr.vmuls(idx_f, inv_bs, mask=mk),
                           dtypes.int32, mask=mk, rounding="rd")
        off = rr.vsub(idx, rr.vmuls(blk, bs, mask=mk), mask=mk)
        p = rr.vgather(self._ch_addr_bt,
                       rr.vreinterpret(blk, dtypes.uint32), mask=mk)
        row = rr.vadd(rr.vmuls(p, bs, mask=mk), off, mask=mk)
        rr.vstore(self._ch_addr_out, chunk * _ADDR_HALF, row, mk)

    @jit
    def _addr_precompute(self, m_count):
        """Precompute clamped physical row numbers for ori/cmp, then publish them within the block."""
        tab_cols = self._avec_k1_tab + (self._avec_k2_tab if self.has_cmp else 0)
        # Query rows are consecutive: locate the first batch once, then advance at cu_q boundaries.
        b_last = dtypes.int64(self._b_rt)
        batch0 = self._batch_of(self._m_start)
        bound0 = self._bound_after(batch0, b_last)
        for side in range_constexpr(2 if self.has_cmp else 1):
            if const_expr(side == 0):
                idx_tab, bt_gm = self._ori_idx, self._pa_bt
                bs, kwidth, col0 = self._avec_bs_ori, self._avec_k1, 0
                ktab = self._avec_k1_tab

                def w_fn(mi):
                    return self._ori_valid_w(mi)
            else:
                idx_tab, bt_gm = self._cmp_idx, self._pa_bt_cmp
                bs, kwidth, col0 = (self._avec_bs_cmp, self._avec_k2,
                                    self._avec_k1_tab)
                ktab = self._avec_k2_tab

                def w_fn(mi):
                    return self._cmp_topk_len(mi)
            btp = bt_gm.shape[1]
            if const_expr(isinstance(bs, int)):
                inv_bs = 1.0 / bs
            else:
                inv_bs = dtypes.float32(1.0) / dtypes.float32(bs)
            # Round up to cover every 16-column consumer subblock; mask the final vector chunk.
            chunks = (ktab + _ADDR_HALF - 1) // _ADDR_HALF
            total_valid = m_count
            per = total_valid // 2
            tail = total_valid % 2
            core = dtypes.int64(self.subblock_idx)
            # For an odd row count, give the extra ori row to AIV0 and the extra cmp row to AIV1.
            if const_expr(side == 0):
                start = per * core + min(core, tail)
                count = per + dyn_select(core < tail, Int64(1), Int64(0))
            else:
                start = per * core
                count = per + dyn_select(core < Int64(1), Int64(0), tail)
            counter = Int64(0)
            bt_staged = Int64(-1)
            # Initialize loop-carried batch state outside the loop; the inner while may execute zero times.
            batch = batch0
            bound = bound0
            for m_seq in range(0, m_count):
                m_idx = self._m_idx(m_seq)
                while m_idx >= bound:
                    batch = batch + 1
                    bound = self._bound_after(batch, b_last)
                w = w_fn(m_idx)
                active = dyn_select(w > Int64(0), Int64(1), Int64(0)) * \
                    dyn_select(counter >= start, Int64(1), Int64(0)) * \
                    dyn_select(counter < start + count, Int64(1), Int64(0))
                if active == Int64(1):
                    _copy_addr_from_gm(self._ch_addr_sp, idx_tab,
                               m_idx * kwidth, kwidth * 4)
                    key = batch * 2 + side
                    if key != bt_staged:
                        _copy_addr_from_gm(self._ch_addr_bt, bt_gm,
                                   batch * btp, btp * 4)
                    with vf(mode="raw"):
                        for chunk in range(chunks):
                            self._addr_vector_chunk(chunk, ktab, w, bs, inv_bs)
                    dst = m_idx * tab_cols + col0
                    # 写 ktab 列（含按 w-1 钳位的补齐列）；ktab 是 _TILE_ROWS 的
                    # 整数倍 ⇒ 每笔起止都落在 32B 边界，UB→GM 无 pad 能力也安全。
                    _copy_addr_to_gm(self._addr_tab, self._ch_addr_out, dst, ktab)
                counter = counter + Int64(1)
                # active==1 已蕴含 w>0，直接合并键
                bt_staged = dyn_select(active == Int64(1), batch * 2 + side, bt_staged)
        # Publish both AIVs' address writes through the AIC relay before either AIV reads the table.
        vec_sync_intra_arrive(PIPE.MTE3, self._addr_bar_sid)
        vec_sync_block_wait(PIPE.S, self._addr_bar_flag, mode=2)

    @jit
    def _stage_vec0(self, m_seq: int, n):
        # 按 n 选择 ori/cmp 的池、索引表和有效宽度，写同一条 L1 任务环。
        # cmp 的局部 tile 号 c=n−ori_tiles，从索引表 c*128 列开始取数；其地址表行偏移为 T1。
        # 两 AIV 共用所选 L1 槽；Channel 发布覆盖本 tile 的全部有效子块。
        m_idx = self._m_idx(m_seq)
        # Only scalar addressing needs a per-tile batch lookup.
        batch = None
        if const_expr(_addr_vec_mode() != "pre"):
            batch = self._batch_of(m_idx)

        # 在条件分支外选槽并构造所有视图，供自动同步建立完整发布边界。
        kv_slot = self.matmul.kv_ring.produce()
        l1_nd = reinterpret(kv_slot, shape=(D // 16, self.tile_n * 16), data_format="nd")
        kv_dsts = [tile_slice(l1_nd, (D // 16, _TILE_ROWS * 16),
                              (0, self.subblock_idx * (self.n_sub // 2) + i))
                   for i in range(self.n_sub // 2)]

        if const_expr(not self.has_cmp):
            self._vec0_body(kv_dsts, kv_slot, self._pa_phys, self._pa_bt, self._pa_bs_rt,
                            n * self.tile_n, self._ori_width(m_idx, n),
                            idx_tab=self._ori_idx, idx_row=m_idx, batch=batch,
                            is_cmp=False)
        else:
            ori_tiles = self._ori_tiles_rt(m_idx)
            ori_bound = ori_tiles
            if n >= ori_bound:
                c = n - ori_bound
                self._vec0_body(kv_dsts, kv_slot, self._pa_phys_cmp, self._pa_bt_cmp, self._pa_cmp_bs_rt,
                                c * self.tile_n,
                                self._cmp_valid(m_idx, c),
                                idx_tab=self._cmp_idx, idx_row=m_idx, batch=batch,
                                is_cmp=True)
            else:
                self._vec0_body(kv_dsts, kv_slot, self._pa_phys, self._pa_bt, self._pa_bs_rt,
                                n * self.tile_n, self._ori_width(m_idx, n),
                                idx_tab=self._ori_idx, idx_row=m_idx, batch=batch,
                                is_cmp=False)


        if const_expr(self._ori_topk_length is None):
            # Publish one transaction after either pool's conditional subblocks.
            empty_src = reinterpret(self._v0_out.consume(), shape=(_TILE_ROWS, D),
                                    data_format="nz", n1_pad=16)
            mem_copy(reinterpret(kv_slot, shape=(2 * _TILE_ROWS, D), data_format="nz"),
                     empty_src, engine=make_copy_engine(split_axis=0, split_alignment=16),
                     part_id=self.subblock_idx, actual=(0, D))

    @jit
    def _stage_bmm1_fanout(self, kv_slot, m_seq: int, is_first: int, is_last: int,
                           row_count):
        # Q half-slot credits protect resident Q; QK is copied to qk_ub through FIXPIPE.
        self.matmul.bmm1_fanout_q(kv_slot, m_seq, is_first, is_last)
        # bmm1_fanout_q returns the Q credit on the part's last KV tile. Issue
        # the next M copy now, before lag1 reaches it, retaining cross-M
        # overlap. Empty rows never run bmm1 and thus never consume/return a
        # Q credit; the prefetch must skip them or the ring deadlocks (the
        # metadata splitter can leave empty rows inside a core's range).
        if is_last == dtypes.int64(1):
            # Keep both scan states in the loop condition for DSL while lowering.
            j = m_seq + dtypes.int64(1)
            stop = row_count
            while j < stop:
                found = self._n_end_rt(self._m_idx(j)) != 0
                stop = dyn_select(found, j, stop)
                j = dyn_select(found, j, j + dtypes.int64(1))
            if j < row_count:
                q_queries = self._q.view(self._q.shape[0] // self.tile_cube_m,
                                         self.tile_cube_m, self.tile_d)
                next_q = q_queries[self._m_idx(j), None, None]
                self.matmul.load_q(next_q, j)
        self.matmul.store_s(self.qk_ub)

    @jit
    def _stage_softmax(self, tick: int, m_seq: int, n, is_first: int,
                       sum_slot: int):
        # lag2 AIV：Channel 自动管理 qk_ub 的消费事务 →
        # online softmax（分部首 tile 播种：整行首分部用 sinks，FD 续算分部用
        # (FP32_MIN, 0)）→ store_p 送 p_l1。
        # max/sum use the nonempty-row slot; exp uses tick%2.
        m_idx = self._m_idx(m_seq)
        actual_n = self._actual_n(m_idx, n)
        actual_vec_m = self.tile_vec_m

        m_axis_triple = sum_slot
        tile_triple = tick % 2

        qk_slot = self.qk_ub.consume()
        qk_view = reinterpret(qk_slot, shape=(actual_vec_m, self.tile_n), stride=(self.tile_n, 1))
        # 续算分部 = 本核首行(m_seq==0)且 s2_start>0；其首 tile 不得再播种 sinks。
        cont_part = dyn_select(m_seq == 0,
                               dyn_select(self._s2_start > 0, Int32(1), Int32(0)),
                               Int32(0))
        if is_first == dtypes.int64(1):
            if cont_part == Int32(1):
                self.vector.seed_empty(m_axis_triple)
            else:
                sinks_coord = self.subblock_idx
                sk = self.vector.sinks_ub
                mem_copy(sk, tile_slice(self._sinks, (1, self.sinks_span),
                                       (0, sinks_coord)))
                skr = self.vector.sinks_ub
                self.vector.seed_from_sinks(skr, m_axis_triple)
        self.vector.softmax_rest(qk_view, self._scale, m_axis_triple, tile_triple, actual_n)

        self.vector.store_p(self.p_l1)

    @jit
    def _stage_pv_fanout(self, kv_slot, m_seq: int, n):
        # lag3 cube：O_tile = P@K̃（P 读 p_l1，K̃ 转置读同一代 L1 环）→ fixpipe 送 pv_ub。
        self.matmul.compute_pv_fanout(self.p_l1, self.pv_ub,
                                      kv_slot, self._actual_n(self._m_idx(m_seq), n))
        # 此处结束同一 KV 槽的最后一次读取；Channel 随后允许 AIV 复用。

    @jit
    def _stage_loadqk(self, tick: int, m_seq: int):
        q_queries = self._q.view(self._q.shape[0] // self.tile_cube_m,
                                 self.tile_cube_m, self.tile_d)
        q_tile_gm = q_queries[self._m_idx(m_seq), None, None]
        self.matmul.load_qk(q_tile_gm, m_seq, tick)

    @jit
    def _stage_qk_softmax(self, kv_slot, tick: int, m_seq: int, n, is_last: int,
                          is_first: int, row_count, sum_slot: int):
        # Channel 在 bmm1 读 L1 槽前等待两 AIV 的 MTE3 发布。

        self._stage_bmm1_fanout(kv_slot, m_seq, is_first,
                                is_last, row_count)
        # Re-publish the same KV storage for the delayed PV read; zero extent
        # performs no UB read or L1 write, only the automatic ownership handoff.
        handoff_src = reinterpret(self._v0_out.consume(), shape=(_TILE_ROWS, D),
                                  data_format="nz", n1_pad=16)
        mem_copy(reinterpret(kv_slot, shape=(2 * _TILE_ROWS, D), data_format="nz"),
                 handoff_src, engine=make_copy_engine(split_axis=0, split_alignment=16),
                 part_id=self.subblock_idx, actual=(0, D))
        self._stage_softmax(tick, m_seq, n, is_first, sum_slot)

    @jit
    def _stage_pv_update(self, kv_slot, tick: int, m_seq: int, n, is_last: int,
                         is_first: int, sum_slot: int):
        self._stage_pv_fanout(kv_slot, m_seq, n)
        self._stage_update(tick, m_seq, is_last, is_first,
                           sum_slot)

    @jit
    def _stage_update(self, tick: int, m_seq: int, is_last: int,
                      is_first: int, sum_slot: int):
        # At a part boundary, normalize O and either stage the split part or write final output.
        # Empty rows bypass the pipeline and are finalized after draining.
        exp_idx = tick % 2
        sum_idx = sum_slot

        m_idx = self._m_idx(m_seq)
        o_row_tile = m_idx
        lse_tile_base = (
            o_row_tile * (self.tile_cube_m // self.tile_vec_m)
            + self.subblock_idx) if const_expr(self._lse is not None) else None
        # lse_tile_base 是 32 元素 tile 的编号；对应扁平 LSE 元素偏移 m_idx*64+aiv_id*32。
        if is_last == 1:
            if is_first == 1:
                if tick > dtypes.int64(0):
                    self.vector.wait_prev_out_copy()
                self.vector.init_o_last(self.pv_ub.consume(), sum_idx)
            else:
                self.vector.update_o_last(self.pv_ub.consume(), exp_idx, sum_idx)
            split_count = dyn_select(m_seq == self._first_split_row,
                                     dtypes.int64(1), dtypes.int64(0))
            split_count += dyn_select(m_seq == self._last_split_row,
                                      dtypes.int64(1), dtypes.int64(0))
            if split_count > 0:
                # A leading continuation uses slot 0. A trailing split uses slot 1 only
                # when this core also starts with a continuation.
                part_idx = dyn_select(
                    m_seq == 0, dtypes.int64(0),
                    dyn_select(self._s2_start > 0, dtypes.int64(1), dtypes.int64(0)))
                slot = self._first_fd + part_idx
                fd_o, fd_ms = self._fd_workspace_views()
                local_first = dyn_select(self._fd_async == 1,
                                         dyn_select(slot % 2 == 0, Int32(1), Int32(0)),
                                         Int32(0))
                self.vector.stage_partial(fd_o, fd_ms, slot, sum_idx,
                                          skip_o=local_first)
                if self._fd_async == 1 and slot % 2 == 1:
                    # The second part publishes readiness only after all
                    # three MTE3 staging writes have completed.
                    vec_sync_all()
                    ready_word = _FD_READY_BASE + (slot // 2) * 2 + self.subblock_idx
                    vec_store_bypass(self._metadata_gm.ptr((ready_word,)), Int32(1))
            else:
                o_tile_gm = tile_slice(self._out, (self.tile_cube_m, self.tile_d),
                                      (o_row_tile, 0))
                self.vector.finalize_o(o_tile_gm, sum_idx,
                                       lse_gm=self._lse, lse_base=lse_tile_base)
        else:
            if is_first == 1:
                if tick > dtypes.int64(0):
                    self.vector.wait_prev_out_copy()
                self.vector.init_o(self.pv_ub.consume())
            else:
                self.vector.update_o(self.pv_ub.consume(), exp_idx)

    @jit
    def _fd_workspace_views(self):
        # FD views are needed only by split-row staging and final reduction.
        blocks = self._ws.shape[0] // WS_BYTES_PER_CORE
        slots = blocks * FD_SLOTS_PER_CORE
        fd_o0 = dtypes.int64(0)
        ws_f32 = self._ws.view(dtypes.float32)
        fd_o = ws_f32[fd_o0:fd_o0 + slots * FD_O_ELEMS,].view(slots * N1, D)
        fd_ms0 = fd_o0 + slots * FD_O_ELEMS
        fd_ms = ws_f32[fd_ms0:fd_ms0 + slots * FD_MS_ELEMS,].view(slots * FD_MS_ELEMS)
        return fd_o, fd_ms

    def __call__(self, out_gm: Tensor, q_gm: Tensor,
                 sinks_gm: Tensor,
                 pa_phys_gm: Tensor = None, pa_bt_gm: Tensor = None, ws_gm: Tensor = None,
                 pa_phys_cmp_gm: Tensor = None, pa_bt_cmp_gm: Tensor = None,
                 cmp_idx_gm: Tensor = None,
                 ori_idx_gm: Tensor = None,
                 cu_seqlens_q: Tensor = None,
                 softmax_lse: Tensor = None,
                 ori_topk_length: Tensor = None, cmp_topk_length: Tensor = None,
                 metadata_gm: Tensor = None, softmax_scale: dtypes.float32 = 1.0,
                 batch_consistency: dtypes.int32 = 0,
                 addr_ws_gm: Tensor = None):
        # Workspace capacity determines the launch grid and FD slot count.
        self._b_rt = cu_seqlens_q.shape[1] - 1
        self._scale = softmax_scale
        self._batch_consistency = batch_consistency
        self._ori_page_stride = pa_phys_gm.stride[0]
        self._pa_bs_rt = pa_phys_gm.shape[1]
        if const_expr(self.has_cmp):
            self._cmp_page_stride = pa_phys_cmp_gm.stride[0]
            self._pa_cmp_bs_rt = pa_phys_cmp_gm.shape[1]
        self._ws = ws_gm
        self._q = q_gm
        self._sinks = sinks_gm
        self._out = out_gm
        self._lse = softmax_lse
        self._ori_topk_length = ori_topk_length
        self._cmp_topk_length = cmp_topk_length

        self._cu_q = cu_seqlens_q

        self._pa_phys, self._pa_bt = pa_phys_gm, pa_bt_gm
        self._ori_idx = ori_idx_gm
        if const_expr(self.has_cmp):
            self._pa_phys_cmp, self._pa_bt_cmp = pa_phys_cmp_gm, pa_bt_cmp_gm
            self._cmp_idx = cmp_idx_gm

        # Address-prepass storage exists only in the vector-addressing template.
        _avec = _addr_vec_mode()
        if const_expr(_avec == "pre"):
            self._avec_bs_ori = pa_phys_gm.shape[1]
            self._avec_k1 = ori_idx_gm.shape[1]
            self._avec_k1_tab = _addr_tab_w(self._avec_k1)
            self._avec_k2_tab = 0
            if const_expr(self.has_cmp):
                self._avec_bs_cmp = pa_phys_cmp_gm.shape[1]
                self._avec_k2 = cmp_idx_gm.shape[1]
                self._avec_k2_tab = _addr_tab_w(self._avec_k2)
            self._ch_addr_bt = Buffer(MemLoc.UB, shape=(1, _ADDR_BT_CAPACITY),
                                       dtype=dtypes.int32)
            self._ch_addr_sp = Buffer(MemLoc.UB, shape=(1, _ADDR_K_CAPACITY),
                                       dtype=dtypes.int32)
            # Fixed capacity also covers K rounded up to a 16-column boundary.
            self._ch_addr_out = Buffer(MemLoc.UB, shape=(1, _ADDR_K_CAPACITY),
                                        dtype=dtypes.int32)
            tab_cols = self._avec_k1_tab + (self._avec_k2_tab
                                            if self.has_cmp else 0)
            self._addr_tab = addr_ws_gm.view(dtypes.int32).view(
                addr_ws_gm.shape[0] // 4 // tab_cols, tab_cols)
            self._addr_bar_flag = 9
            # Both AIVs share an intra-sync ID; AIV1 uses the fixed ID offset on the AIC side.
            self._addr_bar_sid = 9

        # ---- FA metadata（faMetadata[block_idx][*]，字段对齐 AscendC）----
        # 区间语义：本核处理行 [m_start, m_end]（s2_end==0 时末行为 m_end-1）；
        # 首行从 tile s2_start 起、末行到 tile s2_end 止（0=整行）。
        # start[i] == end[i-1]，即 metadata 编码 (行, tile) 工作空间的连续半开划分。
        # 禁用核整行字段为 0 ⇒ row_count=0，自然跳过主循环，只参与 barrier。
        fa = self.block_idx * FA_METADATA_SIZE
        bn2_start = _i64(metadata_gm, fa + FA_BN2_START_INDEX)
        m_start_g = _i64(metadata_gm, fa + FA_M_START_INDEX)
        bn2_end = _i64(metadata_gm, fa + FA_BN2_END_INDEX)
        m_end_g = _i64(metadata_gm, fa + FA_M_END_INDEX)
        self._m_start = _i64(self._cu_q, 0, bn2_start) + m_start_g
        self._s2_start = _i64(metadata_gm, fa + FA_S2_START_INDEX)
        m_end = _i64(self._cu_q, 0, bn2_end) + m_end_g
        s2_end = _i64(metadata_gm, fa + FA_S2_END_INDEX)
        self._metadata_gm = metadata_gm
        self._first_fd = _i64(metadata_gm, fa + FA_FIRST_FD_DATA_WORKSPACE_IDX_INDEX)
        self._fd_async = _i64(metadata_gm, _FD_ASYNC_MODE_WORD)
        row_count = m_end - self._m_start + (1 if s2_end > 0 else 0)
        self._first_split_row = dyn_select(self._s2_start > 0,
                                           dtypes.int64(0), dtypes.int64(-1))
        self._last_split_row = dyn_select(s2_end > 0, row_count - 1,
                                          dtypes.int64(-1))
        # Zero s2 boundaries encode whole-row execution. Compute tile bounds
        # directly; the global FD gate is read only after the main loop.
        # DelayLineGroup 只延迟任务坐标，不保存张量；深度 4 对应最大 lag=3。
        # g 是本核流水时钟，s.t 是被取出的任务编号；每级必须用 s.t 选择该任务的环槽。
        # m/n/last/first 随任务一起传递，跨 query 边界也不能拿当前循环坐标
        # 替代延迟坐标；split 状态在分部末尾由 metadata 边界重建。
        lag_load = 1
        lag_b = 2
        lag_c = lag_b + 1
        DEPTH = 4
        DRAIN = lag_c
        dl = DelayLineGroup(DEPTH, 'm', 'n', 't', 'last', 'first', 'sum_slot')
        g = 0
        active_row = dtypes.int64(0)
        self.matmul.q_events_init()

        if const_expr(_addr_vec_mode() == "pre"):
            # Publish the address table before the main loop consumes it.
            self._addr_precompute(row_count)
            # AIC waits for both AIV writes before releasing the block.
            # Use MTE1 so the wait does not block Q prefetch on MTE2.
            cube_sync_intra_wait(PIPE.MTE1, self._addr_bar_sid)
            cube_sync_intra_wait(PIPE.MTE1,
                                 self._addr_bar_sid + _AIV1_ID_OFFSET)
            # Wait and release must use the same pipe to preserve ordering.
            cube_sync_block_arrive(PIPE.MTE1, self._addr_bar_flag, mode=2)

            # _addr_precompute's MTE3 arrive follows the last workspace store;
            # its S wait observes both AIV completions through the AIC relay.
            # All address Buffer reads/writes are therefore complete before any
            # main-loop UB use. Rewind reclaims storage, not synchronization.
            channel_rewind(reset_sync_id=False)

        self._setup_main_ub()

        # ---- warmup / steady：每核 g 从 0 递增，跨 query 及 ori→cmp 边界不重置 ----
        # g>=lag 才存在该级任务；每级按 Channel 依赖分别发往 AIC/AIV，Python 调用顺序
        # 不等于所有硬件串行执行。每个 query 仅 n 从 t0 起计数；first 触发 softmax/O
        # 初始化（续算分部用空种子），last+split 触发 FD 暂存而非 finalize。
        # row_count=0 的核不发任务；分页查表不需要全核地址预计算屏障。
        kv_qk = self.matmul.kv_ring.consume()
        kv_pv = kv_qk
        for m_seq in range(0, row_count):
            m_idx = self._m_idx(m_seq)
            tiles = self._n_end_rt(m_idx)
            t0 = dyn_select(m_seq == 0, self._s2_start, dtypes.int64(0))
            t1_tail = dyn_select(s2_end > 0, s2_end, tiles)
            t1 = dyn_select(m_seq == row_count - 1, t1_tail, tiles)
            for n in range(t0, t1):
                is_last = 1 if n == t1 - 1 else 0
                is_first = 1 if n == t0 else 0
                dl.push(m=m_seq, n=n, t=g, last=is_last, first=is_first,
                        sum_slot=active_row % 2)

                next_pv = kv_pv
                self._stage_vec0(m_seq, n)
                if g >= lag_load:
                    s0 = dl.tap(lag_load)
                    self._stage_loadqk(s0.t, s0.m)
                if g >= lag_b:
                    s1 = dl.tap(lag_b)
                    self._stage_qk_softmax(kv_qk, s1.t, s1.m, s1.n, s1.last, s1.first,
                                           row_count, s1.sum_slot)
                    next_pv = kv_qk
                    kv_qk = self.matmul.kv_ring.consume()

                if g >= lag_c:
                    s2 = dl.tap(lag_c)
                    self._stage_pv_update(kv_pv, s2.t, s2.m, s2.n, s2.last, s2.first,
                                          s2.sum_slot)

                kv_pv = next_pv
                dl.advance()
                g = g + 1
            active_row = active_row + dyn_select(
                t1 > t0, dtypes.int64(1), dtypes.int64(0))
        # ---- drain：不再 push 新任务，固定推进 3 拍，让末尾坐标走完所有后级 ----
        # r<lag 排除该级已排空的拍；g>=lag 排除任务数过少时尚未填充的 tap。
        # 即使只发 1 个任务，也会依次补跑 loadQK、QK/softmax、PV/update；空核各守卫均不通过。
        for r in range_constexpr(DRAIN):
            next_pv = kv_pv
            if const_expr(r < lag_load):
                if g >= lag_load:
                    s0 = dl.tap(lag_load)
                    self._stage_loadqk(s0.t, s0.m)
            if const_expr(r < lag_b):
                if g >= lag_b:
                    s1 = dl.tap(lag_b)
                    self._stage_qk_softmax(kv_qk, s1.t, s1.m, s1.n, s1.last, s1.first,
                                           row_count, s1.sum_slot)
                    next_pv = kv_qk
                    kv_qk = self.matmul.kv_ring.consume()
            if const_expr(r < lag_c):
                if g >= lag_c:
                    s2 = dl.tap(lag_c)
                    self._stage_pv_update(kv_pv, s2.t, s2.m, s2.n, s2.last, s2.first,
                                          s2.sum_slot)
            kv_pv = next_pv
            dl.advance()
            g = g + 1

        self.matmul.q_events_drain()

        # Empty queries never enter the delay line. Write their outputs after
        # draining so the shared output buffer cannot disturb pending PVs.
        for m_seq in range(0, row_count):
            m_idx = self._m_idx(m_seq)
            if self._n_end_rt(m_idx) == 0:
                o_tile = tile_slice(self._out, (self.tile_cube_m, self.tile_d),
                                   (m_idx, 0))
                lse_base = (m_idx * 2 + self.subblock_idx
                            if const_expr(self._lse is not None) else None)
                self.vector.finalize_empty(o_tile, self._sinks, self._lse, lse_base)

        # The uniform fd_any field gates synchronization and reduction on every core.
        # Without split rows, skip both. Enabled AIVs reduce their assigned partials.
        fd_any = _i64(metadata_gm, FD_USED_VEC_NUM_WORD)
        if fd_any != 0:
            if self._fd_async == 1:
                vec_sync_all()
            else:
                global_sync_all()
            # After the barrier, reclaim main-loop UB for the full (32,512) FP32 reduction landing.
            channel_rewind(reset_sync_id=False)
            self.vector._setup_fd_reduce_buffers()
            aiv_idx = self.block_idx * get_subblock_dim() + self.subblock_idx
            fdb = FD_METADATA_BASE + aiv_idx * FD_METADATA_SIZE
            fd_enable = _i64(metadata_gm, fdb + FD_CORE_ENABLE_INDEX)
            if fd_enable != 0:
                fd_bn2 = _i64(metadata_gm, fdb + FD_BN2_IDX_INDEX)
                fd_m = _i64(metadata_gm, fdb + FD_M_IDX_INDEX)
                fd_row = _i64(self._cu_q, 0, fd_bn2) + fd_m
                fd_ws = _i64(metadata_gm, fdb + FD_WORKSPACE_IDX_INDEX)
                fd_k = _i64(metadata_gm, fdb + FD_WORKSPACE_NUM_INDEX)
                fd_h0 = _i64(metadata_gm, fdb + FD_M_START_INDEX)
                fd_o, fd_ms = self._fd_workspace_views()
                if self._fd_async == 1:
                    ready_word = _FD_READY_BASE + (fd_ws // 2) * 2 + self.subblock_idx
                    vec_busy_wait(metadata_gm[ready_word], Int32(1))
                    self.vector.fd_reduce_local_first(
                        fd_o, fd_ms, self.vector.fd_ub, self._out, self._lse,
                        fd_row, fd_ws, fd_h0)
                else:
                    self.vector.fd_reduce(fd_o, fd_ms, self.vector.fd_ub,
                                          self._out, self._lse,
                                          fd_row, fd_ws, fd_k, fd_h0)


def _batch_consistency_enabled():
    """批量一致性开关：torch_npu 确定性等级 == 3 时开启。

    用 `torch_npu.npu._get_deterministic_level()` 读取，level == 3 时 VEC0 的 sparse KV
    搬入从「成对双行 DMA」退化成「逐行搬运」（见 `_vec0_body` 的 `all_pairs_ok` 覆盖）。
    """
    try:
        import torch_npu
        return int(torch_npu.npu._get_deterministic_level()) == 3
    except (AttributeError, ImportError):
        return False

def _validate_inputs(
    q,
    *,
    ori_kv=None,
    cmp_kv=None,
    ori_sparse_indices=None,
    cmp_sparse_indices=None,
    ori_block_table=None,
    cmp_block_table=None,
    cu_seqlens_q=None,
    seqused_q=None,
    seqused_ori_kv=None,
    seqused_cmp_kv=None,
    ori_topk_length=None,
    cmp_topk_length=None,
    sinks=None,
    metadata=None,
    quant_mode,
    layout_q="TND",
    layout_kv="PA_BBND",
):
    """Validate tensor metadata only; never read tensor values on the host.

    Callers supply valid prefix sums, sequence lengths and active indices.
    seqused_q, when supplied, must equal the cu_seqlens_q spans (no padding).
    """
    if ori_kv is None:
        raise ValueError("ori_kv is required")
    if str(layout_q).upper() != "TND" or str(layout_kv).upper() != "PA_BBND":
        raise ValueError("mixed_quant_sparse_flash_mla supports only "
                         "layout_q='TND' and layout_kv='PA_BBND'")
    if int(quant_mode) != 1:
        raise ValueError("mixed_quant_sparse_flash_mla supports only "
                         "quant_mode=1")

    if not isinstance(q, torch.Tensor):
        raise TypeError("q must be a torch.Tensor")
    if q.dtype != torch.bfloat16 or q.dim() != 3 or int(q.shape[-1]) != D:
        raise ValueError("q must be a BF16 TND tensor with shape [T1, N1, 512]")
    rows, n1 = int(q.shape[0]), int(q.shape[1])
    if n1 != N1:
        raise ValueError(f"N1 must be {N1} (the only supported query-head "
                         f"count), got {n1}")
    if rows <= 0:
        raise ValueError("q must contain at least one token")

    if cu_seqlens_q is None:
        raise ValueError(
            "cu_seqlens_q is required for TND varlen and is never synthesized: "
            "pass an int32 [B+1] prefix-sum tensor ending at q.shape[0]")
    if (not isinstance(cu_seqlens_q, torch.Tensor)
            or cu_seqlens_q.dtype != torch.int32 or cu_seqlens_q.dim() != 1):
        raise ValueError("cu_seqlens_q must be an int32 tensor of shape (B+1,)")
    if cu_seqlens_q.numel() < 2:
        raise ValueError("cu_seqlens_q must describe at least one batch")
    b = cu_seqlens_q.numel() - 1

    if seqused_q is not None:
        if not isinstance(seqused_q, torch.Tensor):
            raise TypeError("seqused_q must be a torch.Tensor when provided")
        if seqused_q.dtype != torch.int32 or seqused_q.dim() != 1:
            raise ValueError("seqused_q must be a 1-D int32 tensor of shape (B,)")
        if seqused_q.numel() != b:
            raise ValueError("seqused_q must have one length per cu_seqlens_q batch")

    for name, seqused in (("seqused_ori_kv", seqused_ori_kv),
                          ("seqused_cmp_kv", seqused_cmp_kv)):
        if seqused is None:
            continue
        if not isinstance(seqused, torch.Tensor):
            raise TypeError(f"{name} must be a torch.Tensor when provided")
        if seqused.dtype != torch.int32 or seqused.dim() != 1:
            raise ValueError(f"{name} must be a 1-D int32 tensor of shape (B,)")
        if int(seqused.numel()) != b:
            raise ValueError(f"{name} must have one entry per batch element (B={b})")

    has_cmp = (cmp_kv is not None or cmp_sparse_indices is not None
               or cmp_block_table is not None)
    if has_cmp:
        if (cmp_kv is None or cmp_sparse_indices is None
                or cmp_block_table is None):
            raise ValueError("ORI_CMP_SPARSE requires cmp_kv, cmp_sparse_indices, "
                             "cmp_block_table together")
    elif cmp_topk_length is not None:
        raise ValueError("cmp inputs are not valid for ORI_SPARSE")

    _validate_pa_side(ori_kv, ori_block_table, name="ori_kv",
                      row_bytes=KV_ROW_BYTES_ORI)
    _validate_indices(ori_sparse_indices, name="ori_sparse_indices", rows=rows)
    _validate_lengths(ori_topk_length, name="ori_topk_length", rows=rows)

    if has_cmp:
        _validate_pa_side(cmp_kv, cmp_block_table, name="cmp_kv",
                          row_bytes=KV_ROW_BYTES_CMP)
        _validate_indices(cmp_sparse_indices, name="cmp_sparse_indices", rows=rows)
        _validate_lengths(cmp_topk_length, name="cmp_topk_length", rows=rows)

    if sinks is None:
        raise ValueError("sinks is required: pass an FP32 [N1] tensor shared by all batches")
    if (not isinstance(sinks, torch.Tensor) or sinks.dtype != torch.float32
            or tuple(sinks.shape) != (n1,)):
        raise ValueError("sinks must be an FP32 tensor with shape [N1], shared by all batches")

    if metadata is None:
        raise ValueError(
            "metadata is required and is never synthesized: generate it with "
            "mixed_quant_sparse_flash_mla_metadata(ori_topk_length, cmp_topk_length, num_heads_q=64, num_heads_kv=1, head_dim=512, quant_mode=1, has_cmp_kv=...) and pass "
            "the result in (two-stage call)")
    if not isinstance(metadata, torch.Tensor):
        raise TypeError("metadata must be a torch.Tensor")
    if (metadata.dtype != torch.int32 or metadata.dim() != 1
            or metadata.numel() != MQSMLA_METADATA_TOTAL_SIZE):
        raise ValueError(f"metadata must be a 1-D int32 tensor with exactly "
                         f"{MQSMLA_METADATA_TOTAL_SIZE} elements (fixed shape)")


def _validate_pa_side(kv, block_table, *, name, row_bytes):
    if not isinstance(kv, torch.Tensor) or not isinstance(block_table, torch.Tensor):
        raise TypeError(f"{name} and {name}_block_table must be torch.Tensor")
    if (kv.dtype != torch.uint8 or kv.dim() != 4
            or int(kv.shape[2]) != N2 or int(kv.shape[-1]) != row_bytes):
        side = "FP8 (ori)" if name != "cmp_kv" else "FP4 (cmp)"
        raise ValueError(
            f"{name} must be a uint8 [blocknum, blocksize, 1, {row_bytes}] "
            f"tensor ({side} byte view); got shape {tuple(kv.shape)}, "
            f"dtype {kv.dtype}")
    if int(kv.shape[0]) <= 0 or int(kv.shape[1]) <= 0:
        raise ValueError(f"{name} must be non-empty")
    if (block_table.dtype != torch.int32 or block_table.dim() != 2
            or int(block_table.shape[0]) <= 0 or int(block_table.shape[1]) <= 0):
        raise ValueError(f"{name}_block_table must be a non-empty int32 "
                         f"[batch, num_blocks] tensor")
    bs = int(kv.shape[1])
    strides = tuple(kv.stride())
    page_stride = int(kv.stride(0))  # uint8 元素数即字节数；独立于页内 token 数。
    if strides[1:] != (N2 * row_bytes, row_bytes, 1):
        raise ValueError(f"{name} only supports axis-0 non-contiguity; "
                         f"page dimensions must be contiguous, got strides {strides}")
    if page_stride < bs * N2 * row_bytes:
        raise ValueError(f"{name} page stride must be at least {bs * N2 * row_bytes} "
                         "bytes (positive, non-overlapping pages)")
    if bs > 1024:
        raise ValueError("PA block size must be in 1..1024")

def _validate_indices(idx, *, name, rows):
    if not isinstance(idx, torch.Tensor) or idx.dtype != torch.int32:
        raise ValueError(f"{name} must be an int32 torch.Tensor")
    if (idx.dim() != 3 or int(idx.shape[0]) != rows
            or int(idx.shape[1]) != N2):
        raise ValueError(f"{name} must be int32 with shape [T1, 1, K] "
                         f"(one row per query token, {rows} rows)")
    k = int(idx.shape[2])
    if k <= 0:
        raise ValueError(f"{name} must have at least one index column")

def _validate_lengths(x, *, name, rows):
    if x is None:
        return None
    if not isinstance(x, torch.Tensor) or x.dtype != torch.int32:
        raise ValueError(f"{name} must be an int32 torch.Tensor")
    if x.dim() != 2 or int(x.shape[0]) != rows or int(x.shape[1]) != N2:
        raise ValueError(f"{name} must be int32 with shape [T1, 1]")

def construct_workspace(metadata, addr_bytes=0):
    # Query the same device core count as metadata; workspace capacity determines the launch grid.
    blocks = _get_cube_core_num(metadata.device)
    if not 0 < blocks <= AIC_CORE_MAX_NUM:
        raise ValueError(f"core count must be in 1..{AIC_CORE_MAX_NUM}, got {blocks}")
    ws_bytes = blocks * WS_BYTES_PER_CORE
    # Allocation only: avoid a zeros device op during ACLGraph capture.
    # FD slots are fully written by their staging core before publication.
    # addr_bytes：pre 臂的行号表区（T1×(K1+K2)×4B），同一次 device 分配，
    # 不增加 host 内存与 H2D（kernel 自写自读，消费侧只读被写过的列）。
    return torch.empty(ws_bytes + addr_bytes, dtype=torch.uint8,
                       device=metadata.device)

@jit
def _run_mqsmla(q_gm: Tensor, ori_kv_gm: Tensor, ori_idx_gm: Tensor,
                ori_bt_gm: Tensor, ori_len_gm: Tensor, out_gm: Tensor,
                sinks_gm: Tensor, cu_seqlens_q: Tensor,
                metadata_gm: Tensor, workspace_gm: Tensor,
                cmp_kv_gm: Tensor = None, cmp_idx_gm: Tensor = None,
                cmp_bt_gm: Tensor = None, cmp_len_gm: Tensor = None,
                lse_gm: Tensor = None, softmax_scale: dtypes.float32 = 1.0,
                batch_consistency: dtypes.int32 = 0,
                addr_ws_gm: Tensor = None):
    """Adapt dynamic tensor views and launch the device kernel from a JIT entry."""
    # trace 期只变 DSL Tensor 视图，不做 torch 变形或数值转换：
    # Q/out [T1,64,512]→[T1*64,512]，故设备 m-tile 行号就是全局 query token 号；
    # KV 保留四维 uint8 原视图；两侧页大小和 page stride 从运行时 DSL Tensor 获取；
    # indices [T1,1,K]→[T1,K]；lengths [T1,1]→[T1]；cu [B+1]→[1,B+1]；
    # sinks [64]→[1,64]（所有 batch/query 共用）；LSE [1,T1,64]→[T1*64]。
    # KV 按字节寻址，避免把页间 padding 当成 token；vec0 搬到 UB 后按 FP8/FP4 解码。
    m_rows = q_gm.shape[0] * q_gm.shape[1]
    q_flat = q_gm.view(m_rows, D)
    out_flat = out_gm.view(m_rows, D)
    ori_pool = ori_kv_gm
    ori_idx_flat = ori_idx_gm.view(
        ori_idx_gm.shape[0] * ori_idx_gm.shape[1], ori_idx_gm.shape[2])
    ori_len_flat = None
    if const_expr(ori_len_gm is not None):
        ori_len_flat = ori_len_gm.view(
            ori_len_gm.shape[0] * ori_len_gm.shape[1])
    cu_q = cu_seqlens_q.view(1, cu_seqlens_q.shape[0])
    sinks_k = sinks_gm.view(1, q_gm.shape[1])
    lse_flat = None
    if const_expr(lse_gm is not None):
        lse_flat = lse_gm.view(lse_gm.shape[1] * lse_gm.shape[2])
    cmp_pool = None
    cmp_idx_flat = None
    cmp_len_flat = None
    if const_expr(cmp_kv_gm is not None):
        cmp_pool = cmp_kv_gm
        cmp_idx_flat = cmp_idx_gm.view(
            cmp_idx_gm.shape[0] * cmp_idx_gm.shape[1], cmp_idx_gm.shape[2])
        if const_expr(cmp_len_gm is not None):
            cmp_len_flat = cmp_len_gm.view(
                cmp_len_gm.shape[0] * cmp_len_gm.shape[1])
    op = MqsmlaKernel(
        tile_cube_m=N1, tile_vec_m=N1 // 2, tile_n=TILE_N,
        has_cmp=(cmp_kv_gm is not None))
    # Each core has two FD staging slots; workspace capacity determines the dynamic launch grid.
    blocks = workspace_gm.shape[0] // WS_BYTES_PER_CORE
    if const_expr(_addr_vec_mode() == "pre"):
        op[blocks](out_flat, q_flat, sinks_k,
                   ori_pool, ori_bt_gm, workspace_gm,
                   cmp_pool, cmp_bt_gm, cmp_idx_flat,
                   ori_idx_flat, cu_q, lse_flat, ori_len_flat,
                   cmp_len_flat, metadata_gm,
                   softmax_scale, batch_consistency, addr_ws_gm)
    else:
        op[blocks](out_flat, q_flat, sinks_k,
                   ori_pool, ori_bt_gm, workspace_gm,
                   cmp_pool, cmp_bt_gm, cmp_idx_flat,
                   ori_idx_flat, cu_q, lse_flat, ori_len_flat,
                   cmp_len_flat, metadata_gm,
                   softmax_scale, batch_consistency)

_COMPILED_KERNELS = {}
_COMPILED_KERNEL_LOCK = threading.Lock()


def clear_caches():
    """Close cached executables."""
    with _COMPILED_KERNEL_LOCK:
        for compiled in _COMPILED_KERNELS.values():
            compiled.close()
        _COMPILED_KERNELS.clear()


def _get_compiled_kernel(
    ori_kv, ori_sparse_indices, ori_block_table, ori_topk_length,
    cmp_kv=None, cmp_sparse_indices=None, cmp_block_table=None,
    cmp_topk_length=None, lse=None,
):
    """Cache the dynamic executable by optional-input structure.

    The host entry validates the fixed tensor contract before calling here.
    S2, K1/K2 and page-table widths remain runtime values in every template.
    The page128 layout has a fixed-stride fast template; other eligible pages
    share one symbolic vector template, and remaining layouts share scalar AOT.
    """
    has_cmp = cmp_kv is not None
    # Select algorithms by layout/capacity only, never by individual S2/K values.
    eligible = _addr_vec_eligible(
        ori_kv, ori_block_table, ori_sparse_indices,
        cmp_kv, cmp_block_table, cmp_sparse_indices)
    eff_mode = "pre" if eligible else "off"
    fixed_page128 = (eligible and ori_kv.shape[1] == 128
                     and (not has_cmp or cmp_kv.shape[1] == 128))
    key = (has_cmp, ori_topk_length is not None, cmp_topk_length is not None,
           lse is not None, eff_mode, fixed_page128)
    with _COMPILED_KERNEL_LOCK:
        compiled = _COMPILED_KERNELS.get(key)
        if compiled is not None:
            return compiled
        global _ADDR_VEC_OVERRIDE
        _ADDR_VEC_OVERRIDE = eff_mode
        try:
            return _compile_mqsmla_locked(
                ori_topk_length, cmp_topk_length, lse,
                has_cmp, eff_mode, key, fixed_page128)
        finally:
            _ADDR_VEC_OVERRIDE = None


def _compile_mqsmla_locked(
        ori_topk_length, cmp_topk_length, lse,
        has_cmp, eff_mode, key, fixed_page128):
    rows = cannbotdsl.Dim("T1", min=1)
    batch = cannbotdsl.Dim("B", min=1)
    # 固定 1024：静态 shape，图捕获友好；分核计划在其中动态编码。
    metadata_size = MQSMLA_METADATA_TOTAL_SIZE
    spec = cannbotdsl.TensorSpec
    bs_w = 128 if fixed_page128 else cannbotdsl.Dim("ORI_BS", min=1, max=1024)
    btp_w = cannbotdsl.Dim("ORI_BT", min=1)
    k1 = cannbotdsl.Dim("K1", min=1)
    bs_c = 128 if fixed_page128 else cannbotdsl.Dim("CMP_BS", min=1, max=1024)
    btp_c = cannbotdsl.Dim("CMP_BT", min=1)
    k2 = cannbotdsl.Dim("K2", min=1)
    stride_w = 128 * KV_ROW_BYTES_ORI if fixed_page128 else cannbotdsl.Dim("ORI_STRIDE", min=1)
    stride_c = 128 * KV_ROW_BYTES_CMP if fixed_page128 else cannbotdsl.Dim("CMP_STRIDE", min=1)
    q_spec = spec((rows, N1, D), dtypes.bfloat16)
    ori_kv_spec = spec(
        (cannbotdsl.Dim("ORI_PAGES", min=1),
         bs_w, N2, KV_ROW_BYTES_ORI),
        dtypes.uint8,
        stride=(stride_w,
                KV_ROW_BYTES_ORI, KV_ROW_BYTES_ORI, 1))
    ori_indices_spec = spec((rows, N2, k1), dtypes.int32)
    ori_bt_spec = spec((batch, btp_w), dtypes.int32)
    ori_length_spec = None
    if ori_topk_length is not None:
        ori_length_spec = spec((rows, N2), dtypes.int32)
    out_spec = spec((rows, N1, D), dtypes.bfloat16)
    sinks_spec = spec((N1,), dtypes.float32)
    cu_spec = spec((batch + 1,), dtypes.int32)
    metadata_spec = spec((metadata_size,), dtypes.int32)
    # workspace = blocks × WS_BYTES_PER_CORE（FD staging），
    # 整除约束让 kernel 从容量反推动态发射网格。
    workspace_spec = spec(
        (cannbotdsl.Dim("WORKSPACE_BYTES", min=WS_BYTES_PER_CORE,
                        multiple_of=WS_BYTES_PER_CORE),),
        dtypes.uint8)
    cmp_kv_spec = None
    cmp_indices_spec = None
    cmp_bt_spec = None
    cmp_length_spec = None
    if has_cmp:
        cmp_kv_spec = spec(
            (cannbotdsl.Dim("CMP_PAGES", min=1),
             bs_c, N2, KV_ROW_BYTES_CMP),
            dtypes.uint8,
            stride=(stride_c,
                    KV_ROW_BYTES_CMP, KV_ROW_BYTES_CMP, 1))
        cmp_indices_spec = spec((rows, N2, k2), dtypes.int32)
        cmp_bt_spec = spec((batch, btp_c), dtypes.int32)
    if cmp_topk_length is not None:
        cmp_length_spec = spec((rows, N2), dtypes.int32)
    lse_spec = None
    if lse is not None:
        lse_spec = spec((N2, rows, N1), dtypes.float32)
    # Optional address workspace is last, keeping scalar arguments in fixed order.
    addr_ws_spec = (spec((cannbotdsl.Dim("ADDR_WS_BYTES", min=1),), dtypes.uint8)
                    if eff_mode == "pre"
                    else None)
    compiled = _run_mqsmla.compile(
        q_spec, ori_kv_spec, ori_indices_spec, ori_bt_spec, ori_length_spec,
        out_spec, sinks_spec, cu_spec, metadata_spec, workspace_spec,
        cmp_kv_spec, cmp_indices_spec, cmp_bt_spec, cmp_length_spec,
        lse_spec, dtypes.float32, dtypes.int32, addr_ws_spec,
    )
    # Publish only after compilation succeeds; failures can be retried.
    _COMPILED_KERNELS[key] = compiled
    return compiled


def mixed_quant_sparse_flash_mla(
    q,
    *,
    ori_kv=None,
    cmp_kv=None,
    ori_sparse_indices=None,
    cmp_sparse_indices=None,
    ori_block_table=None,
    cmp_block_table=None,
    cu_seqlens_q=None,
    seqused_q=None,
    seqused_ori_kv=None,
    seqused_cmp_kv=None,
    ori_topk_length=None,
    cmp_topk_length=None,
    sinks=None,
    metadata=None,
    quant_mode,
    softmax_scale=None,
    layout_q="TND",
    layout_kv="PA_BBND",
    return_softmax_lse=False,
    out,
    lse,
):
    _validate_inputs(
        q,
        ori_kv=ori_kv,
        cmp_kv=cmp_kv,
        ori_sparse_indices=ori_sparse_indices,
        cmp_sparse_indices=cmp_sparse_indices,
        ori_block_table=ori_block_table,
        cmp_block_table=cmp_block_table,
        cu_seqlens_q=cu_seqlens_q,
        seqused_q=seqused_q,
        seqused_ori_kv=seqused_ori_kv,
        seqused_cmp_kv=seqused_cmp_kv,
        ori_topk_length=ori_topk_length,
        cmp_topk_length=cmp_topk_length,
        sinks=sinks,
        metadata=metadata,
        quant_mode=quant_mode,
        layout_q=layout_q,
        layout_kv=layout_kv,
    )
    for name, tensor, shape, dtype in (
        ("out", out, tuple(q.shape), torch.bfloat16),
        ("lse", lse, (N2, q.shape[0], q.shape[1]), torch.float32),
    ):
        if name == "lse" and not return_softmax_lse:
            shape = (0,)
        if not isinstance(tensor, torch.Tensor):
            raise ValueError(f"{name} must be a caller-allocated tensor")
        if (tuple(tensor.shape) != shape or tensor.dtype != dtype
                or not tensor.is_contiguous()):
            raise ValueError(f"{name} must be contiguous {dtype} {shape}")
    # An absent length tensor activates all sparse-index columns; the kernel
    # reads K from the index shape without allocating a replacement tensor.
    addr_ws = None
    addr_bytes = 0
    if _addr_vec_eligible(ori_kv, ori_block_table, ori_sparse_indices,
                          cmp_kv, cmp_block_table, cmp_sparse_indices):
        columns = _addr_tab_w(ori_sparse_indices.shape[2])
        if cmp_kv is not None:
            columns += _addr_tab_w(cmp_sparse_indices.shape[2])
        addr_bytes = q.shape[0] * columns * 4
    # Allocate FD staging and the address table together.
    workspace_full = construct_workspace(metadata, addr_bytes)
    if addr_bytes:
        workspace = workspace_full[:-addr_bytes]
        addr_ws = workspace_full[-addr_bytes:]
    else:
        workspace = workspace_full
    tensors = (
        q, ori_kv, ori_sparse_indices, ori_block_table, ori_topk_length,
        out, sinks, cu_seqlens_q, metadata, workspace,
        cmp_kv, cmp_sparse_indices, cmp_block_table, cmp_topk_length,
        lse if return_softmax_lse else None,
    )
    compiled = _get_compiled_kernel(
        ori_kv, ori_sparse_indices, ori_block_table, ori_topk_length,
        cmp_kv, cmp_sparse_indices, cmp_block_table, cmp_topk_length,
        lse if return_softmax_lse else None,
    )
    # AOT fixes absent Tensor parameters at compile time and removes them from
    # the runtime signature. Remaining Tensor arguments keep their order.
    scale = (float(softmax_scale) if softmax_scale is not None
             else 1.0 / math.sqrt(q.shape[-1]))
    batch_consistency = 1 if _batch_consistency_enabled() else 0
    compiled(*(tensor for tensor in tensors if tensor is not None), scale,
             batch_consistency,
             *( [addr_ws] if addr_ws is not None else [] ))
# Native export profiles describe optional-input structures and example tensors.
# T1, K1/K2 and physical page sizes/counts stay dynamic in the public TensorSpecs.
from cannbotdsl.package.native import register


@register("mqsmla")
def export_mqsmla():
    """Export without allocating NPU inputs or launching an attention kernel.

    CANNBOTDSL_DS41_PROFILES may name a JSON file with a ``mqsmla`` list.
    Each entry selects optional-input structure and example tensor shapes.
    K1/K2, like other sizes, become symbolic TensorSpecs and do not select a binary.
    """
    import json

    profile_path = os.environ.get("CANNBOTDSL_DS41_PROFILES")
    # One symbolic Native binary per optional-input structure and layout.
    # Runtime S2/K values do not select another binary.
    profiles = [
        {"has_ori_length": ori_length, "has_cmp_length": cmp_length,
         "return_softmax_lse": lse}
        for ori_length in (True, False)
        for cmp_length in (True, False)
        for lse in (True, False)
    ] + [
        {"k2": 0, "has_ori_length": ori_length,
         "return_softmax_lse": lse}
        for ori_length in (True, False)
        for lse in (True, False)
    ]
    # Three layout strategies, independent of the S2/K value range:
    # page128 vector, general power-of-two vector, symbolic scalar fallback.
    profiles = (profiles
                + [dict(profile, bs=32, bs2=32) for profile in profiles]
                + [dict(profile, bs=3, bs2=3) for profile in profiles])
    if profile_path:
        with open(profile_path, encoding="utf-8") as stream:
            profiles = json.load(stream).get("mqsmla", profiles)
    # Custom vector-only profiles must also package their scalar fallback.
    if profile_path:
        profiles += [dict(profile, bs=3, bs2=3) for profile in list(profiles)]
    defaults = dict(b=1, k1=128, k2=512, bs=128, bs2=128,
                    s2_cap=8192, s2c_cap=4096, blocks=28)
    clear_caches()
    try:
        for profile in profiles:
            config = dict(defaults, **profile)
            if config.pop("sinks_dim", 1) != 1:
                raise ValueError("MQSMLA sinks must have shape [N1]; sinks_dim must be 1")
            has_lse = config.pop("return_softmax_lse", False)
            has_ori_length = config.pop("has_ori_length", True)
            has_cmp_length = config.pop("has_cmp_length", True)
            config.setdefault("ori_page_stride", config["bs"] * 544)
            config.setdefault("cmp_page_stride", config["bs2"] * 320 if config["k2"] else 0)
            def tensor(shape, dtype, stride=None):
                if stride is not None:
                    return torch.empty_strided(shape, stride, dtype=dtype, device="meta")
                return torch.empty(shape, dtype=dtype, device="meta")
            rows = config["blocks"] + 1
            if os.environ.get("MQSMLA_EXPORT_TRACE"):
                print(f"mqsmla export profile={profile} rows={rows}", flush=True)
            _get_compiled_kernel(
                tensor((1, config["bs"], 1, 544), torch.uint8,
                       (config["ori_page_stride"], 544, 544, 1)),
                tensor((rows, 1, config["k1"]), torch.int32),
                tensor((config["b"], config["s2_cap"] // config["bs"]), torch.int32),
                tensor((rows, 1), torch.int32) if has_ori_length else None,
                tensor((1, config["bs2"], 1, 320), torch.uint8,
                       (config["cmp_page_stride"], 320, 320, 1)) if config["k2"] else None,
                tensor((rows, 1, config["k2"]), torch.int32) if config["k2"] else None,
                tensor((config["b"], config["s2c_cap"] // config["bs2"]), torch.int32) if config["k2"] else None,
                tensor((rows, 1), torch.int32) if config["k2"] and has_cmp_length else None,
                tensor((1, rows, N1), torch.float32) if has_lse else None,
            )
    finally:
        clear_caches()
